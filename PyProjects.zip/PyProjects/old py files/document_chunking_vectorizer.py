import re
import logging
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass

# Assuming OpenAIEmbeddingClient is in the same package
from openai_embedding_client import OpenAIEmbeddingClient

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class DocumentChunk:
    """Represents a chunk of document content with its metadata."""
    chunk_id: str
    content: str
    topic: Optional[str] = None
    section_title: Optional[str] = None
    section_type: str = "general"
    start_position: int = 0
    end_position: int = 0
    chunk_index: int = 0
    word_count: int = 0
    char_count: int = 0
    
    def __post_init__(self):
        if self.word_count == 0:
            self.word_count = len(self.content.split())
        if self.char_count == 0:
            self.char_count = len(self.content)


@dataclass
class VectorizedChunk:
    """Document chunk with its vector embedding."""
    chunk: DocumentChunk
    embedding: List[float]
    embedding_model: str = "text-embedding-3-small"
    
    @property
    def dimension(self) -> int:
        return len(self.embedding) if self.embedding else 0


@dataclass
class DocumentVectorization:
    """Complete vectorization result for a document."""
    document_path: str
    chunks: List[VectorizedChunk]
    metadata_embedding: Optional[List[float]] = None
    vectorization_stats: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.vectorization_stats is None:
            self.vectorization_stats = {}


class DocumentChunkingAndVectorization:
    """
    Handles topic-aware chunking and OpenAI vectorization for hybrid RAG.
    
    Key features:
    - Chunks documents without crossing topic boundaries
    - Uses OpenAI embeddings API for vectorization
    - Maintains topic context for each chunk
    - Supports different chunking strategies
    """
    
    def __init__(self, 
                 chunk_size: int = 500,
                 chunk_overlap: int = 50,
                 min_chunk_size: int = 100,
                 embedding_model: str = "text-embedding-3-small"):
        """
        Initialize the chunking and vectorization system.
        
        Args:
            chunk_size: Target size for chunks (in characters)
            chunk_overlap: Overlap between chunks (in characters)
            min_chunk_size: Minimum chunk size to avoid tiny chunks
            embedding_model: OpenAI embedding model to use
        """
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.min_chunk_size = min_chunk_size
        self.embedding_model = embedding_model
        
        # Initialize OpenAI client
        self.embedding_client = OpenAIEmbeddingClient()
        
        logger.info(f"DocumentChunkingAndVectorization initialized: "
                   f"chunk_size={chunk_size}, model={embedding_model}")
    
    def chunk_and_vectorize_document(self, 
                                   content: str, 
                                   document_path: str,
                                   metadata_text: Optional[str] = None) -> DocumentVectorization:
        """
        Main method: Chunk document and vectorize all chunks.
        
        Args:
            content: Full document content
            document_path: Path to the document
            metadata_text: Optional metadata text to vectorize separately
            
        Returns:
            DocumentVectorization with all vectorized chunks
        """
        logger.info(f"Starting chunking and vectorization for: {document_path}")
        
        # Step 1: Parse document into topic-aware sections
        topic_sections = self._parse_topic_sections(content)
        logger.info(f"Parsed {len(topic_sections)} topic sections")
        
        # Step 2: Create chunks within each topic section
        all_chunks = []
        for section in topic_sections:
            section_chunks = self._chunk_section(section)
            all_chunks.extend(section_chunks)
        
        logger.info(f"Created {len(all_chunks)} chunks total")
        
        # Step 3: Vectorize all chunks using OpenAI
        vectorized_chunks = self._vectorize_chunks(all_chunks)
        
        # Step 4: Vectorize metadata if provided
        metadata_embedding = None
        if metadata_text:
            try:
                metadata_embedding = self.embedding_client.get_single_embedding(metadata_text)
                logger.debug("Metadata vectorized successfully")
            except Exception as e:
                logger.warning(f"Failed to vectorize metadata: {e}")
        
        # Step 5: Create vectorization result
        vectorization_result = DocumentVectorization(
            document_path=document_path,
            chunks=vectorized_chunks,
            metadata_embedding=metadata_embedding,
            vectorization_stats=self._calculate_stats(vectorized_chunks)
        )
        
        logger.info(f"Vectorization complete: {len(vectorized_chunks)} chunks, "
                   f"avg dimension: {vectorization_result.vectorization_stats.get('avg_dimension', 0)}")
        
        return vectorization_result
    
    def _parse_topic_sections(self, content: str) -> List[Dict[str, Any]]:
        """
        Parse document content into topic-aware sections.
        Each section represents a logical unit that should not be split across chunks.
        """
        sections = []
        lines = content.split('\n')
        
        current_section = {
            'topic': None,
            'section_title': None,
            'section_type': 'general',
            'content_lines': [],
            'start_line': 0
        }
        
        for i, line in enumerate(lines):
            # Check for topic comment: <!-- topic: TopicName -->
            topic_match = re.search(r'<!--\s*topic:\s*([^-]+)\s*-->', line)
            if topic_match:
                # Finish current section and start new one
                if current_section['content_lines']:
                    current_section['content'] = '\n'.join(current_section['content_lines']).strip()
                    current_section['end_line'] = i - 1
                    if current_section['content']:  # Only add non-empty sections
                        sections.append(current_section.copy())
                
                # Start new section with topic
                current_section = {
                    'topic': topic_match.group(1).strip(),
                    'section_title': None,
                    'section_type': 'topic_specific',
                    'content_lines': [],
                    'start_line': i + 1
                }
                continue
            
            # Check for section headers: ## Header or ### Header
            header_match = re.match(r'^(#{1,3})\s+(.+)', line)
            if header_match:
                # Finish current section if it has content
                if current_section['content_lines']:
                    current_section['content'] = '\n'.join(current_section['content_lines']).strip()
                    current_section['end_line'] = i - 1
                    if current_section['content']:
                        sections.append(current_section.copy())
                
                # Start new section with header
                header_title = header_match.group(2).strip()
                current_section = {
                    'topic': current_section.get('topic'),  # Inherit topic if set
                    'section_title': header_title,
                    'section_type': self._determine_section_type(header_title),
                    'content_lines': [line],  # Include header in content
                    'start_line': i
                }
                continue
            
            # Add line to current section
            if line.strip():  # Only add non-empty lines
                current_section['content_lines'].append(line)
        
        # Add the last section
        if current_section['content_lines']:
            current_section['content'] = '\n'.join(current_section['content_lines']).strip()
            current_section['end_line'] = len(lines) - 1
            if current_section['content']:
                sections.append(current_section)
        
        return sections
    
    def _chunk_section(self, section: Dict[str, Any]) -> List[DocumentChunk]:
        """
        Create chunks within a single topic section.
        Ensures chunks don't cross topic boundaries.
        """
        content = section['content']
        topic = section.get('topic')
        section_title = section.get('section_title')
        section_type = section.get('section_type', 'general')
        
        # If section is smaller than chunk_size, return as single chunk
        if len(content) <= self.chunk_size:
            return [DocumentChunk(
                chunk_id=f"{topic or 'unknown'}_{section_title or 'untitled'}_0",
                content=content,
                topic=topic,
                section_title=section_title,
                section_type=section_type,
                start_position=0,
                end_position=len(content),
                chunk_index=0,
                char_count=len(content)
            )]
        
        # Split large section into chunks
        chunks = []
        start = 0
        chunk_index = 0
        
        while start < len(content):
            # Determine chunk end position
            end = min(start + self.chunk_size, len(content))
            
            # If not at the end, try to break at a natural boundary
            if end < len(content):
                # Look for sentence endings, paragraph breaks, or other natural breaks
                for break_char in ['\n\n', '. ', '.\n', '\n']:
                    break_pos = content.rfind(break_char, start, end)
                    if break_pos > start + self.min_chunk_size:
                        end = break_pos + len(break_char)
                        break
            
            chunk_content = content[start:end].strip()
            
            if len(chunk_content) >= self.min_chunk_size or end == len(content):
                chunk_id = f"{topic or 'unknown'}_{section_title or 'untitled'}_{chunk_index}"
                
                chunks.append(DocumentChunk(
                    chunk_id=self._sanitize_chunk_id(chunk_id),
                    content=chunk_content,
                    topic=topic,
                    section_title=section_title,
                    section_type=section_type,
                    start_position=start,
                    end_position=end,
                    chunk_index=chunk_index,
                    char_count=len(chunk_content)
                ))
                
                chunk_index += 1
            
            # Move start position (with overlap)
            start = max(start + self.chunk_size - self.chunk_overlap, end)
        
        return chunks
    
    def _vectorize_chunks(self, chunks: List[DocumentChunk]) -> List[VectorizedChunk]:
        """
        Vectorize all chunks using OpenAI embeddings.
        Uses batch processing for efficiency.
        """
        if not chunks:
            return []
        
        try:
            # Extract texts for batch processing
            chunk_texts = [chunk.content for chunk in chunks]
            
            logger.info(f"Vectorizing {len(chunk_texts)} chunks using OpenAI API")
            
            # Get embeddings in batch
            embeddings = self.embedding_client.get_embeddings(chunk_texts)
            
            # Create vectorized chunks
            vectorized_chunks = []
            for chunk, embedding in zip(chunks, embeddings):
                vectorized_chunks.append(VectorizedChunk(
                    chunk=chunk,
                    embedding=embedding,
                    embedding_model=self.embedding_model
                ))
            
            logger.info(f"Successfully vectorized {len(vectorized_chunks)} chunks")
            return vectorized_chunks
            
        except Exception as e:
            logger.error(f"Batch vectorization failed: {e}")
            
            # Fallback: Vectorize one by one
            logger.info("Attempting individual vectorization as fallback")
            return self._vectorize_chunks_individually(chunks)
    
    def _vectorize_chunks_individually(self, chunks: List[DocumentChunk]) -> List[VectorizedChunk]:
        """Fallback: Vectorize chunks one by one if batch fails."""
        vectorized_chunks = []
        
        for i, chunk in enumerate(chunks):
            try:
                embedding = self.embedding_client.get_single_embedding(chunk.content)
                vectorized_chunks.append(VectorizedChunk(
                    chunk=chunk,
                    embedding=embedding,
                    embedding_model=self.embedding_model
                ))
                
                if (i + 1) % 10 == 0:
                    logger.info(f"Vectorized {i + 1}/{len(chunks)} chunks")
                    
            except Exception as e:
                logger.warning(f"Failed to vectorize chunk {chunk.chunk_id}: {e}")
                # Continue with other chunks
        
        return vectorized_chunks
    
    def _determine_section_type(self, section_title: str) -> str:
        """Determine section type from title."""
        title_lower = section_title.lower()
        
        type_keywords = {
            'overview': ['overview', 'introduction', 'summary'],
            'api_scope': ['api', 'scope', 'apiscope'],
            'security': ['security', 'auth', 'authentication', 'authorization'],
            'database': ['database', 'db', 'data', 'storage'],
            'external_api': ['external', 'integration', 'third-party'],
            'endpoints': ['endpoint', 'route', 'url', 'path'],
            'error_handling': ['error', 'exception', 'failure', 'troubleshoot']
        }
        
        for section_type, keywords in type_keywords.items():
            if any(keyword in title_lower for keyword in keywords):
                return section_type
        
        return 'general'
    
    def _sanitize_chunk_id(self, chunk_id: str) -> str:
        """Clean chunk ID for safe usage."""
        # Replace problematic characters with underscores
        sanitized = re.sub(r'[^a-zA-Z0-9_-]', '_', chunk_id)
        # Remove multiple consecutive underscores
        sanitized = re.sub(r'_+', '_', sanitized)
        # Remove leading/trailing underscores
        return sanitized.strip('_')
    
    def _calculate_stats(self, vectorized_chunks: List[VectorizedChunk]) -> Dict[str, Any]:
        """Calculate statistics about the vectorization process."""
        if not vectorized_chunks:
            return {}
        
        chunk_sizes = [chunk.chunk.char_count for chunk in vectorized_chunks]
        word_counts = [chunk.chunk.word_count for chunk in vectorized_chunks]
        dimensions = [chunk.dimension for chunk in vectorized_chunks if chunk.dimension > 0]
        
        # Count chunks by topic
        topic_counts = {}
        for chunk in vectorized_chunks:
            topic = chunk.chunk.topic or 'no_topic'
            topic_counts[topic] = topic_counts.get(topic, 0) + 1
        
        # Count chunks by section type
        type_counts = {}
        for chunk in vectorized_chunks:
            section_type = chunk.chunk.section_type
            type_counts[section_type] = type_counts.get(section_type, 0) + 1
        
        return {
            'total_chunks': len(vectorized_chunks),
            'avg_chunk_size': sum(chunk_sizes) / len(chunk_sizes),
            'min_chunk_size': min(chunk_sizes),
            'max_chunk_size': max(chunk_sizes),
            'avg_word_count': sum(word_counts) / len(word_counts),
            'avg_dimension': sum(dimensions) / len(dimensions) if dimensions else 0,
            'embedding_model': self.embedding_model,
            'chunks_by_topic': topic_counts,
            'chunks_by_type': type_counts,
            'successful_vectorizations': len([c for c in vectorized_chunks if c.embedding])
        }
    
    def get_chunk_summary(self, vectorization_result: DocumentVectorization) -> Dict[str, Any]:
        """Get a summary of the chunking and vectorization results."""
        return {
            'document_path': vectorization_result.document_path,
            'total_chunks': len(vectorization_result.chunks),
            'metadata_vectorized': vectorization_result.metadata_embedding is not None,
            'vectorization_stats': vectorization_result.vectorization_stats,
            'chunk_topics': list(set(c.chunk.topic for c in vectorization_result.chunks if c.chunk.topic)),
            'chunk_types': list(set(c.chunk.section_type for c in vectorization_result.chunks))
        }


# Example usage and testing
def main():
    """Demonstrate document chunking and vectorization."""
    print("=== Document Chunking and Vectorization Demo ===\n")
    
    # Sample document with topics
    sample_content = """---
title: "FinalizeSaleAPI Documentation"  
primary_topic: "FinalizeSaleAPI"  
tags: ["API", "subscription", "billing"]
---

# FinalizeSaleAPI Documentation

## Overview
The FinalizeSaleAPI is a critical component of the LEX SignUP process that completes sales and manages subscription activation.

## APIscope
<!-- topic: APIscope -->
This API finalizes sales and activates subscriptions with comprehensive error handling and security measures. The API handles multiple scenarios including credit repair products and standard subscriptions.

The finalization process involves several steps:
1. Validation of customer data
2. Processing payment information
3. Activating the subscription
4. Generating appropriate invoices

## ExternalAPICalls
<!-- topic: ExternalAPICalls -->
The API integrates with external services for enhanced functionality including Avalara for tax calculations and various payment processors.

### Avalara Integration
- Tax calculation for all invoice-generating transactions
- Fallback mechanisms for service unavailability
- Retry logic with configurable intervals

## APISecurity
<!-- topic: APISecurity -->
Security implementation follows company standards with Spring Security Framework and proper authentication mechanisms.

### Authentication Requirements
- Basic Auth for all endpoints
- Required roles for read and write operations
- Content-Type validation
- Security headers enforcement
"""
    
    try:
        # Initialize chunker
        chunker = DocumentChunkingAndVectorization(
            chunk_size=300,  # Smaller chunks for demo
            chunk_overlap=50,
            min_chunk_size=100,
            embedding_model="text-embedding-3-small"
        )
        
        # Create metadata text
        metadata_text = "FinalizeSaleAPI documentation for LEX SignUP process API subscription billing"
        
        # Chunk and vectorize
        print("🔄 Processing document...")
        vectorization_result = chunker.chunk_and_vectorize_document(
            content=sample_content,
            document_path="./sample_finalize_sale_api.md",
            metadata_text=metadata_text
        )
        
        # Show results
        summary = chunker.get_chunk_summary(vectorization_result)
        print("\n📊 Chunking and Vectorization Summary:")
        print(f"   📄 Document: {summary['document_path']}")
        print(f"   🧩 Total chunks: {summary['total_chunks']}")
        print(f"   🏷️  Topics found: {summary['chunk_topics']}")
        print(f"   📝 Section types: {summary['chunk_types']}")
        print(f"   📊 Metadata vectorized: {summary['metadata_vectorized']}")
        
        print(f"\n📈 Vectorization Stats:")
        stats = summary['vectorization_stats']
        print(f"   📏 Avg chunk size: {stats.get('avg_chunk_size', 0):.0f} chars")
        print(f"   📐 Embedding dimension: {stats.get('avg_dimension', 0):.0f}")
        print(f"   🤖 Model: {stats.get('embedding_model', 'N/A')}")
        print(f"   ✅ Success rate: {stats.get('successful_vectorizations', 0)}/{stats.get('total_chunks', 0)}")
        
        print(f"\n🧩 Individual Chunks:")
        for i, vectorized_chunk in enumerate(vectorization_result.chunks[:3]):  # Show first 3
            chunk = vectorized_chunk.chunk
            print(f"   Chunk {i+1}:")
            print(f"     ID: {chunk.chunk_id}")
            print(f"     Topic: {chunk.topic or 'None'}")
            print(f"     Section: {chunk.section_title or 'N/A'}")
            print(f"     Size: {chunk.char_count} chars, {chunk.word_count} words")
            print(f"     Content preview: {chunk.content[:100]}...")
            print(f"     Vector dimension: {vectorized_chunk.dimension}")
            print()
        
        if len(vectorization_result.chunks) > 3:
            print(f"   ... and {len(vectorization_result.chunks) - 3} more chunks")
        
    except Exception as e:
        print(f"❌ Demo failed: {e}")
        print("Make sure OpenAIEmbeddingClient is properly implemented and configured")


if __name__ == "__main__":
    main()