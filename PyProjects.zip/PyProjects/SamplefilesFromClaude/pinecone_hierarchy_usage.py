import pinecone
from typing import List, Dict, Set
import openai

class PineconeRAGWithHierarchy:
    """RAG system using Pinecone with intelligent topic hierarchy expansion"""
    
    def __init__(self, pinecone_api_key: str, openai_api_key: str):
        # Initialize Pinecone
        pinecone.init(api_key=pinecone_api_key, environment="us-west1-gcp")
        self.index = pinecone.Index("company-docs")
        
        # Initialize OpenAI
        self.openai_client = openai.OpenAI(api_key=openai_api_key)
        
        # Load flattened hierarchy (this is the key!)
        self.flattened_hierarchy = self.load_flattened_hierarchy()
    
    def load_flattened_hierarchy(self) -> Dict:
        """Load the pre-computed flattened hierarchy"""
        return {
            "Brands": {
                "children": ["LEX", "CRCOM", "CCOM"],
                "parent": None,
                "level": 1
            },
            "LEX": {
                "children": ["BrandScope", "SignUP", "CreditPullProcess", "SubscriptionManagement"],
                "parent": "Brands", 
                "level": 2
            },
            "SignUP": {
                "children": ["CreateCustomerAPI", "CreateSubscriptionAPI", "CreateWalletAPI", "FinalizeSaleAPI"],
                "parent": "LEX",
                "level": 3
            },
            "FinalizeSaleAPI": {
                "children": ["APIscope", "ExternalAPICalls", "DBInteraction", "APISecurity"],
                "parent": "SignUP",
                "level": 4
            },
            "APIscope": {
                "children": [],
                "parent": "FinalizeSaleAPI",
                "level": 5
            },
            "DBInteraction": {
                "children": [],
                "parent": "FinalizeSaleAPI", 
                "level": 5
            },
            "ExternalAPICalls": {
                "children": [],
                "parent": "FinalizeSaleAPI",
                "level": 5
            },
            "APISecurity": {
                "children": [],
                "parent": "FinalizeSaleAPI",
                "level": 5
            }
            # ... rest of hierarchy
        }
    
    def expand_topics_for_pinecone_filter(self, user_topics: List[str], expansion_strategy: str = "comprehensive") -> Set[str]:
        """
        Expand topics for Pinecone single-stage filtering
        
        This is WHERE the flattened hierarchy is essential!
        """
        expanded_topics = set(user_topics)
        
        for topic in user_topics:
            if topic not in self.flattened_hierarchy:
                continue
                
            topic_info = self.flattened_hierarchy[topic]
            
            if expansion_strategy == "comprehensive":
                # Add parent chain (going up)
                current = topic
                while current and current in self.flattened_hierarchy:
                    parent = self.flattened_hierarchy[current]["parent"]
                    if parent:
                        expanded_topics.add(parent)
                        current = parent
                    else:
                        break
                
                # Add immediate children (going down 1 level)
                children = topic_info["children"]
                expanded_topics.update(children)
                
                # Add siblings (same parent)
                parent = topic_info["parent"]
                if parent and parent in self.flattened_hierarchy:
                    siblings = self.flattened_hierarchy[parent]["children"]
                    expanded_topics.update(siblings)
            
            elif expansion_strategy == "focused":
                # Only add immediate parent and children
                parent = topic_info["parent"]
                if parent:
                    expanded_topics.add(parent)
                expanded_topics.update(topic_info["children"])
            
            elif expansion_strategy == "contextual":
                # Add topics at same level (siblings) and immediate parent
                parent = topic_info["parent"] 
                if parent and parent in self.flattened_hierarchy:
                    expanded_topics.add(parent)
                    siblings = self.flattened_hierarchy[parent]["children"]
                    expanded_topics.update(siblings)
        
        return expanded_topics
    
    def detect_query_topics(self, query: str) -> List[str]:
        """Use LLM to detect topics in user query"""
        
        # Get available topics for context
        available_topics = list(self.flattened_hierarchy.keys())
        
        prompt = f"""
        Analyze this user query and identify relevant topics from our system.
        
        Query: "{query}"
        
        Available topics: {available_topics[:20]}  # Show subset to avoid token limits
        
        Return 1-3 most relevant topics as a JSON array.
        Example: ["APIscope", "DBInteraction"]
        """
        
        try:
            response = self.openai_client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1
            )
            
            # Parse response (simplified - add proper error handling)
            import json
            topics = json.loads(response.choices[0].message.content)
            return topics
        
        except Exception as e:
            print(f"Topic detection failed: {e}")
            return []
    
    def search(self, query: str, user_context: Dict = None) -> Dict:
        """
        Main search function - this is where hierarchy expansion happens!
        """
        
        print(f"🔍 User query: {query}")
        
        # Step 1: Detect topics in query
        detected_topics = self.detect_query_topics(query)
        print(f"📊 Detected topics: {detected_topics}")
        
        # Step 2: Expand topics using flattened hierarchy
        # THIS IS THE KEY STEP - we pre-compute ALL relevant topics for Pinecone
        expanded_topics = self.expand_topics_for_pinecone_filter(
            detected_topics, 
            expansion_strategy="comprehensive"
        )
        expanded_list = list(expanded_topics)
        print(f"🎯 Expanded topics for Pinecone: {expanded_list}")
        
        # Step 3: Generate query embedding
        query_embedding = self.get_embedding(query)
        
        # Step 4: Query Pinecone with expanded topics (single-stage filter)
        pinecone_results = self.index.query(
            vector=query_embedding,
            filter={
                "expanded_topics": {"$in": expanded_list}  # This is why we need expanded topics!
            },
            top_k=20,
            include_metadata=True
        )
        
        print(f"📄 Found {len(pinecone_results['matches'])} results from Pinecone")
        
        # Step 5: Post-process and rank results
        processed_results = self.post_process_results(pinecone_results, detected_topics, query)
        
        return {
            "query": query,
            "detected_topics": detected_topics,
            "expanded_topics": expanded_list,
            "results": processed_results,
            "total_found": len(processed_results)
        }
    
    def post_process_results(self, pinecone_results: Dict, original_topics: List[str], query: str) -> List[Dict]:
        """Post-process results to add relevance scoring"""
        
        processed = []
        
        for match in pinecone_results['matches']:
            metadata = match['metadata']
            
            # Calculate topic relevance score
            doc_topics = metadata.get('expanded_topics', [])
            topic_overlap = len(set(original_topics) & set(doc_topics))
            topic_score = topic_overlap / len(original_topics) if original_topics else 0
            
            # Combine with vector similarity
            vector_score = match['score']
            final_score = (vector_score * 0.7) + (topic_score * 0.3)
            
            processed.append({
                "content": metadata.get('content', ''),
                "title": metadata.get('title', ''),
                "topics": doc_topics,
                "vector_score": vector_score,
                "topic_score": topic_score,
                "final_score": final_score,
                "chunk_id": match['id']
            })
        
        # Sort by final score
        processed.sort(key=lambda x: x['final_score'], reverse=True)
        return processed[:10]  # Return top 10
    
    def get_embedding(self, text: str) -> List[float]:
        """Generate embedding for text"""
        response = self.openai_client.embeddings.create(
            model="text-embedding-3-large",
            input=text
        )
        return response.data[0].embedding

# DEMONSTRATION: Why hierarchy expansion is critical

def demonstrate_pinecone_hierarchy_usage():
    """Show the difference between with/without hierarchy expansion"""
    
    print("=== PINECONE QUERY COMPARISON ===")
    print()
    
    user_query = "How does API security work in our sales process?"
    detected_topics = ["APISecurity"]  # What LLM detects from query
    
    # Without hierarchy expansion (LIMITED RESULTS)
    print("❌ WITHOUT HIERARCHY EXPANSION:")
    print(f"Query: {user_query}")
    print(f"Detected topics: {detected_topics}")
    print(f"Pinecone filter: {{'expanded_topics': {{'$in': {detected_topics}}}}}")
    print("Result: Only finds documents explicitly tagged with 'APISecurity'")
    print("Missing: Documents about FinalizeSaleAPI, SignUP APIs, general security practices")
    print()
    
    # With hierarchy expansion (COMPREHENSIVE RESULTS)  
    print("✅ WITH HIERARCHY EXPANSION:")
    print(f"Query: {user_query}")
    print(f"Detected topics: {detected_topics}")
    
    # Simulate expansion
    expanded = {
        "APISecurity",           # Original
        "FinalizeSaleAPI",       # Parent
        "SignUP",               # Grandparent  
        "LEX",                  # Great-grandparent
        "APIscope",             # Sibling
        "ExternalAPICalls",     # Sibling
        "DBInteraction",        # Sibling
        "CreateCustomerAPI",    # Cousin (same grandparent)
        "CreateSubscriptionAPI" # Cousin
    }
    
    expanded_list = list(expanded)
    print(f"Expanded topics: {expanded_list}")
    print(f"Pinecone filter: {{'expanded_topics': {{'$in': {expanded_list}}}}}")
    print("Result: Finds ALL relevant documents about:")
    print("  - Specific APISecurity implementations")  
    print("  - APIs that have security sections (FinalizeSaleAPI, CreateCustomerAPI)")
    print("  - General SignUP and LEX security practices")
    print("  - Related API documentation that might mention security")
    print()
    
    print("📈 RESULT QUALITY:")
    print("Without expansion: 5-10 results, narrow focus")
    print("With expansion: 50+ results, comprehensive coverage, better context")

# Example usage
def main():
    # Initialize system
    rag_system = PineconeRAGWithHierarchy(
        pinecone_api_key="your-key",
        openai_api_key="your-key" 
    )
    
    # Example queries
    queries = [
        "How does API security work in FinalizeSaleAPI?",
        "What database interactions happen during signup?", 
        "Show me external API calls in LEX brand",
        "Security best practices for our APIs"
    ]
    
    for query in queries:
        print(f"\n{'='*60}")
        results = rag_system.search(query)
        
        print(f"Query: {results['query']}")
        print(f"Topics detected: {results['detected_topics']}")  
        print(f"Topics expanded: {results['expanded_topics']}")
        print(f"Results found: {results['total_found']}")
        
        for i, result in enumerate(results['results'][:3]):
            print(f"\n  Result {i+1}:")
            print(f"    Title: {result['title']}")
            print(f"    Score: {result['final_score']:.3f}")
            print(f"    Topics: {result['topics'][:5]}...")  # Show first 5 topics

if __name__ == "__main__":
    demonstrate_pinecone_hierarchy_usage()
