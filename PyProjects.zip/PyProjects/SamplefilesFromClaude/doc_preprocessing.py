import yaml
import re
from typing import Dict, List, Optional, Tuple
from pathlib import Path
import hashlib
from datetime import datetime
import openai
from dataclasses import dataclass
import json

@dataclass
class ProcessedChunk:
    chunk_id: str
    content: str
    topics: List[str]
    primary_topic: str
    metadata: Dict
    embedding: Optional[List[float]] = None

@dataclass
class DocumentMetadata:
    title: str
    topics: List[str]
    primary_topic: str
    department: str
    team: str
    created_by: str
    created_date: str
    file_path: str
    doc_hash: str

class DocumentProcessor:
    def __init__(self, openai_api_key: str):
        self.client = openai.OpenAI(api_key=openai_api_key)
        self.topic_hierarchy = self._load_topic_hierarchy()
        
    def _load_topic_hierarchy(self) -> Dict:
        """Load company-specific topic hierarchy"""
        return {
            "technology": {
                "aws": ["lambda", "ec2", "s3", "rds", "vpc"],
                "databases": ["postgresql", "mongodb", "redis"],
                "frontend": ["react", "vue", "angular"],
                "backend": ["python", "java", "nodejs"]
            },
            "processes": {
                "deployment": ["cicd", "docker", "kubernetes"],
                "security": ["auth", "encryption", "compliance"],
                "monitoring": ["logging", "metrics", "alerting"]
            }
        }
    
    def parse_markdown_document(self, file_path: str) -> Tuple[DocumentMetadata, str]:
        """Parse markdown document with YAML frontmatter"""
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Split frontmatter and content
        if content.startswith('---'):
            parts = content.split('---', 2)
            if len(parts) >= 3:
                frontmatter = yaml.safe_load(parts[1])
                doc_content = parts[2].strip()
            else:
                frontmatter = {}
                doc_content = content
        else:
            frontmatter = {}
            doc_content = content
            
        # Create document metadata
        metadata = DocumentMetadata(
            title=frontmatter.get('title', Path(file_path).stem),
            topics=frontmatter.get('topics', []),
            primary_topic=frontmatter.get('primary_topic', ''),
            department=frontmatter.get('department', ''),
            team=frontmatter.get('team', ''),
            created_by=frontmatter.get('created_by', ''),
            created_date=frontmatter.get('created_date', ''),
            file_path=file_path,
            doc_hash=hashlib.md5(content.encode()).hexdigest()
        )
        
        return metadata, doc_content
    
    def auto_detect_topics(self, content: str, existing_topics: List[str] = None) -> List[str]:
        """Auto-detect topics using LLM if not provided or to enhance existing ones"""
        
        # Create prompt for topic detection
        hierarchy_context = json.dumps(self.topic_hierarchy, indent=2)
        
        prompt = f"""
        Analyze the following document content and identify relevant topics based on our company's topic hierarchy.
        
        Company Topic Hierarchy:
        {hierarchy_context}
        
        Existing topics from document metadata: {existing_topics or "None"}
        
        Document content (first 2000 chars):
        {content[:2000]}...
        
        Instructions:
        1. Identify 3-7 most relevant topics from the hierarchy
        2. If existing topics are provided, enhance them but keep the main ones
        3. Include both broad categories and specific subtopics
        4. Return as JSON array of topic strings
        
        Response format: {{"topics": ["topic1", "topic2", ...]}}
        """
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1
            )
            
            result = json.loads(response.choices[0].message.content)
            detected_topics = result.get("topics", [])
            
            # Merge with existing topics
            if existing_topics:
                all_topics = list(set(existing_topics + detected_topics))
            else:
                all_topics = detected_topics
                
            return all_topics[:7]  # Limit to 7 topics max
            
        except Exception as e:
            print(f"Topic detection failed: {e}")
            return existing_topics or []
    
    def semantic_chunking(self, content: str, max_chunk_size: int = 600) -> List[str]:
        """Intelligent chunking based on document structure"""
        
        # Remove excessive whitespace
        content = re.sub(r'\n\s*\n', '\n\n', content)
        
        chunks = []
        
        # Split by headers first
        sections = re.split(r'\n(?=#+\s)', content)
        
        for section in sections:
            if not section.strip():
                continue
                
            # If section is small enough, keep as is
            if len(section.split()) <= max_chunk_size:
                chunks.append(section.strip())
            else:
                # Split large sections by paragraphs
                paragraphs = section.split('\n\n')
                current_chunk = ""
                
                for para in paragraphs:
                    # Check if adding this paragraph exceeds limit
                    test_chunk = current_chunk + "\n\n" + para if current_chunk else para
                    
                    if len(test_chunk.split()) <= max_chunk_size:
                        current_chunk = test_chunk
                    else:
                        # Save current chunk and start new one
                        if current_chunk:
                            chunks.append(current_chunk.strip())
                        current_chunk = para
                
                # Add remaining chunk
                if current_chunk:
                    chunks.append(current_chunk.strip())
        
        return [chunk for chunk in chunks if len(chunk.strip()) > 50]  # Filter tiny chunks
    
    def extract_inline_topics(self, chunk: str) -> List[str]:
        """Extract topics from inline comments like <!-- topic: security -->"""
        pattern = r'<!--\s*topic:\s*([^-]+)\s*-->'
        matches = re.findall(pattern, chunk, re.IGNORECASE)
        return [topic.strip() for topic in matches]
    
    def generate_embeddings(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for chunks"""
        try:
            response = self.client.embeddings.create(
                model="text-embedding-3-large",
                input=texts
            )
            return [item.embedding for item in response.data]
        except Exception as e:
            print(f"Embedding generation failed: {e}")
            return []
    
    def process_document(self, file_path: str) -> List[ProcessedChunk]:
        """Main processing pipeline"""
        
        # 1. Parse document
        doc_metadata, content = self.parse_markdown_document(file_path)
        
        # 2. Auto-detect/enhance topics
        enhanced_topics = self.auto_detect_topics(content, doc_metadata.topics)
        primary_topic = doc_metadata.primary_topic or (enhanced_topics[0] if enhanced_topics else "general")
        
        # 3. Chunk the document
        chunks = self.semantic_chunking(content)
        
        # 4. Process each chunk
        processed_chunks = []
        chunk_texts = []
        
        for i, chunk_content in enumerate(chunks):
            # Extract inline topics
            inline_topics = self.extract_inline_topics(chunk_content)
            
            # Combine document topics with inline topics
            chunk_topics = list(set(enhanced_topics + inline_topics))
            
            chunk_id = f"{doc_metadata.doc_hash}_{i}"
            
            # Prepare chunk metadata
            chunk_metadata = {
                "document_title": doc_metadata.title,
                "document_path": doc_metadata.file_path,
                "chunk_index": i,
                "total_chunks": len(chunks),
                "department": doc_metadata.department,
                "team": doc_metadata.team,
                "created_by": doc_metadata.created_by,
                "created_date": doc_metadata.created_date,
                "processed_date": datetime.now().isoformat(),
                "doc_hash": doc_metadata.doc_hash,
                "chunk_word_count": len(chunk_content.split()),
                "has_inline_topics": len(inline_topics) > 0
            }
            
            processed_chunk = ProcessedChunk(
                chunk_id=chunk_id,
                content=chunk_content,
                topics=chunk_topics,
                primary_topic=primary_topic,
                metadata=chunk_metadata
            )
            
            processed_chunks.append(processed_chunk)
            chunk_texts.append(chunk_content)
        
        # 5. Generate embeddings in batch
        embeddings = self.generate_embeddings(chunk_texts)
        
        # 6. Assign embeddings to chunks
        for i, embedding in enumerate(embeddings):
            if i < len(processed_chunks):
                processed_chunks[i].embedding = embedding
        
        return processed_chunks

# Usage example
def main():
    processor = DocumentProcessor(openai_api_key="your-api-key")
    
    # Process all markdown files in a directory
    docs_dir = Path("./company_docs")
    all_processed_chunks = []
    
    for md_file in docs_dir.glob("**/*.md"):
        print(f"Processing: {md_file}")
        try:
            chunks = processor.process_document(str(md_file))
            all_processed_chunks.extend(chunks)
            print(f"Generated {len(chunks)} chunks")
        except Exception as e:
            print(f"Error processing {md_file}: {e}")
    
    print(f"Total processed chunks: {len(all_processed_chunks)}")
    return all_processed_chunks

if __name__ == "__main__":
    processed_chunks = main()
