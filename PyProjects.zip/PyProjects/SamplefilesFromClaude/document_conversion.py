import yaml
import re
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, asdict
import json
from datetime import datetime

@dataclass
class DocumentStructure:
    """Standardized document structure after conversion"""
    metadata: Dict[str, Any]
    content: str
    sections: List[Dict[str, Any]]
    topics: List[str]
    inline_topics: Dict[str, List[str]]  # section_id -> topics
    
class DocumentConverter:
    """Converts various input formats to standardized structure"""
    
    def __init__(self, topic_hierarchy: Dict = None):
        self.topic_hierarchy = topic_hierarchy or {}
        self.required_metadata = [
            'title', 'created_by', 'department'
        ]
        self.optional_metadata = [
            'topics', 'primary_topic', 'team', 'classification', 
            'version', 'created_date', 'tags', 'related_docs'
        ]
    
    def detect_format(self, file_path: str) -> str:
        """Detect input document format"""
        path = Path(file_path)
        extension = path.suffix.lower()
        
        if extension == '.md':
            # Check if it has YAML frontmatter
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                if content.strip().startswith('---'):
                    return 'markdown_with_frontmatter'
                else:
                    return 'plain_markdown'
        
        elif extension == '.yaml' or extension == '.yml':
            return 'yaml'
        
        elif extension == '.txt':
            return 'plain_text'
        
        elif extension == '.json':
            return 'json'
        
        else:
            raise ValueError(f"Unsupported file format: {extension}")
    
    def convert_markdown_with_frontmatter(self, file_path: str) -> DocumentStructure:
        """Convert markdown with YAML frontmatter (RECOMMENDED FORMAT)"""
        
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Split frontmatter and content
        if content.startswith('---'):
            parts = content.split('---', 2)
            if len(parts) >= 3:
                frontmatter_raw = parts[1]
                markdown_content = parts[2].strip()
            else:
                raise ValueError("Invalid frontmatter format")
        else:
            raise ValueError("No frontmatter found")
        
        # Parse frontmatter
        try:
            metadata = yaml.safe_load(frontmatter_raw) or {}
        except yaml.YAMLError as e:
            raise ValueError(f"Invalid YAML frontmatter: {e}")
        
        # Validate and complete metadata
        metadata = self._validate_and_complete_metadata(metadata, file_path)
        
        # Parse content sections
        sections, inline_topics = self._parse_markdown_sections(markdown_content)
        
        # Extract topics
        topics = self._extract_all_topics(metadata, inline_topics)
        
        return DocumentStructure(
            metadata=metadata,
            content=markdown_content,
            sections=sections,
            topics=topics,
            inline_topics=inline_topics
        )
    
    def convert_plain_markdown(self, file_path: str) -> DocumentStructure:
        """Convert plain markdown (no frontmatter) - auto-generate metadata"""
        
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Generate basic metadata from file
        path = Path(file_path)
        auto_metadata = {
            'title': self._extract_title_from_content(content) or path.stem,
            'created_by': 'unknown@company.com',  # Could be detected from git
            'department': 'unknown',
            'classification': 'internal',
            'created_date': datetime.now().strftime('%Y-%m-%d'),
            'version': '1.0',
            'source_file': str(path),
            'auto_generated_metadata': True
        }
        
        # Validate and complete
        metadata = self._validate_and_complete_metadata(auto_metadata, file_path)
        
        # Parse sections
        sections, inline_topics = self._parse_markdown_sections(content)
        
        # Auto-detect topics (this would use LLM as in previous example)
        topics = self._auto_detect_topics(content, list(inline_topics.values()))
        metadata['topics'] = topics
        metadata['primary_topic'] = topics[0] if topics else 'general'
        
        return DocumentStructure(
            metadata=metadata,
            content=content,
            sections=sections,
            topics=topics,
            inline_topics=inline_topics
        )
    
    def convert_yaml_document(self, file_path: str) -> DocumentStructure:
        """Convert pure YAML document format"""
        
        with open(file_path, 'r', encoding='utf-8') as f:
            yaml_data = yaml.safe_load(f)
        
        if not isinstance(yaml_data, dict):
            raise ValueError("YAML document must be a dictionary")
        
        # Extract content and metadata
        content = yaml_data.get('content', '')
        metadata = {k: v for k, v in yaml_data.items() if k != 'content'}
        
        # Validate metadata
        metadata = self._validate_and_complete_metadata(metadata, file_path)
        
        # Since YAML content is usually plain text, treat as single section
        sections = [{
            'id': 'main',
            'title': metadata.get('title', 'Main Content'),
            'content': content,
            'level': 1
        }]
        
        # Extract topics
        topics = metadata.get('topics', [])
        inline_topics = {}
        
        return DocumentStructure(
            metadata=metadata,
            content=content,
            sections=sections,
            topics=topics,
            inline_topics=inline_topics
        )
    
    def _validate_and_complete_metadata(self, metadata: Dict, file_path: str) -> Dict:
        """Validate and complete metadata with defaults"""
        
        # Check required fields
        for field in self.required_metadata:
            if field not in metadata or not metadata[field]:
                if field == 'title':
                    metadata[field] = Path(file_path).stem
                elif field == 'created_by':
                    # Could extract from git blame or file owner
                    metadata[field] = 'unknown@company.com'
                elif field == 'department':
                    # Could be inferred from file path or config
                    metadata[field] = self._infer_department_from_path(file_path)
        
        # Set defaults for optional fields
        defaults = {
            'classification': 'internal',
            'version': '1.0',
            'created_date': datetime.now().strftime('%Y-%m-%d'),
            'topics': [],
            'tags': [],
            'related_docs': []
        }
        
        for field, default in defaults.items():
            if field not in metadata:
                metadata[field] = default
        
        # Ensure topics is a list
        if isinstance(metadata.get('topics'), str):
            metadata['topics'] = [metadata['topics']]
        
        # Set primary_topic if not specified
        if not metadata.get('primary_topic') and metadata.get('topics'):
            metadata['primary_topic'] = metadata['topics'][0]
        
        return metadata
    
    def _parse_markdown_sections(self, content: str) -> Tuple[List[Dict], Dict[str, List[str]]]:
        """Parse markdown into sections and extract inline topics"""
        
        sections = []
        inline_topics = {}
        
        # Split by headers
        lines = content.split('\n')
        current_section = None
        section_content = []
        section_topics = []
        
        for line in lines:
            # Check for headers
            header_match = re.match(r'^(#{1,6})\s+(.+)', line)
            
            if header_match:
                # Save previous section
                if current_section:
                    sections.append({
                        'id': current_section['id'],
                        'title': current_section['title'],
                        'content': '\n'.join(section_content).strip(),
                        'level': current_section['level']
                    })
                    
                    if section_topics:
                        inline_topics[current_section['id']] = section_topics
                
                # Start new section
                level = len(header_match.group(1))
                title = header_match.group(2).strip()
                section_id = re.sub(r'[^\w\s-]', '', title).strip().lower().replace(' ', '_')
                
                current_section = {
                    'id': section_id,
                    'title': title,
                    'level': level
                }
                section_content = []
                section_topics = []
                
            else:
                # Check for inline topic comments
                topic_matches = re.findall(r'<!--\s*topic:\s*([^-]+)\s*-->', line)
                if topic_matches:
                    for match in topic_matches:
                        topics = [t.strip() for t in match.split(',')]
                        section_topics.extend(topics)
                
                section_content.append(line)
        
        # Save last section
        if current_section:
            sections.append({
                'id': current_section['id'],
                'title': current_section['title'],
                'content': '\n'.join(section_content).strip(),
                'level': current_section['level']
            })
            
            if section_topics:
                inline_topics[current_section['id']] = section_topics
        
        return sections, inline_topics
    
    def _extract_title_from_content(self, content: str) -> Optional[str]:
        """Extract title from markdown content"""
        lines = content.split('\n')
        for line in lines:
            if line.strip().startswith('# '):
                return line.strip()[2:].strip()
        return None
    
    def _infer_department_from_path(self, file_path: str) -> str:
        """Infer department from file path"""
        path_parts = Path(file_path).parts
        
        # Common department mappings
        dept_mappings = {
            'engineering': ['eng', 'tech', 'dev', 'backend', 'frontend'],
            'product': ['product', 'pm'],
            'security': ['security', 'sec'],
            'sre': ['sre', 'ops', 'infra', 'infrastructure'],
            'data': ['data', 'analytics', 'ml', 'ai'],
            'sales': ['sales'],
            'marketing': ['marketing', 'mkt']
        }
        
        for dept, keywords in dept_mappings.items():
            for part in path_parts:
                if any(keyword in part.lower() for keyword in keywords):
                    return dept
        
        return 'general'
    
    def _extract_all_topics(self, metadata: Dict, inline_topics: Dict) -> List[str]:
        """Combine metadata topics with inline topics"""
        all_topics = set(metadata.get('topics', []))
        
        # Add inline topics
        for section_topics in inline_topics.values():
            all_topics.update(section_topics)
        
        return list(all_topics)
    
    def _auto_detect_topics(self, content: str, existing_topics: List[List[str]]) -> List[str]:
        """Auto-detect topics (placeholder - implement with LLM)"""
        # This would use the OpenAI API as shown in previous example
        # For now, return flattened existing topics or defaults
        
        flattened = []
        for topic_list in existing_topics:
            flattened.extend(topic_list)
        
        return list(set(flattened)) if flattened else ['general']
    
    def convert_to_standard_yaml(self, doc_structure: DocumentStructure) -> str:
        """Convert DocumentStructure to standardized YAML for storage"""
        
        yaml_doc = {
            'metadata': doc_structure.metadata,
            'content': doc_structure.content,
            'sections': doc_structure.sections,
            'topics': doc_structure.topics,
            'inline_topics': doc_structure.inline_topics,
            'processed_date': datetime.now().isoformat()
        }
        
        return yaml.dump(yaml_doc, default_flow_style=False, allow_unicode=True)
    
    def convert_document(self, file_path: str) -> DocumentStructure:
        """Main conversion method - auto-detects format and converts"""
        
        format_type = self.detect_format(file_path)
        
        print(f"Detected format: {format_type} for {file_path}")
        
        if format_type == 'markdown_with_frontmatter':
            return self.convert_markdown_with_frontmatter(file_path)
        elif format_type == 'plain_markdown':
            return self.convert_plain_markdown(file_path)
        elif format_type == 'yaml':
            return self.convert_yaml_document(file_path)
        else:
            raise ValueError(f"Conversion not implemented for format: {format_type}")

# Usage Example
def main():
    converter = DocumentConverter()
    
    # Example 1: Convert markdown with frontmatter (RECOMMENDED)
    doc1 = converter.convert_document("./docs/aws-lambda-guide.md")
    print("Converted document metadata:", doc1.metadata)
    print("Topics found:", doc1.topics)
    
    # Example 2: Convert plain markdown (auto-generate metadata)
    doc2 = converter.convert_document("./docs/legacy-doc.md")
    print("Auto-generated metadata:", doc2.metadata)
    
    # Example 3: Convert to standard YAML for storage
    standard_yaml = converter.convert_to_standard_yaml(doc1)
    
    # Save standardized version
    with open("./processed/aws-lambda-guide.yaml", "w") as f:
        f.write(standard_yaml)
    
    print("Conversion completed!")

if __name__ == "__main__":
    main()
