"""
Dual Topic Expansion Architecture
- Expansion during document ingestion (storage time)
- Expansion during query processing (search time)
"""

class DualExpansionRAGSystem:
    """RAG system with topic expansion at both ingestion and query time"""
    
    def __init__(self):
        self.flattened_hierarchy = self.load_hierarchy()
        self.pinecone_index = self.init_pinecone()
        self.openai_client = self.init_openai()
    
    def load_hierarchy(self):
        """Single source of truth - used by both ingestion and query"""
        return {
            "Brands": {"children": ["LEX", "CRCOM", "CCOM"], "parent": None, "level": 1},
            "LEX": {"children": ["SignUP", "SubscriptionManagement"], "parent": "Brands", "level": 2},
            "SignUP": {"children": ["CreateCustomerAPI", "FinalizeSaleAPI"], "parent": "LEX", "level": 3},
            "FinalizeSaleAPI": {"children": ["APIscope", "ExternalAPICalls", "DBInteraction", "APISecurity"], "parent": "SignUP", "level": 4},
            "APIscope": {"children": [], "parent": "FinalizeSaleAPI", "level": 5},
            "ExternalAPICalls": {"children": [], "parent": "FinalizeSaleAPI", "level": 5},
            "DBInteraction": {"children": [], "parent": "FinalizeSaleAPI", "level": 5},
            "APISecurity": {"children": [], "parent": "FinalizeSaleAPI", "level": 5},
            "CreateCustomerAPI": {"children": ["APIscope", "ExternalAPICalls", "DBInteraction", "APISecurity"], "parent": "SignUP", "level": 4},
        }
    
    def expand_topics(self, topics, context="both", max_levels=3):
        """
        Core expansion logic used by both ingestion and query
        
        Args:
            topics: List of topic strings to expand
            context: "ingestion", "query", or "both" - affects expansion strategy
            max_levels: How many hierarchy levels to traverse
        """
        expanded = set(topics)
        
        for topic in topics:
            if topic not in self.flattened_hierarchy:
                continue
                
            topic_info = self.flattened_hierarchy[topic]
            
            # Add ancestors (parent chain)
            current = topic
            levels_up = 0
            while current and levels_up < max_levels:
                parent = self.flattened_hierarchy.get(current, {}).get("parent")
                if parent:
                    expanded.add(parent)
                    current = parent
                    levels_up += 1
                else:
                    break
            
            # Add children (for broader context)
            if context in ["ingestion", "both"]:
                # During ingestion, add immediate children for discoverability
                children = topic_info.get("children", [])
                expanded.update(children)
            
            # Add siblings (same parent - related concepts)
            parent = topic_info.get("parent")
            if parent and parent in self.flattened_hierarchy:
                siblings = self.flattened_hierarchy[parent].get("children", [])
                # During query, be more selective about siblings
                if context == "query":
                    # Only add siblings for leaf nodes (most specific topics)
                    if not topic_info.get("children"):
                        expanded.update(siblings[:3])  # Limit to avoid noise
                else:
                    expanded.update(siblings)
        
        return list(expanded)
    
    # ==========================================
    # STAGE 1: DOCUMENT INGESTION (WRITE TIME)
    # ==========================================
    
    def ingest_document(self, document):
        """
        INGESTION-TIME EXPANSION
        Purpose: Pre-compute expanded topics for fast retrieval
        """
        print("📥 DOCUMENT INGESTION - Topic Expansion")
        print("=" * 50)
        
        # Extract original topics from document frontmatter
        original_topics = document["frontmatter_topics"]
        print(f"📄 Document: {document['title']}")
        print(f"🏷️  Original topics: {original_topics}")
        
        # EXPANSION AT INGESTION TIME
        # Goal: Make document discoverable through related topics
        expanded_topics_ingestion = self.expand_topics(
            original_topics, 
            context="ingestion",  # More liberal expansion for discoverability
            max_levels=3
        )
        
        print(f"🔄 Expanded topics (ingestion): {expanded_topics_ingestion}")
        print(f"📈 Expansion ratio: {len(original_topics)} → {len(expanded_topics_ingestion)} ({len(expanded_topics_ingestion)/len(original_topics):.1f}x)")
        
        # Create chunks
        chunks = self.create_document_chunks(document)
        
        # Store each chunk with expanded topics
        for i, chunk in enumerate(chunks):
            chunk_id = f"{document['id']}_chunk_{i}"
            
            # Generate embedding
            embedding = self.get_embedding(chunk["content"])
            
            # Store in Pinecone with PRE-EXPANDED topics
            vector_data = {
                "id": chunk_id,
                "values": embedding,
                "metadata": {
                    "content": chunk["content"],
                    "title": document["title"],
                    "original_topics": original_topics,           # What author specified
                    "expanded_topics": expanded_topics_ingestion, # Pre-computed for fast filtering
                    "primary_topic": original_topics[0] if original_topics else "general",
                    "department": document.get("department", "unknown"),
                    "chunk_index": i
                }
            }
            
            self.pinecone_index.upsert([vector_data])
            print(f"  ✅ Stored chunk {i}: {len(chunk['content'])} chars, {len(expanded_topics_ingestion)} topics")
        
        print(f"📊 Document ingestion complete: {len(chunks)} chunks stored\n")
        return len(chunks)
    
    # =========================================
    # STAGE 2: QUERY PROCESSING (READ TIME)  
    # =========================================
    
    def search(self, user_query, user_context=None):
        """
        QUERY-TIME EXPANSION  
        Purpose: Cast a wide net to find all relevant documents
        """
        print("🔍 QUERY PROCESSING - Topic Expansion")
        print("=" * 50)
        
        print(f"❓ User query: '{user_query}'")
        
        # Step 1: Detect topics in user query
        detected_topics = self.detect_query_topics(user_query)
        print(f"🤖 Detected topics: {detected_topics}")
        
        # EXPANSION AT QUERY TIME
        # Goal: Find all potentially relevant documents
        expanded_topics_query = self.expand_topics(
            detected_topics,
            context="query",  # More focused expansion to avoid noise
            max_levels=2
        )
        
        print(f"🎯 Expanded topics (query): {expanded_topics_query}")
        print(f"📈 Query expansion: {len(detected_topics)} → {len(expanded_topics_query)} ({len(expanded_topics_query)/len(detected_topics) if detected_topics else 0:.1f}x)")
        
        # Step 2: Search Pinecone using expanded topics
        query_embedding = self.get_embedding(user_query)
        
        # The magic happens here - query expansion matches ingestion expansion
        search_results = self.pinecone_index.query(
            vector=query_embedding,
            filter={"expanded_topics": {"$in": expanded_topics_query}},  # Matches pre-expanded topics
            top_k=20,
            include_metadata=True
        )
        
        print(f"📄 Pinecone results: {len(search_results['matches'])} documents found")
        
        # Step 3: Post-process and rank results
        final_results = self.post_process_results(
            search_results, 
            detected_topics, 
            expanded_topics_query,
            user_query
        )
        
        print(f"🏆 Final results: {len(final_results)} after post-processing\n")
        
        return {
            "query": user_query,
            "detected_topics": detected_topics,
            "expanded_topics": expanded_topics_query,
            "results": final_results
        }
    
    def post_process_results(self, pinecone_results, original_query_topics, expanded_query_topics, query_text):
        """Re-rank results based on topic relevance and content similarity"""
        
        processed_results = []
        
        for match in pinecone_results['matches']:
            metadata = match['metadata']
            
            # Calculate topic overlap scores
            doc_original_topics = set(metadata.get('original_topics', []))
            doc_expanded_topics = set(metadata.get('expanded_topics', []))
            
            # Higher score for exact topic matches
            exact_topic_score = len(set(original_query_topics) & doc_original_topics) / len(original_query_topics) if original_query_topics else 0
            
            # Medium score for expanded topic matches  
            expanded_topic_score = len(set(expanded_query_topics) & doc_expanded_topics) / len(expanded_query_topics) if expanded_query_topics else 0
            
            # Combine scores
            topic_relevance = (exact_topic_score * 0.7) + (expanded_topic_score * 0.3)
            vector_similarity = match['score']
            
            final_score = (vector_similarity * 0.6) + (topic_relevance * 0.4)
            
            processed_results.append({
                "content": metadata['content'][:300] + "...",  # Truncate for display
                "title": metadata['title'],
                "chunk_id": match['id'],
                "vector_score": vector_similarity,
                "topic_relevance": topic_relevance,
                "final_score": final_score,
                "doc_topics": metadata.get('original_topics', [])
            })
        
        # Sort by final score
        processed_results.sort(key=lambda x: x['final_score'], reverse=True)
        return processed_results[:10]  # Return top 10
    
    # Helper methods
    def create_document_chunks(self, document):
        """Split document into chunks"""
        content = document["content"]
        # Simple chunking - in real implementation, use semantic chunking
        chunks = []
        words = content.split()
        chunk_size = 300
        
        for i in range(0, len(words), chunk_size):
            chunk_words = words[i:i + chunk_size]
            chunks.append({
                "content": " ".join(chunk_words),
                "start_word": i,
                "end_word": min(i + chunk_size, len(words))
            })
        
        return chunks
    
    def detect_query_topics(self, query):
        """Detect topics in user query using LLM"""
        # Simplified - in real implementation, use OpenAI API
        query_lower = query.lower()
        detected = []
        
        # Simple keyword matching for demo
        if "security" in query_lower or "auth" in query_lower:
            detected.append("APISecurity")
        if "database" in query_lower or "db" in query_lower:
            detected.append("DBInteraction")  
        if "external" in query_lower or "integration" in query_lower:
            detected.append("ExternalAPICalls")
        if "api" in query_lower and "scope" in query_lower:
            detected.append("APIscope")
        if "finalize" in query_lower or "sale" in query_lower:
            detected.append("FinalizeSaleAPI")
        if "signup" in query_lower or "sign up" in query_lower:
            detected.append("SignUP")
            
        return detected or ["general"]
    
    def get_embedding(self, text):
        """Generate embedding for text"""
        # Placeholder - use actual OpenAI API
        return [0.1] * 1536
    
    def init_pinecone(self):
        """Initialize Pinecone client"""
        # Placeholder
        return type('MockIndex', (), {
            'upsert': lambda x: None,
            'query': lambda **kwargs: {
                'matches': [
                    {
                        'id': 'doc1_chunk_0',
                        'score': 0.85,
                        'metadata': {
                            'content': 'Mock content about API security...',
                            'title': 'FinalizeSaleAPI Documentation',
                            'original_topics': ['APISecurity'],
                            'expanded_topics': ['APISecurity', 'FinalizeSaleAPI', 'SignUP', 'LEX']
                        }
                    }
                ]
            }
        })()
    
    def init_openai(self):
        """Initialize OpenAI client"""
        # Placeholder
        return None


def demonstrate_dual_expansion():
    """Show the dual expansion in action"""
    
    print("🎯 DUAL TOPIC EXPANSION DEMONSTRATION")
    print("=" * 70)
    
    rag_system = DualExpansionRAGSystem()
    
    # Sample document for ingestion
    sample_document = {
        "id": "finalize_sale_api_doc",
        "title": "FinalizeSaleAPI Documentation", 
        "frontmatter_topics": ["APIscope", "ExternalAPICalls", "DBInteraction", "APISecurity"],
        "content": """
        # FinalizeSaleAPI Documentation
        
        ## APIscope
        This API finalizes sales and activates subscription. When it finalizes TU subscriptions 
        or for billing in advance subscriptions, finalize sale also creates invoices.
        
        ## ExternalAPICalls  
        To calculate taxes for invoices, it calls Avalara tax service with proper error handling
        and retry mechanisms for reliability.
        
        ## APISecurity
        SpringSecurity is used for API security with JWT token-based authentication and 
        role-based authorization for different user types.
        
        ## DBInteractions
        It updates Subscription table and optionally creates entries in 
        SubscriptionRecessionPeriodMappingTable with proper transaction management.
        """,
        "department": "engineering"
    }
    
    # STAGE 1: Ingest document (expansion happens here)
    print("STAGE 1: DOCUMENT INGESTION")
    chunks_created = rag_system.ingest_document(sample_document)
    
    print("\n" + "="*70 + "\n")
    
    # STAGE 2: Process queries (expansion happens here too)
    print("STAGE 2: QUERY PROCESSING")
    
    sample_queries = [
        "How does API security work in our sales process?",
        "What external integrations are used in FinalizeSale?", 
        "Database transaction handling in SignUP APIs"
    ]
    
    for query in sample_queries:
        results = rag_system.search(query)
        print(f"Query processed: {len(results['results'])} relevant results found\n")
    
    print("="*70)
    print("🎉 SUMMARY: WHY DUAL EXPANSION WORKS")
    print("="*70)
    print("""
    INGESTION TIME EXPANSION:
    ✅ Makes documents discoverable through related topics
    ✅ Pre-computes relationships for fast retrieval  
    ✅ Stores comprehensive topic coverage with each chunk
    ✅ Enables broad contextual search capabilities
    
    QUERY TIME EXPANSION: 
    ✅ Interprets user intent beyond literal keywords
    ✅ Finds documents through hierarchical relationships
    ✅ Matches against pre-expanded document topics
    ✅ Provides comprehensive, contextual results
    
    THE MAGIC:
    🔄 Query expansion matches ingestion expansion
    🎯 Maximum recall with high precision
    🚀 Fast retrieval (pre-computed relationships)
    📊 Rich context for better answers
    """)

if __name__ == "__main__":
    demonstrate_dual_expansion()
