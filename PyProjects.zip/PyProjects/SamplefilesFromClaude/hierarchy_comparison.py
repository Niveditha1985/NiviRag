# BEFORE: Nested hierarchy (human-friendly, algorithm-unfriendly)
nested_hierarchy = {
    "Brands": {
        "LEX": {
            "SignUP": {
                "FinalizeSaleAPI": [
                    "APIscope",
                    "ExternalAPICalls", 
                    "DBInteraction",
                    "APISecurity"
                ]
            }
        }
    }
}

# AFTER: Flattened hierarchy (algorithm-friendly)
flattened_hierarchy = {
    "Brands": {
        "children": ["LEX", "CRCOM", "CCOM"],
        "parent": None,
        "path": "Brands",
        "level": 1
    },
    "LEX": {
        "children": ["BrandScope", "SignUP", "CreditPullProcess", "SubscriptionManagement", "WalletManagement", "CreditRepair"],
        "parent": "Brands", 
        "path": "Brands.LEX",
        "level": 2
    },
    "SignUP": {
        "children": ["CreateCustomerAPI", "CreateSubscriptionAPI", "CreateWalletAPI", "FinalizeSaleAPI"],
        "parent": "LEX",
        "path": "Brands.LEX.SignUP", 
        "level": 3
    },
    "FinalizeSaleAPI": {
        "children": ["APIscope", "ExternalAPICalls", "DBInteraction", "APISecurity"],
        "parent": "SignUP",
        "path": "Brands.LEX.SignUP.FinalizeSaleAPI",
        "level": 4
    },
    "APIscope": {
        "children": [],
        "parent": "FinalizeSaleAPI",
        "path": "Brands.LEX.SignUP.FinalizeSaleAPI.APIscope", 
        "level": 5
    }
    # ... etc for all topics
}

# COMPARISON: Common RAG operations

def demonstrate_efficiency():
    """Show why flattening is essential for RAG operations"""
    
    print("=== OPERATION 1: Find all ancestors of 'APIscope' ===")
    
    # With nested structure (SLOW - requires tree traversal)
    def find_ancestors_nested(topic, hierarchy, current_path=[]):
        """Recursive search through nested structure - O(n) complexity"""
        for key, value in hierarchy.items():
            new_path = current_path + [key]
            
            if isinstance(value, list) and topic in value:
                return new_path
            elif isinstance(value, dict):
                result = find_ancestors_nested(topic, value, new_path)
                if result:
                    return result
        return None
    
    # With flattened structure (FAST - direct lookup)
    def find_ancestors_flat(topic, flat_hierarchy):
        """Direct lookup - O(1) complexity per level"""
        ancestors = []
        current = topic
        
        while current and current in flat_hierarchy:
            parent = flat_hierarchy[current]["parent"]
            if parent:
                ancestors.append(parent)
            current = parent
        
        return list(reversed(ancestors))
    
    # Results are the same, but performance is dramatically different
    nested_result = find_ancestors_nested("APIscope", nested_hierarchy)
    flat_result = find_ancestors_flat("APIscope", flattened_hierarchy)
    
    print(f"Nested approach: {nested_result}")
    print(f"Flat approach: {flat_result}")
    print()
    
    print("=== OPERATION 2: Expand topics for search ===")
    
    # Document has these topics
    document_topics = ["APIscope", "DBInteraction"]
    
    # With nested: Complex recursive traversal needed
    def expand_nested(topics, hierarchy):
        """Would require complex recursive logic"""
        # This gets very complicated...
        pass
    
    # With flattened: Simple and efficient
    def expand_flat(topics, flat_hierarchy, levels_up=2):
        """Simple expansion using flat structure"""
        expanded = set(topics)
        
        for topic in topics:
            if topic not in flat_hierarchy:
                continue
            
            # Add ancestors (going up the hierarchy)
            current = topic
            for _ in range(levels_up):
                parent = flat_hierarchy[current]["parent"]
                if parent:
                    expanded.add(parent)
                    current = parent
                else:
                    break
            
            # Add children (going down the hierarchy)  
            children = flat_hierarchy[topic]["children"]
            expanded.update(children)
        
        return expanded
    
    expanded_topics = expand_flat(document_topics, flattened_hierarchy)
    print(f"Original topics: {document_topics}")
    print(f"Expanded topics: {expanded_topics}")
    print()
    
    print("=== OPERATION 3: Topic similarity scoring ===")
    
    def calculate_topic_distance(topic1, topic2, flat_hierarchy):
        """Calculate relationship distance between topics"""
        
        if topic1 == topic2:
            return 0
        
        # Get paths for both topics
        path1 = flat_hierarchy.get(topic1, {}).get("path", "").split(".")
        path2 = flat_hierarchy.get(topic2, {}).get("path", "").split(".")
        
        # Find common ancestor
        common_length = 0
        for i in range(min(len(path1), len(path2))):
            if path1[i] == path2[i]:
                common_length += 1
            else:
                break
        
        # Distance = steps from topic1 to common ancestor + steps from common ancestor to topic2
        distance = (len(path1) - common_length) + (len(path2) - common_length)
        return distance
    
    # Example: How related are different topics?
    topics_to_compare = ["APIscope", "DBInteraction", "ExternalAPICalls", "CreateCustomerAPI", "WalletManagement"]
    
    print("Topic relationship distances:")
    base_topic = "APIscope"
    for topic in topics_to_compare:
        distance = calculate_topic_distance(base_topic, topic, flattened_hierarchy)
        print(f"  {base_topic} <-> {topic}: distance = {distance}")

# Run the demonstration
demonstrate_efficiency()

print("\n=== WHY THIS MATTERS FOR YOUR RAG SYSTEM ===")
print("""
1. SEARCH QUERY EXPANSION:
   - User searches for "APIscope"  
   - System quickly expands to related topics: ["FinalizeSaleAPI", "SignUP", "LEX", "ExternalAPICalls", "DBInteraction"]
   - Finds more relevant documents

2. DOCUMENT PROCESSING:
   - Document mentions "DBInteraction"
   - System instantly knows: Parent="FinalizeSaleAPI", Grandparent="SignUP" 
   - Adds hierarchical context to embeddings

3. SIMILARITY SCORING:
   - Documents about "APIscope" and "DBInteraction" get higher similarity scores
   - Both belong to "FinalizeSaleAPI" - they're closely related
   - Documents about "WalletManagement" get lower scores - more distant relationship

4. FILTERING & ROUTING:
   - User from "LEX" team gets prioritized results from LEX topics
   - Easy to filter by hierarchy level or branch
   - Can route questions to appropriate team based on topic ancestry

5. PERFORMANCE:
   - O(1) lookups instead of O(n) tree traversals
   - Critical when processing thousands of documents
   - Enables real-time query expansion
""")
