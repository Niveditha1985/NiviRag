from typing import Dict, List, Set, Optional
import json
import networkx as nx
from dataclasses import dataclass
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

@dataclass
class Topic:
    id: str
    name: str
    description: str
    parent: Optional[str] = None
    children: List[str] = None
    aliases: List[str] = None
    department: str = ""
    embedding: List[float] = None
    
    def __post_init__(self):
        if self.children is None:
            self.children = []
        if self.aliases is None:
            self.aliases = []

class TopicHierarchy:
    def __init__(self, config_file: str = None):
        self.topics: Dict[str, Topic] = {}
        self.graph = nx.DiGraph()
        
        if config_file:
            self.load_from_config(config_file)
        else:
            self._initialize_default_hierarchy()
    
    def _initialize_default_hierarchy(self):
        """Initialize with company-specific topic hierarchy"""
        
        # Define topics with hierarchy
        topic_definitions = [
            # Technology - Root
            ("technology", "Technology", "All technology-related topics", None, "engineering"),
            
            # AWS - Level 1
            ("aws", "Amazon Web Services", "AWS cloud services", "technology", "engineering"),
            ("databases", "Databases", "Database technologies", "technology", "engineering"),
            ("frontend", "Frontend Development", "Frontend technologies", "technology", "engineering"),
            ("backend", "Backend Development", "Backend technologies", "engineering", "engineering"),
            
            # AWS Services - Level 2
            ("lambda", "AWS Lambda", "Serverless functions", "aws", "engineering"),
            ("ec2", "Amazon EC2", "Virtual servers", "aws", "engineering"),
            ("s3", "Amazon S3", "Object storage", "aws", "engineering"),
            ("rds", "Amazon RDS", "Relational database service", "aws", "engineering"),
            ("vpc", "Amazon VPC", "Virtual private cloud", "aws", "engineering"),
            
            # Database Types - Level 2
            ("postgresql", "PostgreSQL", "Relational database", "databases", "engineering"),
            ("mongodb", "MongoDB", "Document database", "databases", "engineering"),
            ("redis", "Redis", "In-memory data store", "databases", "engineering"),
            
            # Process Topics
            ("processes", "Processes", "Company processes", None, "all"),
            ("deployment", "Deployment", "Software deployment", "processes", "engineering"),
            ("security", "Security", "Security practices", "processes", "security"),
            ("monitoring", "Monitoring", "System monitoring", "processes", "sre"),
        ]
        
        # Create topics
        for topic_id, name, description, parent, department in topic_definitions:
            topic = Topic(
                id=topic_id,
                name=name,
                description=description,
                parent=parent,
                department=department
            )
            self.add_topic(topic)
    
    def add_topic(self, topic: Topic):
        """Add a topic to the hierarchy"""
        self.topics[topic.id] = topic
        
        # Add to graph
        self.graph.add_node(topic.id, **topic.__dict__)
        
        # Add parent-child relationship
        if topic.parent:
            self.graph.add_edge(topic.parent, topic.id)
            # Update parent's children list
            if topic.parent in self.topics:
                self.topics[topic.parent].children.append(topic.id)
    
    def get_topic_path(self, topic_id: str) -> List[str]:
        """Get full path from root to topic"""
        if topic_id not in self.topics:
            return []
        
        path = []
        current = topic_id
        
        while current:
            path.insert(0, current)
            current = self.topics[current].parent
            
        return path
    
    def get_all_descendants(self, topic_id: str) -> Set[str]:
        """Get all descendant topics"""
        if topic_id not in self.graph:
            return set()
            
        return set(nx.descendants(self.graph, topic_id))
    
    def get_all_ancestors(self, topic_id: str) -> Set[str]:
        """Get all ancestor topics"""
        if topic_id not in self.graph:
            return set()
            
        return set(nx.ancestors(self.graph, topic_id))
    
    def get_related_topics(self, topic_id: str, max_distance: int = 2) -> Dict[str, int]:
        """Get related topics within specified graph distance"""
        if topic_id not in self.graph:
            return {}
        
        related = {}
        
        # Get topics within max_distance
        for node in self.graph.nodes():
            if node == topic_id:
                continue
                
            try:
                distance = nx.shortest_path_length(self.graph.to_undirected(), topic_id, node)
                if distance <= max_distance:
                    related[node] = distance
            except nx.NetworkXNoPath:
                continue
        
        return related
    
    def expand_topic_query(self, topics: List[str], include_children: bool = True, 
                          include_parents: bool = True) -> Set[str]:
        """Expand a list of topics to include related topics for better search"""
        expanded = set(topics)
        
        for topic in topics:
            if topic not in self.topics:
                continue
                
            # Add children
            if include_children:
                expanded.update(self.get_all_descendants(topic))
            
            # Add parents (but maybe limit to immediate parent)
            if include_parents:
                if self.topics[topic].parent:
                    expanded.add(self.topics[topic].parent)
        
        return expanded
    
    def compute_topic_embeddings(self, embedding_client):
        """Compute embeddings for all topics based on their descriptions"""
        
        for topic_id, topic in self.topics.items():
            # Create rich description including context
            context_parts = [
                f"Topic: {topic.name}",
                f"Description: {topic.description}",
            ]
            
            # Add parent context
            if topic.parent and topic.parent in self.topics:
                parent_name = self.topics[topic.parent].name
                context_parts.append(f"Parent category: {parent_name}")
            
            # Add children context
            if topic.children:
                children_names = [self.topics[child_id].name 
                                for child_id in topic.children 
                                if child_id in self.topics]
                if children_names:
                    context_parts.append(f"Includes: {', '.join(children_names)}")
            
            topic_context = "\n".join(context_parts)
            
            # Generate embedding
            try:
                response = embedding_client.embeddings.create(
                    model="text-embedding-3-large",
                    input=topic_context
                )
                topic.embedding = response.data[0].embedding
            except Exception as e:
                print(f"Failed to generate embedding for topic {topic_id}: {e}")
    
    def find_similar_topics(self, topic_id: str, threshold: float = 0.7) -> List[tuple]:
        """Find topics similar to given topic based on embedding similarity"""
        
        if topic_id not in self.topics or not self.topics[topic_id].embedding:
            return []
        
        target_embedding = np.array(self.topics[topic_id].embedding).reshape(1, -1)
        similar_topics = []
        
        for other_id, other_topic in self.topics.items():
            if other_id == topic_id or not other_topic.embedding:
                continue
            
            other_embedding = np.array(other_topic.embedding).reshape(1, -1)
            similarity = cosine_similarity(target_embedding, other_embedding)[0][0]
            
            if similarity >= threshold:
                similar_topics.append((other_id, similarity))
        
        # Sort by similarity descending
        similar_topics.sort(key=lambda x: x[1], reverse=True)
        return similar_topics
    
    def suggest_topics_for_content(self, content: str, embedding_client, top_k: int = 5) -> List[tuple]:
        """Suggest topics for given content based on embedding similarity"""
        
        # Generate embedding for content
        try:
            response = embedding_client.embeddings.create(
                model="text-embedding-3-large",
                input=content[:3000]  # Limit content length
            )
            content_embedding = np.array(response.data[0].embedding).reshape(1, -1)
        except Exception as e:
            print(f"Failed to generate embedding for content: {e}")
            return []
        
        topic_similarities = []
        
        for topic_id, topic in self.topics.items():
            if not topic.embedding:
                continue
            
            topic_embedding = np.array(topic.embedding).reshape(1, -1)
            similarity = cosine_similarity(content_embedding, topic_embedding)[0][0]
            topic_similarities.append((topic_id, similarity, topic.name))
        
        # Sort by similarity and return top_k
        topic_similarities.sort(key=lambda x: x[1], reverse=True)
        return topic_similarities[:top_k]
    
    def save_to_config(self, file_path: str):
        """Save hierarchy to JSON config file"""
        config = {
            "topics": {
                topic_id: {
                    "name": topic.name,
                    "description": topic.description,
                    "parent": topic.parent,
                    "children": topic.children,
                    "aliases": topic.aliases,
                    "department": topic.department,
                    "embedding": topic.embedding
                }
                for topic_id, topic in self.topics.items()
            }
        }
        
        with open(file_path, 'w') as f:
            json.dump(config, f, indent=2)
    
    def load_from_config(self, file_path: str):
        """Load hierarchy from JSON config file"""
        with open(file_path, 'r') as f:
            config = json.load(f)
        
        self.topics.clear()
        self.graph.clear()
        
        for topic_id, topic_data in config["topics"].items():
            topic = Topic(
                id=topic_id,
                name=topic_data["name"],
                description=topic_data["description"],
                parent=topic_data.get("parent"),
                children=topic_data.get("children", []),
                aliases=topic_data.get("aliases", []),
                department=topic_data.get("department", ""),
                embedding=topic_data.get("embedding")
            )
            self.add_topic(topic)

# Usage example
def main():
    import openai
    
    # Initialize hierarchy
    hierarchy = TopicHierarchy()
    
    # Set up OpenAI client
    client = openai.OpenAI(api_key="your-api-key")
    
    # Compute embeddings for all topics
    hierarchy.compute_topic_embeddings(client)
    
    # Example: Get expanded topics for search
    query_topics = ["aws", "security"]
    expanded_topics = hierarchy.expand_topic_query(query_topics)
    print(f"Expanded topics: {expanded_topics}")
    
    # Example: Suggest topics for content
    sample_content = "This document explains how to set up monitoring and alerting for Lambda functions in production environments."
    suggested_topics = hierarchy.suggest_topics_for_content(sample_content, client)
    print(f"Suggested topics: {suggested_topics}")
    
    # Save hierarchy
    hierarchy.save_to_config("topic_hierarchy.json")

if __name__ == "__main__":
    main()
