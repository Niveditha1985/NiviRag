#!/usr/bin/env python3

import os
import sys
from pathlib import Path
import asyncio
import aiofiles
from typing import List, Dict, Any
import logging
from dataclasses import dataclass
import hashlib

# Import your custom modules
from document_converter import DocumentConverter, DocumentStructure
from document_processor import DocumentProcessor
from topic_hierarchy import TopicHierarchy

@dataclass
class ProcessingResult:
    success: bool
    file_path: str
    chunks_created: int
    topics_detected: List[str]
    error_message: str = ""

class DocumentPipelineOrchestrator:
    """
    Complete pipeline orchestrator that handles:
    1. Format detection and conversion
    2. Topic enhancement
    3. Chunking and embedding generation
    4. Vector database storage
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.setup_logging()
        
        # Initialize components
        self.topic_hierarchy = TopicHierarchy(config.get('topic_hierarchy_file'))
        self.converter = DocumentConverter(self.topic_hierarchy.topics)
        self.processor = DocumentProcessor(config['openai_api_key'])
        
        # Storage clients (will be initialized based on config)
        self.vector_db = self._init_vector_db()
        self.document_store = self._init_document_store()
        
    def setup_logging(self):
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)
    
    def _init_vector_db(self):
        """Initialize vector database client"""
        db_type = self.config.get('vector_db_type', 'pinecone')
        
        if db_type == 'pinecone':
            import pinecone
            pinecone.init(
                api_key=self.config['pinecone_api_key'],
                environment=self.config['pinecone_environment']
            )
            return pinecone.Index(self.config['pinecone_index_name'])
            
        elif db_type == 'opensearch':
            from opensearchpy import OpenSearch
            return OpenSearch(
                hosts=[self.config['opensearch_host']],
                http_auth=(self.config['opensearch_user'], self.config['opensearch_password']),
                use_ssl=True,
                verify_certs=True
            )
        else:
            raise ValueError(f"Unsupported vector DB type: {db_type}")
    
    def _init_document_store(self):
        """Initialize document storage (for full text + metadata)"""
        store_type = self.config.get('document_store_type', 'postgresql')
        
        if store_type == 'postgresql':
            import psycopg2
            return psycopg2.connect(
                host=self.config['postgres_host'],
                database=self.config['postgres_db'],
                user=self.config['postgres_user'],
                password=self.config['postgres_password']
            )
        # Add other storage options as needed
        
        return None
    
    async def process_single_document(self, file_path: str) -> ProcessingResult:
        """Process a single document through the complete pipeline"""
        
        try:
            self.logger.info(f"Processing document: {file_path}")
            
            # Step 1: Convert to standard format
            doc_structure = self.converter.convert_document(file_path)
            
            # Step 2: Enhance topics using hierarchy and LLM
            enhanced_topics = await self._enhance_topics(doc_structure)
            doc_structure.topics = enhanced_topics
            
            # Step 3: Generate chunks and embeddings
            processed_chunks = await self._generate_chunks_and_embeddings(doc_structure)
            
            # Step 4: Store in vector database
            await self._store_vectors(processed_chunks)
            
            # Step 5: Store document metadata and full text
            await self._store_document_metadata(doc_structure, file_path)
            
            self.logger.info(f"Successfully processed {file_path}: {len(processed_chunks)} chunks created")
            
            return ProcessingResult(
                success=True,
                file_path=file_path,
                chunks_created=len(processed_chunks),
                topics_detected=enhanced_topics
            )
            
        except Exception as e:
            self.logger.error(f"Error processing {file_path}: {str(e)}")
            return ProcessingResult(
                success=False,
                file_path=file_path,
                chunks_created=0,
                topics_detected=[],
                error_message=str(e)
            )
    
    async def _enhance_topics(self, doc_structure: DocumentStructure) -> List[str]:
        """Enhance topics using hierarchy and LLM detection"""
        
        # Start with existing topics
        current_topics = set(doc_structure.topics)
        
        # Add inline topics
        for section_topics in doc_structure.inline_topics.values():
            current_topics.update(section_topics)
        
        # Use LLM to detect additional topics
        if self.config.get('auto_detect_topics', True):
            suggested_topics = self.processor.auto_detect_topics(
                doc_structure.content, 
                list(current_topics)
            )
            current_topics.update(suggested_topics)
        
        # Expand using hierarchy (add parent/child relationships)
        expanded_topics = self.topic_hierarchy.expand_topic_query(
            list(current_topics),
            include_children=False,  # Don't include children by default
            include_parents=True     # Include parents for better retrieval
        )
        
        return list(expanded_topics)
    
    async def _generate_chunks_and_embeddings(self, doc_structure: DocumentStructure) -> List[Any]:
        """Generate chunks and embeddings for document"""
        
        # Use the semantic chunking from DocumentProcessor
        chunks = self.processor.semantic_chunking(doc_structure.content)
        
        processed_chunks = []
        
        for i, chunk_content in enumerate(chunks):
            # Determine chunk topics (inherit from document + section-specific)
            chunk_topics = doc_structure.topics.copy()
            
            # Add section-specific topics if this chunk belongs to a specific section
            chunk_section = self._find_chunk_section(chunk_content, doc_structure.sections)
            if chunk_section and chunk_section['id'] in doc_structure.inline_topics:
                chunk_topics.extend(doc_structure.inline_topics[chunk_section['id']])
            
            chunk_id = f"{hashlib.md5(doc_structure.content.encode()).hexdigest()}_{i}"
            
            chunk_metadata = {
                **doc_structure.metadata,
                'chunk_index': i,
                'total_chunks': len(chunks),
                'chunk_section': chunk_section['title'] if chunk_section else 'main',
                'chunk_topics': list(set(chunk_topics)),
                'processed_date': doc_structure.metadata.get('processed_date')
            }
            
            # Generate embedding
            embedding = await self._generate_embedding(chunk_content)
            
            processed_chunk = {
                'chunk_id': chunk_id,
                'content': chunk_content,
                'embedding': embedding,
                'topics': list(set(chunk_topics)),
                'primary_topic': doc_structure.metadata.get('primary_topic', chunk_topics[0] if chunk_topics else 'general'),
                'metadata': chunk_metadata
            }
            
            processed_chunks.append(processed_chunk)
        
        return processed_chunks
    
    def _find_chunk_section(self, chunk_content: str, sections: List[Dict]) -> Dict:
        """Find which section a chunk belongs to"""
        # Simple implementation - could be more sophisticated
        for section in sections:
            if chunk_content.strip().startswith(section['content'][:50]):
                return section
        return None
    
    async def _generate_embedding(self, text: str) -> List[float]:
        """Generate embedding for text"""
        try:
            response = await self.processor.client.embeddings.acreate(
                model="text-embedding-3-large",
                input=text
            )
            return response.data[0].embedding
        except Exception as e:
            self.logger.error(f"Failed to generate embedding: {e}")
            return []
    
    async def _store_vectors(self, processed_chunks: List[Dict]):
        """Store vectors in vector database"""
        
        if self.config.get('vector_db_type') == 'pinecone':
            await self._store_in_pinecone(processed_chunks)
        elif self.config.get('vector_db_type') == 'opensearch':
            await self._store_in_opensearch(processed_chunks)
    
    async def _store_in_pinecone(self, processed_chunks: List[Dict]):
        """Store chunks in Pinecone"""
        
        vectors_to_upsert = []
        
        for chunk in processed_chunks:
            # Pinecone format
            vector_data = {
                'id': chunk['chunk_id'],
                'values': chunk['embedding'],
                'metadata': {
                    # Pinecone metadata (limited to 40KB)
                    'content': chunk['content'][:2000],  # Truncate if needed
                    'topics': chunk['topics'],
                    'primary_topic': chunk['primary_topic'],
                    'title': chunk['metadata']['title'],
                    'department': chunk['metadata']['department'],
                    'created_by': chunk['metadata']['created_by'],
                    'chunk_index': chunk['metadata']['chunk_index']
                }
            }
            vectors_to_upsert.append(vector_data)
        
        # Batch upsert
        if vectors_to_upsert:
            self.vector_db.upsert(vectors_to_upsert)
            self.logger.info(f"Stored {len(vectors_to_upsert)} vectors in Pinecone")
    
    async def _store_in_opensearch(self, processed_chunks: List[Dict]):
        """Store chunks in OpenSearch"""
        
        for chunk in processed_chunks:
            doc = {
                'content': chunk['content'],
                'embedding': chunk['embedding'],
                'topics': chunk['topics'],
                'primary_topic': chunk['primary_topic'],
                'metadata': chunk['metadata']
            }
            
            self.vector_db.index(
                index='company-documents',
                id=chunk['chunk_id'],
                body=doc
            )
        
        self.logger.info(f"Stored {len(processed_chunks)} documents in OpenSearch")
    
    async def _store_document_metadata(self, doc_structure: DocumentStructure, file_path: str):
        """Store full document metadata and content"""
        
        if self.document_store is None:
            return
        
        # Store in PostgreSQL (example)
        cursor = self.document_store.cursor()
        
        insert_query = """
        INSERT INTO documents (
            file_path, title, content, topics, metadata, processed_date
        ) VALUES (%s, %s, %s, %s, %s, %s)
        ON CONFLICT (file_path) DO UPDATE SET
            content = EXCLUDED.content,
            topics = EXCLUDED.topics,
            metadata = EXCLUDED.metadata,
            processed_date = EXCLUDED.processed_date
        """
        
        cursor.execute(insert_query, (
            file_path,
            doc_structure.metadata['title'],
            doc_structure.content,
            doc_structure.topics,
            doc_structure.metadata,
            doc_structure.metadata.get('processed_date')
        ))
        
        self.document_store.commit()
        cursor.close()
    
    async def process_directory(self, directory_path: str) -> List[ProcessingResult]:
        """Process all documents in a directory"""
        
        results = []
        supported_extensions = {'.md', '.yaml', '.yml', '.txt'}
        
        for file_path in Path(directory_path).rglob('*'):
            if file_path.suffix.lower() in supported_extensions:
                result = await self.process_single_document(str(file_path))
                results.append(result)
        
        return results
    
    async def reprocess_changed_documents(self, directory_path: str) -> List[ProcessingResult]:
        """Process only documents that have changed since last processing"""
        
        # This would check file modification times against stored processing dates
        # Implementation depends on your document store
        pass

# Configuration example
def create_config():
    return {
        'openai_api_key': os.getenv('OPENAI_API_KEY'),
        'vector_db_type': 'pinecone',  # or 'opensearch'
        'pinecone_api_key': os.getenv('PINECONE_API_KEY'),
        'pinecone_environment': os.getenv('PINECONE_ENVIRONMENT'),
        'pinecone_index_name': 'company-docs',
        'document_store_type': 'postgresql',
        'postgres_host': os.getenv('POSTGRES_HOST'),
        'postgres_db': os.getenv('POSTGRES_DB'),
        'postgres_user': os.getenv('POSTGRES_USER'),
        'postgres_password': os.getenv('POSTGRES_PASSWORD'),
        'auto_detect_topics': True,
        'topic_hierarchy_file': './config/topic_hierarchy.json'
    }

async def main():
    """Main pipeline execution"""
    
    config = create_config()
    orchestrator = DocumentPipelineOrchestrator(config)
    
    # Process all documents in the docs directory
    results = await orchestrator.process_directory('./company_docs')
    
    # Print summary
    successful = sum(1 for r in results if r.success)
    failed = len(results) - successful
    total_chunks = sum(r.chunks_created for r in results)
    
    print(f"\nProcessing Summary:")
    print(f"Documents processed: {len(results)}")
    print(f"Successful: {successful}")
    print(f"Failed: {failed}")
    print(f"Total chunks created: {total_chunks}")
    
    if failed > 0:
        print("\nFailed documents:")
        for result in results:
            if not result.success:
                print(f"  - {result.file_path}: {result.error_message}")

if __name__ == "__main__":
    asyncio.run(main())