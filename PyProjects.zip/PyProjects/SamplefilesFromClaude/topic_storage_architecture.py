"""
Topic Hierarchy Storage Architecture for RAG System
"""

# SYSTEM LEVEL (ONE INSTANCE) - Shared across all documents
class TopicHierarchyManager:
    """Single source of truth for topic relationships"""
    
    def __init__(self):
        # This is calculated ONCE and cached in memory/Redis
        self.flattened_hierarchy = {
            "Brands": {
                "children": ["LEX", "CRCOM", "CCOM"],
                "parent": None,
                "path": "Brands",
                "level": 1
            },
            "LEX": {
                "children": ["BrandScope", "SignUP", "CreditPullProcess"],
                "parent": "Brands",
                "path": "Brands.LEX", 
                "level": 2
            },
            "FinalizeSaleAPI": {
                "children": ["APIscope", "ExternalAPICalls", "DBInteraction", "APISecurity"],
                "parent": "SignUP",
                "path": "Brands.LEX.SignUP.FinalizeSaleAPI",
                "level": 4
            },
            "APIscope": {
                "children": [],
                "parent": "FinalizeSaleAPI", 
                "path": "Brands.LEX.SignUP.FinalizeSaleAPI.APIscope",
                "level": 5
            }
            # ... all other topics
        }
        
    def expand_topics(self, document_topics):
        """Expand topics using the shared hierarchy"""
        expanded = set(document_topics)
        
        for topic in document_topics:
            if topic in self.flattened_hierarchy:
                # Add parent topics
                parent = self.flattened_hierarchy[topic]["parent"]
                if parent:
                    expanded.add(parent)
                
                # Add children topics
                children = self.flattened_hierarchy[topic]["children"]
                expanded.update(children)
        
        return list(expanded)

# DOCUMENT LEVEL - Only stores minimal topic references
class DocumentMetadata:
    """What gets stored with each document chunk"""
    
    def __init__(self, document_topics):
        # ONLY store the topics mentioned in the document
        self.original_topics = document_topics  # e.g., ["APIscope", "DBInteraction"]
        
        # Store expanded topics (calculated once during ingestion)
        topic_manager = TopicHierarchyManager()
        self.expanded_topics = topic_manager.expand_topics(document_topics)
        # e.g., ["APIscope", "DBInteraction", "FinalizeSaleAPI", "SignUP", "LEX"]
        
        # Other metadata
        self.title = "FinalizeSaleAPI Documentation"
        self.department = "engineering"
        self.created_by = "john.doe@company.com"
        # ... other fields

# STORAGE COMPARISON

print("❌ INEFFICIENT APPROACH (Don't do this):")
print("Each document stores full hierarchy = 1000s of documents × hierarchy = MASSIVE waste")
print()

inefficient_document = {
    "content": "API documentation...",
    "topics": ["APIscope"],
    "full_hierarchy": {  # ❌ DON'T DO THIS
        "Brands": {"children": ["LEX", "CRCOM"], "parent": None},
        "LEX": {"children": ["SignUP"], "parent": "Brands"},
        # ... entire hierarchy repeated for every document
    }
}

print("✅ EFFICIENT APPROACH (Do this):")
print("Single hierarchy shared + documents store only their specific topics")
print()

efficient_document = {
    "content": "API documentation...", 
    "original_topics": ["APIscope"],  # What was in the document
    "expanded_topics": ["APIscope", "FinalizeSaleAPI", "SignUP", "LEX"],  # Calculated once
    "primary_topic": "APIscope",
    "title": "FinalizeSaleAPI Documentation"
    # No hierarchy stored here!
}

# SYSTEM ARCHITECTURE DIAGRAM
print("""
SYSTEM ARCHITECTURE:

┌─────────────────────────┐
│   Topic Hierarchy       │  ← Single instance, loaded at startup
│   Manager               │    Cached in memory/Redis
│   (Flattened)          │    Used by all operations
└─────────────────────────┘
            ▲
            │ (references)
            ▼
┌─────────────────────────┐
│   Document 1            │  ← Only stores its specific topics
│   topics: ["APIscope"]  │    References shared hierarchy
└─────────────────────────┘

┌─────────────────────────┐
│   Document 2            │  ← Only stores its specific topics  
│   topics: ["DBQuery"]   │    References shared hierarchy
└─────────────────────────┘

┌─────────────────────────┐
│   Document N            │  ← Only stores its specific topics
│   topics: ["Security"]  │    References shared hierarchy  
└─────────────────────────┘

BENEFITS:
✅ Single source of truth
✅ Easy to update hierarchy globally
✅ Minimal storage per document
✅ Fast operations (hierarchy cached)
✅ Consistent across all documents
""")

# PRACTICAL IMPLEMENTATION

class RAGSystem:
    """Complete RAG system with proper topic management"""
    
    def __init__(self):
        # Load hierarchy once at startup
        self.topic_manager = TopicHierarchyManager()
        
        # Vector database client
        self.vector_db = self.init_vector_db()
    
    def process_document(self, document_content, document_topics):
        """Process a single document"""
        
        # Expand topics using shared hierarchy
        expanded_topics = self.topic_manager.expand_topics(document_topics)
        
        # Create chunks
        chunks = self.create_chunks(document_content)
        
        # Store each chunk
        for i, chunk in enumerate(chunks):
            chunk_metadata = {
                "chunk_id": f"doc_123_chunk_{i}",
                "original_topics": document_topics,      # From document frontmatter
                "expanded_topics": expanded_topics,      # Calculated using hierarchy
                "primary_topic": document_topics[0],     # First topic as primary
                # ... other metadata
            }
            
            # Store in vector DB (Pinecone example)
            self.vector_db.upsert([{
                "id": chunk_metadata["chunk_id"],
                "values": self.generate_embedding(chunk),
                "metadata": {
                    "content": chunk,
                    "topics": expanded_topics,  # For filtering
                    "primary_topic": chunk_metadata["primary_topic"],
                    # Note: NO hierarchy stored here!
                }
            }])
    
    def search(self, query, user_context=None):
        """Search with intelligent topic expansion"""
        
        # Detect topics in query
        query_topics = self.detect_query_topics(query)
        
        # Expand using shared hierarchy
        expanded_query_topics = self.topic_manager.expand_topics(query_topics)
        
        # Search vector DB with expanded topics
        results = self.vector_db.query(
            vector=self.generate_embedding(query),
            filter={"topics": {"$in": expanded_query_topics}},
            top_k=10
        )
        
        return results
    
    def update_hierarchy(self, new_hierarchy):
        """Update hierarchy globally - affects all future operations"""
        self.topic_manager.flattened_hierarchy = self.flatten_hierarchy(new_hierarchy)
        # All documents automatically benefit from new hierarchy
        # No need to update individual document metadata!

# MEMORY USAGE COMPARISON

def calculate_storage_savings():
    """Show the massive storage savings"""
    
    # Assume you have 10,000 documents
    num_documents = 10000
    
    # Hierarchy size (flattened)
    hierarchy_size_kb = 50  # Reasonable estimate for your hierarchy
    
    print("STORAGE COMPARISON:")
    print(f"Number of documents: {num_documents}")
    print(f"Hierarchy size: {hierarchy_size_kb} KB")
    print()
    
    # Inefficient approach
    inefficient_storage = num_documents * hierarchy_size_kb
    print(f"❌ Storing hierarchy in each document: {inefficient_storage} KB = {inefficient_storage/1024:.1f} MB")
    
    # Efficient approach  
    efficient_storage = hierarchy_size_kb + (num_documents * 2)  # 2KB per doc for topics
    print(f"✅ Shared hierarchy + topic refs: {efficient_storage} KB = {efficient_storage/1024:.1f} MB")
    
    savings = inefficient_storage - efficient_storage
    print(f"💰 Storage savings: {savings} KB = {savings/1024:.1f} MB ({savings/inefficient_storage*100:.1f}% reduction)")

calculate_storage_savings()
