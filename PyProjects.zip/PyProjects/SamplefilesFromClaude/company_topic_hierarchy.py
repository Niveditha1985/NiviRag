topics_hierarchy = {
    # Fixed typo and organized by business domains
    "Brands": {
        "LEX": {
            "BrandScope": [],
            "SignUP": {
                "CreateCustomerAPI": [
                    "APIscope",
                    "ExternalAPICalls", 
                    "DBInteraction",
                    "APISecurity"
                ],
                "CreateSubscriptionAPI": [
                    "APIscope",
                    "ExternalAPICalls",
                    "DBInteraction", 
                    "APISecurity"
                ],
                "CreateWalletAPI": [
                    "APIscope",
                    "ExternalAPICalls",
                    "DBInteraction",
                    "APISecurity"
                ],
                "FinalizeSaleAPI": [
                    "APIscope",
                    "ExternalAPICalls",
                    "DBInteraction",
                    "APISecurity"
                ]
            },
            "CreditPullProcess": [
                "APIscope",
                "ExternalAPICalls",
                "DBInteraction", 
                "APISecurity"
            ],
            "SubscriptionManagement": [
                "lifecycle",
                "billing", 
                "activation",
                "cancellation"
            ],
            "WalletManagement": [
                "payments",
                "transactions",
                "refunds",
                "balances"
            ],
            "CreditRepair": [
                "disputation",
                "monitoring", 
                "reporting",
                "compliance"
            ]
        },
        "CRCOM": {
            # Add CRCOM specific topics
        },
        "CCOM": {
            # Add CCOM specific topics  
        }
    },
    
    # Cross-cutting technical concerns
    "Technical": {
        "APISecurity": [
            "authentication",
            "authorization", 
            "encryption",
            "compliance"
        ],
        "DBInteraction": [
            "queries",
            "transactions",
            "performance",
            "migrations"
        ],
        "ExternalAPICalls": [
            "integrations",
            "errorhandling",
            "ratelimiting", 
            "monitoring"
        ],
        "APIscope": [
            "endpoints",
            "requests",
            "responses",
            "validation"
        ]
    },
    
    # Operational concerns
    "Operations": {
        "monitoring": [
            "metrics",
            "alerting",
            "logging",
            "tracing"
        ],
        "deployment": [
            "cicd",
            "infrastructure",
            "configuration",
            "scaling"
        ],
        "errorhandling": [
            "exceptions",
            "retries", 
            "fallbacks",
            "recovery"
        ]
    }
}

# Flattened version for easier processing
def flatten_hierarchy(hierarchy, parent_path=""):
    """Convert nested hierarchy to flat topic relationships"""
    relationships = {}
    
    for key, value in hierarchy.items():
        current_path = f"{parent_path}.{key}" if parent_path else key
        
        if isinstance(value, dict):
            # This is a parent topic
            relationships[key] = {
                "children": list(value.keys()),
                "parent": parent_path.split(".")[-1] if parent_path else None,
                "path": current_path,
                "level": len(current_path.split("."))
            }
            # Recursively process children
            child_relationships = flatten_hierarchy(value, current_path)
            relationships.update(child_relationships)
            
        elif isinstance(value, list):
            # These are leaf topics
            relationships[key] = {
                "children": value,
                "parent": parent_path.split(".")[-1] if parent_path else None, 
                "path": current_path,
                "level": len(current_path.split("."))
            }
            
            # Add leaf topics as well
            for leaf in value:
                relationships[leaf] = {
                    "children": [],
                    "parent": key,
                    "path": f"{current_path}.{leaf}",
                    "level": len(current_path.split(".")) + 1
                }
    
    return relationships

# Usage for your document processor
flattened_topics = flatten_hierarchy(topics_hierarchy)

# Enhanced topic expansion for better search
def expand_topics_for_search(query_topics, relationships, max_levels=2):
    """
    Expand topics for better search coverage
    
    Args:
        query_topics: List of topics from document
        relationships: Flattened topic relationships
        max_levels: How many levels up/down to include
    
    Returns:
        Set of expanded topics for search
    """
    expanded = set(query_topics)
    
    for topic in query_topics:
        if topic not in relationships:
            continue
            
        topic_info = relationships[topic]
        current_level = topic_info["level"]
        
        # Add parent topics (up to max_levels)
        parent = topic_info["parent"]
        levels_up = 0
        while parent and levels_up < max_levels:
            expanded.add(parent)
            if parent in relationships:
                parent = relationships[parent]["parent"]
                levels_up += 1
            else:
                break
        
        # Add child topics (up to max_levels) 
        def add_children(topic_name, current_depth):
            if current_depth >= max_levels or topic_name not in relationships:
                return
            
            children = relationships[topic_name]["children"]
            for child in children:
                expanded.add(child)
                add_children(child, current_depth + 1)
        
        add_children(topic, 0)
    
    return expanded

# Example usage with your document
document_topics = ["FinalizeSaleAPI", "APIscope", "ExternalAPICalls", "DBInteraction", "APISecurity"]
expanded_search_topics = expand_topics_for_search(document_topics, flattened_topics)

print("Original topics:", document_topics)
print("Expanded for search:", expanded_search_topics)

# This would output something like:
# Original topics: ['FinalizeSaleAPI', 'APIscope', 'ExternalAPICalls', 'DBInteraction', 'APISecurity']
# Expanded for search: {'FinalizeSaleAPI', 'APIscope', 'ExternalAPICalls', 'DBInteraction', 'APISecurity', 
#                       'SignUP', 'LEX', 'Technical', 'authentication', 'authorization', 'queries', 
#                       'transactions', 'integrations', 'endpoints', 'requests'}