# File Vector Processor

The `FileVectorProcessor` class provides a comprehensive solution for processing files, creating text chunks, generating vector embeddings via Anthropic API, and managing FAISS vector stores with metadata handling.

## Features

- **File Processing**: Automatically reads and processes various text file formats
- **Text Chunking**: Creates overlapping text chunks for better context preservation
- **Vector Embeddings**: Generates embeddings using OpenAI's text-embedding-3-small model
- **FAISS Integration**: Manages vector storage and similarity search
- **Metadata Handling**: Tracks file information, chunk positions, and processing details
- **Persistent Storage**: Automatically saves and loads vector stores
- **SSL Configuration**: Supports corporate SSL certificate configurations

## Installation

Ensure you have the required dependencies installed:

```bash
pip install -r requirements.txt
```

## Environment Setup

Create a `.env` file with your OpenAI API configuration:

```env
OPENAI_API_KEY=sk-your-openai-api-key-here
SSL_VERIFY=DEFAULT  # Options: NONE, DEFAULT, CUSTOM
ANTHROPIC_CA_BUNDLE_PATH=/path/to/ca-bundle.pem  # Required if SSL_VERIFY=CUSTOM
```

## Basic Usage

### 1. Initialize the Processor

```python
from file_vector_processor import FileVectorProcessor

# Create processor with default settings
processor = FileVectorProcessor()

# Or customize the configuration
processor = FileVectorProcessor(
    store_path="my_vector_store",
    chunk_size=1500,
    chunk_overlap=300
)
```

### 2. Process Files

```python
# Process a single file
success = processor.process_file("document.txt")

# Process multiple files
files = ["file1.txt", "file2.py", "document.md"]
for file_path in files:
    success = processor.process_file(file_path)
    if success:
        print(f"Successfully processed {file_path}")
```

### 3. Search for Similar Content

```python
# Search for similar content
query = "machine learning algorithms"
distances, indices, metadata = processor.search_similar(query, k=5)

# Display results
for i, (dist, idx, meta) in enumerate(zip(distances, indices, metadata)):
    if meta:
        print(f"Result {i+1}:")
        print(f"  File: {meta['file_name']}")
        print(f"  Chunk: {meta['chunk_index']}")
        print(f"  Distance: {dist:.4f}")
```

### 4. Add Vectors Directly

```python
# Add custom vectors to the index
vectors = [[0.1, 0.2, 0.3] * 512]  # 1536 dimensions
metadata = [{"source": "custom", "description": "sample vector"}]

success = processor.add_vectors_to_index(vectors, metadata=metadata)
```

### 5. Get Store Statistics

```python
# Get information about the vector store
stats = processor.get_store_stats()
print(f"Total vectors: {stats['total_vectors']}")
print(f"Store dimension: {stats['dimension']}")
print(f"Index type: {stats['index_type']}")
```

## File Format Support

The processor supports various text file formats:

- **Text files**: `.txt`, `.md`
- **Code files**: `.py`, `.js`, `.html`, `.css`
- **Data files**: `.json`, `.xml`
- **PDF files**: Basic support (requires additional libraries)

## Configuration Options

### Chunking Parameters

- `chunk_size`: Size of each text chunk in characters (default: 1000)
- `chunk_overlap`: Overlap between consecutive chunks (default: 200)

### Store Parameters

- `store_path`: Path for storing FAISS index and metadata files
- `index_type`: FAISS index type (default: "flat")
- `use_gpu`: Enable GPU acceleration if available

## Advanced Features

### SSL Configuration

The processor automatically handles SSL configuration based on your environment using the existing http_client_utils:

```python
# SSL_VERIFY=NONE: Disables SSL verification
# SSL_VERIFY=DEFAULT: Uses standard SSL verification
# SSL_VERIFY=CUSTOM: Uses corporate CA bundle
```

### Metadata Tracking

Each processed chunk includes comprehensive metadata:

```python
{
    "file_path": "/path/to/file.txt",
    "file_name": "file.txt",
    "file_extension": ".txt",
    "chunk_index": 0,
    "chunk_size": 1000,
    "chunk_start": 0,
    "chunk_end": 1000,
    "processing_timestamp": None
}
```

### Vector Store Management

The processor automatically handles:

- **New Store Creation**: Creates new FAISS index when no existing store is found
- **Store Loading**: Loads existing stores from `.metadata` files
- **Dimension Updates**: Automatically adjusts vector dimensions as needed
- **Persistent Storage**: Saves changes automatically after each operation

## Example Workflow

```python
from file_vector_processor import FileVectorProcessor

# 1. Initialize processor
processor = FileVectorProcessor(store_path="project_vectors")

# 2. Process project files
project_files = [
    "README.md",
    "src/main.py",
    "docs/architecture.md",
    "tests/test_main.py"
]

for file_path in project_files:
    processor.process_file(file_path)

# 3. Search for relevant code
query = "database connection configuration"
results = processor.search_similar(query, k=3)

# 4. Analyze results
for dist, idx, meta in zip(*results):
    if meta:
        print(f"Found in {meta['file_name']}, chunk {meta['chunk_index']}")
```

## Error Handling

The processor includes comprehensive error handling:

- **File Not Found**: Logs error and returns False
- **API Failures**: Falls back to zero vectors and logs warnings
- **Store Corruption**: Automatically creates new store if loading fails
- **Dimension Mismatches**: Automatically adjusts store dimensions

## Performance Considerations

- **Chunk Size**: Larger chunks provide more context but increase processing time
- **Overlap**: Higher overlap improves context but increases storage requirements
- **Batch Processing**: Process multiple files sequentially for better memory management
- **Vector Dimensions**: OpenAI text-embedding-3-small embeddings are 1536-dimensional by default

## Troubleshooting

### Common Issues

1. **API Key Error**: Ensure `OPENAI_API_KEY` is set in your `.env` file
2. **SSL Errors**: Check `SSL_VERIFY` setting and CA bundle path
3. **Memory Issues**: Reduce chunk size for large files
4. **Store Corruption**: Delete `.metadata` and `.faiss` files to recreate store

### Debug Mode

Enable detailed logging:

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

## API Reference

### FileVectorProcessor Class

#### Methods

- `__init__(store_path, chunk_size, chunk_overlap)`: Initialize processor
- `process_file(file_path)`: Process a file and add to vector store
- `add_vectors_to_index(vectors, vector_ids, metadata)`: Add vectors directly
- `search_similar(query_text, k)`: Search for similar content
- `get_store_stats()`: Get vector store statistics
- `clear_store()`: Clear all vectors from store

#### Properties

- `store_path`: Path to vector store files
- `chunk_size`: Size of text chunks
- `chunk_overlap`: Overlap between chunks
- `vector_store`: FAISS vector store instance

## Contributing

When contributing to this project:

1. Follow the existing code style
2. Add comprehensive error handling
3. Include logging for debugging
4. Update documentation for new features
5. Add tests for new functionality

## License

This project is part of the TestCaseAutomation suite and follows the same licensing terms. 