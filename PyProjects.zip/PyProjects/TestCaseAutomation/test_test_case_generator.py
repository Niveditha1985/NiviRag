#!/usr/bin/env python3
"""
Test cases for TestCaseGenerator

This module contains unit tests for the TestCaseGenerator class.
"""

import unittest
from unittest.mock import Mock, patch
import os
from test_case_generator import TestCaseGenerator


class TestTestCaseGenerator(unittest.TestCase):
    """Test cases for TestCaseGenerator class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.mock_api_key = "sk-ant-test-key"
        # Set up environment variable for testing
        os.environ["ANTHROPIC_API_KEY"] = self.mock_api_key
    
    def test_initialization(self):
        """Test TestCaseGenerator initialization."""
        with patch('test_case_generator.AnthropicLangChainIntegration'):
            generator = TestCaseGenerator()
            self.assertIsNotNone(generator)
    
    def test_initialization_without_api_key(self):
        """Test TestCaseGenerator initialization without API key."""
        # Remove API key from environment
        if "ANTHROPIC_API_KEY" in os.environ:
            del os.environ["ANTHROPIC_API_KEY"]
        
        with patch('test_case_generator.AnthropicLangChainIntegration'):
            with self.assertRaises(ValueError):
                TestCaseGenerator()
    
    @patch('test_case_generator.AnthropicLangChainIntegration')
    def test_generate_test_cases_basic(self, mock_integration):
        """Test basic test case generation with minimal inputs."""
        # Mock the integration
        mock_integration_instance = Mock()
        mock_integration_instance.run_chat_chain.return_value = "Generated test cases"
        mock_integration.return_value = mock_integration_instance
        
        generator = TestCaseGenerator()
        
        # Test with only requirements
        result = generator.generate_test_cases(
            requirements="User can login with email and password"
        )
        
        self.assertEqual(result, "Generated test cases")
        mock_integration_instance.run_chat_chain.assert_called_once()
        
        # Verify the call arguments
        call_args = mock_integration_instance.run_chat_chain.call_args
        self.assertIn("system_template", call_args[1])
        self.assertIn("human_template", call_args[1])
        self.assertIn("input_variables", call_args[1])
    
    @patch('test_case_generator.AnthropicLangChainIntegration')
    def test_generate_test_cases_with_all_inputs(self, mock_integration):
        """Test test case generation with all inputs provided."""
        mock_integration_instance = Mock()
        mock_integration_instance.run_chat_chain.return_value = "Complete test cases"
        mock_integration.return_value = mock_integration_instance
        
        generator = TestCaseGenerator()
        
        requirements = "User registration feature"
        business_rules = "Email must be verified\nPassword must be strong"
        existing_test_cases = "TC001: Login test\nTC002: Logout test"
        
        result = generator.generate_test_cases(
            requirements=requirements,
            business_rules=business_rules,
            existing_test_cases=existing_test_cases
        )
        
        self.assertEqual(result, "Complete test cases")
        
        # Verify input variables are correctly formatted
        call_args = mock_integration_instance.run_chat_chain.call_args
        input_vars = call_args[1]["input_variables"]
        
        self.assertEqual(input_vars["requirements"], requirements)
        self.assertIn("BUSINESS RULES:", input_vars["business_rules_section"])
        self.assertIn("Email must be verified", input_vars["business_rules_section"])
        self.assertIn("EXISTING TEST CASES", input_vars["existing_test_cases_section"])
        self.assertIn("TC001: Login test", input_vars["existing_test_cases_section"])
    
    @patch('test_case_generator.AnthropicLangChainIntegration')
    def test_generate_test_cases_with_json_output(self, mock_integration):
        """Test JSON output generation."""
        mock_integration_instance = Mock()
        expected_json = {
            "test_strategy": "Comprehensive testing approach",
            "test_cases": [
                {
                    "test_case_id": "TC001",
                    "title": "User Login Test",
                    "description": "Test user login functionality",
                    "preconditions": ["User is registered"],
                    "test_steps": ["Enter email", "Enter password", "Click login"],
                    "expected_results": ["User is logged in successfully"],
                    "priority": "High",
                    "test_type": "Functional"
                }
            ]
        }
        mock_integration_instance.generate_json_response.return_value = expected_json
        mock_integration.return_value = mock_integration_instance
        
        generator = TestCaseGenerator()
        
        result = generator.generate_test_cases_with_json_output(
            requirements="User login feature"
        )
        
        self.assertEqual(result, expected_json)
        mock_integration_instance.generate_json_response.assert_called_once()
    
    @patch('test_case_generator.AnthropicLangChainIntegration')
    def test_generate_test_cases_for_specific_type(self, mock_integration):
        """Test specific test type generation."""
        mock_integration_instance = Mock()
        mock_integration_instance.run_chat_chain.return_value = "API test cases"
        mock_integration.return_value = mock_integration_instance
        
        generator = TestCaseGenerator()
        
        result = generator.generate_test_cases_for_specific_type(
            requirements="API endpoint testing",
            test_type="API"
        )
        
        self.assertEqual(result, "API test cases")
        
        # Verify the system template includes the specific test type
        call_args = mock_integration_instance.run_chat_chain.call_args
        system_template = call_args[1]["system_template"]
        self.assertIn("API", system_template)
    
    @patch('test_case_generator.AnthropicLangChainIntegration')
    def test_error_handling(self, mock_integration):
        """Test error handling in test case generation."""
        mock_integration_instance = Mock()
        mock_integration_instance.run_chat_chain.return_value = "Error: API rate limit exceeded"
        mock_integration.return_value = mock_integration_instance
        
        generator = TestCaseGenerator()
        
        result = generator.generate_test_cases(
            requirements="Test requirements"
        )
        
        self.assertTrue(result.startswith("Error:")) 