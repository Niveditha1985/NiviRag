"""
Offline Test Case Generator - Fallback when API is overloaded

This module provides sample test cases when the Anthropic API is unavailable.
"""

def get_sample_test_cases(requirements: str, business_rules: str = None) -> str:
    """
    Generate sample test cases for demonstration purposes.
    
    Args:
        requirements (str): The requirements provided by the user
        business_rules (str, optional): Business rules provided by the user
        
    Returns:
        str: Sample test cases in Gherkin format
    """
    
    # Extract key information from requirements
    requirements_lower = requirements.lower()
    
    # Determine the type of functionality based on requirements
    if "api" in requirements_lower or "endpoint" in requirements_lower:
        return _get_api_test_cases(requirements, business_rules)
    elif "ui" in requirements_lower or "interface" in requirements_lower or "form" in requirements_lower:
        return _get_ui_test_cases(requirements, business_rules)
    elif "database" in requirements_lower or "table" in requirements_lower or "store" in requirements_lower:
        return _get_database_test_cases(requirements, business_rules)
    else:
        return _get_generic_test_cases(requirements, business_rules)

def _get_api_test_cases(requirements: str, business_rules: str = None) -> str:
    """Generate API-specific test cases."""
    
    return f"""
# Test Strategy Summary
This test strategy focuses on API testing for the specified requirements, covering functional validation, error handling, and edge cases.

## Test Cases

### Test Case ID: API_TC_001
**Title:** Valid API Request with Required Parameters
**Preconditions:** 
- API server is running and accessible
- Database is available
**Priority:** High
**Test Type:** API

**Test Steps:**
1. Send POST request to the API endpoint
2. Include all required parameters (first_name, last_name, email)
3. Include valid email format
4. Submit the request

**Expected Results:**
- HTTP 201 Created status code
- Response contains generated user_id
- User data is stored in database
- Email validation passes

---

### Test Case ID: API_TC_002
**Title:** API Request with Missing Required Parameters
**Preconditions:** 
- API server is running
**Priority:** High
**Test Type:** API

**Test Steps:**
1. Send POST request without first_name
2. Send POST request without last_name
3. Send POST request without email

**Expected Results:**
- HTTP 400 Bad Request status code
- Error message indicates missing required parameter
- No user record created in database

---

### Test Case ID: API_TC_003
**Title:** API Request with Invalid Email Format
**Preconditions:** 
- API server is running
**Priority:** Medium
**Test Type:** API

**Test Steps:**
1. Send POST request with invalid email format (e.g., "invalid-email")
2. Send POST request with email missing @ symbol
3. Send POST request with email missing domain

**Expected Results:**
- HTTP 400 Bad Request status code
- Error message indicates invalid email format
- No user record created in database

---

### Test Case ID: API_TC_004
**Title:** API Request with Duplicate Email
**Preconditions:** 
- API server is running
- User with email "test@example.com" already exists
**Priority:** High
**Test Type:** API

**Test Steps:**
1. Send POST request with email "test@example.com"
2. Include valid first_name and last_name

**Expected Results:**
- HTTP 409 Conflict status code
- Error message indicates email already exists
- No duplicate user record created

---

### Test Case ID: API_TC_005
**Title:** API Request with Valid Optional Phone Number
**Preconditions:** 
- API server is running
**Priority:** Medium
**Test Type:** API

**Test Steps:**
1. Send POST request with valid 10-digit phone number
2. Include all required parameters

**Expected Results:**
- HTTP 201 Created status code
- User record created with phone number
- Phone number validation passes

---

### Test Case ID: API_TC_006
**Title:** API Request with Invalid Phone Number Format
**Preconditions:** 
- API server is running
**Priority:** Medium
**Test Type:** API

**Test Steps:**
1. Send POST request with phone number less than 10 digits
2. Send POST request with phone number more than 10 digits
3. Send POST request with phone number containing letters

**Expected Results:**
- HTTP 400 Bad Request status code
- Error message indicates invalid phone number format
- No user record created

---

### Test Case ID: API_TC_007
**Title:** API Request with Boundary Values
**Preconditions:** 
- API server is running
**Priority:** Medium
**Test Type:** API

**Test Steps:**
1. Send POST request with very long first_name (100+ characters)
2. Send POST request with very long last_name (100+ characters)
3. Send POST request with very long email (254+ characters)

**Expected Results:**
- Appropriate validation of field lengths
- Either success (if within limits) or appropriate error message
- Database constraints respected

---

### Test Case ID: API_TC_008
**Title:** API Request with Special Characters
**Preconditions:** 
- API server is running
**Priority:** Low
**Test Type:** API

**Test Steps:**
1. Send POST request with special characters in names (e.g., "O'Connor", "José")
2. Send POST request with Unicode characters

**Expected Results:**
- Proper handling of special characters
- Data stored correctly in database
- No encoding issues

---

**Requirements Tested:** {requirements}

**Business Rules Considered:** {business_rules if business_rules else "None specified"}
"""

def _get_ui_test_cases(requirements: str, business_rules: str = None) -> str:
    """Generate UI-specific test cases."""
    
    return f"""
# Test Strategy Summary
This test strategy focuses on UI testing for the specified requirements, covering user interface interactions, form validation, and user experience.

## Test Cases

### Test Case ID: UI_TC_001
**Title:** Valid Form Submission with All Required Fields
**Preconditions:** 
- Application is accessible
- User is on the registration form page
**Priority:** High
**Test Type:** UI

**Test Steps:**
1. Navigate to the user registration form
2. Enter valid first name
3. Enter valid last name
4. Enter valid email address
5. Click Submit button

**Expected Results:**
- Form submits successfully
- Success message is displayed
- User is redirected to confirmation page
- User data is stored in database

---

### Test Case ID: UI_TC_002
**Title:** Form Validation for Required Fields
**Preconditions:** 
- User is on the registration form page
**Priority:** High
**Test Type:** UI

**Test Steps:**
1. Leave first name field empty and try to submit
2. Leave last name field empty and try to submit
3. Leave email field empty and try to submit

**Expected Results:**
- Form does not submit
- Error messages appear for empty required fields
- Focus moves to first empty required field

---

### Test Case ID: UI_TC_003
**Title:** Email Format Validation
**Preconditions:** 
- User is on the registration form page
**Priority:** Medium
**Test Type:** UI

**Test Steps:**
1. Enter invalid email format (e.g., "invalid-email")
2. Enter email without @ symbol
3. Enter email without domain
4. Try to submit form

**Expected Results:**
- Real-time validation shows error message
- Form does not submit
- Clear error message about invalid email format

---

### Test Case ID: UI_TC_004
**Title:** Phone Number Field Validation
**Preconditions:** 
- User is on the registration form page
**Priority:** Medium
**Test Type:** UI

**Test Steps:**
1. Enter phone number with less than 10 digits
2. Enter phone number with more than 10 digits
3. Enter phone number with letters
4. Try to submit form

**Expected Results:**
- Real-time validation shows error message
- Form does not submit
- Clear error message about invalid phone number format

---

### Test Case ID: UI_TC_005
**Title:** Duplicate Email Error Handling
**Preconditions:** 
- User is on the registration form page
- Email "test@example.com" already exists in system
**Priority:** High
**Test Type:** UI

**Test Steps:**
1. Enter email "test@example.com"
2. Fill in other required fields
3. Submit form

**Expected Results:**
- Error message displayed about email already existing
- Form remains on same page
- User can modify email and retry

---

### Test Case ID: UI_TC_006
**Title:** Responsive Design Testing
**Preconditions:** 
- Application is accessible
**Priority:** Medium
**Test Type:** UI

**Test Steps:**
1. Test form on desktop browser
2. Test form on tablet device
3. Test form on mobile device
4. Test form with different screen resolutions

**Expected Results:**
- Form displays correctly on all devices
- All form elements are accessible
- Submit button is clickable on all screen sizes

---

**Requirements Tested:** {requirements}

**Business Rules Considered:** {business_rules if business_rules else "None specified"}
"""

def _get_database_test_cases(requirements: str, business_rules: str = None) -> str:
    """Generate database-specific test cases."""
    
    return f"""
# Test Strategy Summary
This test strategy focuses on database testing for the specified requirements, covering data integrity, constraints, and storage operations.

## Test Cases

### Test Case ID: DB_TC_001
**Title:** Successful User Record Creation
**Preconditions:** 
- Database is accessible
- User table exists with proper schema
**Priority:** High
**Test Type:** Integration

**Test Steps:**
1. Execute user creation API call
2. Verify user record is created in database
3. Verify all required fields are stored correctly
4. Verify user_id is generated and unique

**Expected Results:**
- User record created successfully
- All data fields match input values
- user_id is unique and properly formatted
- Timestamps are set correctly

---

### Test Case ID: DB_TC_002
**Title:** Database Constraint Validation
**Preconditions:** 
- Database is accessible
- User table has proper constraints
**Priority:** High
**Test Type:** Integration

**Test Steps:**
1. Attempt to create user with NULL first_name
2. Attempt to create user with NULL last_name
3. Attempt to create user with NULL email
4. Attempt to create user with duplicate email

**Expected Results:**
- Database rejects NULL values for required fields
- Database rejects duplicate email addresses
- Proper error messages returned

---

### Test Case ID: DB_TC_003
**Title:** Data Type Validation
**Preconditions:** 
- Database is accessible
**Priority:** Medium
**Test Type:** Integration

**Test Steps:**
1. Verify email field accepts valid email format
2. Verify phone field accepts only numeric values
3. Verify name fields accept text with special characters
4. Verify field length constraints

**Expected Results:**
- Data types are properly validated
- Field length limits are enforced
- Special characters are handled correctly

---

### Test Case ID: DB_TC_004
**Title:** Transaction Rollback on Error
**Preconditions:** 
- Database is accessible
- Transaction management is enabled
**Priority:** Medium
**Test Type:** Integration

**Test Steps:**
1. Start user creation process
2. Introduce error during process
3. Verify transaction rollback

**Expected Results:**
- No partial data is committed
- Database remains in consistent state
- Error is properly handled

---

**Requirements Tested:** {requirements}

**Business Rules Considered:** {business_rules if business_rules else "None specified"}
"""

def _get_generic_test_cases(requirements: str, business_rules: str = None) -> str:
    """Generate generic test cases for any functionality."""
    
    return f"""
# Test Strategy Summary
This test strategy provides comprehensive testing coverage for the specified requirements, covering functional, non-functional, and edge case scenarios.

## Test Cases

### Test Case ID: GEN_TC_001
**Title:** Happy Path - Successful Operation
**Preconditions:** 
- System is available and accessible
- All required components are running
**Priority:** High
**Test Type:** Functional

**Test Steps:**
1. Prepare valid input data
2. Execute the main functionality
3. Verify the expected outcome

**Expected Results:**
- Operation completes successfully
- Expected output is generated
- System state is updated correctly

---

### Test Case ID: GEN_TC_002
**Title:** Input Validation - Required Fields
**Preconditions:** 
- System is available
**Priority:** High
**Test Type:** Functional

**Test Steps:**
1. Test with missing required field 1
2. Test with missing required field 2
3. Test with missing required field 3

**Expected Results:**
- System rejects invalid input
- Appropriate error messages are displayed
- No processing occurs with invalid data

---

### Test Case ID: GEN_TC_003
**Title:** Input Validation - Data Format
**Preconditions:** 
- System is available
**Priority:** Medium
**Test Type:** Functional

**Test Steps:**
1. Test with invalid data format for field 1
2. Test with invalid data format for field 2
3. Test with boundary values

**Expected Results:**
- System validates data format
- Error messages are clear and helpful
- Boundary conditions are handled properly

---

### Test Case ID: GEN_TC_004
**Title:** Error Handling
**Preconditions:** 
- System is available
**Priority:** Medium
**Test Type:** Functional

**Test Steps:**
1. Simulate network error
2. Simulate database error
3. Simulate timeout condition

**Expected Results:**
- Errors are caught and handled gracefully
- User receives meaningful error messages
- System remains stable

---

### Test Case ID: GEN_TC_005
**Title:** Performance Testing
**Preconditions:** 
- System is available
**Priority:** Medium
**Test Type:** Non-functional

**Test Steps:**
1. Test with normal load
2. Test with high load
3. Test response times

**Expected Results:**
- System performs within acceptable limits
- Response times are reasonable
- No degradation under load

---

**Requirements Tested:** {requirements}

**Business Rules Considered:** {business_rules if business_rules else "None specified"}
""" 