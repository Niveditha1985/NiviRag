#!/usr/bin/env python3
"""
Direct API Connection Test

This script tests the Anthropic API connection directly and provides detailed error information.
"""

import os
import traceback
from dotenv import load_dotenv

def test_direct_api_connection():
    """
    Test the API connection directly with detailed error reporting.
    """
    print("🔍 Testing Direct API Connection...")
    print("=" * 50)
    
    # Load environment variables
    load_dotenv()
    
    # Check API key
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        print("❌ API key not found in environment variables")
        return
    
    print(f"✅ API key found: {api_key[:8]}...{api_key[-4:]}")
    
    try:
        # Test 1: Basic import
        print("\n📦 Testing imports...")
        from langchain_anthropic import ChatAnthropic
        print("✅ LangChain Anthropic import successful")
        
        # Test 2: Initialize client
        print("\n🔧 Initializing Anthropic client...")
        llm = ChatAnthropic(
            anthropic_api_key=api_key,
            model="claude-3-5-sonnet-20241022",
            temperature=0.7,
            max_tokens=100
        )
        print("✅ Anthropic client initialized successfully")
        
        # Test 3: Simple API call
        print("\n📡 Making API call...")
        test_message = "Hello, this is a test message. Please respond with 'Test successful'."
        response = llm.invoke(test_message)
        print("✅ API call successful!")
        print(f"📝 Response: {response.content}")
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        print("💡 Try installing required packages: pip install langchain-anthropic")
        
    except Exception as e:
        print(f"❌ Error occurred: {type(e).__name__}")
        print(f"📝 Error message: {str(e)}")
        print(f"🔍 Full traceback:")
        print(traceback.format_exc())
        
        # Check for specific error types
        error_str = str(e).lower()
        if "certificate" in error_str or "ssl" in error_str:
            print("\n🔒 This appears to be a certificate/SSL error.")
            print("💡 Solutions:")
            print("   - Check your network/proxy settings")
            print("   - Try updating your certificates")
            print("   - Check if you're behind a corporate firewall")
            
        elif "timeout" in error_str:
            print("\n⏰ This appears to be a timeout error.")
            print("💡 Solutions:")
            print("   - Check your internet connection")
            print("   - Try again in a few minutes")
            print("   - Check if Anthropic API is experiencing issues")
            
        elif "unauthorized" in error_str or "401" in error_str:
            print("\n🔑 This appears to be an authentication error.")
            print("💡 Solutions:")
            print("   - Check if your API key is correct")
            print("   - Verify your API key has the necessary permissions")
            print("   - Check if your API key is active")
            
        elif "rate limit" in error_str or "429" in error_str:
            print("\n🚫 This appears to be a rate limit error.")
            print("💡 Solutions:")
            print("   - Wait a few minutes before trying again")
            print("   - Check your API usage limits")
            
        elif "connection" in error_str or "network" in error_str:
            print("\n🌐 This appears to be a network connection error.")
            print("💡 Solutions:")
            print("   - Check your internet connection")
            print("   - Try disabling VPN if you're using one")
            print("   - Check firewall settings")

def test_network_connectivity():
    """
    Test basic network connectivity to Anthropic's servers.
    """
    print("\n🌐 Testing Network Connectivity...")
    print("=" * 50)
    
    import socket
    import requests
    
    # Test basic internet connectivity
    try:
        response = requests.get("https://www.google.com", timeout=5)
        print("✅ Basic internet connectivity: OK")
    except Exception as e:
        print(f"❌ Basic internet connectivity failed: {e}")
        return
    
    # Test connection to Anthropic's API endpoint
    try:
        response = requests.get("https://api.anthropic.com", timeout=10)
        print("✅ Anthropic API endpoint reachable")
    except requests.exceptions.SSLError as e:
        print(f"❌ SSL/Certificate error connecting to Anthropic: {e}")
        print("💡 This might be a certificate issue")
    except requests.exceptions.ConnectionError as e:
        print(f"❌ Connection error to Anthropic: {e}")
        print("💡 This might be a network/firewall issue")
    except requests.exceptions.Timeout as e:
        print(f"❌ Timeout connecting to Anthropic: {e}")
        print("💡 This might be a network issue")
    except Exception as e:
        print(f"❌ Unexpected error connecting to Anthropic: {e}")

if __name__ == "__main__":
    test_network_connectivity()
    test_direct_api_connection() 