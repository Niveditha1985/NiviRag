# Vector Search Integration inTestCaseGenerator

## Overview

The `TestCaseGenerator` class has been enhanced with vector search capabilities to automatically retrieve relevant business rules from a vector store. This eliminates the need to manually specify business rules and provides more intelligent, context-aware test case generation.

## Key Features

### 🔍 **Automatic Business Rules Retrieval**
- Generates vector embeddings for requirements using OpenAI's text-embedding-3-small model
- Searches the FAISS vector store for similar business rules
- Automatically includes retrieved business rules in test case generation
- No manual business rules specification required

### 🎯 **Smart Context Matching**
- Uses semantic similarity to find relevant business rules
- Configurable search parameters (k-nearest neighbors)
- Maintains relevance between requirements and business rules
- Supports both automatic and manual business rules override

### 🚀 **Seamless Integration**
- All existing test case generation methods support vector search
- Backward compatible - existing code continues to work
- Optional feature that can be enabled/disabled per call
- Comprehensive logging and error handling

## Architecture

```
Requirements → OpenAI Embedding → FAISS Vector Search → Business Rules → Anthropic API → Test Cases
```

### Components

1. **OpenAI Embedding Client**: Generates 1536-dimensional vector embeddings
2. **FAISS Vector Store**: Efficient similarity search using FAISS library
3. **Vector Search Integration**: Connects requirements to relevant business rules
4. **Test Case Generation**: Uses retrieved business rules with existing Anthropic API logic

## Usage

### Basic Usage with Vector Search

```python
from test_case_generator import TestCaseGenerator

# Initialize the generator
generator = TestCaseGenerator()

# Generate test cases with automatic business rules retrieval
test_cases = generator.generate_test_cases(
    requirements="Create user API with email validation",
    use_vector_search=True  # Enable vector search (default: True)
)
```

### Manual Business Rules Override

```python
# Manual business rules override vector search
test_cases = generator.generate_test_cases(
    requirements="Create user API with email validation",
    business_rules="Manual business rules here",  # This overrides vector search
    use_vector_search=True
)
```

### All Test Case Generation Methods Support Vector Search

```python
# JSON structured output
json_test_cases = generator.generate_test_cases_with_json_output(
    requirements="Create user API with email validation",
    use_vector_search=True
)

# Type-specific test cases
api_test_cases = generator.generate_test_cases_for_specific_type(
    requirements="Create user API with email validation",
    test_type="API",
    use_vector_search=True
)
```

## Vector Store Management

### Populating the Vector Store

```python
# Add business rules to the vector store
sample_business_rules = [
    "User email must be unique in the system",
    "Password must be at least 8 characters long",
    "API responses must include appropriate HTTP status codes"
]

success = generator.populate_vector_store_with_business_rules(
    business_rules=sample_business_rules,
    save_path="business_rules_store"
)
```

### Checking Vector Store Status

```python
# Get vector store statistics
stats = generator.get_vector_store_stats()
print(f"Total vectors: {stats.get('total_vectors', 0)}")
print(f"Dimension: {stats.get('dimension', 'N/A')}")
print(f"Index type: {stats.get('index_type', 'N/A')}")
```

## Configuration

### Environment Variables

The system automatically loads configuration from your `.env` file:

```bash
# OpenAI API for embeddings
OPENAI_API_KEY=sk-your-openai-api-key-here

# SSL Configuration (for corporate environments)
SSL_VERIFY=DEFAULT|NONE|CUSTOM
ANTHROPIC_CA_BUNDLE_PATH=/path/to/ca-bundle.pem  # Required if SSL_VERIFY=CUSTOM

# Vector Store Configuration (optional)
FAISS_METADATA_PATH=path/to/your/vector_store.metadata
```

### Vector Store Initialization

The system automatically:
1. Checks for existing vector stores in the environment
2. Loads from `FAISS_METADATA_PATH` if specified
3. Creates a new store if none exists
4. Uses appropriate dimensions (1536) for OpenAI embeddings

## Testing

### Run the Integration Test

```bash
python test_vector_search_integration.py
```

This test script verifies:
- Vector search integration functionality
- Business rules retrieval
- Test case generation with vector search
- Vector store population capabilities

### Test Output Example

```
🧪 Testing Vector Search Integration inTestCaseGenerator
============================================================
1️⃣ Initializing TestCaseGenerator...
✅ TestCaseGenerator initialized successfully

2️⃣ Checking vector store statistics...
   Total vectors: 10
   Dimension: 1536
   Index type: flat

3️⃣ Testing vector search with requirements:
   Requirements: Create a user registration API that validates email format...

4️⃣ Testing automatic business rules retrieval...
✅ Business rules retrieved successfully:
   Retrieved Business Rules from Vector Store:
   - User email must be unique in the system
   - Email validation must follow standard email format patterns
   - Input validation must occur before any database operations

5️⃣ Testing test case generation with vector search...
✅ Test cases generated successfully with vector search
   Generated 2847 characters of test cases

✅ Vector search integration test completed successfully!
```

## Benefits

### 🎯 **Improved Test Quality**
- Business rules are automatically relevant to requirements
- Semantic matching ensures better context alignment
- Reduced manual effort in business rules specification

### 🔄 **Scalability**
- Vector store can contain thousands of business rules
- Automatic relevance scoring and ranking
- Easy to add new business rules to the system

### 🚀 **Developer Experience**
- No need to remember or manually specify business rules
- Consistent business rules across similar requirements
- Faster test case generation workflow

### 🧠 **Intelligence**
- Learns from existing business rules
- Semantic understanding of requirements
- Context-aware rule selection

## Error Handling

The system includes comprehensive error handling:

- **Vector Store Errors**: Gracefully falls back to no business rules
- **Embedding Errors**: Logs errors and continues without vector search
- **Search Errors**: Handles empty results and malformed metadata
- **API Errors**: Maintains existing retry logic for Anthropic API

## Logging

All vector search operations are logged:

```
INFO - Generating vector embedding for requirements
INFO - Searching vector store for 5 similar business rules
INFO - Retrieved 3 business rules from vector store
INFO - Successfully retrieved business rules from vector store
```

## Performance Considerations

- **Embedding Generation**: ~100-500ms per requirements text
- **Vector Search**: ~1-10ms for FAISS search operations
- **Overall Impact**: Minimal overhead, significant quality improvement
- **Caching**: Vector embeddings are not cached (regenerated per request)

## Future Enhancements

- **Caching**: Cache embeddings for repeated requirements
- **Batch Processing**: Process multiple requirements simultaneously
- **Advanced Ranking**: Implement more sophisticated relevance scoring
- **Rule Learning**: Automatically learn from generated test cases
- **Multi-language Support**: Support for different natural languages

## Troubleshooting

### Common Issues

1. **No Business Rules Retrieved**
   - Check if vector store is populated
   - Verify vector store statistics
   - Ensure business rules exist in the store

2. **Embedding Generation Fails**
   - Verify OpenAI API key in `.env` file
   - Check SSL configuration for corporate environments
   - Ensure network connectivity to OpenAI API

3. **Vector Store Loading Issues**
   - Check `FAISS_METADATA_PATH` in `.env` file
   - Verify file permissions for vector store files
   - Ensure sufficient disk space

### Debug Mode

Enable detailed logging by setting log level to DEBUG in your environment:

```python
import logging
logging.getLogger('test_case_generator').setLevel(logging.DEBUG)
```

## Support

For issues or questions:
1. Check the logs in `logs/test_case_generator.log`
2. Run the integration test script
3. Verify environment configuration
4. Check vector store statistics

---

**Note**: This vector search integration maintains full backward compatibility. Existing code will continue to work without modification, and the new functionality can be gradually adopted as needed. 