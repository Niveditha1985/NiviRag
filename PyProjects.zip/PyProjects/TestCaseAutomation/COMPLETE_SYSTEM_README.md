# Complete Vector Processing System

A comprehensive Python system for processing files, generating vector embeddings using OpenAI's API, and managing FAISS vector stores with advanced search capabilities.

## 🚀 Features

- **File Processing**: Automatically chunks text files into overlapping segments
- **Vector Embeddings**: Generates embeddings using OpenAI's text-embedding-3-small model
- **FAISS Vector Store**: High-performance similarity search with metadata support
- **Corporate SSL Support**: Handles corporate certificate environments
- **Flexible Configuration**: Configurable chunk sizes, overlap, and index types
- **Environment-Based Initialization**: Automatically load existing vector stores from .env configuration
- **Comprehensive Testing**: Built-in test suite for validation

## 🏗️ Architecture

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│ File Processor  │───▶│ OpenAI Embedding │───▶│ FAISS Vector    │
│                 │    │ Client           │    │ Store           │
└─────────────────┘    └──────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│ Text Chunking   │    │ SSL/HTTP Utils   │    │ Metadata Mgmt   │
└─────────────────┘    └──────────────────┘    └─────────────────┘
```

## 📦 Components

### 1. FileVectorProcessor (`file_vector_processor.py`)
Main orchestrator class that:
- Processes files and creates text chunks
- Manages the embedding generation pipeline
- Handles vector store operations
- Provides similarity search interface

### 2. FAISSVectorStore (`faiss_vector_store.py`)
High-performance vector storage with:
- Multiple index types (flat, IVF, HNSW)
- GPU acceleration support
- Metadata storage and retrieval
- Persistent storage with pickle
- **Environment-based initialization** from .env configuration

### 3. OpenAIEmbeddingClient (`openai_embedding_client.py`)
OpenAI API integration with:
- Text embedding generation
- Corporate SSL certificate support
- Automatic retry and error handling
- Configurable dimensions

### 4. HTTP Client Utils (`http_client_utils.py`)
SSL and HTTP configuration utilities:
- Corporate CA bundle support
- Proxy configuration
- SSL verification modes
- Automatic fallback strategies

## 🛠️ Installation

1. **Clone the repository**:
```bash
git clone <repository-url>
cd TestCaseAutomation
```

2. **Install dependencies**:
```bash
pip install -r requirements.txt
```

3. **Set up environment variables**:
Create a `.env` file in the project root:
```env
# Required
OPENAI_API_KEY=sk-your-openai-api-key-here

# Optional SSL Configuration
SSL_VERIFY=DEFAULT  # DEFAULT, NONE, or CUSTOM
ANTHROPIC_CA_BUNDLE_PATH=/path/to/ca-bundle.pem  # Required if SSL_VERIFY=CUSTOM

# Optional Proxy Configuration
HTTP_PROXY=http://proxy.company.com:8080
HTTPS_PROXY=https://proxy.company.com:8080

# Optional Vector Store Configuration
FAISS_METADATA_PATH=/path/to/your/vector_store.metadata
```

## 🚀 Quick Start

### Basic Usage

```python
from file_vector_processor import FileVectorProcessor

# Initialize processor
processor = FileVectorProcessor(
    store_path="my_vector_store",
    chunk_size=1000,
    chunk_overlap=200
)

# Process a file
success = processor.process_file("document.txt")
if success:
    print("File processed successfully!")

# Search for similar content
query = "machine learning algorithms"
distances, indices, metadata = processor.search_similar(query, k=5)

# Display results
for i, (dist, idx, meta) in enumerate(zip(distances, indices, metadata)):
    print(f"Result {i+1}: {meta['file_name']} (Distance: {dist:.4f})")
```

### Environment-Based Initialization

```python
from faiss_vector_store import create_faiss_store_from_environment

# Automatically load from .env configuration or create new
store = create_faiss_store_from_environment(dimension=1536)

# Or use the constructor with auto-loading
from faiss_vector_store import FAISSVectorStore
store = FAISSVectorStore(auto_load_from_env=True)  # Will load from .env if available
```

### Advanced Usage

```python
from faiss_vector_store import FAISSVectorStore

# Create custom vector store
store = FAISSVectorStore(
    dimension=1536,
    index_type="hnsw",  # Hierarchical Navigable Small World
    use_gpu=True        # GPU acceleration
)

# Add vectors with metadata
vectors = [[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]]
metadata = [{"source": "doc1"}, {"source": "doc2"}]
store.add_vectors(vectors, metadata=metadata)

# Save and load
store.save_index("my_index")
loaded_store = FAISSVectorStore.from_saved_index("my_index")
```

## 🔧 Environment-Based Configuration

The system now supports automatic initialization from environment variables:

### Setting Up Environment-Based Loading

1. **Save your vector store**:
```python
store.save_index("/path/to/my_store")
# This creates: /path/to/my_store.faiss and /path/to/my_store.metadata
```

2. **Add to .env file**:
```env
FAISS_METADATA_PATH=/path/to/my_store.metadata
```

3. **Use automatic loading**:
```python
# Method 1: Convenience function
store = create_faiss_store_from_environment(dimension=1536)

# Method 2: Constructor with auto-loading
store = FAISSVectorStore(auto_load_from_env=True)

# Method 3: Direct class method
store = FAISSVectorStore.from_environment_config(dimension=1536)
```

### Benefits of Environment-Based Loading

- **Persistent State**: Automatically load existing vector stores
- **Configuration Management**: Centralize store paths in .env files
- **Development/Production**: Easy switching between environments
- **Team Collaboration**: Share vector store configurations

## 🧪 Testing

### Run Complete System Test
```bash
python test_complete_system.py
```

### Run Environment Initialization Test
```bash
python test_environment_initialization.py
```

### Run Individual Component Tests
```bash
# Test FAISS vector store
python faiss_vector_store.py

# Test OpenAI embedding client
python openai_embedding_client.py

# Test HTTP client utilities
python http_client_utils.py

# Test file vector processor
python file_vector_processor.py
```

## ⚙️ Configuration Options

### FileVectorProcessor
- `store_path`: Path for vector store files
- `chunk_size`: Size of text chunks (default: 1000 characters)
- `chunk_overlap`: Overlap between chunks (default: 200 characters)

### FAISSVectorStore
- `dimension`: Vector dimensions
- `index_type`: FAISS index type (`flat`, `ivf`, `hnsw`)
- `use_gpu`: Enable GPU acceleration
- `auto_load_from_env`: Automatically load from .env configuration (default: True)

### OpenAIEmbeddingClient
- `SSL_VERIFY`: SSL verification mode
- `ANTHROPIC_CA_BUNDLE_PATH`: Custom CA bundle path
- `HTTP_PROXY`/`HTTPS_PROXY`: Proxy configuration

### Environment Variables
- `FAISS_METADATA_PATH`: Path to existing vector store metadata file

## 📊 Performance

- **Chunking**: O(n) where n is text length
- **Embedding**: API-dependent (OpenAI rate limits)
- **Search**: O(log n) for HNSW, O(n) for flat index
- **Storage**: Efficient binary format with metadata

## 🔒 Security Features

- **SSL Verification**: Multiple verification modes
- **Corporate Certificates**: Custom CA bundle support
- **API Key Management**: Environment variable configuration
- **Proxy Support**: Corporate network compatibility

## 🚨 Error Handling

The system includes comprehensive error handling:
- **API Failures**: Automatic fallback and retry
- **SSL Issues**: Multiple SSL configuration strategies
- **File Errors**: Graceful degradation and logging
- **Memory Issues**: Efficient vector storage and cleanup

## 📝 Logging

All components include detailed logging:
```python
import logging
logging.basicConfig(level=logging.INFO)
```

Log levels:
- `INFO`: General operations and status
- `WARNING`: Non-critical issues
- `ERROR`: Critical failures
- `DEBUG`: Detailed debugging information

## 🔧 Troubleshooting

### Common Issues

1. **OpenAI API Key Not Found**
   - Ensure `.env` file exists with `OPENAI_API_KEY`
   - Check file permissions and encoding

2. **SSL Certificate Errors**
   - Set `SSL_VERIFY=NONE` for testing
   - Configure `ANTHROPIC_CA_BUNDLE_PATH` for corporate certificates

3. **FAISS Installation Issues**
   - Use `faiss-cpu` for CPU-only systems
   - Install `faiss-gpu` for GPU acceleration

4. **Memory Issues**
   - Reduce chunk size for large files
   - Use appropriate index types for your use case

### Debug Mode

Enable debug logging for detailed troubleshooting:
```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

## 📚 API Reference

### FileVectorProcessor Methods

- `process_file(file_path)`: Process a file and add to vector store
- `search_similar(query_text, k=5)`: Search for similar content
- `get_store_stats()`: Get vector store statistics
- `clear_store()`: Clear all vectors from store

### FAISSVectorStore Methods

- `add_vectors(vectors, vector_ids, metadata)`: Add vectors to store
- `search(query_vector, k=5)`: Search for similar vectors
- `save_index(filepath)`: Save index to disk
- `load_index(filepath)`: Load index from disk

### OpenAIEmbeddingClient Methods

- `get_embeddings(text, dimensions=1536)`: Generate embeddings
- `get_single_embedding(text, dimensions=1536)`: Generate single embedding

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:
- Check the troubleshooting section
- Review the test files for examples
- Enable debug logging for detailed information
- Check the component-specific README files

## 🎯 Roadmap

- [ ] PDF processing support
- [ ] Batch file processing
- [ ] Advanced index types (IVF, PQ)
- [ ] Web interface for management
- [ ] Docker containerization
- [ ] Performance benchmarking tools

---

**Ready to process your documents into searchable vectors? Start with the quick start guide above!** 🚀 