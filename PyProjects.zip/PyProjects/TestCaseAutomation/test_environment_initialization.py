#!/usr/bin/env python3
"""
Test Environment-Based Initialization

This script demonstrates the new environment-based initialization functionality
for the FAISS vector store.
"""

import os
import tempfile
from pathlib import Path

def test_environment_initialization():
    """Test the environment-based initialization functionality."""
    print("🧪 Testing Environment-Based Initialization")
    print("=" * 60)
    
    # Create a temporary directory for testing
    temp_dir = tempfile.mkdtemp()
    test_store_path = os.path.join(temp_dir, "test_env_store")
    
    try:
        print("1️⃣ Testing imports...")
        from faiss_vector_store import FAISSVectorStore, create_faiss_store_from_environment
        print("✅ All imports successful")
        
        print("\n2️⃣ Testing without environment variable...")
        try:
            # This should create a new store since no FAISS_METADATA_PATH is set
            store = create_faiss_store_from_environment(dimension=4)
            print("✅ Created new store successfully")
            print(f"   Store stats: {store.get_index_stats()}")
            
            # Add some test vectors
            test_vectors = [[1.0, 2.0, 3.0, 4.0], [5.0, 6.0, 7.0, 8.0]]
            store.add_vectors(test_vectors)
            print("✅ Added test vectors successfully")
            
            # Save the store
            store.save_index(test_store_path)
            print(f"✅ Store saved to {test_store_path}")
            
        except Exception as e:
            print(f"❌ Failed to create store: {e}")
            return False
        
        print("\n3️⃣ Testing with environment variable...")
        try:
            # Set environment variable to point to our saved store
            os.environ["FAISS_METADATA_PATH"] = f"{test_store_path}.metadata"
            print(f"   Set FAISS_METADATA_PATH={os.environ['FAISS_METADATA_PATH']}")
            
            # Now try to create store from environment
            env_store = create_faiss_store_from_environment()
            print("✅ Successfully loaded store from environment!")
            print(f"   Store stats: {env_store.get_index_stats()}")
            
            # Test that it's the same store by searching
            query = [1.0, 2.0, 3.0, 4.0]
            distances, indices, metadata = env_store.search(query, k=2)
            print(f"✅ Search successful: found {len(distances)} results")
            
        except Exception as e:
            print(f"❌ Failed to load from environment: {e}")
            return False
        
        print("\n4️⃣ Testing constructor auto-loading...")
        try:
            # Test the constructor's auto-loading feature
            auto_store = FAISSVectorStore(auto_load_from_env=True)
            print("✅ Constructor auto-loading successful!")
            print(f"   Store stats: {auto_store.get_index_stats()}")
            
        except Exception as e:
            print(f"❌ Constructor auto-loading failed: {e}")
            return False
        
        print("\n5️⃣ Testing constructor without auto-loading...")
        try:
            # Test constructor without auto-loading
            manual_store = FAISSVectorStore(dimension=4, auto_load_from_env=False)
            print("✅ Manual store creation successful!")
            print(f"   Store stats: {manual_store.get_index_stats()}")
            
        except Exception as e:
            print(f"❌ Manual store creation failed: {e}")
            return False
        
        print("\n✅ All environment initialization tests passed!")
        return True
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        return False
        
    finally:
        # Clean up
        try:
            # Remove test files
            if os.path.exists(f"{test_store_path}.faiss"):
                os.remove(f"{test_store_path}.faiss")
            if os.path.exists(f"{test_store_path}.metadata"):
                os.remove(f"{test_store_path}.metadata")
            
            # Remove temporary directory
            os.rmdir(temp_dir)
            print("✅ Test files cleaned up")
            
        except Exception as e:
            print(f"⚠️  Cleanup warning: {e}")


def test_environment_config_method():
    """Test the from_environment_config class method directly."""
    print("\n🧪 Testing from_environment_config Class Method")
    print("=" * 60)
    
    try:
        from faiss_vector_store import FAISSVectorStore
        
        print("1️⃣ Testing without environment variable...")
        store = FAISSVectorStore.from_environment_config(dimension=3)
        if store is None:
            print("✅ Correctly returned None when no environment config found")
        else:
            print("❌ Should have returned None")
            return False
        
        print("\n2️⃣ Testing with invalid environment path...")
        os.environ["FAISS_METADATA_PATH"] = "/nonexistent/path"
        store = FAISSVectorStore.from_environment_config(dimension=3)
        if store is None:
            print("✅ Correctly returned None for invalid path")
        else:
            print("❌ Should have returned None for invalid path")
            return False
        
        print("\n✅ from_environment_config method tests passed!")
        return True
        
    except Exception as e:
        print(f"❌ from_environment_config test failed: {e}")
        return False


if __name__ == "__main__":
    print("🚀 Starting Environment Initialization Tests")
    print("=" * 60)
    
    # Test the main functionality
    main_test_success = test_environment_initialization()
    
    # Test the class method directly
    method_test_success = test_environment_config_method()
    
    print("\n" + "=" * 60)
    print("🏁 FINAL TEST RESULTS")
    print("=" * 60)
    
    if main_test_success:
        print("✅ Main environment initialization test: PASSED")
    else:
        print("❌ Main environment initialization test: FAILED")
    
    if method_test_success:
        print("✅ from_environment_config method test: PASSED")
    else:
        print("❌ from_environment_config method test: FAILED")
    
    if main_test_success and method_test_success:
        print("\n🎉 Environment-based initialization is working correctly!")
        print("\n💡 Usage:")
        print("   1. Set FAISS_METADATA_PATH in .env file")
        print("   2. Use create_faiss_store_from_environment()")
        print("   3. Or use FAISSVectorStore() with auto_load_from_env=True")
    else:
        print("\n❌ Some tests failed - check the output above") 