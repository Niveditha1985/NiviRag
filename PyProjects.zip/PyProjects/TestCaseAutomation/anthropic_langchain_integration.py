"""
Anthropic API Integration with LangChain Framework

This module demonstrates how to integrate with Anthropic's Claude API using the LangChain framework.
It includes various examples of LLM usage, prompt templates, and chain operations.
"""

import os
from typing import List, Dict, Any
from dotenv import load_dotenv
from langchain_anthropic import ChatAnthropic
from langchain_core.prompts import ChatPromptTemplate, PromptTemplate
from langchain_core.output_parsers import StrOutputParser, JsonOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain.chains import LLMChain
from langchain.schema import HumanMessage, SystemMessage
import json
from http_client_utils import create_http_client_with_ssl_disabled, create_http_client_with_ca_bundle, get_environment_http_client

# Load environment variables
load_dotenv()

class AnthropicLangChainIntegration:
    """
    A class to handle Anthropic API integration using LangChain framework.
    """
    
    def __init__(self):
        """
        Initialize the Anthropic LangChain integration.
        
        All configuration is automatically loaded from the .env file:
        - ANTHROPIC_API_KEY: Your Anthropic API key
        - ANTHROPIC_MODEL: The model to use (defaults to claude-3-5-sonnet-20241022)
        - SSL_VERIFY: SSL verification mode ('NONE', 'DEFAULT', 'CUSTOM')
        - ANTHROPIC_CA_BUNDLE_PATH: Path to CA bundle (required if SSL_VERIFY=CUSTOM)
        """
        # Load API key from environment
        self.api_key = os.getenv("ANTHROPIC_API_KEY")
        if not self.api_key:
            raise ValueError("ANTHROPIC_API_KEY not found in .env file or environment variables")
        
        # Validate API key format
        if not self.api_key.startswith("sk-ant-"):
            raise ValueError("Invalid API key format. Anthropic API keys should start with 'sk-ant-'")
        
        # Load model from environment with default
        self.model = os.getenv("ANTHROPIC_MODEL", "claude-3-5-sonnet-20241022")
        
        # Load SSL verification setting from environment
        self.ssl_verify = os.getenv("SSL_VERIFY", "DEFAULT").upper()
        if self.ssl_verify not in ["NONE", "DEFAULT", "CUSTOM"]:
            raise ValueError("SSL_VERIFY must be one of: 'NONE', 'DEFAULT', 'CUSTOM'")
        
        # Validate that CA bundle path exists if using CUSTOM SSL
        if self.ssl_verify == "CUSTOM":
            ca_bundle_path = os.getenv("ANTHROPIC_CA_BUNDLE_PATH")
            if not ca_bundle_path:
                raise ValueError("SSL_VERIFY is set to 'CUSTOM' but ANTHROPIC_CA_BUNDLE_PATH is not found in .env file")
        
        self.base_url = "https://api.anthropic.com/v1"
        
        try:
            # Create HTTP client based on SSL_VERIFY setting
            client = self._create_client()
            
            # Create the LangChain model
            self.llm = ChatAnthropic(
                anthropic_api_key=self.api_key,
                model=self.model,
                temperature=0.7,
                max_tokens=4096
            )
            
            # Set the HTTP client on the underlying httpx client
            # Based on debug output: llm._client._client is the httpx client wrapper
            if hasattr(self.llm, '_client') and hasattr(self.llm._client, '_client'):
                # Replace the underlying httpx client with our custom one
                self.llm._client._client = client
            else:
                # Fallback: try to set it directly on the client
                self.llm._client = client
                
        except Exception as e:
            raise ValueError(f"Failed to initialize Anthropic client: {str(e)}")
    
    def _create_client(self):
        """
        Create an HTTP client with appropriate SSL configuration based on SSL_VERIFY setting.
        
        SSL_VERIFY options:
        - 'NONE': SSL verification disabled
        - 'DEFAULT': Standard SSL verification
        - 'CUSTOM': Use corporate certificates from ANTHROPIC_CA_BUNDLE_PATH
        
        Returns:
            httpx.Client: Configured HTTP client
        """
        if self.ssl_verify == "NONE":
            # SSL verification disabled
            return create_http_client_with_ssl_disabled()
        elif self.ssl_verify == "CUSTOM":
            # Use corporate CA bundle
            return create_http_client_with_ca_bundle()
        else:  # DEFAULT
            # Use standard SSL verification
            return get_environment_http_client()
    
    @property
    def ssl_verify(self) -> str:
        """Get the SSL verification setting."""
        return self._ssl_verify
    
    @ssl_verify.setter
    def ssl_verify(self, value: str):
        """Set the SSL verification setting."""
        value_upper = value.upper()
        if value_upper not in ["NONE", "DEFAULT", "CUSTOM"]:
            raise ValueError("SSL_VERIFY must be one of: 'NONE', 'DEFAULT', 'CUSTOM'")
        self._ssl_verify = value_upper
    
    def simple_chat(self, message: str) -> str:
        """
        Simple chat with the LLM.
        
        Args:
            message (str): The message to send to the LLM.
            
        Returns:
            str: The LLM's response.
        """
        try:
            response = self.llm.invoke(message)
            return response.content
        except Exception as e:
            import traceback
            error_details = {
                'error_type': type(e).__name__,
                'error_message': str(e),
                'full_traceback': traceback.format_exc()
            }
            print(f"Detailed error in simple_chat: {error_details}")
            return f"Error: {str(e)}"
    
    def chat_with_system_prompt(self, system_prompt: str, user_message: str) -> str:
        """
        Chat with a system prompt and user message.
        
        Args:
            system_prompt (str): The system prompt to set the context.
            user_message (str): The user's message.
            
        Returns:
            str: The LLM's response.
        """
        try:
            messages = [
                SystemMessage(content=system_prompt),
                HumanMessage(content=user_message)
            ]
            response = self.llm.invoke(messages)
            return response.content
        except Exception as e:
            return f"Error: {str(e)}"
    
    
    def create_chat_prompt_template(self, system_template: str, human_template: str) -> ChatPromptTemplate:
        """
        Create a chat prompt template.
        
        Args:
            system_template (str): The system message template.
            human_template (str): The human message template.
            
        Returns:
            ChatPromptTemplate: The created chat prompt template.
        """
        return ChatPromptTemplate.from_messages([
            ("system", system_template),
            ("human", human_template)
        ])
    
    
    def run_chat_chain(self, system_template: str, human_template: str, input_variables: Dict[str, Any]) -> str:
        """
        Run a chat chain with system and human templates.
        
        Args:
            system_template (str): The system message template.
            human_template (str): The human message template.
            input_variables (Dict[str, Any]): Variables to inject into the templates.
            
        Returns:
            str: The LLM's response.
        """
        try:
            prompt = self.create_chat_prompt_template(system_template, human_template)
            chain = prompt | self.llm | StrOutputParser()
            response = chain.invoke(input_variables)
            return response
        except Exception as e:
            import traceback
            error_details = {
                'error_type': type(e).__name__,
                'error_message': str(e),
                'full_traceback': traceback.format_exc(),
                'api_key_prefix': self.api_key[:8] + "..." if self.api_key else "None",
                'model': self.model
            }
            print(f"Detailed error in run_chat_chain: {error_details}")
            return f"Error: {str(e)}"
    
    def generate_json_response(self, prompt: str, json_schema: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate a structured JSON response.
        
        Args:
            prompt (str): The prompt to generate JSON from.
            json_schema (Dict[str, Any]): The expected JSON schema.
            
        Returns:
            Dict[str, Any]: The structured JSON response.
        """
        try:
            json_prompt = f"""
            {prompt}
            
            Please respond with a JSON object that follows this schema:
            {json.dumps(json_schema, indent=2)}
            
            Response:
            """
            
            response = self.llm.invoke(json_prompt)
            # Try to parse JSON from response
            try:
                # Find JSON in the response
                start_idx = response.content.find('{')
                end_idx = response.content.rfind('}') + 1
                if start_idx != -1 and end_idx != 0:
                    json_str = response.content[start_idx:end_idx]
                    return json.loads(json_str)
                else:
                    return {"error": "No JSON found in response", "raw_response": response.content}
            except json.JSONDecodeError:
                return {"error": "Invalid JSON response", "raw_response": response.content}
        except Exception as e:
            return {"error": str(e)}


def create_anthropic_integration() -> AnthropicLangChainIntegration:
    """
    Factory function to create an Anthropic LangChain integration.
    
    All configuration will be automatically loaded from the .env file.
    
    Required .env variables:
    - ANTHROPIC_API_KEY: Your Anthropic API key
    
    Optional .env variables:
    - ANTHROPIC_MODEL: The model to use (defaults to claude-3-5-sonnet-20241022)
    - SSL_VERIFY: SSL verification mode ('NONE', 'DEFAULT', 'CUSTOM')
    - ANTHROPIC_CA_BUNDLE_PATH: Path to CA bundle (required if SSL_VERIFY=CUSTOM)
    
    Returns:
        AnthropicLangChainIntegration: Configured integration
        
    Raises:
        ValueError: If required configuration is missing or invalid
    """
    return AnthropicLangChainIntegration()


# Example usage and testing
if __name__ == "__main__":
    print("🔍 Testing Anthropic LangChain Integration...")
    print("=" * 50)
    
    try:
        # Create integration (all configuration loaded from .env file)
        integration = create_anthropic_integration()
        
        # Display current configuration
        print(f"🔧 Configuration:")
        print(f"   Model: {integration.model}")
        print(f"   SSL_VERIFY: {integration.ssl_verify}")
        if integration.ssl_verify == "CUSTOM":
            print(f"   CA Bundle Path: {os.getenv('ANTHROPIC_CA_BUNDLE_PATH')}")
        
        # Test simple chat
        print(f"\n💬 Testing simple chat...")
        response = integration.simple_chat("Hello! Can you tell me a short joke?")
        print(f"Response: {response}")
        
        # Test with system prompt
        print(f"\n🤖 Testing with system prompt...")
        system_prompt = "You are a helpful assistant that provides concise answers."
        user_message = "What is the capital of France?"
        response = integration.chat_with_system_prompt(system_prompt, user_message)
        print(f"Response: {response}")
        
        # Test SSL property modification
        print(f"\n🔄 Testing SSL property modification...")
        print(f"   Before: SSL verify = {integration.ssl_verify}")
        original_ssl_mode = integration.ssl_verify
        integration.ssl_verify = "NONE"
        print(f"   After setting to NONE: SSL verify = {integration.ssl_verify}")
        
        # Test chat chain
        print(f"\n⛓️ Testing chat chain...")
        system_template = "You are a helpful assistant that provides {style} answers."
        human_template = "What is {topic}?"
        input_vars = {"style": "concise", "topic": "machine learning"}
        response = integration.run_chat_chain(system_template, human_template, input_vars)
        print(f"Response: {response}")
        
        # Restore original SSL mode
        integration.ssl_verify = original_ssl_mode
        print(f"   Restored to original: SSL verify = {integration.ssl_verify}")
        
        print("\n✅ Anthropic LangChain integration test completed successfully!")
        print("\n📋 .env file configuration options:")
        print("   ANTHROPIC_API_KEY=sk-ant-your-api-key-here")
        print("   ANTHROPIC_MODEL=claude-3-5-sonnet-20241022")
        print("   SSL_VERIFY=DEFAULT|NONE|CUSTOM")
        print("   ANTHROPIC_CA_BUNDLE_PATH=/path/to/ca-bundle.pem  # Required if SSL_VERIFY=CUSTOM")
        
    except ValueError as e:
        print(f"❌ Configuration error: {e}")
        print("\n💡 Make sure to create a .env file with the required configuration:")
        print("   ANTHROPIC_API_KEY=sk-ant-your-api-key-here")
        print("   ANTHROPIC_MODEL=claude-3-5-sonnet-20241022  # optional")
        print("   SSL_VERIFY=DEFAULT|NONE|CUSTOM  # optional")
        print("   ANTHROPIC_CA_BUNDLE_PATH=/path/to/ca-bundle.pem  # required if SSL_VERIFY=CUSTOM")
    except Exception as e:
        print(f"❌ Error during testing: {e}")
        print("\n💡 Check your .env file configuration and network connectivity")
    
   