# Anthropic API Integration with LangChain

This project demonstrates how to integrate with Anthropic's Claude API using the LangChain framework. It provides a comprehensive set of tools and examples for working with large language models.

## Features

- 🤖 Simple chat interface with Claude
- 📝 Prompt template management
- 🔗 LangChain integration with various chain types
- 📊 Structured JSON response generation
- ⚡ Batch processing capabilities
- 🛡️ Error handling and validation
- 🔧 Configurable model parameters

## Prerequisites

- Python 3.8 or higher
- Anthropic API key (get one from [Anthropic Console](https://console.anthropic.com/))

## Installation

1. **Clone or download this project**

2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Set up your API key:**
   
   Create a `.env` file in the project root and add your Anthropic API key:
   ```bash
   # Copy the example file
   cp env_example.txt .env
   
   # Edit .env and add your API key
   ANTHROPIC_API_KEY=your_actual_api_key_here
   ```

## Usage

### Web Interface (Gradio UI)

The easiest way to use the Test Case Generator is through the web interface:

```bash
# Run the Gradio UI
python run_gradio_ui.py
```

This will start a web server at `http://localhost:7860` with a user-friendly interface that includes:
- Three input boxes for Requirements, Business Rules, and Existing Test Cases
- A "Generate Test Cases" button
- Real-time output display
- Example inputs and instructions
- Clear all functionality

### Basic Usage

```python
from anthropic_langchain_integration import AnthropicLangChainIntegration

# Initialize the integration (all configuration from .env file)
integration = AnthropicLangChainIntegration()

# Simple chat
response = integration.simple_chat("What is the capital of France?")
print(response)
```

### Advanced Usage

```python
# Chat with system prompt
system_prompt = "You are a helpful assistant that provides concise answers."
response = integration.chat_with_system_prompt(
    system_prompt, 
    "Explain quantum computing in simple terms."
)

# Using prompt templates
template = "Write a {style} poem about {topic}."
variables = {"style": "haiku", "topic": "artificial intelligence"}
response = integration.run_chain_with_template(template, variables)

# Generate structured JSON responses
json_schema = {
    "title": "string",
    "author": "string",
    "genre": "string",
    "reason": "string"
}
response = integration.generate_json_response(
    "Create a book recommendation for a science fiction fan.",
    json_schema
)
```

### Running Examples

To see all examples in action:

```bash
python anthropic_langchain_integration.py
```

## Test Case Generator

The project includes a specialized `TestCaseGenerator` class that uses the Anthropic integration to generate comprehensive test cases:

### Features
- Generate test cases from requirements and business rules
- Support for existing test cases as context
- Multiple output formats (text and JSON)
- Specialized test type generation (API, UI, Functional, etc.)

### Usage Examples

```python
from test_case_generator import TestCaseGenerator

# Initialize the generator (all configuration from .env file)
generator = TestCaseGenerator()

# Generate test cases
test_cases = generator.generate_test_cases(
    requirements="Create user API with email validation",
    business_rules="Email must be unique, phone number optional",
    existing_test_cases="Previous test cases for reference"
)
```

# Generate JSON structured output
json_test_cases = generator.generate_test_cases_with_json_output(
    requirements="User registration functionality",
    business_rules="Password must be 8+ characters"
)

# Generate specific test type
api_test_cases = generator.generate_test_cases_for_specific_type(
    requirements="REST API for user management",
    test_type="API"
)
```

## API Reference

### AnthropicLangChainIntegration Class

#### Constructor
```python
__init__()
```
All configuration (API key, model, SSL settings) is automatically loaded from the `.env` file.

#### Methods

- `simple_chat(message: str) -> str`: Simple chat with the LLM
- `chat_with_system_prompt(system_prompt: str, user_message: str) -> str`: Chat with system context
- `create_prompt_template(template: str) -> PromptTemplate`: Create a prompt template
- `create_chat_prompt_template(system_template: str, human_template: str) -> ChatPromptTemplate`: Create a chat prompt template
- `run_chain_with_template(template: str, input_variables: Dict[str, Any]) -> str`: Run a chain with template
- `run_chat_chain(system_template: str, human_template: str, input_variables: Dict[str, Any]) -> str`: Run a chat chain
- `generate_json_response(prompt: str, json_schema: Dict[str, Any]) -> Dict[str, Any]`: Generate structured JSON
- `batch_process(messages: List[str]) -> List[str]`: Process multiple messages

## Configuration

### Environment Variables

- `ANTHROPIC_API_KEY`: Your Anthropic API key (required)
- `ANTHROPIC_MODEL`: Model to use (optional, defaults to claude-3-5-sonnet-20241022)

### Model Parameters

You can customize the LLM behavior by modifying the parameters in the constructor:

```python
self.llm = ChatAnthropic(
    anthropic_api_key=self.api_key,
    model=model,
    temperature=0.7,  # Controls randomness (0.0 = deterministic, 1.0 = very random)
    max_tokens=4096   # Maximum tokens in response
)
```

## Available Models

- `claude-3-5-sonnet-20241022` (default) - Latest and most capable
- `claude-3-5-haiku-20241022` - Fast and efficient
- `claude-3-opus-20240229` - Most capable (older version)
- `claude-3-sonnet-20240229` - Balanced (older version)

## Error Handling

The integration includes comprehensive error handling:

- API key validation
- Network error handling
- JSON parsing error handling
- Graceful fallbacks for failed requests

## Examples

### 1. Simple Chat
```python
response = integration.simple_chat("What is Python?")
```

### 2. System Prompt
```python
response = integration.chat_with_system_prompt(
    "You are a coding expert.",
    "How do I implement a binary search?"
)
```

### 3. Template with Variables
```python
template = "Explain {concept} in the context of {field}."
variables = {"concept": "machine learning", "field": "healthcare"}
response = integration.run_chain_with_template(template, variables)
```

### 4. Structured Output
```python
schema = {
    "steps": ["string"],
    "difficulty": "string",
    "time_estimate": "string"
}
response = integration.generate_json_response(
    "How to make a cake?",
    schema
)
```

### 5. Batch Processing
```python
messages = [
    "What is AI?",
    "What is ML?",
    "What is DL?"
]
responses = integration.batch_process(messages)
```

## Troubleshooting

### Common Issues

1. **API Key Error**: Make sure your `ANTHROPIC_API_KEY` is set correctly in the `.env` file
2. **Import Errors**: Ensure all dependencies are installed with `pip install -r requirements.txt`
3. **Rate Limiting**: Anthropic has rate limits. If you hit them, wait a moment and try again
4. **Model Not Found**: Ensure you're using a valid model name

### Getting Help

- Check the [Anthropic API Documentation](https://docs.anthropic.com/)
- Review the [LangChain Documentation](https://python.langchain.com/)
- Ensure your API key has the necessary permissions

## License

This project is open source and available under the MIT License.

## Contributing

Feel free to submit issues, feature requests, or pull requests to improve this integration. 