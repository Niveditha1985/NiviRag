#!/usr/bin/env python3
"""
HTTP Client Utilities

This module provides utility functions to create HTTP clients with different SSL contexts
for use with various API integrations.
"""

import os
import httpx
import ssl
from typing import Optional


def create_http_client_with_ssl_disabled() -> httpx.Client:
    """
    Create an HTTP client with SSL certificate verification disabled.
    
    ⚠️  Security Warning: This disables SSL certificate verification and should only be used as a last resort.
    
    Returns:
        httpx.Client: HTTP client with SSL verification disabled
    """
    # Create a custom SSL context that doesn't verify certificates
    ssl_context = ssl.create_default_context()
    ssl_context.check_hostname = False
    ssl_context.verify_mode = ssl.CERT_NONE
    
    # Create custom transport with SSL context
    transport = httpx.HTTPTransport(verify=ssl_context)
    client = httpx.Client(transport=transport)
    
    return client


def create_http_client_with_ca_bundle() -> httpx.Client:
    """
    Create an HTTP client with custom CA bundle for corporate certificates.
    
    The CA bundle path is automatically read from the ANTHROPIC_CA_BUNDLE_PATH environment variable.
    
    Returns:
        httpx.Client: HTTP client with custom CA bundle
        
    Raises:
        ValueError: If CA bundle file is not found or ANTHROPIC_CA_BUNDLE_PATH environment variable not set
    """
    # Get CA bundle path from environment variable
    ca_bundle_path = os.getenv("ANTHROPIC_CA_BUNDLE_PATH")
    if not ca_bundle_path:
        raise ValueError("ANTHROPIC_CA_BUNDLE_PATH environment variable not set")
    
    if not os.path.exists(ca_bundle_path):
        raise ValueError(f"CA bundle file not found: {ca_bundle_path}")
    
    # Create SSL context with custom CA bundle
    ssl_context = ssl.create_default_context()
    ssl_context.load_verify_locations(cafile=ca_bundle_path)
    
    # Create custom transport with SSL context
    transport = httpx.HTTPTransport(verify=ssl_context)
    client = httpx.Client(transport=transport)
    
    return client


def create_http_client_with_standard_ssl() -> httpx.Client:
    """
    Create an HTTP client with standard SSL verification.
    
    Returns:
        httpx.Client: HTTP client with standard SSL verification
    """
    # Use default SSL verification
    return httpx.Client()


def create_http_client_with_proxy(proxy_url: str, verify_ssl: bool = True, 
                                 ca_bundle_path: Optional[str] = None) -> httpx.Client:
    """
    Create an HTTP client with proxy configuration.
    
    Args:
        proxy_url (str): Proxy URL (e.g., "http://proxy.company.com:8080")
        verify_ssl (bool): Whether to verify SSL certificates
        ca_bundle_path (str, optional): Path to CA bundle file (supports .pem and .crt formats)
        
    Returns:
        httpx.Client: HTTP client with proxy configuration
    """
    proxies = {
        "http://": proxy_url,
        "https://": proxy_url
    }
    
    if not verify_ssl:
        # Create SSL context that doesn't verify certificates
        ssl_context = ssl.create_default_context()
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE
        transport = httpx.HTTPTransport(verify=ssl_context)
    elif ca_bundle_path:
        # Create SSL context with custom CA bundle
        if not os.path.exists(ca_bundle_path):
            raise ValueError(f"CA bundle file not found: {ca_bundle_path}")
        
        ssl_context = ssl.create_default_context()
        ssl_context.load_verify_locations(cafile=ca_bundle_path)
        transport = httpx.HTTPTransport(verify=ssl_context)
    else:
        # Use default transport
        transport = None
    
    client = httpx.Client(proxies=proxies, transport=transport)
    return client


def create_http_client_auto_ssl(ca_bundle_path: Optional[str] = None, 
                               proxy_url: Optional[str] = None) -> httpx.Client:
    """
    Create an HTTP client with automatic SSL configuration.
    
    This function tries different SSL configurations in order:
    1. Standard SSL verification
    2. Corporate CA bundle (if provided)
    3. Proxy configuration (if provided)
    4. SSL verification disabled (as last resort)
    
    Args:
        ca_bundle_path (str, optional): Path to CA bundle file (supports .pem and .crt formats)
        proxy_url (str, optional): Proxy URL
        
    Returns:
        httpx.Client: HTTP client with appropriate SSL configuration
    """
    try:
        # Try with standard SSL first
        if proxy_url:
            return create_http_client_with_proxy(proxy_url, verify_ssl=True, ca_bundle_path=ca_bundle_path)
        elif ca_bundle_path:
            # If ca_bundle_path is provided, use it directly
            if not os.path.exists(ca_bundle_path):
                raise ValueError(f"CA bundle file not found: {ca_bundle_path}")
            
            # Create SSL context with custom CA bundle
            ssl_context = ssl.create_default_context()
            ssl_context.load_verify_locations(cafile=ca_bundle_path)
            transport = httpx.HTTPTransport(verify=ssl_context)
            return httpx.Client(transport=transport)
        else:
            return create_http_client_with_standard_ssl()
    except Exception as e:
        # If standard SSL fails, try with SSL disabled
        if proxy_url:
            return create_http_client_with_proxy(proxy_url, verify_ssl=False)
        else:
            return create_http_client_with_ssl_disabled()


def test_http_client(client: httpx.Client, test_url: str = "https://api.anthropic.com") -> bool:
    """
    Test if an HTTP client can successfully connect to a URL.
    
    Args:
        client (httpx.Client): HTTP client to test
        test_url (str): URL to test connection against
        
    Returns:
        bool: True if connection successful, False otherwise
    """
    try:
        response = client.get(test_url, timeout=10)
        return response.status_code < 400
    except Exception:
        return False


def get_environment_http_client() -> httpx.Client:
    """
    Create an HTTP client based on environment variables.
    
    Environment variables checked:
    - ANTHROPIC_CA_BUNDLE_PATH: Path to CA bundle file
    - HTTP_PROXY: Proxy URL for HTTP
    - HTTPS_PROXY: Proxy URL for HTTPS
    
    Returns:
        httpx.Client: HTTP client with appropriate configuration
    """
    ca_bundle_path = os.getenv("ANTHROPIC_CA_BUNDLE_PATH")
    http_proxy = os.getenv("HTTP_PROXY")
    https_proxy = os.getenv("HTTPS_PROXY")
    
    # Use HTTPS proxy if available, otherwise HTTP proxy
    proxy_url = https_proxy or http_proxy
    
    return create_http_client_auto_ssl(
        ca_bundle_path=ca_bundle_path,
        proxy_url=proxy_url
    )


# Example usage and testing
if __name__ == "__main__":
    print("🔍 Testing HTTP Client Utilities...")
    print("=" * 50)
    
    # Test different client configurations
    clients_to_test = [
        ("Standard SSL", create_http_client_with_standard_ssl()),
        ("SSL Disabled", create_http_client_with_ssl_disabled()),
    ]
    
    # Try to add CA bundle client (automatically reads from environment)
    try:
        ca_client = create_http_client_with_ca_bundle()
        clients_to_test.append(("CA Bundle (from env)", ca_client))
    except ValueError as e:
        print(f"⚠️  CA bundle not available: {e}")
    except Exception as e:
        print(f"⚠️  Could not create CA bundle client: {e}")
    
    # Test each client
    for name, client in clients_to_test:
        print(f"\n🧪 Testing {name} client...")
        success = test_http_client(client)
        print(f"✅ {name}: {'Success' if success else 'Failed'}")
        client.close()
    
    print("\n✅ HTTP client utilities ready for use!")
    print("\n💡 Usage examples:")
    print("- For standard SSL: create_http_client_with_standard_ssl()")
    print("- For SSL disabled: create_http_client_with_ssl_disabled()")
    print("- For CA bundle (from env): create_http_client_with_ca_bundle()")
    print("- For environment-based: get_environment_http_client()") 