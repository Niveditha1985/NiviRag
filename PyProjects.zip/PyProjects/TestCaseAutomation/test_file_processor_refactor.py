#!/usr/bin/env python3
"""
Test FileVectorProcessor Refactor

This script tests the refactored FileVectorProcessor to ensure it works correctly
with the new environment-based initialization from faiss_vector_store.
"""

import os
import tempfile
from pathlib import Path

def test_file_processor_refactor():
    """Test the refactored FileVectorProcessor functionality."""
    print("🧪 Testing FileVectorProcessor Refactor")
    print("=" * 60)
    
    # Create a temporary directory for testing
    temp_dir = tempfile.mkdtemp()
    test_store_path = os.path.join(temp_dir, "test_processor_store")
    
    try:
        print("1️⃣ Testing imports...")
        from file_vector_processor import FileVectorProcessor
        print("✅ FileVectorProcessor import successful")
        
        print("\n2️⃣ Testing initialization without environment variable...")
        try:
            # This should create a new store since no FAISS_METADATA_PATH is set
            processor = FileVectorProcessor(store_path=test_store_path)
            print("✅ FileVectorProcessor initialized successfully")
            
            # Check if store was loaded from environment
            if processor.is_environment_loaded():
                print("⚠️  Store was loaded from environment (unexpected)")
            else:
                print("✅ Store was created new (expected)")
            
            print(f"📁 Store path: {processor.get_store_path()}")
            
        except Exception as e:
            print(f"❌ Failed to initialize FileVectorProcessor: {e}")
            return False
        
        print("\n3️⃣ Testing file processing...")
        try:
            # Create a test file
            test_file = os.path.join(temp_dir, "test_doc.txt")
            with open(test_file, 'w') as f:
                f.write("This is a test document for vector processing. "
                       "It contains multiple sentences that will be chunked "
                       "and converted to embeddings for similarity search.")
            
            print(f"📝 Created test file: {test_file}")
            
            # Process the file
            success = processor.process_file(test_file)
            if success:
                print("✅ File processed successfully")
                
                # Check store stats
                stats = processor.get_store_stats()
                print(f"📊 Store stats: {stats}")
                
                # Test search
                query = "test document"
                distances, indices, metadata = processor.search_similar(query, k=2)
                if distances is not None:
                    print(f"🔍 Search successful: found {len(distances)} results")
                else:
                    print("❌ Search failed")
                    return False
                
            else:
                print("❌ File processing failed")
                return False
                
        except Exception as e:
            print(f"❌ File processing test failed: {e}")
            return False
        
        print("\n4️⃣ Testing store saving...")
        try:
            # Save to a different path
            backup_path = os.path.join(temp_dir, "backup_store")
            if processor.save_store(backup_path):
                print(f"✅ Store saved to backup path: {backup_path}")
                print(f"📁 New store path: {processor.get_store_path()}")
                
                # Check if backup files were created
                if os.path.exists(f"{backup_path}.faiss") and os.path.exists(f"{backup_path}.metadata"):
                    print("✅ Backup files created successfully")
                else:
                    print("❌ Backup files not found")
                    return False
            else:
                print("❌ Store saving failed")
                return False
                
        except Exception as e:
            print(f"❌ Store saving test failed: {e}")
            return False
        
        print("\n5️⃣ Testing environment variable loading...")
        try:
            # Set environment variable to point to our backup store
            os.environ["FAISS_METADATA_PATH"] = f"{backup_path}.metadata"
            print(f"   Set FAISS_METADATA_PATH={os.environ['FAISS_METADATA_PATH']}")
            
            # Create new processor - should load from environment
            env_processor = FileVectorProcessor(store_path="different_path")
            
            if env_processor.is_environment_loaded():
                print("✅ Environment-based loading successful!")
                print(f"📁 Environment store path: {env_processor.get_store_path()}")
                
                # Check that it has the same data
                env_stats = env_processor.get_store_stats()
                if env_stats.get('total_vectors', 0) > 0:
                    print("✅ Environment store contains vectors")
                else:
                    print("❌ Environment store is empty")
                    return False
            else:
                print("⚠️  Store was not loaded from environment")
                
        except Exception as e:
            print(f"❌ Environment variable test failed: {e}")
            return False
        
        print("\n✅ All FileVectorProcessor refactor tests passed!")
        return True
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        return False
        
    finally:
        # Clean up
        try:
            # Remove test files
            for ext in ['.faiss', '.metadata']:
                for path in [test_store_path, os.path.join(temp_dir, "backup_store")]:
                    if os.path.exists(f"{path}{ext}"):
                        os.remove(f"{path}{ext}")
            
            # Remove test document
            test_doc = os.path.join(temp_dir, "test_doc.txt")
            if os.path.exists(test_doc):
                os.remove(test_doc)
            
            # Remove temporary directory
            os.rmdir(temp_dir)
            print("✅ Test files cleaned up")
            
        except Exception as e:
            print(f"⚠️  Cleanup warning: {e}")


if __name__ == "__main__":
    print("🚀 Starting FileVectorProcessor Refactor Tests")
    print("=" * 60)
    
    success = test_file_processor_refactor()
    
    print("\n" + "=" * 60)
    print("🏁 FINAL TEST RESULT")
    print("=" * 60)
    
    if success:
        print("🎉 FileVectorProcessor refactor is working correctly!")
        print("\n💡 What was tested:")
        print("   ✅ Environment-based initialization")
        print("   ✅ Local store creation and loading")
        print("   ✅ File processing and vector generation")
        print("   ✅ Store saving and path management")
        print("   ✅ Environment variable override")
        print("   ✅ Store statistics and search functionality")
    else:
        print("❌ Some tests failed - check the output above") 