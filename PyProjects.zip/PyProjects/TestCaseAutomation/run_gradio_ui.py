#!/usr/bin/env python3
"""
Simple launcher for the Gradio Test Case Generator UI.
"""

from gradio_ui import main

if __name__ == "__main__":
    print("🚀 Starting Test Case Generator UI...")
    print("📱 The interface will be available at: http://localhost:7860")
    print("⏹️  Press Ctrl+C to stop the server")
    print("-" * 50)
    
    # Try to load vector store from environment configuration
    try:
        from faiss_vector_store import FAISSVectorStore
        print("🔍 Checking for vector store configuration...")
        vector_store = FAISSVectorStore.from_environment_config()
        
        if vector_store:
            print("✅ Vector store loaded successfully from environment")
            stats = vector_store.get_index_stats()
            print(f"   Total vectors: {stats.get('total_vectors', 'Unknown')}")
        else:
            print("ℹ️ No vector store configuration found - will use default settings")
    except Exception as e:
        print(f"⚠️ Vector store loading failed: {e}")
        print("   Continuing with default settings...")
    
    print("-" * 50)
    
    try:
        main()
    except KeyboardInterrupt:
        print("\n👋 Shutting down the server...")
    except Exception as e:
        print(f"❌ Error starting the server: {e}") 