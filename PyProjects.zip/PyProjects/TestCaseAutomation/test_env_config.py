#!/usr/bin/env python3
"""
Test Environment-based Configuration

This script tests that the configuration is correctly read from environment variables.
"""

import os
from dotenv import load_dotenv
from anthropic_langchain_integration import AnthropicLangChainIntegration

# Load environment variables
load_dotenv()

def test_env_config():
    """
    Test that the environment-based configuration works correctly.
    """
    print("🔍 Testing Environment-based Configuration...")
    print("=" * 50)
    
    # Check environment variables
    api_key = os.getenv("ANTHROPIC_API_KEY")
    model = os.getenv("ANTHROPIC_MODEL", "claude-3-5-sonnet-20241022")
    ssl_verify = os.getenv("SSL_VERIFY", "DEFAULT")
    ca_bundle_path = os.getenv("ANTHROPIC_CA_BUNDLE_PATH")
    
    print(f"🔑 API Key: {'✅ Found' if api_key else '❌ Not found'}")
    print(f"🤖 Model: {model}")
    print(f"🔒 SSL Verify: {ssl_verify}")
    print(f"📦 CA Bundle Path: {'✅ Found' if ca_bundle_path else '❌ Not found'}")
    
    if ca_bundle_path:
        ca_exists = os.path.exists(ca_bundle_path)
        print(f"📁 CA Bundle File: {'✅ Exists' if ca_exists else '❌ Not found'}")
    
    if not api_key:
        print("❌ Cannot test without API key")
        return
    
    try:
        print("\n🧪 Testing AnthropicLangChainIntegration initialization...")
        
        # Test with environment-based configuration
        integration = AnthropicLangChainIntegration()
        print("✅ AnthropicLangChainIntegration initialized successfully")
        print(f"   Model: {integration.model}")
        print(f"   SSL Verify: {integration.ssl_verify}")
        
        # Test a simple API call
        print("\n📡 Testing API call...")
        response = integration.simple_chat("Hello, this is a test message.")
        
        if response.startswith("Error:"):
            print(f"❌ API call failed: {response}")
        else:
            print("✅ API call successful!")
            print(f"📝 Response preview: {response[:100]}...")
            
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    test_env_config() 