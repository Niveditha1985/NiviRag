#!/usr/bin/env python3
"""
OpenAI Text Embedding Client

This module provides functionality to generate text embeddings using OpenAI's
text-embedding-3-small model with proper SSL configuration for corporate environments.
"""

import os
import json
import base64
from typing import List, Union, Optional
from dotenv import load_dotenv
from http_client_utils import create_http_client_with_ca_bundle, get_environment_http_client, create_http_client_with_ssl_disabled

# Load environment variables from .env file
load_dotenv()


class OpenAIEmbeddingClient:
    """
    Client for generating text embeddings using OpenAI's text-embedding-3-small model.
    """
    
    def __init__(self):
        """
        Initialize the OpenAI embedding client.
        
        All configuration is automatically loaded from the .env file:
        - OPENAI_API_KEY: Your OpenAI API key
        - ANTHROPIC_MODEL: The model to use (defaults to claude-3-5-sonnet-20241022)
        - SSL_VERIFY: SSL verification mode ('NONE', 'DEFAULT', 'CUSTOM')
        - ANTHROPIC_CA_BUNDLE_PATH: Path to CA bundle (required if SSL_VERIFY=CUSTOM)
        """
        # Load API key from environment
        self.api_key = os.getenv("OPENAI_API_KEY")
        if not self.api_key:
            raise ValueError("OPENAI_API_KEY not found in .env file or environment variables")
        
        # Load SSL verification setting from environment
        self.ssl_verify = os.getenv("SSL_VERIFY", "DEFAULT").upper()
        if self.ssl_verify not in ["NONE", "DEFAULT", "CUSTOM"]:
            raise ValueError("SSL_VERIFY must be one of: 'NONE', 'DEFAULT', 'CUSTOM'")
        
        # Validate that CA bundle path exists if using CUSTOM SSL
        if self.ssl_verify == "CUSTOM":
            ca_bundle_path = os.getenv("ANTHROPIC_CA_BUNDLE_PATH")
            if not ca_bundle_path:
                raise ValueError("SSL_VERIFY is set to 'CUSTOM' but ANTHROPIC_CA_BUNDLE_PATH is not found in .env file")
        
        self.base_url = "https://api.openai.com/v1"
        self.model = "text-embedding-3-small"
    
    @property
    def ssl_verify(self) -> str:
        """Get the SSL verification setting."""
        return self._ssl_verify
    
    @ssl_verify.setter
    def ssl_verify(self, value: str):
        """Set the SSL verification setting."""
        value_upper = value.upper()
        if value_upper not in ["NONE", "DEFAULT", "CUSTOM"]:
            raise ValueError("SSL_VERIFY must be one of: 'NONE', 'DEFAULT', 'CUSTOM'")
        self._ssl_verify = value_upper
    
    def _create_client(self):
        """
        Create an HTTP client with appropriate SSL configuration based on SSL_VERIFY setting.
        
        SSL_VERIFY options:
        - 'NONE': SSL verification disabled
        - 'DEFAULT': Standard SSL verification
        - 'CUSTOM': Use corporate certificates from ANTHROPIC_CA_BUNDLE_PATH
        
        Returns:
            httpx.Client: Configured HTTP client
        """
        if self.ssl_verify == "NONE":
            # SSL verification disabled
            return create_http_client_with_ssl_disabled()
        elif self.ssl_verify == "CUSTOM":
            # Use corporate CA bundle
            return create_http_client_with_ca_bundle()
        else:  # DEFAULT
            # Use standard SSL verification
            return get_environment_http_client()
    
    def _make_embedding_request(self, texts: List[str], dimensions: int = 1536) -> List[List[float]]:
        """
        Make the actual HTTP request to OpenAI's embedding API.
        
        Args:
            texts (List[str]): List of texts to embed
            dimensions (int): Number of dimensions for the embedding
            
        Returns:
            List[List[float]]: List of embedding vectors
            
        Raises:
            Exception: If the API request fails
        """
        # Prepare the request payload
        payload = {
            "model": self.model,
            "input": texts,
            "dimensions": dimensions,
            "encoding_format": "float"
        }
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        # Create client, make request, and close client
        client = self._create_client()
        try:
            response = client.post(
                f"{self.base_url}/embeddings",
                headers=headers,
                json=payload,
                timeout=30
            )
            
            # Check if request was successful
            response.raise_for_status()
            
            # Parse the response
            data = response.json()
            
            # Extract embeddings
            embeddings = [item["embedding"] for item in data["data"]]
            
            return embeddings
            
        except Exception as e:
            raise Exception(f"Failed to generate embeddings: {str(e)}")
        finally:
            client.close()
    
    def get_embeddings(self, text: Union[str, List[str]], dimensions: int = 1536) -> List[List[float]]:
        """
        Generate embeddings for the given text using OpenAI's text-embedding-3-small model.
        
        This method handles all HTTP communication internally. The caller doesn't need to
        manage any client lifecycle.
        
        Args:
            text (Union[str, List[str]]): Text or list of texts to embed
            dimensions (int): Number of dimensions for the embedding (default: 1536)
        
        Returns:
            List[List[float]]: List of embedding vectors
            
        Raises:
            Exception: If the API request fails
        """
        # Ensure text is a list
        if isinstance(text, str):
            texts = [text]
        else:
            texts = text
        
        return self._make_embedding_request(texts, dimensions)
    
    def get_single_embedding(self, text: str, dimensions: int = 1536) -> List[float]:
        """
        Generate a single embedding for the given text.
        
        This method handles all HTTP communication internally. The caller doesn't need to
        manage any client lifecycle.
        
        Args:
            text (str): Text to embed
            dimensions (int): Number of dimensions for the embedding (default: 1536)
        
        Returns:
            List[float]: Embedding vector
        """
        embeddings = self._make_embedding_request([text], dimensions)
        return embeddings[0]


def create_embedding_client() -> OpenAIEmbeddingClient:
    """
    Factory function to create an OpenAI embedding client.
    
    The API key and SSL configuration will be automatically loaded from the .env file.
    
    SSL_VERIFY options in .env file:
    - 'NONE': SSL verification disabled
    - 'DEFAULT': Standard SSL verification (default)
    - 'CUSTOM': Use corporate certificates from ANTHROPIC_CA_BUNDLE_PATH
    
    Returns:
        OpenAIEmbeddingClient: Configured embedding client
        
    Raises:
        ValueError: If OPENAI_API_KEY is not found in .env file or SSL_VERIFY is invalid
    """
    return OpenAIEmbeddingClient()


# Example usage and testing
if __name__ == "__main__":
    print("🔍 Testing OpenAI Embedding Client...")
    print("=" * 50)
    
    try:
        # Create client (all configuration loaded from .env file)
        client = create_embedding_client()
        
        # Display current SSL configuration
        print(f"🔧 SSL Configuration:")
        print(f"   SSL_VERIFY: {client.ssl_verify}")
        if client.ssl_verify == "CUSTOM":
            print(f"   CA Bundle Path: {os.getenv('ANTHROPIC_CA_BUNDLE_PATH')}")
        
        # Test with a sample text
        sample_text = "This is a test sentence for embedding generation."
        print(f"\n📝 Sample text: {sample_text}")
        
        # Generate embedding
        embedding = client.get_single_embedding(sample_text)
        print(f"✅ Generated embedding with {len(embedding)} dimensions")
        print(f"📊 First 5 values: {embedding[:5]}")
        
        # Test SSL property modification
        print(f"\n🔄 Testing SSL property modification...")
        print(f"   Before: SSL verify = {client.ssl_verify}")
        
        # Test changing SSL mode (this will affect subsequent requests)
        original_ssl_mode = client.ssl_verify
        client.ssl_verify = "NONE"
        print(f"   After setting to NONE: SSL verify = {client.ssl_verify}")
        
        # Test with multiple texts
        sample_texts = [
            "First sentence for testing.",
            "Second sentence for testing.",
            "Third sentence for testing."
        ]
        
        embeddings = client.get_embeddings(sample_texts)
        print(f"✅ Generated {len(embeddings)} embeddings with SSL_VERIFY={client.ssl_verify}")
        
        # Restore original SSL mode
        client.ssl_verify = original_ssl_mode
        print(f"   Restored to original: SSL verify = {client.ssl_verify}")
        
        # Test with different dimensions
        small_embedding = client.get_single_embedding(sample_text, dimensions=512)
        print(f"✅ Generated small embedding with {len(small_embedding)} dimensions")
        
        print("\n✅ OpenAI embedding client test completed successfully!")
        print("💡 No need to manually close the client - HTTP connections are managed automatically!")
        print("\n📋 .env file configuration options:")
        print("   OPENAI_API_KEY=sk-your-api-key-here")
        print("   SSL_VERIFY=DEFAULT|NONE|CUSTOM")
        print("   ANTHROPIC_CA_BUNDLE_PATH=/path/to/ca-bundle.pem  # Required if SSL_VERIFY=CUSTOM")
        
    except ValueError as e:
        print(f"❌ Configuration error: {e}")
        print("\n💡 Make sure to create a .env file with the required configuration:")
        print("   OPENAI_API_KEY=sk-your-api-key-here")
        print("   SSL_VERIFY=DEFAULT|NONE|CUSTOM")
        print("   ANTHROPIC_CA_BUNDLE_PATH=/path/to/ca-bundle.pem  # Required if SSL_VERIFY=CUSTOM")
    except Exception as e:
        print(f"❌ Error during testing: {e}")
        print("\n💡 Check your .env file configuration and network connectivity") 