"""
Gradio UI for Test Case Generator

This module provides a web-based interface for the TestCaseGenerator using Gradio.
"""

import gradio as gr
from test_case_generator import TestCaseGenerator
from offline_test_cases import get_sample_test_cases
import os
import logging
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Set up logging for Gradio UI
def setup_gradio_logging():
    """Set up logging for the Gradio UI."""
    # Create logs directory if it doesn't exist
    log_dir = "logs"
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    # Configure logger
    logger = logging.getLogger("gradio_ui")
    logger.setLevel(logging.INFO)
    
    # Create file handler
    log_file = os.path.join(log_dir, "gradio_ui.log")
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(logging.INFO)
    
    # Create formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    file_handler.setFormatter(formatter)
    
    # Add handler to logger if not already added
    if not logger.handlers:
        logger.addHandler(file_handler)
    
    return logger

# Initialize logger
logger = setup_gradio_logging()

def generate_test_cases_gradio(requirements, business_rules, existing_test_cases):
    """
    Generate test cases using the TestCaseGenerator with fallback to offline mode.
    
    Args:
        requirements (str): The primary requirements for the feature/functionality.
        business_rules (str): Business rules to consider.
        existing_test_cases (str): Existing test cases for context.
        
    Returns:
        str: Generated test cases from the LLM or offline fallback.
    """
    try:
        # Initialize the generator
        generator = TestCaseGenerator()
        
        # Generate test cases
        result = generator.generate_test_cases(
            requirements=requirements,
            business_rules=business_rules if business_rules.strip() else None,
            existing_test_cases=existing_test_cases if existing_test_cases.strip() else None
        )
        
        # Check if it's an overload error
        if "overloaded" in result.lower() or "529" in result.lower():
            # Use offline fallback
            offline_result = get_sample_test_cases(requirements, business_rules)
            return f"⚠️ API is currently overloaded. Here are sample test cases based on your requirements:\n\n{offline_result}"
        return result
    except ValueError as ve:
        # Handle API key or configuration errors
        error_msg = f"Configuration Error: {str(ve)}"
        logger.error(f"Configuration error in generate_test_cases_gradio: {str(ve)}")
        return error_msg
    except Exception as e:
        error_msg = str(e)
        logger.error(f"Unexpected error in generate_test_cases_gradio: {str(e)}")
        
        if "overloaded" in error_msg.lower() or "529" in error_msg.lower():
            # Use offline fallback
            offline_result = get_sample_test_cases(requirements, business_rules)
            return f"⚠️ API is currently overloaded. Here are sample test cases based on your requirements:\n\n{offline_result}"
        else:
            return f"Error: Connection error - {error_msg}"

def create_gradio_interface():
    """
    Create and return the Gradio interface.
    """
    # Define the interface
    with gr.Blocks(
        title="Test Case Generator",
        theme=gr.themes.Soft(),
        css="""
        .gradio-container {
            max-width: 1200px !important;
        }
        .input-box {
            border-radius: 8px;
        }
        .output-box {
            border-radius: 8px;
            background-color: #f8f9fa;
        }
        """
    ) as interface:
        
        # Header
        gr.Markdown(
            """
            # 🤖 Test Case Generator
            Generate comprehensive test cases using AI-powered analysis of requirements, business rules, and existing test cases.
            """
        )
        
        with gr.Row():
            with gr.Column(scale=1):
                # Input section
                gr.Markdown("### 📝 Input Parameters")
                
                requirements_input = gr.Textbox(
                    label="Requirements",
                    placeholder="Enter the primary requirements for the feature/functionality...",
                    lines=6,
                    max_lines=10,
                    elem_classes=["input-box"]
                )
                
                business_rules_input = gr.Textbox(
                    label="Business Rules (Optional)",
                    placeholder="Enter business rules to consider...",
                    lines=4,
                    max_lines=8,
                    elem_classes=["input-box"]
                )
                
                existing_test_cases_input = gr.Textbox(
                    label="Existing Test Cases (Optional)",
                    placeholder="Enter existing test cases for context and consistency...",
                    lines=4,
                    max_lines=8,
                    elem_classes=["input-box"]
                )
                
                # Mode selection
                mode_radio = gr.Radio(
                    choices=["🔄 Online (AI Generated)", "📋 Offline (Sample)"],
                    value="🔄 Online (AI Generated)",
                    label="Generation Mode",
                    info="Choose between AI-generated or sample test cases"
                )
                
                # Generate button
                generate_btn = gr.Button(
                    "🚀 Generate Test Cases",
                    variant="primary",
                    size="lg"
                )
                
                # Clear button
                clear_btn = gr.Button(
                    "🗑️ Clear All",
                    variant="secondary"
                )
            
            with gr.Column(scale=1):
                # Output section
                gr.Markdown("### 📋 Generated Test Cases")
                
                output_text = gr.Textbox(
                    label="Generated Test Cases",
                    lines=20,
                    max_lines=30,
                    interactive=False,
                    elem_classes=["output-box"]
                )
                
                # Status indicator
                status_text = gr.Markdown("Ready to generate test cases...")
        
        # Example section
        with gr.Accordion("💡 Example Input", open=False):
            gr.Markdown(
                """
                **Requirements:**
                ```
                Can you write bdd test cases for the create user API that stores the user in 
                user table and generate user_id. It identifies existing user by email and 
                throws an error. It also does basic email pattern validation and if it fails, 
                it throws an error. It can also accept an optional phone number which can be 
                only 10 digits and throws an error if not.
                ```
                
                **Business Rules:**
                ```
                Create user API requires first name, last name and email and throws an 
                error if any of the three parameters are missing
                ```
                
                **Existing Test Cases:**
                ```
                (Leave empty for new test case generation)
                ```
                """
            )
        
        # Instructions
        with gr.Accordion("📖 Instructions", open=False):
            gr.Markdown(
                """
                ### How to use:
                1. **Requirements**: Enter the primary requirements for the feature or functionality you want to test
                2. **Business Rules**: (Optional) Enter any business rules that should be considered
                3. **Existing Test Cases**: (Optional) Enter existing test cases for context and consistency
                4. Click **"Generate Test Cases"** to create comprehensive test cases
                
                ### Tips:
                - Be specific and detailed in your requirements
                - Include edge cases and error scenarios in business rules
                - Existing test cases help maintain consistency in style and coverage
                - The generated test cases will be in Gherkin format with detailed steps
                """
            )
        
        # Event handlers
        def clear_all():
            return "", "", "", "🔄 Online (AI Generated)", "Ready to generate test cases..."
        
        def on_generate(requirements, business_rules, existing_test_cases, mode):
            if not requirements.strip():
                return "", "❌ Please enter requirements before generating test cases."
            
            status_text = "🔄 Generating test cases... Please wait."
            yield "", status_text
            
            try:
                if mode == "📋 Offline (Sample)":
                    # Use offline mode directly
                    result = get_sample_test_cases(requirements, business_rules)
                    status_text = "✅ Sample test cases generated successfully!"
                    yield result, status_text
                else:
                    # Use online mode with fallback
                    result = generate_test_cases_gradio(requirements, business_rules, existing_test_cases)
                    
                    # Check if it's an overload error
                    if "overloaded" in result.lower() or "529" in result.lower():
                        status_text = "⚠️ API is currently overloaded. Please try again in a few minutes."
                        yield result, status_text
                    else:
                        status_text = "✅ Test cases generated successfully!"
                        yield result, status_text
                        
            except Exception as e:
                error_msg = str(e)
                if "overloaded" in error_msg.lower() or "529" in error_msg.lower():
                    status_text = "⚠️ API is currently overloaded. Please try again in a few minutes."
                else:
                    status_text = f"❌ Error: {error_msg}"
                yield "", status_text
        
        # Connect buttons to functions
        generate_btn.click(
            fn=on_generate,
            inputs=[requirements_input, business_rules_input, existing_test_cases_input, mode_radio],
            outputs=[output_text, status_text]
        )
        
        clear_btn.click(
            fn=clear_all,
            outputs=[requirements_input, business_rules_input, existing_test_cases_input, mode_radio, status_text]
        )
    
    return interface

def main():
    """
    Launch the Gradio interface.
    """
    # Create the interface
    interface = create_gradio_interface()
    
    # Launch the interface
    interface.launch(
        server_name="0.0.0.0",
        server_port=7860,
        share=False,
        show_error=True,
        quiet=False
    )

if __name__ == "__main__":
    main() 