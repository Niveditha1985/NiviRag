"""
File Vector Processor

This module provides a class to process files, create chunks, generate vector embeddings
via OpenAI API, and manage FAISS vector store with metadata handling.
"""

import os
import pickle
import logging
from typing import List, Dict, Any, Optional, Union
from pathlib import Path
import numpy as np

from faiss_vector_store import FAISSVectorStore
from openai_embedding_client import OpenAIEmbeddingClient

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class FileVectorProcessor:
    """
    A class to process files, create chunks, generate vector embeddings via OpenAI API,
    and manage FAISS vector store with metadata handling.
    """
    
    def __init__(self, store_path: str = "vector_store", chunk_size: int = 1000, chunk_overlap: int = 200):
        """
        Initialize the File Vector Processor.
        
        Args:
            store_path (str): Path to store the FAISS index and metadata files
            chunk_size (int): Size of text chunks in characters
            chunk_overlap (int): Overlap between consecutive chunks in characters
        """
        self.store_path = store_path
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        
        # Initialize OpenAI embedding client for embeddings
        try:
            self.embedding_client = OpenAIEmbeddingClient()
            logger.info("OpenAI embedding client initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize OpenAI embedding client: {e}")
            raise
        
        # Initialize vector store - FAISSVectorStore handles environment-based loading automatically
        try:
            from faiss_vector_store import FAISSVectorStore
            
            # Use FAISSVectorStore's built-in environment-based initialization
            # If FAISS_METADATA_PATH is set in .env, it will load from there
            # Otherwise, it will create a new store at store_path
            self.vector_store = FAISSVectorStore(
                dimension=1536, 
                index_type="flat", 
                auto_load_from_env=True
            )
            
            # If no environment store was loaded, save the new store to our specified path
            if not self._is_environment_loaded():
                self.vector_store.save_index(self.store_path)
                logger.info(f"Created new FAISS vector store at {self.store_path}")
            else:
                logger.info("Loaded vector store from environment configuration")
                
        except Exception as e:
            logger.error(f"Failed to initialize vector store: {e}")
            raise
    
    def _create_text_chunks(self, text: str) -> List[str]:
        """
        Create overlapping text chunks from the input text.
        
        Args:
            text (str): Input text to chunk
            
        Returns:
            List[str]: List of text chunks
        """
        chunks = []
        start = 0
        
        while start < len(text):
            end = start + self.chunk_size
            chunk = text[start:end]
            chunks.append(chunk)
            
            # Move start position for next chunk, accounting for overlap
            start = end - self.chunk_overlap
            
            # Ensure we don't get stuck in an infinite loop
            if start >= len(text) - self.chunk_overlap:
                break
        
        # Add the last chunk if it's not already included
        if start < len(text):
            chunks.append(text[start:])
        
        logger.info(f"Created {len(chunks)} text chunks from text of length {len(text)}")
        logger.info(f"First chunk: {chunks[0]}")
        logger.info(f"last chunk: {chunks[-1]}")
        return chunks
    
    def _get_embeddings_from_openai(self, text_chunks: List[str]) -> List[List[float]]:
        """
        Get vector embeddings for text chunks using OpenAI API.
        
        Args:
            text_chunks (List[str]): List of text chunks to embed
            
        Returns:
            List[List[float]]: List of embedding vectors
        """
        embeddings = []
        
        for i, chunk in enumerate(text_chunks):
            try:
                # Use OpenAI's embedding API
                embedding = self.embedding_client.get_single_embedding(chunk)
                embeddings.append(embedding)
                
                logger.info(f"Generated embedding for chunk {i+1}/{len(text_chunks)}")
                
            except Exception as e:
                logger.error(f"Failed to generate embedding for chunk {i}: {e}")
                # Create a zero vector as fallback
                embedding = [0.0] * 1536  # Default dimension
                embeddings.append(embedding)
        
        return embeddings
    
    def process_file(self, file_path: str) -> bool:
        """
        Process a file: read, chunk, generate embeddings, and add to vector store.
        
        Args:
            file_path (str): Path to the file to process
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Check if file exists
            if not os.path.exists(file_path):
                logger.error(f"File not found: {file_path}")
                return False
            
            # Read file content
            file_path_obj = Path(file_path)
            file_extension = file_path_obj.suffix.lower()
            
            # Handle different file types
            if file_extension in ['.txt', '.md', '.py', '.js', '.html', '.css', '.json', '.xml']:
                # Text files
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
            elif file_extension in ['.pdf']:
                # PDF files - would need additional library like PyPDF2
                logger.warning("PDF processing not implemented. Skipping file.")
                return False
            else:
                logger.warning(f"Unsupported file type: {file_extension}. Skipping file.")
                return False
            
            # Create text chunks
            text_chunks = self._create_text_chunks(content)
            
            # Generate embeddings
            embeddings = self._get_embeddings_from_openai(text_chunks)
            
            # Update vector store dimension if needed
            if self.vector_store.dimension != len(embeddings[0]):
                logger.info(f"Updating vector store dimension from {self.vector_store.dimension} to {len(embeddings[0])}")
                # Create new store with correct dimension
                self.vector_store = FAISSVectorStore(dimension=len(embeddings[0]), index_type="flat")
            
            # Create metadata for each chunk
            metadata = []
            vector_ids = []
            
            for i, chunk in enumerate(text_chunks):
                chunk_metadata = {
                    "file_path": file_path,
                    "file_name": file_path_obj.name,
                    "file_extension": file_extension,
                    "chunk_index": i,
                    "chunk_size": len(chunk),
                    "chunk_start": content.find(chunk),
                    "chunk_end": content.find(chunk) + len(chunk),
                    "processing_timestamp": None
                }
                metadata.append(chunk_metadata)
                
                # Create unique vector ID
                vector_id = f"{file_path_obj.stem}_chunk_{i}_{hash(chunk) % 10000}"
                vector_ids.append(vector_id)
            
            # Add vectors to the store
            self.vector_store.add_vectors(
                vectors=embeddings,
                vector_ids=vector_ids,
                metadata=metadata
            )
            
            # Save the updated store
            self.vector_store.save_index(self.store_path)
            
            logger.info(f"Successfully processed file {file_path} and added {len(embeddings)} vectors to store")
            return True
            
        except Exception as e:
            logger.error(f"Failed to process file {file_path}: {e}")
            return False
    
    def add_vectors_to_index(self, vectors: List[List[float]], 
                            vector_ids: Optional[List[str]] = None,
                            metadata: Optional[List[Dict[str, Any]]] = None) -> bool:
        """
        Add vectors to the existing index.
        
        Args:
            vectors (List[List[float]]): List of vectors to add
            vector_ids (Optional[List[str]]): Optional list of vector IDs
            metadata (Optional[List[Dict[str, Any]]]): Optional list of metadata dictionaries
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            if self.vector_store is None:
                logger.error("Vector store not initialized")
                return False
            
            # Update dimension if needed
            if self.vector_store.dimension != len(vectors[0]):
                logger.info(f"Updating vector store dimension from {self.vector_store.dimension} to {len(vectors[0])}")
                # Create new store with correct dimension
                self.vector_store = FAISSVectorStore(dimension=len(vectors[0]), index_type="flat")
            
            # Add vectors to the store
            self.vector_store.add_vectors(vectors, vector_ids, metadata)
            
            # Save the updated store
            self.vector_store.save_index(self.store_path)
            
            logger.info(f"Successfully added {len(vectors)} vectors to the index")
            return True
            
        except Exception as e:
            logger.error(f"Failed to add vectors to index: {e}")
            return False
    
    def search_similar(self, query_text: str, k: int = 5) -> tuple:
        """
        Search for similar vectors in the index.
        
        Args:
            query_text (str): Query text to search for
            k (int): Number of nearest neighbors to return
            
        Returns:
            tuple: (distances, indices, metadata) from the search
        """
        try:
            if self.vector_store is None:
                logger.error("Vector store not initialized")
                return None, None, None
            
            # Generate embedding for query text
            query_embedding = self._get_embeddings_from_openai([query_text])[0]
            
            # Search the index
            distances, indices, metadata = self.vector_store.search(query_embedding, k=k)
            
            return distances, indices, metadata
            
        except Exception as e:
            logger.error(f"Search failed: {e}")
            return None, None, None
    
    def get_store_stats(self) -> Dict[str, Any]:
        """Get statistics about the vector store."""
        if self.vector_store is None:
            return {"error": "Vector store not initialized"}
        
        return self.vector_store.get_index_stats()
    
    def clear_store(self):
        """Clear all vectors from the store."""
        if self.vector_store is None:
            logger.error("Vector store not initialized")
            return
        
        self.vector_store.clear_index()
        self.vector_store.save_index(self.store_path)
        logger.info("Vector store cleared successfully")
    
    def save_store(self, path: str = None) -> bool:
        """
        Save the vector store to the specified path or current store_path.
        
        Args:
            path (str, optional): Path to save the store. If None, uses self.store_path
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            if self.vector_store is None:
                logger.error("Vector store not initialized")
                return False
            
            save_path = path if path is not None else self.store_path
            success = self.vector_store.save_index(save_path)
            
            if success:
                logger.info(f"Vector store saved successfully to {save_path}")
                # Update store_path if a new path was specified
                if path is not None:
                    self.store_path = path
            else:
                logger.error(f"Failed to save vector store to {save_path}")
            
            return success
            
        except Exception as e:
            logger.error(f"Error saving vector store: {e}")
            return False
    
    def get_store_path(self) -> str:
        """Get the current store path."""
        return self.store_path
    
    def _is_environment_loaded(self) -> bool:
        """
        Check if the vector store was loaded from environment configuration.
        
        Returns:
            bool: True if loaded from environment, False if created new
        """
        if self.vector_store is None:
            return False
        
        # Check if the store has vectors (indicating it was loaded from somewhere)
        stats = self.vector_store.get_index_stats()
        return stats.get('total_vectors', 0) > 0


# Example usage
if __name__ == "__main__":
    # Example: Process a file and create vector embeddings
    print("File Vector Processor Example")
    print("=" * 50)
    
    # Create processor
    processor = FileVectorProcessor(store_path="PBS_vector_store")
    
    # Check if store was loaded from environment
    if processor._is_environment_loaded():
        print("✅ Vector store loaded from environment configuration")
    else:
        print("🆕 Vector store created new or loaded from local path")
    
    print(f"📁 Current store path: {processor.get_store_path()}")
    
    # Process a sample file (create one if it doesn't exist)
    sample_file = "/Users/nivenu/Desktop/work_docs/TestCaseGenerator/cancelSubscriptionAPI.txt"
    print("sample_file raw:", repr(sample_file))
    print("exists?", os.path.exists(sample_file))
    print("realpath:", os.path.realpath(sample_file))
    print("isdir?", os.path.isdir(sample_file))
    print("isfile?", os.path.isfile(sample_file))
    print("islink?", os.path.islink(sample_file))
    print("isdir?", os.path.isdir(sample_file))
    print("isfile?", os.path.isfile(sample_file))
    print("islink?", os.path.islink(sample_file))



    if not os.path.exists(sample_file):
        with open(sample_file, 'w') as f:
            f.write("This is a sample text file for testing the vector processor. "
                   "It contains multiple sentences that will be chunked and processed. "
                   "The processor will create embeddings for each chunk and store them "
                   "in a FAISS vector store for similarity search.")
        print(f"📝 Created sample file: {sample_file}")
    
    # Process the file
    print(f"\n🔄 Processing file: {sample_file}")
    success = processor.process_file(sample_file)
    if success:
        print(f"✅ Successfully processed {sample_file}")
        
        # Get store statistics
        stats = processor.get_store_stats()
        print(f"📊 Store statistics: {stats}")
        
        # Search for similar content
        query = "sample text processing"
        print(f"\n🔍 Searching for: '{query}'")
        distances, indices, metadata = processor.search_similar(query, k=3)
        
        if distances is not None:
            print(f"📋 Search results for query '{query}':")
            for i, (dist, idx, meta) in enumerate(zip(distances, indices, metadata)):
                if meta:
                    print(f"  {i+1}. Distance: {dist:.4f}, File: {meta.get('file_name', 'Unknown')}")
        
        # Demonstrate saving to a different path
        print(f"\n💾 Saving store to 'backup_store'...")
        if processor.save_store("backup_store"):
            print("✅ Store saved to backup location")
            print(f"📁 New store path: {processor.get_store_path()}")
        
        # Clean up
    #    if os.path.exists(sample_file):
    #        os.remove(sample_file)
    #        print(f"🗑️  Cleaned up sample file: {sample_file}")
    
    print("\n🎉 File Vector Processor example completed!")
    print("\n💡 Environment Configuration Tips:")
    print("   - Set FAISS_METADATA_PATH in .env to auto-load existing stores")
    print("   - Use processor.save_store() to save to different locations")
    print("   - Check processor.is_environment_loaded() to see source") 