#!/usr/bin/env python3
"""
Test script for FileVectorProcessor

This script demonstrates the usage of the FileVectorProcessor class
for processing files, creating embeddings, and managing vector stores.
"""

import os
import tempfile
from file_vector_processor import FileVectorProcessor


def create_sample_files():
    """Create sample files for testing."""
    sample_files = {}
    
    # Sample text file
    sample_files['text.txt'] = """
    This is a sample text document for testing the vector processor.
    It contains multiple paragraphs with different topics.
    
    The first paragraph discusses machine learning and artificial intelligence.
    These technologies are transforming how we process and analyze data.
    
    The second paragraph covers natural language processing and text analysis.
    Vector embeddings help computers understand the meaning of text.
    
    The third paragraph explains how FAISS vector stores enable efficient similarity search.
    This is useful for finding related documents and content.
    """
    
    # Sample Python file
    sample_files['sample.py'] = '''
def calculate_embeddings(text):
    """Calculate vector embeddings for given text."""
    # This is a sample function
    embeddings = []
    for char in text:
        embeddings.append(ord(char))
    return embeddings

def search_similar(query, database):
    """Search for similar items in database."""
    results = []
    for item in database:
        similarity = calculate_similarity(query, item)
        if similarity > 0.8:
            results.append(item)
    return results
'''
    
    # Sample markdown file
    sample_files['documentation.md'] = """
# Vector Processing Documentation

## Overview
This document describes the vector processing pipeline for text analysis.

## Features
- Text chunking with overlap
- Vector embedding generation
- FAISS index management
- Similarity search capabilities

## Usage
The processor can handle various file types including:
- Text files (.txt)
- Python files (.py)
- Markdown files (.md)
- And more...

## Configuration
- Chunk size: Configurable text chunk size
- Overlap: Configurable overlap between chunks
- Store path: Configurable vector store location
"""
    
    return sample_files


def test_file_processing():
    """Test the file processing functionality."""
    print("=== Testing File Vector Processor ===\n")
    
    # Create sample files
    sample_files = create_sample_files()
    
    # Create a temporary directory for testing
    with tempfile.TemporaryDirectory() as temp_dir:
        print(f"Created temporary directory: {temp_dir}")
        
        # Write sample files to temp directory
        file_paths = []
        for filename, content in sample_files.items():
            file_path = os.path.join(temp_dir, filename)
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            file_paths.append(file_path)
            print(f"Created sample file: {filename}")
        
        print(f"\nCreated {len(file_paths)} sample files")
        
        # Initialize the processor
        store_path = os.path.join(temp_dir, "test_vector_store")
        processor = FileVectorProcessor(store_path=store_path)
        
        print(f"Initialized FileVectorProcessor with store path: {store_path}")
        
        # Process each file
        for file_path in file_paths:
            print(f"\nProcessing file: {os.path.basename(file_path)}")
            success = processor.process_file(file_path)
            if success:
                print(f"✓ Successfully processed {os.path.basename(file_path)}")
            else:
                print(f"✗ Failed to process {os.path.basename(file_path)}")
        
        # Get store statistics
        stats = processor.get_store_stats()
        print(f"\n=== Vector Store Statistics ===")
        for key, value in stats.items():
            print(f"{key}: {value}")
        
        # Test similarity search
        print(f"\n=== Testing Similarity Search ===")
        
        test_queries = [
            "machine learning and AI",
            "vector embeddings and similarity",
            "Python functions and code",
            "documentation and markdown"
        ]
        
        for query in test_queries:
            print(f"\nSearching for: '{query}'")
            distances, indices, metadata = processor.search_similar(query, k=3)
            
            if distances is not None and len(distances) > 0:
                print(f"Found {len(distances)} similar results:")
                for i, (dist, idx, meta) in enumerate(zip(distances, indices, metadata)):
                    if meta:
                        filename = meta.get('file_name', 'Unknown')
                        chunk_idx = meta.get('chunk_index', 'Unknown')
                        print(f"  {i+1}. Distance: {dist:.4f}, File: {filename}, Chunk: {chunk_idx}")
            else:
                print("No results found")
        
        # Test adding vectors directly
        print(f"\n=== Testing Direct Vector Addition ===")
        
        # Create some sample vectors
        sample_vectors = [
            [0.1, 0.2, 0.3] * 512,  # 1536 dimensions
            [0.4, 0.5, 0.6] * 512,
            [0.7, 0.8, 0.9] * 512
        ]
        
        sample_metadata = [
            {"source": "test", "type": "sample", "index": 0},
            {"source": "test", "type": "sample", "index": 1},
            {"source": "test", "type": "sample", "index": 2}
        ]
        
        success = processor.add_vectors_to_index(
            vectors=sample_vectors,
            metadata=sample_metadata
        )
        
        if success:
            print("✓ Successfully added sample vectors directly to index")
        else:
            print("✗ Failed to add sample vectors")
        
        # Get updated statistics
        updated_stats = processor.get_store_stats()
        print(f"\n=== Updated Vector Store Statistics ===")
        for key, value in updated_stats.items():
            print(f"{key}: {value}")
        
        print(f"\n=== Test Completed Successfully ===")
        print(f"All test files and vector store data are in: {temp_dir}")


def main():
    """Main function to run the tests."""
    try:
        test_file_processing()
    except Exception as e:
        print(f"Test failed with error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main() 