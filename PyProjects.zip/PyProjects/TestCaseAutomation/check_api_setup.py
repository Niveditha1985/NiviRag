#!/usr/bin/env python3
"""
API Setup Checker for Test Case Generator

This script helps diagnose and fix API key configuration issues.
"""

import os
from dotenv import load_dotenv

def check_api_setup():
    """
    Check if the Anthropic API key is properly configured.
    """
    print("🔍 Checking API Setup...")
    print("=" * 50)
    
    # Load environment variables
    load_dotenv()
    
    # Check if .env file exists
    env_file_exists = os.path.exists('.env')
    print(f"📁 .env file exists: {'✅ Yes' if env_file_exists else '❌ No'}")
    
    # Check if API key is set
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if api_key:
        # Mask the API key for security
        masked_key = api_key[:8] + "..." + api_key[-4:] if len(api_key) > 12 else "***"
        print(f"🔑 API Key found: ✅ {masked_key}")
        
        # Check if it looks like a valid Anthropic API key
        if api_key.startswith("sk-ant-"):
            print("✅ API Key format looks correct")
        else:
            print("⚠️  API Key format may be incorrect (should start with 'sk-ant-')")
    else:
        print("❌ API Key not found")
    
    # Check for corporate certificates
    ca_bundle_path = os.getenv("ANTHROPIC_CA_BUNDLE_PATH")
    
    print(f"\n🔒 Corporate Certificate Configuration:")
    if ca_bundle_path:
        ca_exists = os.path.exists(ca_bundle_path)
        print(f"📦 CA Bundle: {'✅ Found' if ca_exists else '❌ Not found'} ({ca_bundle_path})")
    else:
        print("📦 CA Bundle: Not configured")
    
    print("\n" + "=" * 50)
    
    if not api_key:
        print("🔧 SETUP INSTRUCTIONS:")
        print("1. Create a .env file in the project root directory")
        print("2. Add your Anthropic API key to the .env file:")
        print("   ANTHROPIC_API_KEY=your_api_key_here")
        print("3. Get your API key from: https://console.anthropic.com/")
        print("4. Restart the application")
        
        # Offer to create .env file
        create_env = input("\nWould you like me to create a .env file template? (y/n): ").lower().strip()
        if create_env == 'y':
            create_env_file()
    else:
        print("✅ API setup looks good!")
        
        # Provide certificate setup guidance if needed
        if not ca_bundle_path:
            print("\n💡 CORPORATE CERTIFICATE SETUP (if behind corporate firewall):")
            print("If you're getting SSL certificate errors, you may need to configure corporate certificates:")
            print("1. Add to your .env file:")
            print("   ANTHROPIC_CA_BUNDLE_PATH=/path/to/your/ca/bundle.pem")
            print("2. Contact your IT department for the correct CA bundle file (.pem or .crt format)")
            print("3. Restart the application")
        
        print("\nYou can now run the Gradio UI with: python run_gradio_ui.py")

def create_env_file():
    """
    Create a .env file template.
    """
    env_content = """# Anthropic API Configuration
# Get your API key from: https://console.anthropic.com/
ANTHROPIC_API_KEY=your_api_key_here

# Optional: Specify a different model
# ANTHROPIC_MODEL=claude-3-5-sonnet-20241022

# Optional: SSL Verification Mode
# SSL_VERIFY=DEFAULT|NONE|CUSTOM
# - DEFAULT: Standard SSL verification
# - NONE: SSL verification disabled
# - CUSTOM: Use corporate certificates from ANTHROPIC_CA_BUNDLE_PATH

# Optional: Corporate CA Bundle (required if SSL_VERIFY=CUSTOM)
# ANTHROPIC_CA_BUNDLE_PATH=/path/to/your/ca/bundle.pem
# Note: Both .pem and .crt file formats are supported
"""
    
    try:
        with open('.env', 'w') as f:
            f.write(env_content)
        print("✅ Created .env file template")
        print("📝 Please edit the .env file and add your actual API key")
    except Exception as e:
        print(f"❌ Failed to create .env file: {e}")

def test_api_connection():
    """
    Test the API connection if API key is available.
    """
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        print("❌ Cannot test connection: API key not found")
        return
    
    print("\n🧪 Testing API Connection...")
    try:
        from anthropic_langchain_integration import AnthropicLangChainIntegration
        
        # Initialize the integration (all configuration from .env file)
        integration = AnthropicLangChainIntegration()
        
        # Test with a simple message
        test_message = "Hello, this is a test message."
        response = integration.simple_chat(test_message)
        
        if response.startswith("Error:"):
            print(f"❌ Connection failed: {response}")
        else:
            print("✅ API connection successful!")
            print(f"📝 Test response: {response[:100]}...")
            
    except Exception as e:
        print(f"❌ Connection test failed: {e}")

if __name__ == "__main__":
    check_api_setup()
    
    # Uncomment the lines below if you want to test the API connection
    # api_key = os.getenv("ANTHROPIC_API_KEY")
    # if api_key:
    #     test_connection = input("\nWould you like to test the API connection? (y/n): ").lower().strip()
    #     if test_connection == 'y':
    #         test_api_connection() 