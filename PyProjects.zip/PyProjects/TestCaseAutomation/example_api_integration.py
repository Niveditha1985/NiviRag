#!/usr/bin/env python3
"""
Example API Integration using HTTP Client Utilities

This script demonstrates how to use the http_client_utils module for different API integrations.
"""

import os
from dotenv import load_dotenv
from http_client_utils import (
    create_http_client_with_standard_ssl,
    create_http_client_with_ssl_disabled,
    create_http_client_with_ca_bundle,
    create_http_client_with_proxy,
    get_environment_http_client,
    test_http_client
)

# Load environment variables
load_dotenv()


def example_anthropic_integration():
    """
    Example integration with Anthropic API using the direct HTTP client approach.
    """
    print("🤖 Example: Anthropic API Integration")
    print("-" * 40)
    
    try:
        # Try to use CA bundle client (automatically reads from environment)
        client = create_http_client_with_ca_bundle()
        print("Using CA bundle HTTP client (from environment)")
    except ValueError:
        # If CA bundle not available, use standard SSL client
        client = create_http_client_with_standard_ssl()
        print("Using standard SSL HTTP client")
    
    # Test connection to Anthropic API
    success = test_http_client(client, "https://api.anthropic.com")
    print(f"Anthropic API connection: {'✅ Success' if success else '❌ Failed'}")
    
    # Use the client for API calls
    try:
        response = client.get("https://api.anthropic.com/v1/models", timeout=10)
        print(f"Anthropic API response status: {response.status_code}")
    except Exception as e:
        print(f"Anthropic API call failed: {e}")
    
    client.close()


def example_openai_integration():
    """
    Example integration with OpenAI API using HTTP client utilities.
    """
    print("🤖 Example: OpenAI API Integration")
    print("-" * 40)
    
    # Get HTTP client based on environment configuration
    client = get_environment_http_client()
    
    # Test connection to OpenAI API
    success = test_http_client(client, "https://api.openai.com")
    print(f"OpenAI API connection: {'✅ Success' if success else '❌ Failed'}")
    
    # Use the client for API calls
    try:
        response = client.get("https://api.openai.com/v1/models", timeout=10)
        print(f"OpenAI API response status: {response.status_code}")
    except Exception as e:
        print(f"OpenAI API call failed: {e}")
    
    client.close()


def example_github_api_integration():
    """
    Example integration with GitHub API using HTTP client utilities.
    """
    print("\n🐙 Example: GitHub API Integration")
    print("-" * 40)
    
    # Create client with CA bundle if available
    try:
        client = create_http_client_with_ca_bundle()
        print("Using CA bundle client")
    except ValueError:
        # If CA bundle not available, use standard SSL
        client = create_http_client_with_standard_ssl()
        print("Using standard SSL client")
    except Exception as e:
        print(f"CA bundle client failed: {e}")
        client = create_http_client_with_standard_ssl()
    
    # Test connection to GitHub API
    success = test_http_client(client, "https://api.github.com")
    print(f"GitHub API connection: {'✅ Success' if success else '❌ Failed'}")
    
    # Use the client for API calls
    try:
        response = client.get("https://api.github.com/zen", timeout=10)
        if response.status_code == 200:
            print(f"GitHub Zen message: {response.text}")
    except Exception as e:
        print(f"GitHub API call failed: {e}")
    
    client.close()


def example_custom_api_integration():
    """
    Example integration with a custom API using HTTP client utilities.
    """
    print("\n🔧 Example: Custom API Integration")
    print("-" * 40)
    
    # Example: Different ways to create clients
    
    # Method 1: Standard SSL
    print("Method 1: Standard SSL client")
    client1 = create_http_client_with_standard_ssl()
    success1 = test_http_client(client1, "https://httpbin.org/get")
    print(f"Standard SSL: {'✅ Success' if success1 else '❌ Failed'}")
    client1.close()
    
    # Method 2: SSL Disabled (for testing)
    print("Method 2: SSL Disabled client")
    client2 = create_http_client_with_ssl_disabled()
    success2 = test_http_client(client2, "https://httpbin.org/get")
    print(f"SSL Disabled: {'✅ Success' if success2 else '❌ Failed'}")
    client2.close()
    
    # Method 3: Environment-based client
    print("Method 3: Environment-based client")
    client3 = get_environment_http_client()
    success3 = test_http_client(client3, "https://httpbin.org/get")
    print(f"Environment-based: {'✅ Success' if success3 else '❌ Failed'}")
    client3.close()


def example_proxy_integration():
    """
    Example integration with proxy configuration.
    """
    print("\n🌐 Example: Proxy Integration")
    print("-" * 40)
    
    # Check if proxy environment variables are set
    http_proxy = os.getenv("HTTP_PROXY")
    https_proxy = os.getenv("HTTPS_PROXY")
    
    if http_proxy or https_proxy:
        proxy_url = https_proxy or http_proxy
        print(f"Using proxy: {proxy_url}")
        
        try:
            # Create client with proxy
            client = create_http_client_with_proxy(proxy_url)
            success = test_http_client(client, "https://httpbin.org/get")
            print(f"Proxy connection: {'✅ Success' if success else '❌ Failed'}")
            client.close()
        except Exception as e:
            print(f"Proxy client failed: {e}")
    else:
        print("No proxy configuration found")


def main():
    """
    Run all example integrations.
    """
    print("🚀 HTTP Client Utilities - Example API Integrations")
    print("=" * 60)
    
    # Run examples
    example_anthropic_integration()
    example_openai_integration()
    example_github_api_integration()
    example_custom_api_integration()
    example_proxy_integration()
    
    print("\n✅ All examples completed!")
    print("\n💡 Tips:")
    print("- Use get_environment_http_client() for automatic configuration")
    print("- Set ANTHROPIC_CA_BUNDLE_PATH for corporate certificates")
    print("- Set HTTP_PROXY/HTTPS_PROXY for proxy configuration")
    print("- Always close clients when done: client.close()")


if __name__ == "__main__":
    main() 