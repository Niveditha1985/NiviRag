#!/usr/bin/env python3
"""
Test script for the vector search integration in TestCaseGenerator.

This script tests the new vector search functionality for automatically retrieving
business rules from the vector store.
"""

import os
import sys
from test_case_generator import TestCaseGenerator


def test_vector_search_integration():
    """Test the vector search integration functionality."""
    print("🧪 Testing Vector Search Integration in TestCaseGenerator")
    print("=" * 60)
    
    try:
        # Initialize the generator
        print("1️⃣ Initializing TestCaseGenerator...")
        generator = TestCaseGenerator()
        print("✅ TestCaseGenerator initialized successfully")
        
        # Test vector store stats
        print("\n2️⃣ Checking vector store statistics...")
        stats = generator.get_vector_store_stats()
        print(f"   Total vectors: {stats.get('total_vectors', 0)}")
        print(f"   Dimension: {stats.get('dimension', 'N/A')}")
        print(f"   Index type: {stats.get('index_type', 'N/A')}")
        
        # Test requirements for vector search
        test_requirements = """
        Create a user registration API that validates email format, ensures unique emails,
        and stores user data securely in the database.
        """
        
        print(f"\n3️⃣ Testing vector search with requirements:")
        print(f"   Requirements: {test_requirements.strip()}")
        
        # Test automatic business rules retrieval
        print("\n4️⃣ Testing automatic business rules retrieval...")
        retrieved_rules = generator._retrieve_business_rules_from_vector_store(test_requirements)
        
        if retrieved_rules:
            print("✅ Business rules retrieved successfully:")
            print(retrieved_rules)
        else:
            print("⚠️  No business rules retrieved (vector store may be empty)")
        
        # Test test case generation with vector search
        print("\n5️⃣ Testing test case generation with vector search...")
        test_cases = generator.generate_test_cases(
            requirements=test_requirements,
            use_vector_search=True
        )
        
        if test_cases and "Error:" not in test_cases:
            print("✅ Test cases generated successfully with vector search")
            print(f"   Generated {len(test_cases)} characters of test cases")
        else:
            print("❌ Test case generation failed or returned error")
            print(f"   Result: {test_cases}")
        
        print("\n✅ Vector search integration test completed successfully!")
        
    except Exception as e:
        print(f"❌ Test failed with error: {str(e)}")
        import traceback
        traceback.print_exc()
        return False
    
    return True


def test_vector_store_population():
    """Test the vector store population functionality."""
    print("\n🔄 Testing Vector Store Population")
    print("=" * 40)
    
    try:
        generator = TestCaseGenerator()
        
        # Sample business rules for testing
        sample_rules = [
            "User authentication requires valid credentials",
            "Password must be at least 8 characters long",
            "Email addresses must be unique in the system",
            "API rate limiting applies to all endpoints",
            "Data encryption is mandatory for sensitive information"
        ]
        
        print(f"📝 Populating vector store with {len(sample_rules)} business rules...")
        success = generator.populate_vector_store_with_business_rules(sample_rules, "test_business_rules")
        
        if success:
            print("✅ Vector store populated successfully")
            
            # Check stats after population
            stats = generator.get_vector_store_stats()
            print(f"   New total vectors: {stats.get('total_vectors', 0)}")
            
            # Test search with populated store
            test_query = "user authentication and password requirements"
            print(f"\n🔍 Testing search with query: '{test_query}'")
            
            retrieved = generator._retrieve_business_rules_from_vector_store(test_query, k=3)
            if retrieved:
                print("✅ Search successful with populated store:")
                print(retrieved)
            else:
                print("⚠️  Search returned no results")
        else:
            print("❌ Failed to populate vector store")
            
    except Exception as e:
        print(f"❌ Vector store population test failed: {str(e)}")
        return False
    
    return True


if __name__ == "__main__":
    print("🚀 Starting Vector Search Integration Tests")
    print("=" * 60)
    
    # Run tests
    test1_success = test_vector_search_integration()
    test2_success = test_vector_store_population()
    
    print("\n" + "=" * 60)
    print("📊 Test Results Summary:")
    print(f"   Vector Search Integration: {'✅ PASSED' if test1_success else '❌ FAILED'}")
    print(f"   Vector Store Population: {'✅ PASSED' if test2_success else '❌ FAILED'}")
    
    if test1_success and test2_success:
        print("\n🎉 All tests passed! Vector search integration is working correctly.")
        sys.exit(0)
    else:
        print("\n💥 Some tests failed. Please check the error messages above.")
        sys.exit(1) 