#!/usr/bin/env python3
"""
Debug script to understand LangChain ChatAnthropic structure
"""

import os
from dotenv import load_dotenv
from langchain_anthropic import ChatAnthropic

# Load environment variables
load_dotenv()

def debug_langchain_structure():
    """
    Debug the structure of LangChain ChatAnthropic object.
    """
    print("🔍 Debugging LangChain ChatAnthropic Structure...")
    print("=" * 50)
    
    # Get API key
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        print("❌ API key not found")
        return
    
    try:
        # Create the LangChain model
        llm = ChatAnthropic(
            anthropic_api_key=api_key,
            model="claude-3-5-sonnet-20241022",
            temperature=0.7,
            max_tokens=4096
        )
        
        print("✅ LangChain model created successfully")
        
        # Debug the structure
        print(f"\n📋 Model type: {type(llm)}")
        print(f"📋 Model attributes: {dir(llm)}")
        
        if hasattr(llm, '_client'):
            print(f"\n🔧 _client type: {type(llm._client)}")
            print(f"🔧 _client attributes: {dir(llm._client)}")
            
            if hasattr(llm._client, '_client'):
                print(f"\n🌐 _client._client type: {type(llm._client._client)}")
                print(f"🌐 _client._client attributes: {dir(llm._client._client)}")
        
        # Try to find HTTP client related attributes
        print("\n🔍 Looking for HTTP client related attributes...")
        for attr in dir(llm):
            if 'http' in attr.lower() or 'client' in attr.lower():
                print(f"  - {attr}: {getattr(llm, attr)}")
        
        if hasattr(llm, '_client'):
            for attr in dir(llm._client):
                if 'http' in attr.lower() or 'client' in attr.lower():
                    print(f"  - _client.{attr}: {getattr(llm._client, attr)}")
        
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    debug_langchain_structure() 