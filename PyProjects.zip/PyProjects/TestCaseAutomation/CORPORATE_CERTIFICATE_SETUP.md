# Corporate Certificate Setup Guide

This guide helps you configure corporate certificates to resolve SSL certificate verification issues when using the Test Case Generator behind a corporate firewall.

## Problem

If you're getting SSL certificate errors like:
```
[SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: self-signed certificate in certificate chain
```

This typically happens when you're behind a corporate firewall that intercepts HTTPS traffic and uses its own certificates.

## Solutions

### Option 1: Use Corporate CA Bundle (Recommended)

1. **Contact your IT department** to obtain:
   - CA bundle file containing your organization's certificate authorities

2. **Add CA bundle path to your `.env` file**:
   ```bash
   ANTHROPIC_API_KEY=your_api_key_here
   ANTHROPIC_CA_BUNDLE_PATH=/path/to/your/ca/bundle.pem
   ```
   
   **Note**: Both `.pem` and `.crt` file formats are supported. The application will automatically detect and use this configuration.

3. **Restart the application**

### Option 2: Configure System Certificate Store

If your organization provides certificates through the system certificate store:

1. **Install corporate certificates** in your system's certificate store
2. **Set environment variable** to use system certificates:
   ```bash
   export SSL_CERT_FILE=/path/to/system/ca-bundle.crt
   ```

### Option 3: Use Proxy Configuration

If your organization uses a proxy:

1. **Set proxy environment variables**:
   ```bash
   export HTTP_PROXY=http://proxy.company.com:8080
   export HTTPS_PROXY=http://proxy.company.com:8080
   ```

2. **Add proxy authentication** if required:
   ```bash
   export HTTP_PROXY=http://username:password@proxy.company.com:8080
   export HTTPS_PROXY=http://username:password@proxy.company.com:8080
   ```

### Option 4: Disable SSL Verification (Last Resort)

⚠️ **Security Warning**: This disables SSL certificate verification and should only be used as a last resort.

The application will automatically try this if all other methods fail, but you can also force it by setting:
```bash
export ANTHROPIC_DISABLE_SSL=true
```

## Testing Your Setup

1. **Run the setup checker**:
   ```bash
   python check_api_setup.py
   ```

2. **Test the connection**:
   ```bash
   python test_api_connection.py
   ```

3. **Test the full application**:
   ```bash
   python run_gradio_ui.py
   ```

## Common Certificate File Locations

### macOS
- System certificates: `/System/Library/OpenSSL/cert.pem`
- Keychain certificates: Use Keychain Access app

### Linux
- System certificates: `/etc/ssl/certs/ca-certificates.crt`
- User certificates: `~/.certs/`

### Windows
- System certificates: Use Certificate Manager (certmgr.msc)
- User certificates: Use Certificate Manager (certmgr.msc)

## Troubleshooting

### Certificate Format Issues
- Ensure certificates are in PEM format
- Check file permissions (should be readable)
- Verify certificate chain is complete

### Path Issues
- Use absolute paths in `.env` file
- Ensure paths don't contain spaces or special characters
- Check that files actually exist at the specified paths

### Permission Issues
- Ensure the application has read access to certificate files
- Check file ownership and permissions

### Still Getting Errors?
1. Check the logs in `logs/test_case_generator.log`
2. Run `python test_api_connection.py` for detailed error information
3. Contact your IT department for assistance with certificate configuration

## Security Best Practices

1. **Use corporate certificates** instead of disabling SSL verification
2. **Keep certificate files secure** and don't commit them to version control
3. **Use environment variables** instead of hardcoding paths
4. **Regularly update certificates** when they expire
5. **Monitor certificate validity** and renew before expiration

## Support

If you continue to have issues:
1. Check the application logs for detailed error messages
2. Contact your IT department for certificate assistance
3. Verify your network configuration and firewall settings 