#!/usr/bin/env python3
"""
Example usage of TestCaseGenerator

This script demonstrates how to use the TestCaseGenerator class
with different types of requirements and scenarios.
"""

import os
from test_case_generator import TestCaseGenerator


def example_basic_usage():
    """Basic usage example."""
    print("📝 Example 1: Basic Test Case Generation")
    print("=" * 50)
    
    generator = TestCaseGenerator()
    
    requirements = """
    User Login Feature:
    1. Users can login with email and password
    2. Invalid credentials show error message
    3. Successful login redirects to dashboard
    4. Remember me functionality works
    """
    
    result = generator.generate_test_cases(requirements)
    print("Generated Test Cases:")
    print(result[:800] + "..." if len(result) > 800 else result)
    print("\n" + "="*60 + "\n")


def example_with_business_rules():
    """Example with business rules."""
    print("📝 Example 2: Test Case Generation with Business Rules")
    print("=" * 50)
    
    generator = TestCaseGenerator()
    
    requirements = """
    E-commerce Checkout Process:
    1. Users can add items to cart
    2. Users can proceed to checkout
    3. Users can enter shipping information
    4. Users can select payment method
    5. Users can complete purchase
    """
    
    business_rules = """
    - Users must be logged in to checkout
    - Minimum order value is $10
    - Free shipping for orders over $50
    - Credit card payments require CVV
    - Orders are processed within 24 hours
    """
    
    result = generator.generate_test_cases(
        requirements=requirements,
        business_rules=business_rules
    )
    
    print("Generated Test Cases with Business Rules:")
    print(result[:800] + "..." if len(result) > 800 else result)
    print("\n" + "="*60 + "\n")


def example_json_output():
    """Example with JSON structured output."""
    print("📝 Example 3: JSON Structured Output")
    print("=" * 50)
    
    generator = TestCaseGenerator()
    
    requirements = """
    User Profile Management:
    1. Users can view their profile
    2. Users can edit profile information
    3. Users can upload profile picture
    4. Users can change password
    """
    
    result = generator.generate_test_cases_with_json_output(requirements)
    
    print("JSON Structured Test Cases:")
    import json
    print(json.dumps(result, indent=2))
    print("\n" + "="*60 + "\n")


def example_api_testing():
    """Example for API testing."""
    print("📝 Example 4: API-Specific Test Cases")
    print("=" * 50)
    
    generator = TestCaseGenerator()
    
    requirements = """
    REST API for User Management:
    1. GET /api/users - List all users
    2. GET /api/users/{id} - Get user by ID
    3. POST /api/users - Create new user
    4. PUT /api/users/{id} - Update user
    5. DELETE /api/users/{id} - Delete user
    """
    
    business_rules = """
    - All endpoints require JWT authentication
    - User IDs must be UUID format
    - Email addresses must be unique
    - Passwords must be hashed before storage
    """
    
    result = generator.generate_test_cases_for_specific_type(
        requirements=requirements,
        test_type="API",
        business_rules=business_rules
    )
    
    print("API Test Cases:")
    print(result[:800] + "..." if len(result) > 800 else result)
    print("\n" + "="*60 + "\n")


def example_complete_workflow():
    """Complete workflow example."""
    print("📝 Example 5: Complete Workflow with All Inputs")
    print("=" * 50)
    
    generator = TestCaseGenerator()
    
    requirements = """
    Online Banking Transfer Feature:
    1. Users can transfer money between accounts
    2. Users can schedule future transfers
    3. Users can set up recurring transfers
    4. Transfer limits are enforced
    5. Transfer confirmations are sent
    """
    
    business_rules = """
    - Daily transfer limit is $10,000
    - Transfers over $1,000 require 2FA
    - Scheduled transfers must be at least 1 hour in advance
    - Recurring transfers can be daily, weekly, or monthly
    - Transfer confirmations are sent via email and SMS
    """
    
    existing_test_cases = """
    TC001: User can view account balance
    TC002: User can view transaction history
    TC003: User can change account settings
    TC004: User can update contact information
    """
    
    result = generator.generate_test_cases(
        requirements=requirements,
        business_rules=business_rules,
        existing_test_cases=existing_test_cases
    )
    
    print("Complete Test Cases:")
    print(result[:800] + "..." if len(result) > 800 else result)
    print("\n" + "="*60 + "\n")


def main():
    """Run all examples."""
    print("🚀 TestCaseGenerator Examples")
    print("=" * 60)
    
    # Check for API key
    if not os.getenv("ANTHROPIC_API_KEY"):
        print("⚠️  Warning: ANTHROPIC_API_KEY not found!")
        print("   Set your API key: export ANTHROPIC_API_KEY='your_key_here'")
        print("   Examples will not work without a valid API key.")
        return
    
    try:
        example_basic_usage()
        example_with_business_rules()
        example_json_output()
        example_api_testing()
        example_complete_workflow()
        
        print("✅ All examples completed successfully!")
        
    except Exception as e:
        print(f"❌ Error running examples: {e}")
        print("Make sure you have a valid ANTHROPIC_API_KEY and internet connection.")


if __name__ == "__main__":
    main() 