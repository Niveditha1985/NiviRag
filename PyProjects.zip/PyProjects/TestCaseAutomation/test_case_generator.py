#!/usr/bin/env python3
"""
Test Case Generator using Anthropic Claude API with LangChain

This module provides functionality to generate test cases using the AnthropicLangChainIntegration class.
Now includes vector search integration to automatically retrieve relevant business rules.
"""

import os
import logging
from typing import Optional, Dict, Any, List
from anthropic_langchain_integration import AnthropicLangChainIntegration
from openai_embedding_client import OpenAIEmbeddingClient
from faiss_vector_store import FAISSVectorStore


class TestCaseGenerator:
    """
    A class to generate test cases using Anthropic Claude API with LangChain.
    Now includes vector search integration to automatically retrieve business rules.
    """
    
    def __init__(self):
        """
        Initialize the TestCaseGenerator.
        
        All configuration (API key, model, SSL settings) is automatically loaded from the .env file.
        """
        # Set up logging first
        self._setup_logging()
        
        try:
            # Create integration (all configuration loaded from .env file)
            self.integration = AnthropicLangChainIntegration()
            
            # Initialize OpenAI embedding client for vector search
            self.embedding_client = OpenAIEmbeddingClient()
            
            # Initialize vector store for business rules retrieval
            # Use existing vector store if available, otherwise create new one
            self.vector_store = FAISSVectorStore(
                dimension=1536,  # OpenAI text-embedding-3-small dimension
                index_type="flat",
                auto_load_from_env=True
            )
            
            self.logger.info("TestCaseGenerator initialized successfully with vector search capabilities")
            
        except Exception as e:
            error_msg = f"Failed to initialize TestCaseGenerator: {str(e)}"
            self.logger.error(error_msg)
            raise ValueError(error_msg)
    
    def _setup_logging(self):
        """
        Set up logging configuration for the TestCaseGenerator.
        """
        # Create logs directory if it doesn't exist
        log_dir = "logs"
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
        
        # Configure logger
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.INFO)
        
        # Create file handler
        log_file = os.path.join(log_dir, "test_case_generator.log")
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.INFO)
        
        # Create formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        file_handler.setFormatter(formatter)
        
        # Add handler to logger if not already added
        if not self.logger.handlers:
            self.logger.addHandler(file_handler)
    
    def _retrieve_business_rules_from_vector_store(self, requirements: str, k: int = 5) -> str:
        """
        Retrieve relevant business rules from the vector store based on requirements.
        
        Args:
            requirements (str): The requirements text to search for
            k (int): Number of similar vectors to retrieve
            
        Returns:
            str: Retrieved business rules as formatted text
        """
        try:
            # Generate embedding for the requirements
            self.logger.info("Generating vector embedding for requirements")
            requirements_embedding = self.embedding_client.get_single_embedding(requirements)
            
            # Search the vector store for similar content
            self.logger.info(f"Searching vector store for {k} similar business rules")
            distances, indices, metadata = self.vector_store.search(requirements_embedding, k=k)
            
            if indices is None or len(indices) == 0:
                self.logger.warning("No business rules found in vector store")
                return ""
            
            # Extract and format the retrieved business rules
            business_rules = []
            for i, (distance, idx) in enumerate(zip(distances, indices)):
                if idx < len(self.vector_store.metadata) and self.vector_store.metadata[idx]:
                    rule_metadata = self.vector_store.metadata[idx]
                    # Extract the actual business rule text from metadata
                    # Assuming metadata contains the business rule content
                    if isinstance(rule_metadata, dict) and 'content' in rule_metadata:
                        rule_text = rule_metadata['content']
                    elif isinstance(rule_metadata, str):
                        rule_text = rule_metadata
                    else:
                        # If metadata structure is different, use a default format
                        rule_text = f"Business Rule {i+1} (similarity: {1-distance:.3f})"
                    
                    business_rules.append(f"- {rule_text}")
            
            if business_rules:
                retrieved_rules = "Retrieved Business Rules from Vector Store:\n" + "\n".join(business_rules)
                self.logger.info(f"Retrieved {len(business_rules)} business rules from vector store")
                return retrieved_rules
            else:
                self.logger.warning("No business rules could be extracted from search results")
                return ""
                
        except Exception as e:
            self.logger.error(f"Error retrieving business rules from vector store: {str(e)}")
            return ""
    
    def populate_vector_store_with_business_rules(self, business_rules: List[str], save_path: str = "business_rules_store") -> bool:
        """
        Populate the vector store with business rules for testing and demonstration.
        
        Args:
            business_rules (List[str]): List of business rule texts to add
            save_path (str): Path to save the populated vector store
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            self.logger.info(f"Populating vector store with {len(business_rules)} business rules")
            
            # Generate embeddings for all business rules
            embeddings = self.embedding_client.get_embeddings(business_rules)
            
            # Create metadata for each business rule
            metadata = []
            vector_ids = []
            for i, rule in enumerate(business_rules):
                metadata.append({
                    'content': rule,
                    'type': 'business_rule',
                    'index': i,
                    'timestamp': '2024-01-01'  # Example timestamp
                })
                vector_ids.append(f"br_{i}")
            
            # Add vectors to the store
            self.vector_store.add_vectors(embeddings, vector_ids, metadata)
            
            # Save the populated store
            success = self.vector_store.save_index(save_path)
            if success:
                self.logger.info(f"Vector store populated and saved to {save_path}")
                return True
            else:
                self.logger.error(f"Failed to save populated vector store to {save_path}")
                return False
                
        except Exception as e:
            self.logger.error(f"Error populating vector store: {str(e)}")
            return False
    
    def get_vector_store_stats(self) -> Dict[str, Any]:
        """
        Get statistics about the current vector store.
        
        Returns:
            Dict[str, Any]: Vector store statistics
        """
        try:
            return self.vector_store.get_index_stats()
        except Exception as e:
            self.logger.error(f"Error getting vector store stats: {str(e)}")
            return {"error": str(e)}
    
    def generate_test_cases(
        self, 
        requirements: str, 
        business_rules: Optional[str] = None, 
        existing_test_cases: Optional[str] = None,
        max_retries: int = 3,
        use_vector_search: bool = True
    ) -> str:
        """
        Generate test cases based on requirements, business rules, and existing test cases.
        Now includes automatic business rules retrieval via vector search.
        
        Args:
            requirements (str): The primary requirements for the feature/functionality.
            business_rules (str, optional): Business rules to consider (overrides vector search if provided).
            existing_test_cases (str, optional): Existing test cases for context.
            max_retries (int): Maximum number of retry attempts for API overload errors.
            use_vector_search (bool): Whether to use vector search to retrieve business rules.
            
        Returns:
            str: Generated test cases from the LLM.
        """
        import time
        import random
        
        # If no business rules provided and vector search is enabled, retrieve them automatically
        if not business_rules and use_vector_search:
            self.logger.info("No business rules provided, retrieving from vector store")
            retrieved_business_rules = self._retrieve_business_rules_from_vector_store(requirements)
            if retrieved_business_rules:
                business_rules = retrieved_business_rules
                self.logger.info("Successfully retrieved business rules from vector store")
            else:
                self.logger.info("No business rules found in vector store, proceeding without them")
        
        # System template - defines the role and context
        system_template = """You are an expert QA engineer and test automation specialist. 
Your task is to generate test cases in Gherkin format based on the provided requirements, business rules, and existing test cases.

Guidelines for test case generation:
1. Create test cases that cover all functional requirements
2. Include positive, negative, and edge case scenarios
3. Consider boundary value analysis
4. Ensure test cases are clear, specific, and executable
5. Follow best practices for test case documentation
6. Consider business rules when generating test scenarios
7. Learn from existing test cases to maintain consistency in style and coverage

Format your response as a structured list of test cases only. Do not include any other text or comments."""

        # Human template with input variables
        human_template = """Please generate comprehensive test cases for the following:

REQUIREMENTS:
{requirements}

{business_rules_section}

{existing_test_cases_section}

Please provide:
1. A summary of the test strategy in Gherkin format
2. Also for each test case, add the following fields:
   - Test Case ID
   - Test Case Title
   - Preconditions
   - Priority (High/Medium/Low)
   - Test Type (Functional/Non-functional/Integration/UI/API)

Focus on creating test cases that ensure comprehensive coverage of the requirements while considering the business rules and maintaining consistency with existing test patterns."""

        # Prepare input variables
        business_rules_section = f"BUSINESS RULES:\n{business_rules}" if business_rules else ""
        existing_test_cases_section = f"EXISTING TEST CASES (for reference and consistency):\n{existing_test_cases}" if existing_test_cases else ""
        
        input_variables = {
            "requirements": requirements,
            "business_rules_section": business_rules_section,
            "existing_test_cases_section": existing_test_cases_section
        }
        
        # Retry logic for API overload errors
        for attempt in range(max_retries):
            try:
                # Generate test cases using the chat chain
                result = self.integration.run_chat_chain(
                    system_template=system_template,
                    human_template=human_template,
                    input_variables=input_variables
                )
                
                # Log successful generation
                self.logger.info("Test cases generated successfully")
                return result
                
            except Exception as e:
                error_message = str(e).lower()
                
                # Log the error with attempt information
                self.logger.error(
                    f"Error in generate_test_cases (attempt {attempt + 1}/{max_retries}): {str(e)}"
                )
                
                if "overloaded" in error_message or "529" in error_message:
                    if attempt < max_retries - 1:
                        # Exponential backoff with jitter
                        wait_time = (2 ** attempt) + random.uniform(0, 1)
                        retry_message = f"API overloaded (attempt {attempt + 1}/{max_retries}). Waiting {wait_time:.1f} seconds..."
                        print(retry_message)
                        self.logger.info(retry_message)
                        time.sleep(wait_time)
                        continue
                    else:
                        final_error = f"Error: API is currently overloaded after {max_retries} attempts. Please try again in a few minutes."
                        self.logger.error(final_error)
                        return final_error
                else:
                    # Log non-overload errors and re-raise them
                    self.logger.error(f"Non-overload error occurred: {str(e)}")
                    raise e
    
    def generate_test_cases_with_json_output(
        self, 
        requirements: str, 
        business_rules: Optional[str] = None, 
        existing_test_cases: Optional[str] = None,
        use_vector_search: bool = True
    ) -> Dict[str, Any]:
        """
        Generate test cases with structured JSON output.
        Now includes automatic business rules retrieval via vector search.
        
        Args:
            requirements (str): The primary requirements for the feature/functionality.
            business_rules (str, optional): Business rules to consider (overrides vector search if provided).
            existing_test_cases (str, optional): Existing test cases for context.
            use_vector_search (bool): Whether to use vector search to retrieve business rules.
            
        Returns:
            Dict[str, Any]: Structured JSON response with test cases.
        """
        # If no business rules provided and vector search is enabled, retrieve them automatically
        if not business_rules and use_vector_search:
            self.logger.info("No business rules provided, retrieving from vector store for JSON output")
            retrieved_business_rules = self._retrieve_business_rules_from_vector_store(requirements)
            if retrieved_business_rules:
                business_rules = retrieved_business_rules
                self.logger.info("Successfully retrieved business rules from vector store for JSON output")
            else:
                self.logger.info("No business rules found in vector store, proceeding without them for JSON output")
        
        # Define the expected JSON schema
        json_schema = {
            "type": "object",
            "properties": {
                "test_strategy": {
                    "type": "string",
                    "description": "Summary of the overall test strategy"
                },
                "test_cases": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "test_case_id": {"type": "string"},
                            "title": {"type": "string"},
                            "description": {"type": "string"},
                            "preconditions": {"type": "array", "items": {"type": "string"}},
                            "test_steps": {"type": "array", "items": {"type": "string"}},
                            "expected_results": {"type": "array", "items": {"type": "string"}},
                            "priority": {"type": "string", "enum": ["High", "Medium", "Low"]},
                            "test_type": {"type": "string", "enum": ["Functional", "Non-functional", "Integration", "UI", "API"]}
                        },
                        "required": ["test_case_id", "title", "description", "test_steps", "expected_results", "priority", "test_type"]
                    }
                }
            },
            "required": ["test_strategy", "test_cases"]
        }
        
        # Create the prompt
        business_rules_section = f"BUSINESS RULES:\n{business_rules}" if business_rules else ""
        existing_test_cases_section = f"EXISTING TEST CASES (for reference):\n{existing_test_cases}" if existing_test_cases else ""
        
        prompt = f"""Generate comprehensive test cases for the following requirements:

REQUIREMENTS:
{requirements}

{business_rules_section}

{existing_test_cases_section}

Please provide a structured response with a test strategy summary and detailed test cases."""

        return self.integration.generate_json_response(prompt, json_schema)
    
    def generate_test_cases_for_specific_type(
        self, 
        requirements: str, 
        test_type: str,
        business_rules: Optional[str] = None, 
        existing_test_cases: Optional[str] = None,
        use_vector_search: bool = True
    ) -> str:
        """
        Generate test cases for a specific test type (Functional, API, UI, etc.).
        Now includes automatic business rules retrieval via vector search.
        
        Args:
            requirements (str): The primary requirements for the feature/functionality.
            test_type (str): The type of test cases to generate (Functional, API, UI, Integration, etc.).
            business_rules (str, optional): Business rules to consider (overrides vector search if provided).
            existing_test_cases (str, optional): Existing test cases for context.
            use_vector_search (bool): Whether to use vector search to retrieve business rules.
            
        Returns:
            str: Generated test cases for the specific type.
        """
        # If no business rules provided and vector search is enabled, retrieve them automatically
        if not business_rules and use_vector_search:
            self.logger.info(f"No business rules provided, retrieving from vector store for {test_type} test cases")
            retrieved_business_rules = self._retrieve_business_rules_from_vector_store(requirements)
            if retrieved_business_rules:
                business_rules = retrieved_business_rules
                self.logger.info(f"Successfully retrieved business rules from vector store for {test_type} test cases")
            else:
                self.logger.info(f"No business rules found in vector store, proceeding without them for {test_type} test cases")
        
        system_template = f"""You are an expert QA engineer specializing in {test_type} testing. 
Generate comprehensive {test_type} test cases based on the provided requirements, business rules, and existing test cases.

Focus specifically on {test_type} testing aspects and ensure all test cases are relevant to this testing type."""

        human_template = f"""Please generate {test_type} test cases for the following:

REQUIREMENTS:
{{requirements}}

{{business_rules_section}}

{{existing_test_cases_section}}

Please provide detailed {test_type} test cases with:
- Test Case ID
- Test Case Title  
- Description
- Preconditions
- Test Steps (specific to {test_type} testing)
- Expected Results
- Priority (High/Medium/Low)

Focus on {test_type} specific scenarios and considerations."""

        # Prepare input variables
        business_rules_section = f"BUSINESS RULES:\n{business_rules}" if business_rules else ""
        existing_test_cases_section = f"EXISTING TEST CASES (for reference):\n{existing_test_cases}" if existing_test_cases else ""
        
        input_variables = {
            "requirements": requirements,
            "business_rules_section": business_rules_section,
            "existing_test_cases_section": existing_test_cases_section
        }
        
        return self.integration.run_chat_chain(
            system_template=system_template,
            human_template=human_template,
            input_variables=input_variables
        )


def main():
    """
    Example usage of the TestCaseGenerator with vector search capabilities.
    """
    # Initialize the generator
    generator = TestCaseGenerator()
    
    # Example requirements
    requirements = """
    Can you write bdd test cases for the create user API that stores the user in 
    user table and generate user_id. It identifies existing user by email and 
    throws an error. It also does basic email 
    pattern validation and if it fails, it throws an error. It can also accept an 
    optional phone number which can be only 10 digits and throws an error if not.
    """
    
    # Example existing test cases
    existing_test_cases = """ """
    
    print("=== Test Case Generator with Vector Search ===\n")
    
    # Show current vector store stats
    print("📊 Current Vector Store Statistics:")
    stats = generator.get_vector_store_stats()
    print(f"   Total vectors: {stats.get('total_vectors', 0)}")
    print(f"   Dimension: {stats.get('dimension', 'N/A')}")
    print(f"   Index type: {stats.get('index_type', 'N/A')}")
    print()
    
    # If vector store is empty, populate it with sample business rules
    if stats.get('total_vectors', 0) == 0:
        print("🔄 Vector store is empty, populating with sample business rules...")
        
        sample_business_rules = [
            "Create user API requires first name, last name and email and throws an error if any of the three parameters are missing",
            "User email must be unique in the system - duplicate emails are not allowed",
            "Email validation must follow standard email format patterns",
            "Phone number must be exactly 10 digits if provided",
            "User ID is automatically generated as a UUID when user is created",
            "All user data must be stored in the user table with proper encryption",
            "API responses must include appropriate HTTP status codes and error messages",
            "Input validation must occur before any database operations",
            "User creation must be atomic - either all data is saved or nothing is saved",
            "Audit logging must be maintained for all user creation operations"
        ]
        
        success = generator.populate_vector_store_with_business_rules(sample_business_rules)
        if success:
            print("✅ Vector store populated successfully!")
            # Refresh stats
            stats = generator.get_vector_store_stats()
            print(f"   New total vectors: {stats.get('total_vectors', 0)}")
        else:
            print("❌ Failed to populate vector store")
        print()
    
    # Generate comprehensive test cases with automatic business rules retrieval
    print("🔍 Using vector search to automatically retrieve business rules...")
    test_cases = generator.generate_test_cases(
        requirements=requirements,
        existing_test_cases=existing_test_cases,
        use_vector_search=True  # Enable vector search for business rules
    )
    
    print("Generated Test Cases:")
    print(test_cases)
    print("\n" + "="*50 + "\n")
    
    # Example with manual business rules (vector search will be skipped)
    print("=== Generating Test Cases with Manual Business Rules ===\n")
    manual_business_rules = """Create user API requires first name, last name and email and throws an 
    error if any of the three parameters are missing"""
    
    test_cases_manual = generator.generate_test_cases(
        requirements=requirements,
        business_rules=manual_business_rules,  # This will override vector search
        existing_test_cases=existing_test_cases,
        use_vector_search=True
    )
    
    print("Generated Test Cases (with manual business rules):")
    print(test_cases_manual)
    print("\n" + "="*50 + "\n")
    
    # Generate JSON structured test cases with vector search
    print("=== Generating JSON Structured Test Cases with Vector Search ===\n")
    try:
        json_test_cases = generator.generate_test_cases_with_json_output(
            requirements=requirements,
            existing_test_cases=existing_test_cases,
            use_vector_search=True
        )
        
        print("JSON Structured Test Cases:")
        print(json_test_cases)
        print("\n" + "="*50 + "\n")
    except Exception as e:
        print(f"JSON generation failed: {e}")
    
    # Generate API-specific test cases with vector search
    print("=== Generating API Test Cases with Vector Search ===\n")
    try:
        api_test_cases = generator.generate_test_cases_for_specific_type(
            requirements=requirements,
            test_type="API",
            existing_test_cases=existing_test_cases,
            use_vector_search=True
        )
        
        print("API Test Cases:")
        print(api_test_cases)
        print("\n" + "="*50 + "\n")
    except Exception as e:
        print(f"API test case generation failed: {e}")
    
    print("✅ Vector search integration test completed!")
    print("\n💡 Key Features:")
    print("   - Automatic business rules retrieval via vector search")
    print("   - Manual business rules override when needed")
    print("   - All test case generation methods support vector search")
    print("   - Comprehensive logging for debugging")
    print("   - Vector store population for testing")
    print("   - Statistics and monitoring capabilities")


if __name__ == "__main__":
    main() 