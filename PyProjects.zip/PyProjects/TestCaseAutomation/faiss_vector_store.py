import faiss
import numpy as np
import pickle
import os
from typing import List, Tuple, Optional, Union
import logging
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class FAISSVectorStore:
    """
    A class to handle vector storage and retrieval using FAISS.
    Supports both CPU and GPU operations, and various FAISS index types.
    """
    
    def __init__(self, dimension: int = None, index_type: str = "flat", use_gpu: bool = False, 
                 auto_load_from_env: bool = True):
        """
        Initialize the FAISS vector store.
        
        Args:
            dimension (int, optional): Dimension of the vectors to be stored
            index_type (str): Type of FAISS index ('flat', 'ivf', 'hnsw', etc.)
            use_gpu (bool): Whether to use GPU acceleration (requires faiss-gpu)
            auto_load_from_env (bool): Whether to automatically try loading from .env configuration
        """
        self.dimension = dimension
        self.index_type = index_type
        self.use_gpu = use_gpu
        self.index = None
        self.vector_ids = []  # Store mapping of vector IDs to their positions
        self.metadata = []     # Store metadata for each vector
        
        # Try to load from environment configuration first
        if auto_load_from_env:
            env_store = self.from_environment_config()
            if env_store is not None:
                # Copy the loaded store's attributes to self
                self.index = env_store.index
                self.vector_ids = env_store.vector_ids
                self.metadata = env_store.metadata
                self.dimension = env_store.dimension
                self.index_type = env_store.index_type
                self.use_gpu = env_store.use_gpu
                logger.info("Vector store loaded from environment configuration")
                return
        
        # If no environment config or loading failed, create new index
        if self.dimension is None:
            raise ValueError("Dimension must be specified when creating a new index")
        
        self._create_index()
    
    @classmethod
    def from_environment_config(cls, dimension: int = None, index_type: str = "flat", use_gpu: bool = False):
        """
        Initialize the vector store from environment configuration.
        
        Checks for FAISS_METADATA_PATH in .env file. If found and the file exists,
        loads the existing vector store. Otherwise, returns None.
        
        Args:
            dimension (int, optional): Fallback dimension if loading fails
            index_type (str): Fallback index type if loading fails
            use_gpu (bool): Fallback GPU setting if loading fails
            
        Returns:
            FAISSVectorStore instance if loaded successfully, None otherwise
        """
        try:
            # Check for metadata path in environment
            metadata_path = os.getenv("FAISS_METADATA_PATH")
            
            if not metadata_path:
                logger.info("No FAISS_METADATA_PATH found in environment, will create new index")
                return None
            
            # Remove .metadata extension if present to get base path
            if metadata_path.endswith('.metadata'):
                base_path = metadata_path[:-10]  # Remove '.metadata'
            else:
                base_path = metadata_path
            
            # Check if both .faiss and .metadata files exist
            faiss_path = f"{base_path}.faiss"
            metadata_file_path = f"{base_path}.metadata"
            
            if not os.path.exists(faiss_path):
                logger.warning(f"FAISS index file not found: {faiss_path}")
                return None
                
            if not os.path.exists(metadata_file_path):
                logger.warning(f"Metadata file not found: {metadata_file_path}")
                return None
            
            logger.info(f"Found existing vector store at {base_path}, loading...")
            
            # Create instance and load existing index
            instance = cls.__new__(cls)
            instance.dimension = dimension
            instance.index_type = index_type
            instance.use_gpu = use_gpu
            instance.index = None
            instance.vector_ids = []
            instance.metadata = []
            
            # Load the existing index
            if instance.load_index(base_path):
                logger.info(f"Successfully loaded vector store from {base_path}")
                return instance
            else:
                logger.error(f"Failed to load vector store from {base_path}")
                return None
                
        except Exception as e:
            logger.error(f"Error loading from environment configuration: {e}")
            return None
    
    def _create_index(self):
        """Create the FAISS index based on the specified type."""
        try:
            if self.index_type == "flat":
                self.index = faiss.IndexFlatL2(self.dimension)
            elif self.index_type == "ivf":
                # IVF index requires training data, so we'll use a basic one for now
                self.index = faiss.IndexFlatL2(self.dimension)
                logger.info("IVF index type selected but not yet implemented. Using FlatL2 instead.")
            elif self.index_type == "hnsw":
                self.index = faiss.IndexHNSWFlat(self.dimension, 32)  # 32 neighbors
            else:
                logger.warning(f"Unknown index type '{self.index_type}'. Using FlatL2 instead.")
                self.index = faiss.IndexFlatL2(self.dimension)
            
            if self.use_gpu:
                try:
                    res = faiss.StandardGpuResources()
                    self.index = faiss.index_cpu_to_gpu(res, 0, self.index)
                    logger.info("GPU acceleration enabled")
                except Exception as e:
                    logger.warning(f"GPU acceleration failed: {e}. Falling back to CPU.")
                    self.use_gpu = False
            
            logger.info(f"FAISS index created successfully: {self.index_type}, dimension: {self.dimension}")
            
        except Exception as e:
            logger.error(f"Failed to create FAISS index: {e}")
            raise
    
    def add_vectors(self, vectors: Union[np.ndarray, List[List[float]], List[np.ndarray]], 
                    vector_ids: Optional[List[str]] = None,
                    metadata: Optional[List[dict]] = None) -> List[str]:
        """
        Add vectors to the FAISS index.
        
        Args:
            vectors: Input vectors as numpy array, list of lists, or list of numpy arrays
            vector_ids: Optional list of IDs for the vectors
            metadata: Optional list of metadata dictionaries for each vector
            
        Returns:
            List of vector IDs that were added
        """
        try:
            # Convert vectors to numpy array if needed
            if isinstance(vectors, list):
                if isinstance(vectors[0], list):
                    vectors = np.array(vectors, dtype=np.float32)
                elif isinstance(vectors[0], np.ndarray):
                    vectors = np.vstack(vectors).astype(np.float32)
                else:
                    raise ValueError("Vectors must be a list of lists, list of numpy arrays, or numpy array")
            elif isinstance(vectors, np.ndarray):
                vectors = vectors.astype(np.float32)
            else:
                raise ValueError("Vectors must be a list of lists, list of numpy arrays, or numpy array")
            
            # Validate dimensions
            if vectors.shape[1] != self.dimension:
                raise ValueError(f"Vector dimension {vectors.shape[1]} doesn't match expected dimension {self.dimension}")
            
            # Generate vector IDs if not provided
            if vector_ids is None:
                vector_ids = [f"vec_{len(self.vector_ids) + i}" for i in range(len(vectors))]
            
            # Generate metadata if not provided
            if metadata is None:
                metadata = [{"added_timestamp": None} for _ in range(len(vectors))]
            
            # Add vectors to FAISS index
            self.index.add(vectors)
            
            # Store metadata
            self.vector_ids.extend(vector_ids)
            self.metadata.extend(metadata)
            
            logger.info(f"Successfully added {len(vectors)} vectors to FAISS index")
            return vector_ids
            
        except Exception as e:
            logger.error(f"Failed to add vectors: {e}")
            raise
    
    def search(self, query_vector: Union[List[float], np.ndarray], 
               k: int = 5, return_metadata: bool = True) -> Tuple[np.ndarray, np.ndarray, Optional[List]]:
        """
        Search for similar vectors in the index.
        
        Args:
            query_vector: Query vector to search for
            k: Number of nearest neighbors to return
            return_metadata: Whether to return metadata for the results
            
        Returns:
            Tuple of (distances, indices, metadata)
        """
        try:
            # Convert query vector to numpy array
            if isinstance(query_vector, list):
                query_vector = np.array([query_vector], dtype=np.float32)
            elif isinstance(query_vector, np.ndarray):
                query_vector = query_vector.reshape(1, -1).astype(np.float32)
            else:
                raise ValueError("Query vector must be a list or numpy array")
            
            # Validate dimensions
            if query_vector.shape[1] != self.dimension:
                raise ValueError(f"Query vector dimension {query_vector.shape[1]} doesn't match expected dimension {self.dimension}")
            
            # Search the index
            distances, indices = self.index.search(query_vector, k)
            
            # Get metadata if requested
            metadata = None
            if return_metadata:
                metadata = []
                for idx in indices[0]:
                    if idx < len(self.metadata):
                        metadata.append(self.metadata[idx])
                    else:
                        metadata.append(None)
            
            return distances[0], indices[0], metadata
            
        except Exception as e:
            logger.error(f"Search failed: {e}")
            raise
    
    def get_vector_by_id(self, vector_id: str) -> Optional[Tuple[np.ndarray, dict]]:
        """
        Retrieve a vector and its metadata by ID.
        
        Args:
            vector_id: ID of the vector to retrieve
            
        Returns:
            Tuple of (vector, metadata) or None if not found
        """
        try:
            if vector_id in self.vector_ids:
                idx = self.vector_ids.index(vector_id)
                # Note: FAISS doesn't support direct retrieval by index, 
                # so we can only return metadata here
                return None, self.metadata[idx]
            return None
        except Exception as e:
            logger.error(f"Failed to get vector by ID: {e}")
            return None
    
    def get_index_stats(self) -> dict:
        """Get statistics about the FAISS index."""
        try:
            stats = {
                "total_vectors": self.index.ntotal,
                "dimension": self.dimension,
                "index_type": self.index_type,
                "use_gpu": self.use_gpu,
                "vector_ids_count": len(self.vector_ids),
                "metadata_count": len(self.metadata)
            }
            return stats
        except Exception as e:
            logger.error(f"Failed to get index stats: {e}")
            return {}
    
    def save_index(self, filepath: str) -> bool:
        """
        Save the FAISS index and metadata to disk.
        
        Args:
            filepath: Path where to save the index
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Save FAISS index
            index_path = f"{filepath}.faiss"
            faiss.write_index(self.index, index_path)
            
            # Save metadata and vector IDs
            metadata_path = f"{filepath}.metadata"
            metadata_data = {
                "vector_ids": self.vector_ids,
                "metadata": self.metadata,
                "dimension": self.dimension,
                "index_type": self.index_type,
                "use_gpu": self.use_gpu
            }
            
            with open(metadata_path, 'wb') as f:
                pickle.dump(metadata_data, f)
            
            logger.info(f"Index saved successfully to {filepath}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to save index: {e}")
            return False
    
    def load_index(self, filepath: str) -> bool:
        """
        Load a FAISS index and metadata from disk.
        
        Args:
            filepath: Path to the saved index
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Load FAISS index
            index_path = f"{filepath}.faiss"
            if not os.path.exists(index_path):
                raise FileNotFoundError(f"Index file not found: {index_path}")
            
            self.index = faiss.read_index(index_path)
            
            # Load metadata and vector IDs
            metadata_path = f"{filepath}.metadata"
            if not os.path.exists(metadata_path):
                raise FileNotFoundError(f"Metadata file not found: {metadata_path}")
            
            with open(metadata_path, 'rb') as f:
                metadata_data = pickle.load(f)
            
            self.vector_ids = metadata_data["vector_ids"]
            self.metadata = metadata_data["metadata"]
            self.dimension = metadata_data["dimension"]
            self.index_type = metadata_data["index_type"]
            self.use_gpu = metadata_data["use_gpu"]
            
            logger.info(f"Index loaded successfully from {filepath}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to load index: {e}")
            return False
    
    def clear_index(self):
        """Clear all vectors from the index."""
        try:
            self.index.reset()
            self.vector_ids.clear()
            self.metadata.clear()
            logger.info("Index cleared successfully")
        except Exception as e:
            logger.error(f"Failed to clear index: {e}")
    
    @classmethod
    def from_saved_index(cls, filepath: str, dimension: int = None, index_type: str = "flat", use_gpu: bool = False):
        """
        Create a FAISSVectorStore instance and immediately load a saved index.
        This avoids creating an empty index when you want to load existing data.
        
        Args:
            filepath: Path to the saved index
            dimension: Dimension of vectors (will be loaded from saved index if not provided)
            index_type: Index type (will be loaded from saved index if not provided)
            use_gpu: Whether to use GPU acceleration
            
        Returns:
            FAISSVectorStore instance with loaded index
        """
        try:
            # Create instance with minimal parameters
            instance = cls.__new__(cls)
            instance.dimension = dimension
            instance.index_type = index_type
            instance.use_gpu = use_gpu
            instance.index = None
            instance.vector_ids = []
            instance.metadata = []
            
            # Load the saved index immediately
            if instance.load_index(filepath):
                return instance
            else:
                raise RuntimeError(f"Failed to load index from {filepath}")
                
        except Exception as e:
            logger.error(f"Failed to create instance from saved index: {e}")
            raise


def create_faiss_store_from_vectors(vectors: Union[np.ndarray, List[List[float]], List[np.ndarray]], 
                                   dimension: int,
                                   index_type: str = "flat",
                                   use_gpu: bool = False,
                                   vector_ids: Optional[List[str]] = None,
                                   metadata: Optional[List[dict]] = None) -> FAISSVectorStore:
    """
    Convenience function to create a FAISS store and populate it with vectors in one call.
    
    Args:
        vectors: Input vectors
        dimension: Dimension of the vectors
        index_type: Type of FAISS index
        use_gpu: Whether to use GPU acceleration
        vector_ids: Optional vector IDs
        metadata: Optional metadata
        
    Returns:
        FAISSVectorStore instance
    """
    store = FAISSVectorStore(dimension, index_type, use_gpu)
    store.add_vectors(vectors, vector_ids, metadata)
    return store


def create_faiss_store_from_environment(dimension: int = None, index_type: str = "flat", use_gpu: bool = False) -> FAISSVectorStore:
    """
    Convenience function to create a FAISS store from environment configuration.
    
    This function checks for FAISS_METADATA_PATH in the .env file and loads an existing
    vector store if found. Otherwise, creates a new one with the specified parameters.
    
    Args:
        dimension: Dimension of vectors (required if creating new store)
        index_type: Type of FAISS index
        use_gpu: Whether to use GPU acceleration
        
    Returns:
        FAISSVectorStore instance (either loaded from environment or newly created)
        
    Raises:
        ValueError: If dimension is not specified and no existing store is found
    """
    # Try to load from environment first
    store = FAISSVectorStore.from_environment_config(dimension, index_type, use_gpu)
    
    if store is not None:
        return store
    
    # If no environment config found, create new store
    if dimension is None:
        raise ValueError("Dimension must be specified when creating a new vector store")
    
    return FAISSVectorStore(dimension, index_type, use_gpu, auto_load_from_env=False)


# Example usage
if __name__ == "__main__":
    print("Creating FAISS vector store...")
    
    # Example 1: Environment-based initialization
    print("\n1️⃣ Testing environment-based initialization...")
    try:
        # This will check for FAISS_METADATA_PATH in .env file
        env_store = create_faiss_store_from_environment(dimension=3)
        print("✅ Environment-based store created/loaded successfully")
        print(f"   Store stats: {env_store.get_index_stats()}")
    except Exception as e:
        print(f"⚠️  Environment-based initialization: {e}")
        print("   This is normal if FAISS_METADATA_PATH is not set in .env file")
    
    # Example 2: Traditional initialization
    print("\n2️⃣ Testing traditional initialization...")
    try:
        # Create a simple vector store
        store = FAISSVectorStore(dimension=3, index_type="flat")
        print("✅ Traditional store created successfully")
        
        # Sample vectors (3D vectors)
        sample_vectors = [
            [1.0, 2.0, 3.0],
            [4.0, 5.0, 6.0],
            [7.0, 8.0, 9.0],
            [1.1, 2.1, 3.1],
            [4.1, 5.1, 6.1]
        ]
        
        # Add vectors
        vector_ids = store.add_vectors(sample_vectors)
        print(f"✅ Added {len(vector_ids)} vectors successfully")
        
        # Test search
        query = [1.0, 2.0, 3.0]
        distances, indices, metadata = store.search(query, k=3)
        print(f"✅ Search successful: found {len(distances)} results")
        
        # Save the index for future environment-based loading
        save_path = "example_vector_store"
        store.save_index(save_path)
        print(f"✅ Index saved to {save_path}")
        print("   You can now set FAISS_METADATA_PATH={save_path}.metadata in .env file")
        
    except Exception as e:
        print(f"❌ Traditional initialization failed: {e}")
    
    print("\n✅ FAISS vector store example completed successfully!")
    print("\n💡 Environment Configuration:")
    print("   To use environment-based loading, add to your .env file:")
    print("   FAISS_METADATA_PATH=path/to/your/vector_store.metadata") 