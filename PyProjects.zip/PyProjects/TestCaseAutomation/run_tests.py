#!/usr/bin/env python3
"""
Simple test runner for TestCaseGenerator

This script provides easy ways to run different types of tests.
"""

import os
import sys
from test_test_case_generator import (
    TestTestCaseGenerator, 
    manual_test_examples, 
    performance_test, 
    integration_test
)


def run_unit_tests():
    """Run unit tests."""
    print("🧪 Running Unit Tests...")
    print("=" * 50)
    
    import unittest
    # Create test suite
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromTestCase(TestTestCaseGenerator)
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    print(f"\n✅ Unit Tests Completed: {result.testsRun} tests run")
    print(f"❌ Failures: {len(result.failures)}")
    print(f"❌ Errors: {len(result.errors)}")
    
    return len(result.failures) == 0 and len(result.errors) == 0


def check_api_key():
    """Check if API key is available."""
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        print("⚠️  Warning: ANTHROPIC_API_KEY not found in environment variables.")
        print("   Manual tests and integration tests will be skipped.")
        print("   Set your API key: export ANTHROPIC_API_KEY='your_key_here'")
        return False
    return True


def main():
    """Main test runner."""
    print("🚀 TestCaseGenerator Test Suite")
    print("=" * 50)
    
    # Always run unit tests first
    unit_tests_passed = run_unit_tests()
    
    print("\n" + "=" * 50)
    
    # Check if we can run integration tests
    has_api_key = check_api_key()
    
    if has_api_key:
        print("\n🔗 Running Integration Tests...")
        print("=" * 50)
        try:
            integration_test()
            print("✅ Integration tests completed successfully!")
        except Exception as e:
            print(f"❌ Integration tests failed: {e}")
        
        print("\n" + "=" * 50)
        
        print("\n📊 Running Performance Tests...")
        print("=" * 50)
        try:
            performance_test()
            print("✅ Performance tests completed!")
        except Exception as e:
            print(f"❌ Performance tests failed: {e}")
        
        print("\n" + "=" * 50)
        
        # Ask user if they want to run manual tests
        response = input("\n🤖 Run manual tests with real API calls? (y/n): ").lower().strip()
        if response in ['y', 'yes']:
            print("\n🔧 Running Manual Tests...")
            print("=" * 50)
            try:
                manual_test_examples()
                print("✅ Manual tests completed!")
            except Exception as e:
                print(f"❌ Manual tests failed: {e}")
    else:
        print("\n⏭️  Skipping integration and manual tests (no API key)")
    
    print("\n" + "=" * 50)
    print("🎉 Test suite completed!")
    
    if not unit_tests_passed:
        print("❌ Some unit tests failed. Please review the output above.")
        sys.exit(1)
    else:
        print("✅ All unit tests passed!")


if __name__ == "__main__":
    main() 