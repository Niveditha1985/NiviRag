#!/usr/bin/env python3
"""
Test SSL Certificate Fix

This script tests the TestCaseGenerator with SSL certificate handling.
"""

from test_case_generator import TestCaseGenerator

def test_ssl_fix():
    """
    Test the SSL certificate fix.
    """
    print("🔍 Testing SSL Certificate Fix...")
    print("=" * 50)
    
    try:
        # Initialize the generator (this will handle SSL issues automatically)
        generator = TestCaseGenerator()
        
        # Test with a simple prompt
        requirements = "Test requirement for SSL fix verification"
        
        print("📡 Testing API call with SSL handling...")
        result = generator.generate_test_cases(requirements=requirements)
        
        if result.startswith("Error:"):
            print(f"❌ Still getting error: {result}")
        else:
            print("✅ SSL fix successful! API call worked.")
            print(f"📝 Response preview: {result[:200]}...")
            
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    test_ssl_fix() 