#!/usr/bin/env python3
"""
Context Building Layer

This module assembles retrieved chunks into LLM-ready context for the RAG search system.
"""

import logging
from typing import Dict, List, Any
from collections import defaultdict

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ContextBuilder:
    """
    Assembles retrieved chunks into LLM-ready context.
    
    This class takes search results and combines them into coherent context
    that can be passed to an LLM for answer generation. It handles deduplication,
    ordering, and token management.
    """
    
    def __init__(self, max_context_tokens: int = 8000):
        """
        Initialize the context builder.
        
        Args:
            max_context_tokens: Maximum context window size in tokens
        """
        self.max_context_tokens = max_context_tokens
        logger.info(f"ContextBuilder initialized with max_context_tokens={max_context_tokens}")
    
    def build_context(self, search_results: List[Dict], query: str) -> str:
        """
        Main method: combines chunks into coherent context.
        
        Args:
            search_results: List of search results from SemanticSearchEngine
            query: Original user query for context
            
        Returns:
            str: Formatted context string ready for LLM
        """
        if not search_results:
            logger.warning("No search results provided for context building")
            return ""
        
        logger.info(f"Building context from {len(search_results)} search results")
        
        # Step 1: Deduplicate results
        deduplicated_results = self.deduplicate_results(search_results)
        logger.info(f"Deduplicated to {len(deduplicated_results)} unique chunks")
        logger.info(f"================================================")
        logger.info(f"   complete deduplicated_results: {deduplicated_results}")
        logger.info(f"================================================")

        # Step 2: Format context with sources
        context = self.format_context_with_sources(deduplicated_results)
        
        # Step 3: Truncate to token limit if necessary
        context = self._truncate_to_token_limit(context)
        
        logger.info(f"Context built: {len(context)} characters")
        return context
    
    def deduplicate_results(self, results: List[Dict]) -> List[Dict]:
        """
        Remove duplicate or overlapping chunks.
        
        Args:
            results: List of search results
            
        Returns:
            List[Dict]: Deduplicated results, keeping highest scoring version
        """
        # Group by chunk_id and keep highest scoring version
        chunk_groups = defaultdict(list)
        
        for result in results:
            chunk_id = result.get('chunk_id', 'unknown')
            chunk_groups[chunk_id].append(result)
        
        deduplicated = []
        for chunk_id, group in chunk_groups.items():
            # Keep the highest scoring version
            best_result = max(group, key=lambda x: x.get('score', 0))
            deduplicated.append(best_result)
        
        # Sort by score (highest first)
        deduplicated.sort(key=lambda x: x.get('score', 0), reverse=True)
        
        logger.debug(f"Deduplicated {len(results)} results to {len(deduplicated)} unique chunks")
        return deduplicated
    
    def format_context_with_sources(self, results: List[Dict]) -> str:
        """
        Format chunks with source citations.
        
        Args:
            results: List of deduplicated search results
            
        Returns:
            str: Context with citation markers
        """
        if not results:
            return ""
        
        context_parts = []
        
        for i, result in enumerate(results, 1):
            # Extract content
            content = result.get('content', '').strip()
            if not content:
                continue
            
            # Extract metadata for citation
            topic = result.get('topic', 'Unknown Topic')
            section_title = result.get('section_title', 'Untitled Section')
            document_path = result.get('document_path', 'Unknown Document')
            score = result.get('score', 0.0)
            
            # Format citation
            citation = f"[{i}]"
            source_info = f"Source: {document_path}"
            if section_title and section_title != 'Untitled Section':
                source_info += f" - {section_title}"
            if topic and topic != 'Unknown Topic':
                source_info += f" (Topic: {topic})"
            
            # Format chunk with citation
            chunk_text = f"{citation} {content}\n{source_info} (Relevance: {score:.3f})\n"
            context_parts.append(chunk_text)
        
        # Join all chunks
        context = "\n".join(context_parts)
        
        logger.info(f"Formatted context with {len(context_parts)} chunks")
        return context
    
    def estimate_tokens(self, text: str) -> int:
        """
        Rough token count estimation.
        
        Args:
            text: Text to estimate tokens for
            
        Returns:
            int: Approximate token count
        """
        # Rough estimation: ~4 characters per token for English text
        # This is a conservative estimate
        char_count = len(text)
        estimated_tokens = char_count // 4
        
        return estimated_tokens
    
    def _truncate_to_token_limit(self, context: str) -> str:
        """
        Truncate context to stay within token limits.
        
        Args:
            context: Full context string
            
        Returns:
            str: Truncated context if necessary
        """
        estimated_tokens = self.estimate_tokens(context)
        
        if estimated_tokens <= self.max_context_tokens:
            logger.debug(f"Context within token limit: {estimated_tokens}/{self.max_context_tokens}")
            return context
        
        logger.warning(f"Context exceeds token limit: {estimated_tokens}/{self.max_context_tokens}")
        
        # Truncate by removing chunks from the end (lowest scoring)
        # Split by citation markers to preserve chunk boundaries
        chunks = context.split('\n[')
        
        truncated_chunks = []
        current_tokens = 0
        
        for i, chunk in enumerate(chunks):
            if i == 0:
                # First chunk doesn't have the split prefix
                chunk_text = chunk
            else:
                # Add back the citation marker
                chunk_text = '[' + chunk
            
            chunk_tokens = self.estimate_tokens(chunk_text)
            
            if current_tokens + chunk_tokens <= self.max_context_tokens:
                truncated_chunks.append(chunk_text)
                current_tokens += chunk_tokens
            else:
                break
        
        truncated_context = '\n'.join(truncated_chunks)
        final_tokens = self.estimate_tokens(truncated_context)
        
        logger.info(f"Truncated context: {estimated_tokens} -> {final_tokens} tokens")
        return truncated_context
    
    def get_context_stats(self, context: str) -> Dict[str, Any]:
        """
        Get statistics about the built context.
        
        Args:
            context: Context string
            
        Returns:
            Dict[str, Any]: Context statistics
        """
        estimated_tokens = self.estimate_tokens(context)
        
        # Count citations
        citation_count = context.count('[') if context else 0
        
        return {
            'char_count': len(context),
            'estimated_tokens': estimated_tokens,
            'token_utilization': (estimated_tokens / self.max_context_tokens) * 100,
            'citation_count': citation_count,
            'max_context_tokens': self.max_context_tokens
        }


# Example usage and testing
def main():
    """Demonstrate context building functionality."""
    print("=== Context Builder Demo ===\n")
    
    try:
        # Initialize context builder
        print("🔄 Initializing ContextBuilder...")
        context_builder = ContextBuilder(max_context_tokens=4000)  # Smaller for demo
        
        # Mock search results
        mock_results = [
            {
                'chunk_id': 'api_security_1',
                'content': 'API security requires authentication tokens and proper authorization checks.',
                'score': 0.95,
                'topic': 'APISecurity',
                'section_title': 'Authentication',
                'document_path': 'api_docs.md',
                'metadata': {'section_type': 'security'}
            },
            {
                'chunk_id': 'api_security_2', 
                'content': 'All endpoints must validate user permissions before processing requests.',
                'score': 0.87,
                'topic': 'APISecurity',
                'section_title': 'Authorization',
                'document_path': 'api_docs.md',
                'metadata': {'section_type': 'security'}
            },
            {
                'chunk_id': 'database_1',
                'content': 'Database connections should use connection pooling for better performance.',
                'score': 0.82,
                'topic': 'Database',
                'section_title': 'Performance',
                'document_path': 'database_guide.md',
                'metadata': {'section_type': 'database'}
            },
            # Duplicate chunk (should be deduplicated)
            {
                'chunk_id': 'api_security_1',
                'content': 'API security requires authentication tokens and proper authorization checks.',
                'score': 0.90,  # Lower score than first occurrence
                'topic': 'APISecurity',
                'section_title': 'Authentication',
                'document_path': 'api_docs.md',
                'metadata': {'section_type': 'security'}
            }
        ]
        
        print(f"\n📝 Mock search results: {len(mock_results)} chunks")
        
        # Build context
        query = "What are the API security requirements?"
        context = context_builder.build_context(mock_results, query)
        
        print(f"\n📄 Built Context:")
        print("=" * 50)
        print(context)
        print("=" * 50)
        
        # Get context statistics
        stats = context_builder.get_context_stats(context)
        print(f"\n📊 Context Statistics:")
        print(f"   📏 Characters: {stats['char_count']}")
        print(f"   🎯 Estimated tokens: {stats['estimated_tokens']}")
        print(f"   📈 Token utilization: {stats['token_utilization']:.1f}%")
        print(f"   📚 Citations: {stats['citation_count']}")
        
        # Test deduplication
        print(f"\n🔍 Deduplication Test:")
        deduplicated = context_builder.deduplicate_results(mock_results)
        print(f"   Original chunks: {len(mock_results)}")
        print(f"   After deduplication: {len(deduplicated)}")
        
        print(f"\n✅ ContextBuilder demo completed!")
        print(f"   🧩 Combines chunks into coherent context")
        print(f"   🔄 Deduplicates overlapping content")
        print(f"   📊 Manages token limits")
        print(f"   📚 Includes source citations")
        
    except Exception as e:
        print(f"❌ Demo failed: {e}")


if __name__ == "__main__":
    main()