#!/usr/bin/env python3
"""
Batch Document Processor CLI for Hybrid RAG System

This CLI tool processes multiple documents using the HybridRAGDocumentProcessor
with topic hierarchy enrichment and Pinecone vector storage enabled by default.
"""

import argparse
import sys
import logging
from pathlib import Path
from typing import List
from document_processor import HybridRAGDocumentProcessor

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def validate_paths(paths: List[str]) -> List[str]:
    """Validate that all provided paths exist and return valid paths."""
    valid_paths = []
    invalid_paths = []
    
    for path in paths:
        if Path(path).exists():
            valid_paths.append(path)
        else:
            invalid_paths.append(path)
    
    if invalid_paths:
        logger.error(f"Invalid paths found: {invalid_paths}")
        return []
    
    return valid_paths


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description='Batch process documents for hybrid RAG system',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Process single document
  python batch_processor_cli.py --paths doc1.md
  
  # Process multiple documents
  python batch_processor_cli.py --paths doc1.md doc2.md doc3.md
  
  # Process with parallel processing (faster for many documents)
  python batch_processor_cli.py --paths *.md --parallel --max-workers 8
  
  # Process without vectorization (metadata enrichment only)
  python batch_processor_cli.py --paths *.md --no-vectorize
  
  # Process with custom chunking parameters
  python batch_processor_cli.py --paths *.md --chunk-size 300 --chunk-overlap 75
  
  # Save processed documents with vectors included
  python batch_processor_cli.py --paths *.md --save-vectors --output-dir ./processed_docs
  
  # Verbose output for debugging
  python batch_processor_cli.py --paths *.md --verbose

Configuration:
  - include_hierarchy_in_content: Always True (topic hierarchy included in searchable content)
  - enable_pinecone_storage: Always True (vectors stored in Pinecone after processing)
        """
    )
    
    # Required arguments
    parser.add_argument('--paths', nargs='+', required=True, 
                       help='Document paths to process (supports wildcards like *.md)')
    
    # Processing options
    parser.add_argument('--no-vectorize', action='store_true', 
                       help='Skip vectorization (metadata processing only)')
    parser.add_argument('--parallel', action='store_true', 
                       help='Enable parallel processing for faster batch processing')
    parser.add_argument('--max-workers', type=int, default=4,
                       help='Maximum parallel workers (default: 4)')
    
    # Chunking parameters
    parser.add_argument('--chunk-size', type=int, default=500,
                       help='Chunk size for vectorization (default: 500)')
    parser.add_argument('--chunk-overlap', type=int, default=50,
                       help='Chunk overlap (default: 50)')
    parser.add_argument('--min-chunk-size', type=int, default=100,
                       help='Minimum chunk size (default: 100)')
    
    # Output options
    parser.add_argument('--output-dir', default='./output',
                       help='Output directory for processed documents (default: ./output)')
    parser.add_argument('--save-vectors', action='store_true',
                       help='Include vectors in saved output files (increases file size)')
    parser.add_argument('--no-save', action='store_true',
                       help='Skip saving processed documents to files')
    
    # Logging options
    parser.add_argument('--verbose', '-v', action='store_true',
                       help='Enable verbose logging output')
    parser.add_argument('--quiet', '-q', action='store_true',
                       help='Suppress non-error output')
    
    args = parser.parse_args()
    
    # Configure logging level
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    elif args.quiet:
        logging.getLogger().setLevel(logging.ERROR)
    
    # Validate paths
    valid_paths = validate_paths(args.paths)
    if not valid_paths:
        print("Error: No valid document paths found")
        sys.exit(1)
    
    print(f"🚀 Starting batch processing of {len(valid_paths)} documents")
    print(f"📋 Configuration:")
    print(f"   • Documents: {len(valid_paths)} files")
    print(f"   • Vectorization: {'Disabled' if args.no_vectorize else 'Enabled'}")
    print(f"   • Parallel processing: {'Enabled' if args.parallel else 'Disabled'}")
    if args.parallel:
        print(f"   • Max workers: {args.max_workers}")
    print(f"   • Chunk size: {args.chunk_size}")
    print(f"   • Chunk overlap: {args.chunk_overlap}")
    print(f"   • Include hierarchy in content: True (always enabled)")
    print(f"   • Enable Pinecone storage: True (always enabled)")
    print()
    
    # Initialize processor with your specified settings
    try:
        processor = HybridRAGDocumentProcessor(
            include_hierarchy_in_content=True,  # Always True as requested
            chunk_size=args.chunk_size,
            chunk_overlap=args.chunk_overlap,
            min_chunk_size=args.min_chunk_size,
            enable_pinecone_storage=True  # Always True as requested
        )
        logger.info("HybridRAGDocumentProcessor initialized successfully")
        
    except Exception as e:
        logger.error(f"Failed to initialize processor: {e}")
        print(f"❌ Error: Failed to initialize document processor: {e}")
        sys.exit(1)
    
    # Process documents
    try:
        print("🔄 Processing documents...")
        results = processor.process_documents(
            valid_paths,
            vectorize=not args.no_vectorize,
            parallel=args.parallel,
            max_workers=args.max_workers
        )
        
        successful_count = len(results)
        total_count = len(valid_paths)
        
        print(f"\n✅ Processing complete!")
        print(f"   • Successfully processed: {successful_count}/{total_count} documents")
        
        if successful_count < total_count:
            print(f"   • Failed: {total_count - successful_count} documents")
        
        # Show processing summary
        if results:
            total_chunks = sum(doc.chunk_count for doc in results)
            vectorized_count = sum(1 for doc in results if doc.is_vectorized)
            pinecone_stored_count = sum(1 for doc in results if doc.is_stored_in_pinecone)
            
            print(f"\n📊 Processing Summary:")
            print(f"   • Total chunks created: {total_chunks}")
            print(f"   • Documents vectorized: {vectorized_count}/{successful_count}")
            print(f"   • Documents stored in Pinecone: {pinecone_stored_count}/{successful_count}")
            
            # Show topic enrichment summary
            total_topics = sum(len(doc.topic_filter_tags) for doc in results)
            avg_topics = total_topics / successful_count if successful_count > 0 else 0
            print(f"   • Average topic tags per document: {avg_topics:.1f}")
        
        # Save results if requested
        if not args.no_save and results:
            print(f"\n💾 Saving processed documents...")
            saved_count = 0
            
            for result in results:
                try:
                    output_file = processor.save_processed_document(
                        result, 
                        args.output_dir, 
                        include_vectors=args.save_vectors
                    )
                    saved_count += 1
                    if args.verbose:
                        print(f"   • Saved: {Path(output_file).name}")
                        
                except Exception as e:
                    logger.error(f"Failed to save document {result.metadata.document_path}: {e}")
            
            print(f"   • Documents saved: {saved_count}/{len(results)}")
            print(f"   • Output directory: {args.output_dir}")
        
        print(f"\n🎯 Documents ready for Hybrid RAG retrieval!")
        print(f"   • Stage 1: Topic-based filtering available")
        print(f"   • Stage 2: Semantic similarity search available")
        
    except Exception as e:
        logger.error(f"Error during batch processing: {e}")
        print(f"❌ Error: Batch processing failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
