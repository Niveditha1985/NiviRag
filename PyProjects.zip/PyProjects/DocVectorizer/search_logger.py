#!/usr/bin/env python3
"""
Search Logger for Analytics

This module captures all search interactions for debugging, monitoring, and analytics.
"""

import os
import json
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
from pathlib import Path

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class SearchLogger:
    """
    Captures all search interactions for debugging, monitoring, and analytics.
    
    This class logs all search requests, responses, and errors to structured
    log files for analysis and debugging purposes.
    """
    
    def __init__(self, log_dir: str = "./logs"):
        """
        Initialize the search logger.
        
        Args:
            log_dir: Directory to store log files
        """
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(exist_ok=True)
        
        # Set up log file paths
        self.queries_log = self.log_dir / "search_queries.jsonl"
        self.errors_log = self.log_dir / "search_errors.jsonl"
        self.analytics_log = self.log_dir / "search_analytics.json"
        
        logger.info(f"SearchLogger initialized with log directory: {self.log_dir}")
    
    def log_search_request(self, user_id: str, query: str, timestamp: datetime, session_info: Dict) -> str:
        """
        Log incoming search query with user context.
        
        Args:
            user_id: User identifier
            query: Search query
            timestamp: Request timestamp
            session_info: Session information (IP, user agent, etc.)
            
        Returns:
            str: Unique request_id for tracking
        """
        request_id = self._generate_request_id(timestamp)
        
        log_entry = {
            "request_id": request_id,
            "timestamp": timestamp.isoformat(),
            "user_id": user_id,
            "query": query,
            "session_info": session_info,
            "type": "search_request"
        }
        
        try:
            with open(self.queries_log, "a", encoding="utf-8") as f:
                f.write(json.dumps(log_entry) + "\n")
            
            logger.debug(f"Logged search request: {request_id}")
            return request_id
            
        except Exception as e:
            logger.error(f"Failed to log search request: {e}")
            return request_id
    
    def log_search_response(self, request_id: str, response: Dict, metadata: Dict) -> None:
        """
        Log complete response with answer, sources, and metadata.
        
        Args:
            request_id: Request ID from log_search_request
            response: Complete response from RAGPipeline
            metadata: Processing metadata (timing, chunks, etc.)
        """
        log_entry = {
            "request_id": request_id,
            "timestamp": datetime.now().isoformat(),
            "response": response,
            "metadata": metadata,
            "type": "search_response"
        }
        
        try:
            with open(self.queries_log, "a", encoding="utf-8") as f:
                f.write(json.dumps(log_entry) + "\n")
            
            logger.debug(f"Logged search response: {request_id}")
            
        except Exception as e:
            logger.error(f"Failed to log search response: {e}")
    
    def log_error(self, request_id: str, error: Exception, context: Dict) -> None:
        """
        Log errors with full stack trace.
        
        Args:
            request_id: Request ID (if available)
            error: Exception that occurred
            context: Additional context (query, user_id, stage)
        """
        log_entry = {
            "request_id": request_id,
            "timestamp": datetime.now().isoformat(),
            "error": {
                "type": type(error).__name__,
                "message": str(error),
                "traceback": self._get_traceback(error)
            },
            "context": context,
            "type": "search_error"
        }
        
        try:
            with open(self.errors_log, "a", encoding="utf-8") as f:
                f.write(json.dumps(log_entry) + "\n")
            
            logger.error(f"Logged search error: {request_id}")
            
        except Exception as e:
            logger.error(f"Failed to log search error: {e}")
    
    def log_test_case_request(self, user_id: str, api_name: str, requirements: str, 
                             timestamp: datetime, session_info: Dict) -> str:
        """
        Log test case generation request.
        
        Args:
            user_id: User identifier
            api_name: API name being modified
            requirements: New requirements for the API
            timestamp: Request timestamp
            session_info: Session information (IP, user agent, etc.)
            
        Returns:
            str: Unique request_id for tracking
        """
        request_id = self._generate_request_id(timestamp, prefix="test_case")
        
        log_entry = {
            "request_id": request_id,
            "timestamp": timestamp.isoformat(),
            "user_id": user_id,
            "api_name": api_name,
            "requirements": requirements,
            "session_info": session_info,
            "type": "test_case_request"
        }
        
        try:
            with open(self.queries_log, "a", encoding="utf-8") as f:
                f.write(json.dumps(log_entry) + "\n")
            
            logger.debug(f"Logged test case request: {request_id}")
            return request_id
            
        except Exception as e:
            logger.error(f"Failed to log test case request: {e}")
            return request_id
    
    def log_test_case_response(self, request_id: str, response: Dict, metadata: Dict) -> None:
        """
        Log test case generation response.
        
        Args:
            request_id: Request ID from log_test_case_request
            response: Complete response from TestCaseGenerator
            metadata: Processing metadata (timing, chunks, etc.)
        """
        log_entry = {
            "request_id": request_id,
            "timestamp": datetime.now().isoformat(),
            "response": response,
            "metadata": metadata,
            "type": "test_case_response"
        }
        
        try:
            with open(self.queries_log, "a", encoding="utf-8") as f:
                f.write(json.dumps(log_entry) + "\n")
            
            logger.debug(f"Logged test case response: {request_id}")
            
        except Exception as e:
            logger.error(f"Failed to log test case response: {e}")
    
    def log_test_case_error(self, request_id: str, error: Exception, context: Dict) -> None:
        """
        Log test case generation errors with full stack trace.
        
        Args:
            request_id: Request ID (if available)
            error: Exception that occurred
            context: Additional context (api_name, requirements, user_id, stage)
        """
        log_entry = {
            "request_id": request_id,
            "timestamp": datetime.now().isoformat(),
            "error": {
                "type": type(error).__name__,
                "message": str(error),
                "traceback": self._get_traceback(error)
            },
            "context": context,
            "type": "test_case_error"
        }
        
        try:
            with open(self.errors_log, "a", encoding="utf-8") as f:
                f.write(json.dumps(log_entry) + "\n")
            
            logger.error(f"Logged test case error: {request_id}")
            
        except Exception as e:
            logger.error(f"Failed to log test case error: {e}")
    
    def get_test_case_history(self, user_id: str = None, api_name: str = None, 
                             start_date: datetime = None, end_date: datetime = None, 
                             limit: int = 100) -> List[Dict]:
        """
        Retrieve test case generation history for debugging or analysis.
        
        Args:
            user_id: Filter by user ID
            api_name: Filter by API name
            start_date: Filter by start date
            end_date: Filter by end date
            limit: Maximum number of results
            
        Returns:
            List[Dict]: List of test case generation log entries
        """
        try:
            if not self.queries_log.exists():
                return []
            
            entries = []
            with open(self.queries_log, "r", encoding="utf-8") as f:
                for line in f:
                    try:
                        entry = json.loads(line.strip())
                        if entry.get("type") in ["test_case_request", "test_case_response"]:
                            # Apply filters
                            if user_id and entry.get("user_id") != user_id:
                                continue
                            if api_name and entry.get("api_name") != api_name:
                                continue
                            
                            # Date filtering
                            entry_time = datetime.fromisoformat(entry.get("timestamp", ""))
                            if start_date and entry_time < start_date:
                                continue
                            if end_date and entry_time > end_date:
                                continue
                            
                            entries.append(entry)
                            
                    except json.JSONDecodeError:
                        continue
            
            # Sort by timestamp (newest first) and limit results
            entries.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
            return entries[:limit]
            
        except Exception as e:
            logger.error(f"Failed to get test case history: {e}")
            return []
    
    def get_test_case_analytics(self, date: datetime = None) -> Dict[str, Any]:
        """
        Generate test case generation analytics summary for a specific date.
        
        Args:
            date: Date to analyze (defaults to today)
            
        Returns:
            Dict[str, Any]: Analytics summary
        """
        try:
            if date is None:
                date = datetime.now().date()
            
            start_date = datetime.combine(date, datetime.min.time())
            end_date = datetime.combine(date, datetime.max.time())
            
            # Get all test case entries for the date
            entries = self.get_test_case_history(start_date=start_date, end_date=end_date, limit=1000)
            
            # Separate requests and responses
            requests = [e for e in entries if e.get("type") == "test_case_request"]
            responses = [e for e in entries if e.get("type") == "test_case_response"]
            
            # Calculate metrics
            total_requests = len(requests)
            successful_responses = len(responses)
            
            # Get unique APIs and users
            unique_apis = set(r.get("api_name") for r in requests if r.get("api_name"))
            unique_users = set(r.get("user_id") for r in requests if r.get("user_id"))
            
            # Calculate average processing time
            avg_processing_time = 0
            if responses:
                processing_times = []
                for response in responses:
                    metadata = response.get("metadata", {})
                    processing_times_data = metadata.get("processing_times", {})
                    if processing_times_data and "total_time" in processing_times_data:
                        processing_times.append(processing_times_data["total_time"])
                
                if processing_times:
                    avg_processing_time = sum(processing_times) / len(processing_times)
            
            # Get most common APIs
            api_counts = {}
            for request in requests:
                api_name = request.get("api_name")
                if api_name:
                    api_counts[api_name] = api_counts.get(api_name, 0) + 1
            
            most_common_apis = sorted(api_counts.items(), key=lambda x: x[1], reverse=True)[:5]
            
            return {
                "date": date.isoformat(),
                "total_requests": total_requests,
                "successful_responses": successful_responses,
                "success_rate": (successful_responses / total_requests * 100) if total_requests > 0 else 0,
                "unique_apis": len(unique_apis),
                "unique_users": len(unique_users),
                "avg_processing_time": avg_processing_time,
                "most_common_apis": most_common_apis,
                "apis_tested": list(unique_apis)
            }
            
        except Exception as e:
            logger.error(f"Failed to get test case analytics: {e}")
            return {"error": str(e)}
    
    def get_search_history(self, user_id: str = None, start_date: datetime = None, 
                          end_date: datetime = None, limit: int = 100) -> List[Dict]:
        """
        Retrieve search history for debugging or analysis.
        
        Args:
            user_id: Filter by user ID
            start_date: Filter by start date
            end_date: Filter by end date
            limit: Maximum number of results
            
        Returns:
            List[Dict]: List of search log entries
        """
        try:
            history = []
            
            if not self.queries_log.exists():
                return history
            
            with open(self.queries_log, "r", encoding="utf-8") as f:
                for line in f:
                    try:
                        entry = json.loads(line.strip())
                        
                        # Apply filters
                        if user_id and entry.get("user_id") != user_id:
                            continue
                        
                        entry_timestamp = datetime.fromisoformat(entry.get("timestamp", ""))
                        if start_date and entry_timestamp < start_date:
                            continue
                        if end_date and entry_timestamp > end_date:
                            continue
                        
                        history.append(entry)
                        
                        if len(history) >= limit:
                            break
                            
                    except json.JSONDecodeError:
                        continue
            
            # Sort by timestamp (newest first)
            history.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
            
            logger.debug(f"Retrieved {len(history)} search history entries")
            return history
            
        except Exception as e:
            logger.error(f"Failed to get search history: {e}")
            return []
    
    def get_analytics_summary(self, date: datetime = None) -> Dict[str, Any]:
        """
        Generate daily analytics summary.
        
        Args:
            date: Date to analyze (defaults to today)
            
        Returns:
            Dict[str, Any]: Analytics summary
        """
        if date is None:
            date = datetime.now().date()
        
        try:
            # Get all entries for the date
            start_datetime = datetime.combine(date, datetime.min.time())
            end_datetime = datetime.combine(date, datetime.max.time())
            
            entries = self.get_search_history(
                start_date=start_datetime,
                end_date=end_datetime,
                limit=10000  # Large limit to get all entries for the day
            )
            
            # Analyze entries
            total_searches = len([e for e in entries if e.get("type") == "search_request"])
            successful_responses = len([e for e in entries if e.get("type") == "search_response"])
            errors = len([e for e in entries if e.get("type") == "search_error"])
            
            # Calculate response times
            response_times = []
            for entry in entries:
                if entry.get("type") == "search_response" and "metadata" in entry:
                    total_time = entry["metadata"].get("total_time")
                    if total_time:
                        response_times.append(total_time)
            
            avg_response_time = sum(response_times) / len(response_times) if response_times else 0
            
            # Get top queries
            query_counts = {}
            for entry in entries:
                if entry.get("type") == "search_request":
                    query = entry.get("query", "")
                    query_counts[query] = query_counts.get(query, 0) + 1
            
            top_queries = sorted(query_counts.items(), key=lambda x: x[1], reverse=True)[:10]
            
            summary = {
                "date": date.isoformat(),
                "total_searches": total_searches,
                "successful_responses": successful_responses,
                "errors": errors,
                "success_rate": (successful_responses / total_searches * 100) if total_searches > 0 else 0,
                "avg_response_time": avg_response_time,
                "top_queries": top_queries,
                "error_rate": (errors / total_searches * 100) if total_searches > 0 else 0
            }
            
            logger.info(f"Generated analytics summary for {date}: {total_searches} searches")
            return summary
            
        except Exception as e:
            logger.error(f"Failed to generate analytics summary: {e}")
            return {"error": str(e)}
    
    def export_logs(self, start_date: datetime, end_date: datetime, format: str = "jsonl") -> str:
        """
        Export logs for specified date range.
        
        Args:
            start_date: Start date for export
            end_date: End date for export
            format: Export format (jsonl, csv, json)
            
        Returns:
            str: Path to exported file
        """
        try:
            # Get entries for date range
            entries = self.get_search_history(
                start_date=start_date,
                end_date=end_date,
                limit=100000  # Large limit for export
            )
            
            # Create export directory
            export_dir = self.log_dir / "exports"
            export_dir.mkdir(exist_ok=True)
            
            # Generate filename
            filename = f"search_history_{start_date.strftime('%Y%m%d')}_to_{end_date.strftime('%Y%m%d')}.{format}"
            export_path = export_dir / filename
            
            if format == "jsonl":
                with open(export_path, "w", encoding="utf-8") as f:
                    for entry in entries:
                        f.write(json.dumps(entry) + "\n")
            
            elif format == "json":
                with open(export_path, "w", encoding="utf-8") as f:
                    json.dump(entries, f, indent=2)
            
            elif format == "csv":
                import csv
                if entries:
                    with open(export_path, "w", newline="", encoding="utf-8") as f:
                        writer = csv.DictWriter(f, fieldnames=entries[0].keys())
                        writer.writeheader()
                        writer.writerows(entries)
            
            logger.info(f"Exported {len(entries)} entries to {export_path}")
            return str(export_path)
            
        except Exception as e:
            logger.error(f"Failed to export logs: {e}")
            return ""
    
    def _generate_request_id(self, timestamp: datetime, prefix: str = "req") -> str:
        """Generate unique request ID with optional prefix."""
        return f"{prefix}_{timestamp.strftime('%Y%m%d_%H%M%S')}_{id(timestamp) % 10000:04d}"
    
    def _get_traceback(self, error: Exception) -> str:
        """Get traceback string for error."""
        import traceback
        return traceback.format_exc()


# Example usage and testing
def main():
    """Demonstrate search logger functionality."""
    print("=== Search Logger Demo ===\n")
    
    try:
        # Initialize search logger
        print("🔄 Initializing SearchLogger...")
        search_logger = SearchLogger(log_dir="./test_logs")
        
        # Simulate search request
        print("📝 Logging search request...")
        user_id = "test_user@example.com"
        query = "What are the API security requirements?"
        timestamp = datetime.now()
        session_info = {
            "ip_address": "192.168.1.100",
            "user_agent": "Mozilla/5.0 (Test Browser)",
            "gradio_session_id": "sess_test123"
        }
        
        request_id = search_logger.log_search_request(user_id, query, timestamp, session_info)
        print(f"   Request ID: {request_id}")
        
        # Simulate search response
        print("📄 Logging search response...")
        response = {
            "answer": "API security requires authentication tokens and proper authorization checks.",
            "sources": [
                {"citation_number": "1", "description": "API Security Guide"}
            ],
            "metadata": {
                "model": "claude-3-5-sonnet-20241022",
                "timestamp": datetime.now().isoformat()
            }
        }
        
        metadata = {
            "total_time": 1.5,
            "query_processing_time": 0.1,
            "search_time": 0.3,
            "context_building_time": 0.05,
            "llm_generation_time": 1.0,
            "chunks_retrieved": 10,
            "chunks_used": 3,
            "context_tokens": 1200,
            "top_k": 10
        }
        
        search_logger.log_search_response(request_id, response, metadata)
        
        # Simulate error
        print("❌ Logging search error...")
        try:
            raise ValueError("Test error for logging")
        except Exception as e:
            error_context = {
                "query": "test query",
                "user_id": user_id,
                "stage": "context_building"
            }
            search_logger.log_error(request_id, e, error_context)
        
        # Get search history
        print("📊 Retrieving search history...")
        history = search_logger.get_search_history(limit=10)
        print(f"   Found {len(history)} log entries")
        
        # Generate analytics summary
        print("📈 Generating analytics summary...")
        summary = search_logger.get_analytics_summary()
        print(f"   Total searches: {summary.get('total_searches', 0)}")
        print(f"   Success rate: {summary.get('success_rate', 0):.1f}%")
        print(f"   Avg response time: {summary.get('avg_response_time', 0):.2f}s")
        
        # Export logs
        print("📤 Exporting logs...")
        start_date = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        end_date = datetime.now()
        
        export_path = search_logger.export_logs(start_date, end_date, format="jsonl")
        if export_path:
            print(f"   Exported to: {export_path}")
        
        print(f"\n✅ SearchLogger demo completed!")
        print(f"   📝 Logs search requests and responses")
        print(f"   ❌ Captures errors with context")
        print(f"   📊 Provides analytics summaries")
        print(f"   📤 Supports log export")
        
    except Exception as e:
        print(f"❌ Demo failed: {e}")


if __name__ == "__main__":
    main()
