import os
import re
import json
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple, Set
from dataclasses import dataclass, asdict
import hashlib
from datetime import datetime
import logging

# Import dependencies
from topic_hierarchy_parser import get_topic_hierarchy_manager, get_topic_metadata_all_hierarchies
from document_chunking_vectorizer import DocumentChunkingAndVectorization, DocumentVectorization
from pinecone_vector_store_manager import PineconeVectorStoreManager

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class EnrichedDocumentMetadata:
    """Document metadata enriched with topic hierarchy for hybrid RAG."""
    # Original metadata from frontmatter
    title: str
    primary_topic: str
    department: str
    team: str
    classification: str
    doc_version: str
    created_by: str
    created_date: str
    last_modified: str
    tags: List[str]
    api_version: Optional[str] = None
    
    # Topic hierarchy enrichment (for domain relationships)
    parent_topics: List[str] = None
    children_topics: List[str] = None
    all_related_topics: List[str] = None
    topic_hierarchies: List[str] = None
    
    # Hybrid RAG metadata
    domain_topics: List[str] = None  # All topics for domain filtering
    searchable_content: str = ""     # Enhanced content for vectorization
    document_path: str = ""
    processing_timestamp: str = ""
    document_hash: str = ""
    
    def __post_init__(self):
        if self.parent_topics is None:
            self.parent_topics = []
        if self.children_topics is None:
            self.children_topics = []
        if self.all_related_topics is None:
            self.all_related_topics = []
        if self.topic_hierarchies is None:
            self.topic_hierarchies = []
        if self.domain_topics is None:
            self.domain_topics = []


@dataclass
class HybridRAGDocument:
    """Document prepared for hybrid RAG with topic filtering and semantic search."""
    metadata: EnrichedDocumentMetadata
    content: str
    
    # Vectorization results from chunking system
    vectorization_result: Optional[DocumentVectorization] = None
    
    # For topic-based filtering (Stage 1 of hybrid RAG)
    topic_filter_tags: Set[str] = None
    
    # Pinecone storage results
    pinecone_storage_result: Optional[Dict[str, Any]] = None
    
    def __post_init__(self):
        if self.topic_filter_tags is None:
            self.topic_filter_tags = set()
    
    @property
    def is_vectorized(self) -> bool:
        """Check if document has been vectorized."""
        return self.vectorization_result is not None and len(self.vectorization_result.chunks) > 0
    
    @property
    def chunk_count(self) -> int:
        """Get number of chunks in this document."""
        return len(self.vectorization_result.chunks) if self.vectorization_result else 0
    
    @property
    def is_stored_in_pinecone(self) -> bool:
        """Check if document vectors are stored in Pinecone."""
        return (self.pinecone_storage_result is not None and 
                self.pinecone_storage_result.get('success', False))


class HybridRAGDocumentProcessor:
    """
    Hybrid RAG Document Processor that combines:
    1. Topic hierarchy enrichment for domain relationship understanding
    2. Topic-aware chunking that respects topic boundaries  
    3. OpenAI embeddings for semantic similarity search (via DocumentChunkingAndVectorization)
    
    This enables a two-stage retrieval:
    Stage 1: Topic-based domain filtering (fast, precise)
    Stage 2: Semantic similarity search within filtered chunks (contextual, nuanced)
    
    Note: Embedding model selection is handled internally by DocumentChunkingAndVectorization
    """
    
    def __init__(self, 
                 include_hierarchy_in_content: bool = True,
                 chunk_size: int = 500,
                 chunk_overlap: int = 50,
                 min_chunk_size: int = 100,
                 enable_pinecone_storage: bool = True):
        """
        Initialize hybrid RAG processor.
        
        Args:
            include_hierarchy_in_content: Whether to include topic hierarchy in searchable content
            chunk_size: Target size for chunks (characters)
            chunk_overlap: Overlap between chunks (characters) 
            min_chunk_size: Minimum chunk size to avoid tiny chunks
            enable_pinecone_storage: Whether to store vectors in Pinecone after vectorization
            
        Note: Embedding model is automatically handled by the chunking/vectorization system
        """
        self.hierarchy_manager = get_topic_hierarchy_manager()
        self.include_hierarchy_in_content = include_hierarchy_in_content
        self.enable_pinecone_storage = enable_pinecone_storage
        
        # Initialize chunking and vectorization system (embedding model handled internally)
        self.chunking_vectorizer = DocumentChunkingAndVectorization(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            min_chunk_size=min_chunk_size
        )
        
        # Initialize Pinecone vector store manager if enabled
        self.pinecone_manager = None
        if self.enable_pinecone_storage:
            try:
                self.pinecone_manager = PineconeVectorStoreManager()
                logger.info("Pinecone vector store manager initialized")
            except Exception as e:
                logger.warning(f"Failed to initialize Pinecone manager: {e}")
                logger.warning("Continuing without Pinecone storage")
                self.enable_pinecone_storage = False
        
        logger.info(f"HybridRAGProcessor initialized: "
                   f"chunk_size={chunk_size}, chunk_overlap={chunk_overlap}, "
                   f"hierarchy_in_content={include_hierarchy_in_content}, "
                   f"pinecone_storage={self.enable_pinecone_storage}")
    
    def process_document(self, document_path: str, vectorize: bool = True) -> HybridRAGDocument:
        """
        Process document for hybrid RAG system.
        
        Args:
            document_path: Path to markdown document
            vectorize: Whether to perform chunking and vectorization
            
        Returns:
            HybridRAGDocument with topic enrichment and optional vectorization
        """
        doc_path = Path(document_path)
        if not doc_path.exists():
            raise FileNotFoundError(f"Document not found: {document_path}")
        
        logger.info(f"Processing document for hybrid RAG: {document_path}")
        
        # Read and parse document
        with open(doc_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        metadata_dict, body_content = self._parse_frontmatter(content)
        base_metadata = self._create_base_metadata(metadata_dict, document_path, content)
        
        # Enrich metadata with topic hierarchy
        enriched_metadata = self._enrich_with_topic_hierarchy(base_metadata)
        
        # Create enhanced searchable content
        searchable_content = self._create_searchable_content(body_content, enriched_metadata)
        enriched_metadata.searchable_content = searchable_content
        
        # Create topic filter tags for fast retrieval
        topic_filter_tags = self._create_topic_filter_tags(enriched_metadata)
        
        # Create hybrid RAG document
        hybrid_doc = HybridRAGDocument(
            metadata=enriched_metadata,
            content=body_content,
            topic_filter_tags=topic_filter_tags
        )
        
        # Perform chunking and vectorization if requested
        if vectorize:
            try:
                logger.info("Starting chunking and vectorization...")
                vectorization_result = self.chunking_vectorizer.chunk_and_vectorize_document(
                    content=searchable_content,  # Use enhanced content for vectorization
                    document_path=document_path,
                    metadata_text=self._create_metadata_text(enriched_metadata)
                )
                hybrid_doc.vectorization_result = vectorization_result
                
                logger.info(f"Vectorization complete: {len(vectorization_result.chunks)} chunks created")
                
                # Store vectors in Pinecone if enabled
                if self.enable_pinecone_storage and self.pinecone_manager:
                    try:
                        logger.info("Storing vectors in Pinecone...")
                        pinecone_result = self.pinecone_manager.store_document_vectors(vectorization_result)
                        hybrid_doc.pinecone_storage_result = pinecone_result
                        
                        if pinecone_result.get('success', False):
                            logger.info(f"Pinecone storage complete: {pinecone_result.get('chunks_stored', 0)} chunks stored")
                        else:
                            logger.warning(f"Pinecone storage failed: {pinecone_result.get('error', 'Unknown error')}")
                            
                    except Exception as e:
                        logger.error(f"Pinecone storage failed: {e}")
                        hybrid_doc.pinecone_storage_result = {
                            'success': False,
                            'error': str(e)
                        }
                
            except Exception as e:
                logger.error(f"Vectorization failed: {e}")
                # Document is still useful without vectors (topic filtering only)
        
        logger.info(f"Document processing complete. "
                   f"Topics: {len(topic_filter_tags)}, "
                   f"Chunks: {hybrid_doc.chunk_count}, "
                   f"Vectorized: {hybrid_doc.is_vectorized}, "
                   f"Pinecone stored: {hybrid_doc.is_stored_in_pinecone}")
        
        return hybrid_doc
    
    def process_documents(self, document_paths: List[str], 
                         vectorize: bool = True,
                         parallel: bool = False,
                         max_workers: int = 4) -> List[HybridRAGDocument]:
        """
        Process multiple documents in batch for hybrid RAG system.
        
        Args:
            document_paths: List of document file paths to process
            vectorize: Whether to perform chunking and vectorization
            parallel: Whether to process documents in parallel
            max_workers: Maximum number of parallel workers (ignored if parallel=False)
            
        Returns:
            List of HybridRAGDocument objects
            
        Raises:
            FileNotFoundError: If any document path doesn't exist
            Exception: If processing fails for any document
        """
        if not document_paths:
            logger.warning("No document paths provided")
            return []
        
        # Validate all paths exist
        valid_paths = []
        for path in document_paths:
            if Path(path).exists():
                valid_paths.append(path)
            else:
                logger.error(f"Document not found: {path}")
                raise FileNotFoundError(f"Document not found: {path}")
        
        logger.info(f"Starting batch processing of {len(valid_paths)} documents")
        logger.info(f"Configuration: vectorize={vectorize}, parallel={parallel}, max_workers={max_workers}")
        
        if parallel:
            return self._process_documents_parallel(valid_paths, vectorize, max_workers)
        else:
            return self._process_documents_sequential(valid_paths, vectorize)
    
    def _process_documents_sequential(self, document_paths: List[str], vectorize: bool) -> List[HybridRAGDocument]:
        """Process documents sequentially."""
        results = []
        
        for i, path in enumerate(document_paths, 1):
            try:
                logger.info(f"Processing document {i}/{len(document_paths)}: {Path(path).name}")
                hybrid_doc = self.process_document(path, vectorize=vectorize)
                results.append(hybrid_doc)
                logger.info(f"✅ Successfully processed: {Path(path).name}")
                
            except Exception as e:
                logger.error(f"❌ Failed to process {Path(path).name}: {e}")
                # Continue processing other documents
                continue
        
        logger.info(f"Sequential processing complete: {len(results)}/{len(document_paths)} documents processed successfully")
        return results
    
    def _process_documents_parallel(self, document_paths: List[str], vectorize: bool, max_workers: int) -> List[HybridRAGDocument]:
        """Process documents in parallel using ThreadPoolExecutor."""
        from concurrent.futures import ThreadPoolExecutor, as_completed
        
        results = []
        
        def process_single_document(path: str) -> Tuple[str, Optional[HybridRAGDocument], Optional[str]]:
            """Process a single document and return (path, result, error)."""
            try:
                logger.info(f"Processing: {Path(path).name}")
                hybrid_doc = self.process_document(path, vectorize=vectorize)
                return path, hybrid_doc, None
            except Exception as e:
                logger.error(f"Failed to process {Path(path).name}: {e}")
                return path, None, str(e)
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all tasks
            future_to_path = {
                executor.submit(process_single_document, path): path 
                for path in document_paths
            }
            
            # Collect results as they complete
            for future in as_completed(future_to_path):
                path, result, error = future.result()
                
                if result is not None:
                    results.append(result)
                    logger.info(f"✅ Completed: {Path(path).name}")
                else:
                    logger.error(f"❌ Failed: {Path(path).name} - {error}")
        
        logger.info(f"Parallel processing complete: {len(results)}/{len(document_paths)} documents processed successfully")
        return results
    
    def _enrich_with_topic_hierarchy(self, base_metadata: EnrichedDocumentMetadata) -> EnrichedDocumentMetadata:
        """Enrich metadata with topic hierarchy for domain relationships."""
        # Get metadata topics (primary + tags)
        metadata_topics = [base_metadata.primary_topic] + base_metadata.tags
        metadata_topics = [topic.strip() for topic in metadata_topics if topic.strip()]
        
        logger.debug(f"Enriching metadata topics: {metadata_topics}")
        
        # Get hierarchy information
        all_parents = set()
        all_children = set()
        all_related = set()
        hierarchies_involved = set()
        
        for topic in metadata_topics:
            try:
                topic_metadata = get_topic_metadata_all_hierarchies(topic)
                
                if topic_metadata['exists']:
                    all_parents.update(topic_metadata['all_parents_combined'])
                    all_children.update(topic_metadata['all_children_combined'])
                    all_related.update(topic_metadata['all_related_topics_combined'])
                    hierarchies_involved.update(topic_metadata['hierarchies'])
                    
                    logger.debug(f"Topic '{topic}' enriched from: {topic_metadata['hierarchies']}")
                    
            except Exception as e:
                logger.warning(f"Failed to enrich topic '{topic}': {e}")
        
        # Create comprehensive domain topics list
        domain_topics = set(metadata_topics)
        domain_topics.update(all_parents)
        domain_topics.update(all_children)
        
        # Update metadata
        base_metadata.parent_topics = list(all_parents)
        base_metadata.children_topics = list(all_children)
        base_metadata.all_related_topics = list(all_related)
        base_metadata.topic_hierarchies = list(hierarchies_involved)
        base_metadata.domain_topics = list(domain_topics)
        
        logger.info(f"Topic hierarchy enrichment: {len(all_parents)} parents, "
                   f"{len(all_children)} children, {len(domain_topics)} total domain topics")
        
        return base_metadata
    
    def _create_searchable_content(self, body_content: str, metadata: EnrichedDocumentMetadata) -> str:
        """
        Create enhanced searchable content that includes hierarchy topics.
        This improves semantic similarity by including domain relationships.
        """
        content_parts = [
            f"Title: {metadata.title}",
            f"Primary Topic: {metadata.primary_topic}",
            f"Department: {metadata.department}",
            f"Team: {metadata.team}",
        ]
        
        # Add original tags
        if metadata.tags:
            content_parts.append(f"Tags: {' '.join(metadata.tags)}")
        
        # Add hierarchy topics for better semantic understanding
        if self.include_hierarchy_in_content:
            if metadata.parent_topics:
                content_parts.append(f"Parent Topics: {' '.join(metadata.parent_topics)}")
            if metadata.children_topics:
                content_parts.append(f"Related Topics: {' '.join(metadata.children_topics)}")
        
        # Add the main content
        content_parts.append("Content:")
        content_parts.append(body_content)
        
        return "\n".join(content_parts)
    
    def _create_metadata_text(self, metadata: EnrichedDocumentMetadata) -> str:
        """Create concise metadata text for separate vectorization."""
        parts = [
            metadata.title,
            metadata.primary_topic,
            " ".join(metadata.tags),
            " ".join(metadata.parent_topics),
            " ".join(metadata.children_topics),
            metadata.department,
            metadata.team
        ]
        return " ".join([part for part in parts if part])
    
    def _create_topic_filter_tags(self, metadata: EnrichedDocumentMetadata) -> Set[str]:
        """
        Create comprehensive topic filter tags for fast domain-based filtering.
        These are used in Stage 1 of hybrid retrieval.
        """
        filter_tags = set()
        
        # Add all domain-relevant topics
        filter_tags.update(metadata.domain_topics)
        filter_tags.add(metadata.primary_topic)
        filter_tags.update(metadata.tags)
        filter_tags.update(metadata.parent_topics)
        filter_tags.update(metadata.children_topics)
        
        # Add hierarchy names for broader filtering
        filter_tags.update(metadata.topic_hierarchies)
        
        # Add department/team for organizational filtering
        if metadata.department:
            filter_tags.add(metadata.department.lower())
        if metadata.team:
            filter_tags.add(metadata.team.lower())
        
        # Clean and normalize tags
        cleaned_tags = {tag.lower().strip() for tag in filter_tags if tag and tag.strip()}
        
        return cleaned_tags
    
    def _parse_frontmatter(self, content: str) -> Tuple[Dict, str]:
        """Parse YAML frontmatter from markdown content."""
        frontmatter_pattern = r'^---\s*\n(.*?)\n---\s*\n(.*)'
        match = re.match(frontmatter_pattern, content, re.DOTALL)
        
        if not match:
            return {}, content
        
        frontmatter_content = match.group(1)
        body_content = match.group(2)
        
        metadata = {}
        for line in frontmatter_content.split('\n'):
            line = line.strip()
            if ':' in line:
                key, value = line.split(':', 1)
                key = key.strip().replace('"', '').replace("'", "")
                value = value.strip().replace('"', '').replace("'", "")
                
                if value.startswith('[') and value.endswith(']'):
                    value = value[1:-1]
                    items = [item.strip().replace('"', '').replace("'", "") 
                            for item in value.split(',')]
                    metadata[key] = [item for item in items if item]
                else:
                    metadata[key] = value
        
        return metadata, body_content
    
    def _create_base_metadata(self, metadata_dict: Dict, document_path: str, content: str) -> EnrichedDocumentMetadata:
        """Create base metadata object."""
        doc_hash = hashlib.md5(content.encode()).hexdigest()
        
        return EnrichedDocumentMetadata(
            title=metadata_dict.get('title', ''),
            primary_topic=metadata_dict.get('primary_topic', ''),
            department=metadata_dict.get('department', ''),
            team=metadata_dict.get('team', ''),
            classification=metadata_dict.get('classification', ''),
            doc_version=metadata_dict.get('Docversion', metadata_dict.get('doc_version', '')),
            created_by=metadata_dict.get('created_by', ''),
            created_date=metadata_dict.get('created_date', ''),
            last_modified=metadata_dict.get('last_modified', ''),
            tags=metadata_dict.get('tags', []),
            api_version=metadata_dict.get('api_version'),
            document_path=str(document_path),
            processing_timestamp=datetime.now().isoformat(),
            document_hash=doc_hash
        )
    
    def save_processed_document(self, hybrid_doc: HybridRAGDocument, 
                              output_dir: str, include_vectors: bool = False) -> str:
        """Save processed document with optional vector storage."""
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        base_name = Path(hybrid_doc.metadata.document_path).stem
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{base_name}_hybrid_rag_{timestamp}.json"
        file_path = output_path / filename
        
        # Prepare data for saving
        save_data = {
            'metadata': asdict(hybrid_doc.metadata),
            'content': hybrid_doc.content,
            'topic_filter_tags': list(hybrid_doc.topic_filter_tags),
            'processing_info': {
                'chunk_size': self.chunking_vectorizer.chunk_size,
                'chunk_overlap': self.chunking_vectorizer.chunk_overlap,
                'min_chunk_size': self.chunking_vectorizer.min_chunk_size,
                'hierarchy_in_content': self.include_hierarchy_in_content,
                'vectorized': hybrid_doc.is_vectorized,
                'chunk_count': hybrid_doc.chunk_count
            }
        }
        
        # Add vectorization results if available and requested
        if include_vectors and hybrid_doc.vectorization_result:
            vectorization_data = {
                'chunks': [],
                'metadata_embedding': hybrid_doc.vectorization_result.metadata_embedding,
                'stats': hybrid_doc.vectorization_result.vectorization_stats
            }
            
            # Add chunk data (with or without vectors)
            for vectorized_chunk in hybrid_doc.vectorization_result.chunks:
                chunk_data = {
                    'chunk_id': vectorized_chunk.chunk.chunk_id,
                    'content': vectorized_chunk.chunk.content,
                    'topic': vectorized_chunk.chunk.topic,
                    'section_title': vectorized_chunk.chunk.section_title,
                    'section_type': vectorized_chunk.chunk.section_type,
                    'char_count': vectorized_chunk.chunk.char_count,
                    'word_count': vectorized_chunk.chunk.word_count,
                    'embedding_model': vectorized_chunk.embedding_model
                }
                
                if include_vectors:
                    chunk_data['embedding'] = vectorized_chunk.embedding
                
                vectorization_data['chunks'].append(chunk_data)
            
            save_data['vectorization'] = vectorization_data
        
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(save_data, f, indent=2, ensure_ascii=False)
        
        logger.info(f"Hybrid RAG document saved: {file_path}")
        return str(file_path)
    
    def get_processing_summary(self, hybrid_doc: HybridRAGDocument) -> Dict[str, Any]:
        """Get comprehensive processing summary."""
        summary = {
            'document_path': hybrid_doc.metadata.document_path,
            'original_metadata_topics': [hybrid_doc.metadata.primary_topic] + hybrid_doc.metadata.tags,
            'enriched_parent_topics': hybrid_doc.metadata.parent_topics,
            'enriched_children_topics': hybrid_doc.metadata.children_topics,
            'total_domain_topics': len(hybrid_doc.metadata.domain_topics),
            'topic_filter_tags_count': len(hybrid_doc.topic_filter_tags),
            'hierarchies_involved': hybrid_doc.metadata.topic_hierarchies,
            'processing_timestamp': hybrid_doc.metadata.processing_timestamp,
            'chunking_and_vectorization': {
                'enabled': hybrid_doc.is_vectorized,
                'chunk_count': hybrid_doc.chunk_count,
                'chunk_size': self.chunking_vectorizer.chunk_size,
                'chunk_overlap': self.chunking_vectorizer.chunk_overlap
            },
            'hybrid_features': {
                'topic_filtering': True,
                'semantic_similarity': hybrid_doc.is_vectorized,
                'domain_aware': len(hybrid_doc.metadata.topic_hierarchies) > 0,
                'topic_aware_chunking': hybrid_doc.is_vectorized
            }
        }
        
        # Add chunking statistics if available
        if hybrid_doc.vectorization_result and hybrid_doc.vectorization_result.vectorization_stats:
            summary['chunking_stats'] = hybrid_doc.vectorization_result.vectorization_stats
        
        return summary
    
    def get_chunk_details(self, hybrid_doc: HybridRAGDocument) -> List[Dict[str, Any]]:
        """Get detailed information about document chunks."""
        if not hybrid_doc.vectorization_result:
            return []
        
        chunk_details = []
        for vectorized_chunk in hybrid_doc.vectorization_result.chunks:
            chunk = vectorized_chunk.chunk
            chunk_details.append({
                'chunk_id': chunk.chunk_id,
                'topic': chunk.topic,
                'section_title': chunk.section_title,
                'section_type': chunk.section_type,
                'content_preview': chunk.content[:100] + '...' if len(chunk.content) > 100 else chunk.content,
                'char_count': chunk.char_count,
                'word_count': chunk.word_count,
                'has_embedding': len(vectorized_chunk.embedding) > 0,
                'embedding_dimension': vectorized_chunk.dimension
            })
        
        return chunk_details


# Example usage and testing
def main():
    """Demonstrate the clean v5 hybrid RAG processing."""
    print("=== Hybrid RAG Document Processor v5 Demo ===\n")
    
    # Sample document content
    sample_content = '''---
title: "FinalizeSaleAPI Documentation"  
primary_topic: "FinalizeSaleAPI"  
department: "engineering"
team: "payments team"
tags: ["API", "subscription", "billing"]
---

# FinalizeSaleAPI Documentation

## Overview
The FinalizeSaleAPI is a critical component of the LEX SignUP process that completes sales and manages subscription activation.

## APIscope
<!-- topic: APIscope -->
This API finalizes sales and activates subscriptions with comprehensive error handling and security measures. The API handles multiple scenarios including credit repair products and standard subscriptions.

The finalization process involves several key steps that must be executed in sequence to ensure proper subscription activation and billing.

## ExternalAPICalls
<!-- topic: ExternalAPICalls -->
The API integrates with external services for enhanced functionality including Avalara for tax calculations and various payment processors for secure transaction processing.

## APISecurity
<!-- topic: APISecurity -->
Security implementation follows company standards with Spring Security Framework and proper authentication mechanisms to ensure data protection and access control.
'''
    
    # Create temporary file
    import tempfile
    with tempfile.NamedTemporaryFile(mode='w', suffix='.md', delete=False) as f:
        f.write(sample_content)
        temp_file = f.name
    
    try:
        # Initialize processor - clean interface with no embedding model concerns
        processor = HybridRAGDocumentProcessor(
            include_hierarchy_in_content=True,
            chunk_size=300,  # Smaller chunks for demo
            chunk_overlap=50,
            min_chunk_size=100,
            enable_pinecone_storage=True
            # ✅ No embedding_model parameter - handled internally
        )
        
        print("🔄 Processing document...")
        hybrid_doc = processor.process_document(temp_file, vectorize=True)
        
        # Show processing summary
        summary = processor.get_processing_summary(hybrid_doc)
        print("\n📊 Processing Summary:")
        print(f"   📄 Document: {Path(summary['document_path']).name}")
        print(f"   🏷️  Original topics: {summary['original_metadata_topics']}")
        print(f"   🔼 Parent topics: {summary['enriched_parent_topics']}")
        print(f"   🔽 Children topics: {summary['enriched_children_topics']}")
        print(f"   🧩 Total chunks: {summary['chunking_and_vectorization']['chunk_count']}")
        print(f"   ✅ Vectorized: {summary['chunking_and_vectorization']['enabled']}")
        
        # Show chunk details
        chunk_details = processor.get_chunk_details(hybrid_doc)
        print(f"\n🧩 Chunk Details:")
        for i, chunk_detail in enumerate(chunk_details[:3]):  # Show first 3 chunks
            print(f"   Chunk {i+1}:")
            print(f"     ID: {chunk_detail['chunk_id']}")
            print(f"     Topic: {chunk_detail['topic'] or 'None'}")
            print(f"     Section: {chunk_detail['section_title'] or 'N/A'}")
            print(f"     Type: {chunk_detail['section_type']}")
            print(f"     Size: {chunk_detail['char_count']} chars")
            print(f"     Embedding: {chunk_detail['embedding_dimension']}D")
            print(f"     Preview: {chunk_detail['content_preview']}")
            print()
        
        if len(chunk_details) > 3:
            print(f"   ... and {len(chunk_details) - 3} more chunks")
        
        # Show clean separation of concerns
        print(f"\n🎯 Clean Design Principles:")
        print(f"   ✅ HybridRAGDocumentProcessor: Topic enrichment + orchestration")
        print(f"   ✅ DocumentChunkingAndVectorization: Chunking + embedding (internal)")
        print(f"   ✅ OpenAIEmbeddingClient: OpenAI API calls (internal)")
        print(f"   ✅ No embedding model concerns exposed to calling code")
        
        # Show hybrid RAG capabilities
        print(f"\n🚀 Hybrid RAG Capabilities:")
        features = summary['hybrid_features']
        print(f"   ✅ Topic-based filtering: {features['topic_filtering']}")
        print(f"   ✅ Semantic similarity: {features['semantic_similarity']}")
        print(f"   ✅ Domain awareness: {features['domain_aware']}")
        print(f"   ✅ Topic-aware chunking: {features['topic_aware_chunking']}")
        
        # Save processed document
        output_file = processor.save_processed_document(hybrid_doc, "./output", include_vectors=False)
        print(f"\n💾 Processed document saved: {Path(output_file).name}")
        
        print(f"\n🎯 Ready for Hybrid RAG Retrieval:")
        print(f"   Stage 1: Filter by {len(hybrid_doc.topic_filter_tags)} topic tags")
        print(f"   Stage 2: Semantic search across {hybrid_doc.chunk_count} chunks")
        
    except Exception as e:
        print(f"❌ Demo failed: {e}")
        print("Make sure all dependencies are properly implemented and configured")
        
    finally:
        # Clean up
        os.unlink(temp_file)


if __name__ == "__main__":
    main()