# Import SSL workaround from core HTTP client
from pinecone_http_client import PineconeHTTPClient

import os
import logging
from typing import Dict, Any
import time


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class PineconeAdministrator:
    """
    Administrative operations for Pinecone infrastructure.
    
    This class handles:
    - Index creation and deletion
    - Index configuration management
    - Infrastructure setup and teardown
    - Administrative operations that should NOT be part of regular document processing
    
    Use this for:
    - Initial RAG system setup
    - Index management
    - Environment setup/teardown
    - Configuration changes
    
    Do NOT use this for:
    - Regular document processing
    - Vector storage/retrieval
    - Query operations
    """
    
    def __init__(self):
        """Initialize Pinecone administrator."""
        # Explicitly load environment variables from .env file
        try:
            from dotenv import load_dotenv
            load_dotenv()
        except ImportError:
            logger.warning("python-dotenv not installed. Environment variables must be set manually.")
        
        # Load configuration from environment FIRST
        self.api_key = self._get_env_var("PINECONE_API_KEY")
        self.environment = os.getenv("PINECONE_ENVIRONMENT", "us-east1-gcp")
        self.index_name = os.getenv("PINECONE_INDEX_NAME", "company-rag-index")
        self.dimension = int(os.getenv("PINECONE_DIMENSION", "1536"))
        self.metric = os.getenv("PINECONE_METRIC", "cosine")
        self.cloud = os.getenv("PINECONE_CLOUD", "aws")
        self.region = os.getenv("PINECONE_REGION", "us-east-1")
        

        # Initialize HTTP client
        self.http_client = PineconeHTTPClient(self.api_key)
        
        logger.info(f"PineconeAdministrator initialized for environment: {self.environment}")
    

    def _get_env_var(self, var_name: str) -> str:
        """Get required environment variable."""
        value = os.getenv(var_name)
        if not value:
            raise ValueError(f"Required environment variable {var_name} is not set")
        return value
    
    
    def _create_serverless_spec(self):
        """Create ServerlessSpec-like object for HTTP client."""
        class ServerlessSpec:
            def __init__(self, cloud, region):
                self.cloud = cloud
                self.region = region
        
        return ServerlessSpec(cloud=self.cloud, region=self.region)
    
    
    
    def setup_rag_infrastructure(self) -> Dict[str, Any]:
        """
        Complete setup of Pinecone infrastructure for RAG system.
        
        This should be run ONCE when setting up your RAG system.
        
        Returns:
            Dictionary with setup results
        """
        logger.info("🚀 Setting up Pinecone RAG infrastructure...")
        
        setup_results = {
            "success": False,
            "steps_completed": [],
            "index_created": False,
            "index_ready": False,
            "configuration": {},
            "errors": []
        }
        
        try:
            # Step 1: Verify configuration
            logger.info("📋 Step 1: Verifying configuration...")
            config_valid = self._verify_configuration()
            if config_valid:
                setup_results["steps_completed"].append("configuration_verified")
                setup_results["configuration"] = self._get_configuration_summary()
            else:
                setup_results["errors"].append("Invalid configuration")
                return setup_results
            
            # Step 2: Create index if needed
            logger.info("🗯️  Step 2: Creating Pinecone index...")
            index_result = self.create_index_if_needed()
            setup_results["index_created"] = index_result["created"]
            setup_results["steps_completed"].append("index_processed")
            
            if not index_result["success"]:
                setup_results["errors"].extend(index_result.get("errors", []))
                return setup_results
            
            # Step 3: Wait for index to be ready
            logger.info("⏳ Step 3: Waiting for index to be ready...")
            ready_result = self._wait_for_index_ready()
            setup_results["index_ready"] = ready_result["ready"]
            setup_results["steps_completed"].append("index_ready_check")
            
            if not ready_result["ready"]:
                setup_results["errors"].append("Index not ready after timeout")
                return setup_results
            
            # Step 4: Verify index configuration
            logger.info("✅ Step 4: Verifying index configuration...")
            verification_result = self._verify_index_configuration()
            setup_results["steps_completed"].append("index_verified")
            
            if not verification_result["valid"]:
                setup_results["errors"].extend(verification_result.get("errors", []))
                return setup_results
            
            # Success!
            setup_results["success"] = True
            logger.info("🎉 Pinecone RAG infrastructure setup completed successfully!")
            
            return setup_results
            
        except Exception as e:
            error_msg = f"Failed to setup RAG infrastructure: {e}"
            logger.error(error_msg)
            setup_results["errors"].append(error_msg)
            return setup_results
    
    def create_index_if_needed(self) -> Dict[str, Any]:
        """
        Create Pinecone index if it doesn't exist.
        
        Returns:
            Dictionary with creation results
        """
        try:
            # Check if index exists
            existing_indexes = [index.name for index in self.http_client.list_indexes()]
            
            if self.index_name in existing_indexes:
                logger.info(f"✅ Index '{self.index_name}' already exists")
                return {
                    "success": True,
                    "created": False,
                    "message": f"Index '{self.index_name}' already exists"
                }
            
            # Create new index
            logger.info(f"🔧 Creating new index: {self.index_name}")
            logger.info(f"   📏 Dimension: {self.dimension}")
            logger.info(f"   📊 Metric: {self.metric}")
            logger.info(f"   ☁️  Cloud: {self.cloud}")
            logger.info(f"   🌍 Region: {self.region}")
            
            # Create ServerlessSpec-like object for HTTP client
            spec = self._create_serverless_spec()
            
            # Create index with serverless configuration using HTTP client
            self.http_client.create_index(
                name=self.index_name,
                dimension=self.dimension,
                metric=self.metric,
                spec=spec
            )
            
            logger.info(f"✅ Index '{self.index_name}' created successfully")
            
            return {
                "success": True,
                "created": True,
                "message": f"Index '{self.index_name}' created successfully",
                "configuration": {
                    "name": self.index_name,
                    "dimension": self.dimension,
                    "metric": self.metric,
                    "cloud": self.cloud,
                    "region": self.region
                }
            }
            
        except Exception as e:
            error_msg = f"Failed to create index: {e}"
            logger.error(error_msg)
            return {
                "success": False,
                "created": False,
                "error": error_msg,
                "errors": [error_msg]
            }
    
    def _wait_for_index_ready(self, timeout_seconds: int = 300) -> Dict[str, Any]:
        """Wait for index to be ready for operations."""
        start_time = time.time()
        
        while time.time() - start_time < timeout_seconds:
            try:
                index = self.http_client.get_index(self.index_name)
                stats = index.describe_index_stats()
                
                # Index is ready when we can get stats without error
                logger.info(f"✅ Index '{self.index_name}' is ready for operations")
                return {
                    "ready": True,
                    "wait_time": time.time() - start_time,
                    "stats": {
                        "total_vectors": stats.get('totalVectorCount', stats.get('total_vector_count', 0)),
                        "index_fullness": stats.get('indexFullness', stats.get('index_fullness', 0))
                    }
                }
                
            except Exception as e:
                logger.debug(f"Index not ready yet: {e}")
                time.sleep(10)  # Wait 10 seconds before retry
        
        return {
            "ready": False,
            "timeout": True,
            "wait_time": timeout_seconds
        }
    
    def _verify_configuration(self) -> bool:
        """Verify that all required configuration is valid."""
        try:
            # Check required environment variables
            required_vars = ["PINECONE_API_KEY"]  # Removed PINECONE_ENVIRONMENT as it's deprecated
            for var in required_vars:
                if not os.getenv(var):
                    logger.error(f"Missing required environment variable: {var}")
                    return False
            
            # Validate dimension
            if self.dimension <= 0:
                logger.error(f"Invalid dimension: {self.dimension}")
                return False
            
            # Validate metric
            valid_metrics = ["cosine", "euclidean", "dotproduct"]
            if self.metric not in valid_metrics:
                logger.error(f"Invalid metric: {self.metric}. Must be one of {valid_metrics}")
                return False
            
            logger.info("✅ Configuration validation passed")
            return True
            
        except Exception as e:
            logger.error(f"Configuration validation failed: {e}")
            return False
    
    def _verify_index_configuration(self) -> Dict[str, Any]:
        """Verify that the created index has the correct configuration."""
        try:
            # Get index information
            indexes = self.http_client.list_indexes()
            target_index = None
            
            for index in indexes:
                if index.name == self.index_name:
                    target_index = index
                    break
            
            if not target_index:
                return {
                    "valid": False,
                    "errors": [f"Index '{self.index_name}' not found"]
                }
            
            # Verify configuration
            errors = []
            
            if target_index.dimension != self.dimension:
                errors.append(f"Dimension mismatch: expected {self.dimension}, got {target_index.dimension}")
            
            if target_index.metric != self.metric:
                errors.append(f"Metric mismatch: expected {self.metric}, got {target_index.metric}")
            
            if errors:
                return {
                    "valid": False,
                    "errors": errors
                }
            
            logger.info("✅ Index configuration verification passed")
            return {
                "valid": True,
                "configuration": {
                    "name": target_index.name,
                    "dimension": target_index.dimension,
                    "metric": target_index.metric,
                    "status": target_index.status
                }
            }
            
        except Exception as e:
            return {
                "valid": False,
                "errors": [f"Failed to verify index configuration: {e}"]
            }
    
    def _get_configuration_summary(self) -> Dict[str, Any]:
        """Get summary of current configuration."""
        return {
            "index_name": self.index_name,
            "dimension": self.dimension,
            "metric": self.metric,
            "cloud": self.cloud,
            "region": self.region,
            "environment": self.environment
        }
    
    def delete_index(self, confirm_deletion: bool = False) -> Dict[str, Any]:
        """
        Delete the Pinecone index.
        
        WARNING: This will permanently delete all vectors and cannot be undone!
        
        Args:
            confirm_deletion: Must be True to actually delete
            
        Returns:
            Dictionary with deletion results
        """
        if not confirm_deletion:
            return {
                "success": False,
                "message": "Deletion not confirmed. Set confirm_deletion=True to proceed."
            }
        
        try:
            logger.warning(f"🚨 DELETING INDEX: {self.index_name}")
            self.http_client.delete_index(self.index_name)
            
            logger.info(f"✅ Index '{self.index_name}' deleted successfully")
            
            return {
                "success": True,
                "message": f"Index '{self.index_name}' deleted successfully"
            }
            
        except Exception as e:
            error_msg = f"Failed to delete index: {e}"
            logger.error(error_msg)
            return {
                "success": False,
                "error": error_msg
            }
    
    def list_all_indexes(self) -> Dict[str, Any]:
        """List all indexes in the Pinecone environment."""
        try:
            indexes = self.http_client.list_indexes()
            
            index_info = []
            for index in indexes:
                index_info.append({
                    "name": index.name,
                    "dimension": index.dimension,
                    "metric": index.metric,
                    "status": index.status
                })
            
            return {
                "success": True,
                "total_indexes": len(indexes),
                "indexes": index_info
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to list indexes: {e}"
            }
    
    def get_index_statistics(self) -> Dict[str, Any]:
        """Get detailed statistics about the RAG index."""
        try:
            index = self.http_client.get_index(self.index_name)
            stats = index.describe_index_stats()
            
            return {
                "success": True,
                "index_name": self.index_name,
                "total_vectors": stats.get('totalVectorCount', stats.get('total_vector_count', 0)),
                "index_fullness": stats.get('indexFullness', stats.get('index_fullness', 0)),
                "namespaces": stats.get('namespaces', {}),
                "dimension": self.dimension,
                "metric": self.metric
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to get index statistics: {e}"
            }


# CLI script for administrative operations
def main():
    """Command-line interface for Pinecone administrative operations."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Pinecone RAG Infrastructure Management")
    parser.add_argument("--setup", action="store_true", help="Setup complete RAG infrastructure")
    parser.add_argument("--create-index", action="store_true", help="Create index if needed")
    parser.add_argument("--list-indexes", action="store_true", help="List all indexes")
    parser.add_argument("--stats", action="store_true", help="Show index statistics")
    parser.add_argument("--delete-index", action="store_true", help="Delete the RAG index (DANGEROUS)")
    parser.add_argument("--confirm", action="store_true", help="Confirm destructive operations")
    
    args = parser.parse_args()
    
    try:
        admin = PineconeAdministrator()
        
        if args.setup:
            print("🚀 Setting up Pinecone RAG infrastructure...")
            result = admin.setup_rag_infrastructure()
            print(f"✅ Setup completed: {result['success']}")
            if result.get('errors'):
                print(f"⚠ Errors: {result['errors']}")
        
        elif args.create_index:
            print("🔧 Creating Pinecone index...")
            result = admin.create_index_if_needed()
            if result['success']:
                print(f"✅ Result: {result['message']}")
            else:
                print(f"⚠ Error: {result.get('error', 'Unknown error')}")
                if 'errors' in result:
                    for error in result['errors']:
                        print(f"   - {error}")
        
        elif args.list_indexes:
            print("📋 Listing all indexes...")
            result = admin.list_all_indexes()
            if result['success']:
                for index in result['indexes']:
                    print(f"  📂 {index['name']}: {index['dimension']}D, {index['metric']}, {index['status']}")
            else:
                print(f"⚠ Error: {result['error']}")
        
        elif args.stats:
            print("📊 Getting index statistics...")
            result = admin.get_index_statistics()
            if result['success']:
                print(f"  📂 Index: {result['index_name']}")
                print(f"  📊 Vectors: {result['total_vectors']}")
                print(f"  📈 Fullness: {result['index_fullness']:.2%}")
            else:
                print(f"⚠ Error: {result['error']}")
        
        elif args.delete_index:
            if args.confirm:
                print("🚨 DELETING INDEX...")
                result = admin.delete_index(confirm_deletion=True)
                print(f"Result: {result['message']}")
            else:
                print("⚠ Deletion requires --confirm flag")
        
        else:
            parser.print_help()
    
    except Exception as e:
        print(f"⚠ Error: {e}")


if __name__ == "__main__":
    main()