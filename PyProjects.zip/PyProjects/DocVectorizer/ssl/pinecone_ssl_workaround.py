#!/usr/bin/env python3
"""
Pinecone SSL Workaround for Corporate Environments

This script forces SSL settings that work in corporate environments with self-signed certificates.
Use this for testing/development only - not recommended for production.
"""

import os
import ssl
import urllib3
import warnings
import logging

# Disable all SSL warnings
urllib3.disable_warnings()
warnings.filterwarnings('ignore')

# Set environment variables to disable SSL verification
os.environ['PYTHONHTTPSVERIFY'] = '0'
os.environ['CURL_CA_BUNDLE'] = ''
os.environ['REQUESTS_CA_BUNDLE'] = ''

# Create a custom SSL context that accepts everything
def create_permissive_ssl_context():
    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    # Lower security level to accept weak certificates
    context.set_ciphers('DEFAULT@SECLEVEL=1')
    return context

# Monkey patch the default SSL context globally
ssl._create_default_https_context = create_permissive_ssl_context

# Also patch urllib3 specifically
try:
    import urllib3.util.ssl_
    urllib3.util.ssl_.DEFAULT_CIPHERS = 'ALL:@SECLEVEL=0'
except:
    pass

print("🔧 SSL configuration patched for corporate environment")

# Now import and test Pinecone
try:
    from dotenv import load_dotenv
    load_dotenv()
    
    from pinecone import Pinecone, ServerlessSpec
    
    print("📡 Testing Pinecone connection...")
    
    # Initialize Pinecone client
    pc = Pinecone(api_key=os.getenv("PINECONE_API_KEY"))
    
    # Test connection
    indexes = list(pc.list_indexes())
    print(f"✅ Successfully connected! Found {len(indexes)} indexes:")
    
    for idx in indexes:
        print(f"   - {idx.name}: {idx.dimension}D, {idx.metric}")
    
    # Test creating an index
    index_name = "test-corporate-ssl"
    
    # Check if test index exists
    existing_names = [idx.name for idx in indexes]
    
    if index_name not in existing_names:
        print(f"🔧 Creating test index: {index_name}")
        pc.create_index(
            name=index_name,
            dimension=1536,
            metric="cosine",
            spec=ServerlessSpec(cloud="aws", region="us-east-1")
        )
        print(f"✅ Test index created successfully!")
        
        # Clean up - delete the test index
        print(f"🧹 Cleaning up test index...")
        pc.delete_index(index_name)
        print(f"✅ Test index deleted")
    else:
        print(f"ℹ️  Test index already exists")
    
    print("🎉 All tests passed! Your corporate SSL configuration is working.")
    
except Exception as e:
    print(f"❌ Error: {e}")
    print("\nTroubleshooting:")
    print("1. Check your PINECONE_API_KEY in .env file")
    print("2. Verify your internet connection")
    print("3. Check if your corporate firewall blocks api.pinecone.io")
    print("4. Try running this script as administrator/sudo")