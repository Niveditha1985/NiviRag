#!/usr/bin/env python3
"""
Test PineconeAdministrator with SSL fix
"""

# Apply SSL workaround FIRST, before any other imports
import os
import ssl
import urllib3
import warnings

# Disable all SSL warnings
urllib3.disable_warnings()
warnings.filterwarnings('ignore')

# Set environment variables to disable SSL verification
os.environ['PYTHONHTTPSVERIFY'] = '0'
os.environ['CURL_CA_BUNDLE'] = ''
os.environ['REQUESTS_CA_BUNDLE'] = ''

# Create a custom SSL context that accepts everything
def create_permissive_ssl_context():
    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    # Lower security level to accept weak certificates
    context.set_ciphers('DEFAULT@SECLEVEL=1')
    return context

# Monkey patch the default SSL context globally
ssl._create_default_https_context = create_permissive_ssl_context

# Also patch urllib3 specifically
try:
    import urllib3.util.ssl_
    urllib3.util.ssl_.DEFAULT_CIPHERS = 'ALL:@SECLEVEL=0'
except:
    pass

print("🔧 SSL configuration patched for corporate environment")

# Now import and test
from dotenv import load_dotenv
load_dotenv()

try:
    from pinecone_administrator import PineconeAdministrator
    
    print("📡 Testing PineconeAdministrator...")
    
    # Initialize administrator
    admin = PineconeAdministrator()
    
    print("✅ PineconeAdministrator initialized successfully!")
    
    # Test creating an index
    print("🔧 Testing index creation...")
    result = admin.create_index_if_needed()
    
    if result["success"]:
        print("✅ Index creation test passed!")
        print(f"   Message: {result['message']}")
    else:
        print("❌ Index creation test failed!")
        print(f"   Error: {result.get('error', 'Unknown error')}")
    
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()
