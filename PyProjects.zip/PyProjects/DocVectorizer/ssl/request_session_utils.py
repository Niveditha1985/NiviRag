#!/usr/bin/env python3
"""
Request Session Utilities

This module provides utility functions to create requests.Session objects with corporate SSL
configurations specifically for integrations that require requests.Session (like Pinecone).

This complements http_client_utils.py without modifying it, allowing existing integrations
to continue using httpx.Client while new integrations can use requests.Session.
"""

import os
import ssl
import requests
import urllib3
import warnings
from typing import Optional, Dict, Any
import logging

# Import from existing http_client_utils to reuse SSL detection logic
from http_client_utils import get_environment_http_client

logger = logging.getLogger(__name__)


class RequestSessionManager:
    """
    Manages requests.Session objects with corporate SSL configuration.
    
    This class creates and configures requests.Session objects that work
    with corporate VPN environments, self-signed certificates, and proxies.
    """
    
    def __init__(self):
        """Initialize the session manager."""
        self.ssl_verify_mode = os.getenv("SSL_VERIFY", "DEFAULT").upper()
        self._corporate_ca_bundle = None
        self._proxies = {}
        
        # Detect corporate SSL configuration from existing http_client
        self._detect_corporate_ssl_config()
    
    def _detect_corporate_ssl_config(self) -> None:
        """
        Detect corporate SSL configuration from the existing http_client_utils.
        
        This extracts SSL settings from the existing httpx client to use
        with requests.Session objects.
        """
        try:
            # Get the existing httpx client to extract its configuration
            httpx_client = get_environment_http_client()
            
            # Extract SSL verification settings
            if hasattr(httpx_client, 'verify'):
                if isinstance(httpx_client.verify, str):
                    # This is a CA bundle path
                    self._corporate_ca_bundle = httpx_client.verify
                    logger.info(f"Detected corporate CA bundle: {httpx_client.verify}")
                elif httpx_client.verify is False:
                    # SSL verification is disabled
                    self.ssl_verify_mode = "NONE"
                    logger.info("Detected disabled SSL verification")
            
            # Extract proxy settings if available
            if hasattr(httpx_client, 'proxies') and httpx_client.proxies:
                # Convert httpx proxy format to requests format if needed
                self._proxies = dict(httpx_client.proxies)
                logger.info(f"Detected proxies: {self._proxies}")
            
            # Close the httpx client as we only needed its configuration
            if hasattr(httpx_client, 'close'):
                httpx_client.close()
                
        except Exception as e:
            logger.warning(f"Could not detect corporate SSL config: {e}")
            # Fallback to environment variable detection
            self._detect_ssl_from_environment()
    
    def _detect_ssl_from_environment(self) -> None:
        """Detect SSL configuration from environment variables."""
        # Check for CA bundle in environment variables
        ca_bundle_vars = [
            "ANTHROPIC_CA_BUNDLE_PATH",
            "REQUESTS_CA_BUNDLE", 
            "CURL_CA_BUNDLE",
            "SSL_CERT_FILE"
        ]
        
        for var in ca_bundle_vars:
            path = os.getenv(var)
            if path and os.path.exists(path):
                self._corporate_ca_bundle = path
                logger.info(f"Found CA bundle from {var}: {path}")
                break
        
        # Check for proxy settings
        proxy_vars = [
            ("HTTPS_PROXY", "https"),
            ("https_proxy", "https"),
            ("HTTP_PROXY", "http"),
            ("http_proxy", "http")
        ]
        
        for env_var, protocol in proxy_vars:
            proxy_url = os.getenv(env_var)
            if proxy_url:
                self._proxies[protocol] = proxy_url
    
    def create_session(self) -> requests.Session:
        """
        Create a requests.Session configured for corporate environment.
        
        Returns:
            requests.Session: Configured session object
        """
        session = requests.Session()
        
        # Configure SSL verification
        self._configure_ssl(session)
        
        # Configure proxies
        self._configure_proxies(session)
        
        # Set headers for corporate environment
        self._configure_headers(session)
        
        return session
    
    def _configure_ssl(self, session: requests.Session) -> None:
        """Configure SSL settings for the session."""
        if self.ssl_verify_mode == "NONE":
            # Disable SSL verification
            session.verify = False
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            warnings.filterwarnings('ignore', message='Unverified HTTPS request')
            logger.warning("SSL verification disabled")
            
        elif self._corporate_ca_bundle:
            # Use corporate CA bundle
            session.verify = self._corporate_ca_bundle
            self._set_ssl_environment_variables(self._corporate_ca_bundle)
            logger.info(f"Using corporate CA bundle: {self._corporate_ca_bundle}")
            
        elif self.ssl_verify_mode == "SELFSIGNED":
            # Handle self-signed certificates
            self._configure_self_signed_ssl(session)
            
        else:
            # Use default SSL verification
            logger.info("Using default SSL verification")
    
    def _configure_self_signed_ssl(self, session: requests.Session) -> None:
        """Configure session for self-signed certificates."""
        # Try to find corporate CA bundle first
        ca_bundle = self._find_corporate_ca_bundle()
        
        if ca_bundle:
            session.verify = ca_bundle
            self._set_ssl_environment_variables(ca_bundle)
            logger.info(f"Found corporate CA bundle for self-signed: {ca_bundle}")
        else:
            # Use custom adapter for self-signed certificates
            adapter = SelfSignedHTTPAdapter()
            session.mount('https://', adapter)
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            logger.warning("Using permissive SSL adapter for self-signed certificates")
    
    def _find_corporate_ca_bundle(self) -> Optional[str]:
        """Find corporate CA bundle in common locations."""
        if self._corporate_ca_bundle:
            return self._corporate_ca_bundle
        
        # Common corporate CA bundle locations
        common_paths = [
            # Windows
            r"C:\Program Files\Common Files\SSL\certs\ca-bundle.crt",
            r"C:\Windows\System32\ca-bundle.crt",
            r"C:\Tools\ca-bundle.crt",
            # Linux
            "/etc/ssl/certs/ca-bundle.crt",
            "/etc/ssl/certs/ca-certificates.crt", 
            "/etc/pki/tls/certs/ca-bundle.crt",
            "/usr/local/share/ca-certificates/corporate-ca.crt",
            "/opt/corporate/ssl/ca-bundle.crt",
            # Current directory
            "./ca-bundle.crt",
            "./certificates/ca-bundle.crt"
        ]
        
        for path in common_paths:
            if os.path.exists(path):
                return path
        
        return None
    
    def _configure_proxies(self, session: requests.Session) -> None:
        """Configure proxy settings for the session."""
        if self._proxies:
            session.proxies.update(self._proxies)
            logger.info(f"Configured proxies: {self._proxies}")
            
            # Set proxy environment variables for other libraries
            for protocol, proxy_url in self._proxies.items():
                os.environ[f"{protocol.upper()}_PROXY"] = proxy_url
    
    def _configure_headers(self, session: requests.Session) -> None:
        """Configure default headers for corporate environment."""
        # Add user agent for corporate tracking/compliance
        session.headers.update({
            'User-Agent': 'Corporate-RAG-System/1.0'
        })
    
    def _set_ssl_environment_variables(self, ca_bundle_path: str) -> None:
        """Set SSL environment variables for other libraries."""
        ssl_env_vars = [
            'REQUESTS_CA_BUNDLE',
            'CURL_CA_BUNDLE', 
            'SSL_CERT_FILE'
        ]
        
        for var in ssl_env_vars:
            os.environ[var] = ca_bundle_path
            logger.debug(f"Set {var}={ca_bundle_path}")
    
    def test_session(self, test_url: str = "https://httpbin.org/get") -> Dict[str, Any]:
        """
        Test the session configuration.
        
        Args:
            test_url: URL to test against
            
        Returns:
            Dict with test results
        """
        try:
            session = self.create_session()
            response = session.get(test_url, timeout=10)
            
            success = response.status_code == 200
            
            result = {
                "success": success,
                "status_code": response.status_code,
                "ssl_verify": session.verify,
                "proxies": dict(session.proxies),
                "ssl_mode": self.ssl_verify_mode
            }
            
            if success:
                logger.info(f"Session test successful: {response.status_code}")
            else:
                logger.error(f"Session test failed: {response.status_code}")
            
            return result
            
        except Exception as e:
            logger.error(f"Session test exception: {e}")
            return {
                "success": False,
                "error": str(e),
                "ssl_mode": self.ssl_verify_mode
            }


class SelfSignedHTTPAdapter(requests.adapters.HTTPAdapter):
    """
    Custom HTTP adapter that handles self-signed certificates.
    
    This adapter creates a custom SSL context that accepts self-signed certificates
    while maintaining reasonable security for corporate environments.
    """
    
    def init_poolmanager(self, *args, **kwargs):
        """Initialize the pool manager with custom SSL context."""
        # Create SSL context that accepts self-signed certificates
        ssl_context = ssl.create_default_context()
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE
        
        # Try to load any available CA certificates
        try:
            ssl_context.load_default_certs()
        except Exception:
            pass
        
        kwargs['ssl_context'] = ssl_context
        return super().init_poolmanager(*args, **kwargs)


# Convenience functions for easy usage
def get_corporate_session() -> requests.Session:
    """
    Get a requests.Session configured for corporate environment.
    
    Returns:
        requests.Session: Configured session
    """
    manager = RequestSessionManager()
    return manager.create_session()


def configure_for_pinecone() -> None:
    """
    Configure environment specifically for Pinecone integration.
    
    This sets up environment variables that Pinecone SDK will use.
    """
    logger.info("Configuring environment for Pinecone...")
    
    manager = RequestSessionManager()
    session = manager.create_session()
    
    # Extract configuration and set environment variables
    if isinstance(session.verify, str):
        # CA bundle path
        manager._set_ssl_environment_variables(session.verify)
        logger.info(f"Configured Pinecone SSL with CA bundle: {session.verify}")
    elif session.verify is False:
        # SSL disabled
        os.environ['PYTHONHTTPSVERIFY'] = '0'
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        logger.warning("Configured Pinecone with SSL verification disabled")
    
    # Configure proxies
    if session.proxies:
        for protocol, proxy_url in session.proxies.items():
            os.environ[f"{protocol.upper()}_PROXY"] = proxy_url
        logger.info(f"Configured Pinecone proxies: {session.proxies}")
    
    logger.info("Environment configured for Pinecone integration")


def test_corporate_ssl(test_url: str = "https://httpbin.org/get") -> bool:
    """
    Test corporate SSL configuration.
    
    Args:
        test_url: URL to test against
        
    Returns:
        bool: True if successful, False otherwise
    """
    manager = RequestSessionManager()
    result = manager.test_session(test_url)
    return result["success"]


# Main execution for testing
if __name__ == "__main__":
    """Test the request session utilities."""
    logging.basicConfig(level=logging.INFO)
    
    print("Testing Request Session Utilities for Corporate Environment")
    print("=" * 65)
    
    # Test different SSL modes
    ssl_modes = ["DEFAULT", "SELFSIGNED", "CUSTOM", "NONE"]
    
    for mode in ssl_modes:
        print(f"\nTesting SSL_VERIFY={mode}")
        os.environ["SSL_VERIFY"] = mode
        
        manager = RequestSessionManager()
        result = manager.test_session()
        
        status = "PASS" if result["success"] else "FAIL"
        print(f"Result: {status}")
        print(f"  SSL Verify: {result.get('ssl_verify')}")
        print(f"  Proxies: {result.get('proxies')}")
        
        if not result["success"]:
            print(f"  Error: {result.get('error', 'Unknown error')}")
    
    # Test Pinecone configuration
    print(f"\nTesting Pinecone configuration...")
    os.environ["SSL_VERIFY"] = "SELFSIGNED"  # Set for corporate environment
    configure_for_pinecone()
    print("Pinecone environment configured")
    
    # Test convenience function
    print(f"\nTesting convenience function...")
    session = get_corporate_session()
    print(f"Corporate session created: verify={session.verify}")
    print(f"Session proxies: {dict(session.proxies)}")