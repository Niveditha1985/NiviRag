#!/usr/bin/env python3
"""
Test SSL fix using requests directly
"""

# Apply SSL workaround FIRST, before any other imports
import os
import ssl
import urllib3
import warnings

# Disable all SSL warnings
urllib3.disable_warnings()
warnings.filterwarnings('ignore')

# Set environment variables to disable SSL verification
os.environ['PYTHONHTTPSVERIFY'] = '0'
os.environ['CURL_CA_BUNDLE'] = ''
os.environ['REQUESTS_CA_BUNDLE'] = ''

# Create a custom SSL context that accepts everything
def create_permissive_ssl_context():
    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    # Lower security level to accept weak certificates
    context.set_ciphers('DEFAULT@SECLEVEL=1')
    return context

# Monkey patch the default SSL context globally
ssl._create_default_https_context = create_permissive_ssl_context

# Also patch urllib3 specifically
try:
    import urllib3.util.ssl_
    urllib3.util.ssl_.DEFAULT_CIPHERS = 'ALL:@SECLEVEL=0'
except:
    pass

print("🔧 SSL configuration patched for corporate environment")

# Now import and test
from dotenv import load_dotenv
load_dotenv()

try:
    import requests
    
    print("📡 Testing direct requests connection to Pinecone...")
    
    # Test direct connection to Pinecone API
    api_key = os.getenv("PINECONE_API_KEY")
    if not api_key:
        print("❌ PINECONE_API_KEY not found in environment")
        exit(1)
    
    headers = {
        'Api-Key': api_key,
        'Content-Type': 'application/json'
    }
    
    # Test with SSL verification disabled
    response = requests.get(
        'https://api.pinecone.io/indexes',
        headers=headers,
        verify=False,  # Disable SSL verification
        timeout=30
    )
    
    print(f"✅ Direct requests connection successful! Status: {response.status_code}")
    
    if response.status_code == 200:
        data = response.json()
        indexes = data.get('indexes', [])
        print(f"Found {len(indexes)} indexes:")
        for idx in indexes:
            print(f"   - {idx.get('name', 'Unknown')}: {idx.get('dimension', 'Unknown')}D, {idx.get('metric', 'Unknown')}")
    
    print("🎉 Direct requests SSL fix is working!")
    
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()
