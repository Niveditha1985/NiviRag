import os
import ssl
import socket
import requests
import urllib3
import logging
from typing import Dict, Any, Optional
from urllib.parse import urlparse
import traceback
from datetime import datetime

# Set up detailed logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


class PineconeSSLDebugger:
    """
    Comprehensive test and debug class for Pinecone SSL integration.
    
    This class tests every step of the SSL configuration process to identify
    where the company SSL setup is failing.
    """
    
    def __init__(self):
        """Initialize debugger with environment variables."""
        from dotenv import load_dotenv
        load_dotenv()
        
        self.api_key = os.getenv('PINECONE_API_KEY')
        self.environment = os.getenv('PINECONE_ENVIRONMENT', 'us-east-1-aws')
        self.index_name = os.getenv('PINECONE_INDEX_NAME', 'company-rag-index')
        
        print("=" * 60)
        print("🔍 PINECONE SSL INTEGRATION DEBUGGER")
        print("=" * 60)
        
        if not self.api_key:
            print("❌ PINECONE_API_KEY not found in environment!")
            return
        
        print(f"✅ API Key: {self.api_key[:10]}...")
        print(f"✅ Environment: {self.environment}")
        print(f"✅ Index Name: {self.index_name}")
        print()
    
    def run_full_debug(self) -> Dict[str, Any]:
        """Run complete SSL debug suite."""
        results = {
            "timestamp": str(datetime.now()),
            "tests": {}
        }
        
        test_methods = [
            ("basic_connectivity", self.test_basic_connectivity),
            ("company_http_client", self.test_company_http_client),
            ("ssl_environment", self.test_ssl_environment_setup),
            ("urllib3_config", self.test_urllib3_configuration),
            ("requests_config", self.test_requests_configuration),
            ("pinecone_sdk_basic", self.test_pinecone_sdk_basic),
            ("pinecone_with_ssl", self.test_pinecone_with_company_ssl),
            ("langchain_integration", self.test_langchain_integration)
        ]
        
        for test_name, test_method in test_methods:
            print(f"\n{'='*20} {test_name.upper()} {'='*20}")
            try:
                result = test_method()
                results["tests"][test_name] = result
                status = "✅ PASS" if result.get("success", False) else "❌ FAIL"
                print(f"Result: {status}")
                if not result.get("success", False) and result.get("error"):
                    print(f"Error: {result['error']}")
            except Exception as e:
                print(f"❌ EXCEPTION: {e}")
                results["tests"][test_name] = {"success": False, "error": str(e), "exception": True}
        
        print(f"\n{'='*60}")
        print("📊 DEBUG SUMMARY")
        print(f"{'='*60}")
        
        for test_name, result in results["tests"].items():
            status = "✅" if result.get("success", False) else "❌"
            print(f"{status} {test_name}: {result.get('message', result.get('error', 'Unknown'))}")
        
        return results
    
    def test_basic_connectivity(self) -> Dict[str, Any]:
        """Test basic internet connectivity and DNS resolution."""
        try:
            print("🔍 Testing basic connectivity to Pinecone...")
            
            # Test DNS resolution
            pinecone_host = f"controller.{self.environment}.pinecone.io"
            ip = socket.gethostbyname(pinecone_host)
            print(f"✅ DNS resolution: {pinecone_host} → {ip}")
            
            # Test basic TCP connection
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(10)
            result = sock.connect_ex((pinecone_host, 443))
            sock.close()
            
            if result == 0:
                print(f"✅ TCP connection to {pinecone_host}:443 successful")
                return {"success": True, "message": "Basic connectivity OK"}
            else:
                return {"success": False, "error": f"TCP connection failed: {result}"}
                
        except Exception as e:
            return {"success": False, "error": f"Connectivity test failed: {e}"}
    
    def test_company_http_client(self) -> Dict[str, Any]:
        """Test company HTTP client configuration and capabilities."""
        try:
            print("🔍 Testing company HTTP client...")
            
            from http_client_utils import get_environment_http_client
            client = get_environment_http_client()
            
            print(f"✅ Company client type: {type(client)}")
            print(f"✅ Has 'verify' attribute: {hasattr(client, 'verify')}")
            print(f"✅ Has 'cert' attribute: {hasattr(client, 'cert')}")
            print(f"✅ Has 'proxies' attribute: {hasattr(client, 'proxies')}")
            
            # Inspect SSL configuration
            ssl_info = {}
            if hasattr(client, 'verify'):
                ssl_info['verify'] = client.verify
                print(f"🔒 Verify setting: {client.verify} (type: {type(client.verify)})")
                
                # Check if it's a file path and exists
                if isinstance(client.verify, str):
                    if os.path.exists(client.verify):
                        print(f"✅ CA bundle file exists: {client.verify}")
                    else:
                        print(f"❌ CA bundle file NOT found: {client.verify}")
                        return {"success": False, "error": f"CA bundle file not found: {client.verify}"}
            
            if hasattr(client, 'cert'):
                ssl_info['cert'] = client.cert
                print(f"🔒 Client cert: {client.cert}")
            
            if hasattr(client, 'proxies'):
                ssl_info['proxies'] = client.proxies
                print(f"🌐 Proxies: {client.proxies}")
            
            # Test direct Pinecone API call with company client
            headers = {
                "Api-Key": self.api_key,
                "Content-Type": "application/json"
            }
            
            url = f"https://controller.{self.environment}.pinecone.io/databases"
            print(f"🔍 Testing direct API call to: {url}")
            
            response = client.get(url, headers=headers, timeout=30)
            
            print(f"✅ Direct API call successful! Status: {response.status_code}")
            print(f"✅ Response length: {len(response.text)} characters")
            
            return {
                "success": True,
                "message": "Company HTTP client working",
                "ssl_config": ssl_info,
                "api_test": {
                    "status_code": response.status_code,
                    "response_length": len(response.text)
                }
            }
            
        except Exception as e:
            return {"success": False, "error": f"Company client test failed: {e}"}
    
    def test_ssl_environment_setup(self) -> Dict[str, Any]:
        """Test SSL environment variable configuration."""
        try:
            print("🔍 Testing SSL environment setup...")
            
            from http_client_utils import get_environment_http_client
            client = get_environment_http_client()
            
            # Extract SSL configuration
            ssl_config = {}
            if hasattr(client, 'verify') and isinstance(client.verify, str):
                ssl_config['ca_bundle'] = client.verify
            
            if hasattr(client, 'proxies') and client.proxies:
                ssl_config['proxies'] = client.proxies
            
            # Set environment variables
            env_vars_set = []
            if 'ca_bundle' in ssl_config:
                ca_bundle = ssl_config['ca_bundle']
                
                # Check if file exists
                if os.path.exists(ca_bundle):
                    print(f"✅ CA bundle file exists: {ca_bundle}")
                else:
                    print(f"❌ CA bundle file NOT found: {ca_bundle}")
                    return {"success": False, "error": f"CA bundle file not found: {ca_bundle}"}
                
                # Set multiple environment variables
                ssl_env_vars = [
                    'REQUESTS_CA_BUNDLE',
                    'CURL_CA_BUNDLE',
                    'SSL_CERT_FILE'
                ]
                
                for var in ssl_env_vars:
                    os.environ[var] = ca_bundle
                    env_vars_set.append(f"{var}={ca_bundle}")
                    print(f"✅ Set {var}={ca_bundle}")
            
            if 'proxies' in ssl_config:
                for protocol, proxy_url in ssl_config['proxies'].items():
                    env_var = f"{protocol.upper()}_PROXY"
                    os.environ[env_var] = proxy_url
                    env_vars_set.append(f"{env_var}={proxy_url}")
                    print(f"✅ Set {env_var}={proxy_url}")
            
            # Test environment variables are readable
            print("\n🔍 Verifying environment variables...")
            for var in ['REQUESTS_CA_BUNDLE', 'HTTPS_PROXY', 'HTTP_PROXY']:
                value = os.environ.get(var, 'NOT SET')
                print(f"  {var}: {value}")
            
            return {
                "success": True,
                "message": "SSL environment configured",
                "env_vars_set": env_vars_set,
                "ssl_config": ssl_config
            }
            
        except Exception as e:
            return {"success": False, "error": f"SSL environment setup failed: {e}"}
    
    def test_urllib3_configuration(self) -> Dict[str, Any]:
        """Test urllib3 SSL configuration."""
        try:
            print("🔍 Testing urllib3 SSL configuration...")
            
            import urllib3
            from urllib3.poolmanager import PoolManager
            
            # Disable warnings
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            print("✅ Disabled urllib3 SSL warnings")
            
            # Test urllib3 direct connection
            ca_bundle = os.environ.get('REQUESTS_CA_BUNDLE')
            proxies = {}
            
            if os.environ.get('HTTPS_PROXY'):
                proxies['https'] = os.environ.get('HTTPS_PROXY')
            if os.environ.get('HTTP_PROXY'):
                proxies['http'] = os.environ.get('HTTP_PROXY')
            
            # Create urllib3 pool manager with SSL config
            pool_kwargs = {}
            if ca_bundle:
                pool_kwargs['ca_certs'] = ca_bundle
                print(f"✅ Using CA bundle: {ca_bundle}")
            
            if proxies:
                print(f"✅ Using proxies: {proxies}")
            
            http = PoolManager(**pool_kwargs)
            
            # Test request
            url = f"https://controller.{self.environment}.pinecone.io/databases"
            headers = {
                "Api-Key": self.api_key,
                "Content-Type": "application/json"
            }
            
            response = http.request('GET', url, headers=headers)
            print(f"✅ urllib3 direct request successful! Status: {response.status}")
            
            return {
                "success": True,
                "message": "urllib3 configuration working",
                "status_code": response.status,
                "ca_bundle": ca_bundle,
                "proxies": proxies
            }
            
        except Exception as e:
            return {"success": False, "error": f"urllib3 test failed: {e}"}
    
    def test_requests_configuration(self) -> Dict[str, Any]:
        """Test requests library SSL configuration."""
        try:
            print("🔍 Testing requests SSL configuration...")
            
            import requests
            
            # Create session with SSL config
            session = requests.Session()
            
            ca_bundle = os.environ.get('REQUESTS_CA_BUNDLE')
            if ca_bundle:
                session.verify = ca_bundle
                print(f"✅ Session verify set to: {ca_bundle}")
            
            # Set proxies
            proxies = {}
            if os.environ.get('HTTPS_PROXY'):
                proxies['https'] = os.environ.get('HTTPS_PROXY')
            if os.environ.get('HTTP_PROXY'):
                proxies['http'] = os.environ.get('HTTP_PROXY')
            
            if proxies:
                session.proxies.update(proxies)
                print(f"✅ Session proxies set to: {proxies}")
            
            # Test request
            headers = {
                "Api-Key": self.api_key,
                "Content-Type": "application/json"
            }
            
            url = f"https://controller.{self.environment}.pinecone.io/databases"
            response = session.get(url, headers=headers, timeout=30)
            
            print(f"✅ Requests session test successful! Status: {response.status_code}")
            
            return {
                "success": True,
                "message": "Requests configuration working",
                "status_code": response.status_code,
                "verify": session.verify,
                "proxies": dict(session.proxies)
            }
            
        except Exception as e:
            return {"success": False, "error": f"Requests test failed: {e}"}
    
    def test_pinecone_sdk_basic(self) -> Dict[str, Any]:
        """Test basic Pinecone SDK without SSL configuration."""
        try:
            print("🔍 Testing basic Pinecone SDK...")
            
            from pinecone import Pinecone
            
            # Clear SSL environment temporarily
            ssl_backup = {}
            ssl_vars = ['REQUESTS_CA_BUNDLE', 'CURL_CA_BUNDLE', 'SSL_CERT_FILE', 'HTTPS_PROXY', 'HTTP_PROXY']
            
            for var in ssl_vars:
                if var in os.environ:
                    ssl_backup[var] = os.environ[var]
                    del os.environ[var]
            
            try:
                # Try basic Pinecone client
                client = Pinecone(api_key=self.api_key, environment=self.environment)
                indexes = list(client.list_indexes())
                
                print(f"✅ Basic Pinecone SDK working! Found {len(indexes)} indexes")
                result = {"success": True, "message": "Basic SDK working", "index_count": len(indexes)}
                
            except Exception as sdk_error:
                print(f"❌ Basic Pinecone SDK failed: {sdk_error}")
                result = {"success": False, "error": f"Basic SDK failed: {sdk_error}"}
            
            finally:
                # Restore SSL environment
                for var, value in ssl_backup.items():
                    os.environ[var] = value
            
            return result
            
        except Exception as e:
            return {"success": False, "error": f"Basic SDK test failed: {e}"}
    
    def test_pinecone_with_company_ssl(self) -> Dict[str, Any]:
        """Test Pinecone SDK with company SSL configuration."""
        try:
            print("🔍 Testing Pinecone SDK with company SSL...")
            
            # Ensure SSL environment is set
            ssl_test = self.test_ssl_environment_setup()
            if not ssl_test["success"]:
                return {"success": False, "error": "SSL environment setup failed"}
            
            from pinecone import Pinecone
            
            # Initialize client with SSL environment
            client = Pinecone(api_key=self.api_key, environment=self.environment)
            
            # Test operations
            indexes = list(client.list_indexes())
            print(f"✅ Pinecone with SSL working! Found {len(indexes)} indexes")
            
            # Test index creation if needed
            if self.index_name not in [idx.name for idx in indexes]:
                print(f"🔍 Testing index creation: {self.index_name}")
                
                from pinecone import ServerlessSpec
                client.create_index(
                    name=self.index_name,
                    dimension=1536,
                    metric="cosine",
                    spec=ServerlessSpec(cloud="aws", region="us-east-1")
                )
                print(f"✅ Index creation successful!")
            
            return {
                "success": True,
                "message": "Pinecone with company SSL working",
                "index_count": len(indexes),
                "ssl_environment": {
                    "ca_bundle": os.environ.get('REQUESTS_CA_BUNDLE'),
                    "https_proxy": os.environ.get('HTTPS_PROXY')
                }
            }
            
        except Exception as e:
            return {"success": False, "error": f"Pinecone with SSL failed: {e}"}
    
    def test_langchain_integration(self) -> Dict[str, Any]:
        """Test LangChain-Pinecone integration."""
        try:
            print("🔍 Testing LangChain-Pinecone integration...")
            
            # Check if LangChain is available
            try:
                from langchain_pinecone import PineconeVectorStore
                from langchain.schema import Document
            except ImportError as import_error:
                return {"success": False, "error": f"LangChain import failed: {import_error}"}
            
            # Initialize vector store
            vector_store = PineconeVectorStore(
                index_name=self.index_name,
                pinecone_api_key=self.api_key,
                environment=self.environment
            )
            
            # Test with a sample document
            test_doc = Document(
                page_content="This is a test document for SSL debugging.",
                metadata={"test": True, "source": "ssl_debugger"}
            )
            
            # Try to add document
            vector_store.add_documents([test_doc], ids=["ssl_test_doc"])
            print("✅ LangChain document addition successful!")
            
            # Try similarity search
            results = vector_store.similarity_search("test", k=1)
            print(f"✅ LangChain similarity search successful! Found {len(results)} results")
            
            return {
                "success": True,
                "message": "LangChain integration working",
                "search_results": len(results)
            }
            
        except Exception as e:
            return {"success": False, "error": f"LangChain test failed: {e}"}
    
    def generate_fix_recommendations(self, results: Dict[str, Any]) -> list[str]:
        """Generate fix recommendations based on test results."""
        recommendations = []
        
        tests = results.get("tests", {})
        
        if not tests.get("basic_connectivity", {}).get("success", False):
            recommendations.append("🌐 Check network connectivity and firewall settings")
        
        if not tests.get("company_http_client", {}).get("success", False):
            recommendations.append("🔧 Fix company HTTP client configuration in http_client_utils.py")
        
        if not tests.get("ssl_environment", {}).get("success", False):
            recommendations.append("🔒 Check CA bundle file path and permissions")
        
        if not tests.get("urllib3_config", {}).get("success", False):
            recommendations.append("📦 Update urllib3 configuration or version")
        
        if not tests.get("requests_config", {}).get("success", False):
            recommendations.append("🌐 Fix requests library SSL configuration")
        
        if tests.get("pinecone_sdk_basic", {}).get("success", False) and not tests.get("pinecone_with_company_ssl", {}).get("success", False):
            recommendations.append("🔐 Company SSL blocking Pinecone - configure proxy/firewall")
        
        if not recommendations:
            recommendations.append("✅ All tests passed - SSL configuration is working!")
        
        return recommendations


def main():
    """Run the complete Pinecone SSL debug suite."""
    
    debugger = PineconeSSLDebugger()
    
    if not debugger.api_key:
        print("❌ Cannot run tests without PINECONE_API_KEY")
        return
    
    print("🚀 Starting comprehensive SSL debug suite...\n")
    
    # Run all tests
    results = debugger.run_full_debug()
    
    # Generate recommendations
    recommendations = debugger.generate_fix_recommendations(results)
    
    print(f"\n{'='*60}")
    print("💡 RECOMMENDATIONS")
    print(f"{'='*60}")
    
    for i, rec in enumerate(recommendations, 1):
        print(f"{i}. {rec}")
    
    print(f"\n{'='*60}")
    print("📄 FULL RESULTS (for debugging)")
    print(f"{'='*60}")
    
    import json
    print(json.dumps(results, indent=2, default=str))


if __name__ == "__main__":
    main()