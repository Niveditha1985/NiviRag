#!/usr/bin/env python3
"""
Gradio Search Interface

Web UI for interacting with the RAG system using Gradio.
"""

import os
import logging
from typing import Dict, List, Any, Tuple, Optional
from datetime import datetime
import gradio as gr

from rag_pipeline import RAGPipeline
from test_case_generator import TestCaseGenerator

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class GradioSearchInterface:
    """
    Web UI for interacting with the RAG system.
    
    This class provides a Gradio-based interface for:
    - Query input and processing
    - Advanced search with filters
    - Results display with sources
    - Statistics and debugging information
    """
    
    def __init__(self, rag_pipeline: RAGPipeline = None, test_case_generator: TestCaseGenerator = None):
        """
        Initialize the Gradio search interface.
        
        Args:
            rag_pipeline: RAGPipeline instance. If None, creates a new one.
            test_case_generator: TestCaseGenerator instance. If None, creates a new one.
        """
        logger.info("Initializing GradioSearchInterface...")
        
        # Initialize RAG pipeline if not provided
        if rag_pipeline is None:
            logger.info("Creating new RAGPipeline instance...")
            self.rag_pipeline = RAGPipeline()
        else:
            self.rag_pipeline = rag_pipeline
        
        # Initialize test case generator if not provided
        if test_case_generator is None:
            logger.info("Creating new TestCaseGenerator instance...")
            self.test_case_generator = TestCaseGenerator(self.rag_pipeline)
        else:
            self.test_case_generator = test_case_generator
        
        # Get pipeline statistics for UI
        self.pipeline_stats = self.rag_pipeline.get_pipeline_stats()
        
        logger.info("GradioSearchInterface initialization complete")
    
    def create_interface(self) -> gr.Blocks:
        """
        Build the Gradio interface.
        
        Returns:
            gr.Blocks: Gradio Blocks object with the complete interface
        """
        logger.info("Creating Gradio interface...")
        
        # Get available filter options from pipeline stats
        filter_options = self._get_filter_options()
        
        with gr.Blocks(
            title="RAG Search System",
            theme=gr.themes.Soft(),
            css="""
            .main-container {
                max-width: 1200px;
                margin: 0 auto;
                padding: 20px;
            }
            .stats-container {
                background-color: #f8f9fa;
                padding: 15px;
                border-radius: 8px;
                margin-bottom: 20px;
            }
            .source-item {
                background-color: #ffffff;
                border: 1px solid #e9ecef;
                border-radius: 6px;
                padding: 12px;
                margin-bottom: 8px;
            }
            """
        ) as interface:
            
            # Title and description
            gr.Markdown(
                """
                # 🔍 RAG Search System
                **Semantic search powered by vector embeddings and Claude AI**
                
                Ask questions about your documents and get intelligent answers with source citations.
                """,
                elem_classes=["main-container"]
            )
            
            # Statistics panel
            with gr.Row():
                with gr.Column(scale=1):
                    gr.Markdown("### 📊 System Statistics", elem_classes=["stats-container"])
                    stats_text = self._format_stats_for_display()
                    stats_display = gr.Markdown(stats_text, elem_classes=["stats-container"])
                
                with gr.Column(scale=2):
                    # Main search interface
                    with gr.Tab("🔍 Basic Search"):
                        self._create_basic_search_tab(filter_options)
                    
                    with gr.Tab("⚙️ Advanced Search"):
                        self._create_advanced_search_tab(filter_options)
                    
                    with gr.Tab("🧪 Test Case Generation"):
                        self._create_test_case_generation_tab()
                    
                    with gr.Tab("📈 Analytics"):
                        self._create_analytics_tab()
            
            # Event handlers
            self._setup_event_handlers()
        
        logger.info("Gradio interface created successfully")
        return interface
    
    def _create_basic_search_tab(self, filter_options: Dict[str, List[str]]) -> None:
        """Create the basic search tab."""
        
        with gr.Row():
            with gr.Column(scale=3):
                # Query input
                query_input = gr.Textbox(
                    label="🔍 Enter your question",
                    placeholder="e.g., What are the API security requirements?",
                    lines=3,
                    max_lines=5
                )
                
                # Search options
                with gr.Row():
                    top_k_slider = gr.Slider(
                        minimum=1,
                        maximum=20,
                        value=10,
                        step=1,
                        label="Number of results",
                        info="How many chunks to retrieve"
                    )
                    
                    show_sources = gr.Checkbox(
                        label="Show sources",
                        value=True,
                        info="Display source citations"
                    )
                
                # Search button
                search_btn = gr.Button(
                    "🔍 Search",
                    variant="primary",
                    size="lg"
                )
            
            with gr.Column(scale=2):
                # Quick stats
                gr.Markdown("### Quick Info")
                quick_stats = gr.Markdown(
                    f"""
                    - **Index**: {self.pipeline_stats.get('index_stats', {}).get('index_name', 'Unknown')}
                    - **Total Vectors**: {self.pipeline_stats.get('index_stats', {}).get('total_vectors', 0):,}
                    - **Max Context**: {self.pipeline_stats.get('pipeline_config', {}).get('max_context_tokens', 0):,} tokens
                    """
                )
        
        # Results section
        with gr.Row():
            with gr.Column():
                gr.Markdown("### 💬 Answer")
                answer_output = gr.Markdown(
                    value="Enter a question above to get started...",
                    elem_classes=["answer-container"]
                )
                
                # Sources section
                with gr.Accordion("📚 Sources", open=False):
                    sources_output = gr.Markdown(
                        value="Sources will appear here after searching...",
                        elem_classes=["sources-container"]
                    )
                
                # Debug info
                with gr.Accordion("🔧 Debug Information", open=False):
                    debug_output = gr.JSON(
                        value={},
                        label="Processing Details"
                    )
        
        # Store components for event handlers
        self.basic_components = {
            'query_input': query_input,
            'top_k_slider': top_k_slider,
            'show_sources': show_sources,
            'search_btn': search_btn,
            'answer_output': answer_output,
            'sources_output': sources_output,
            'debug_output': debug_output
        }
    
    def _create_advanced_search_tab(self, filter_options: Dict[str, List[str]]) -> None:
        """Create the advanced search tab with filters."""
        
        with gr.Row():
            with gr.Column(scale=3):
                # Query input
                adv_query_input = gr.Textbox(
                    label="🔍 Enter your question",
                    placeholder="e.g., How do I implement authentication?",
                    lines=3,
                    max_lines=5
                )
                
                # Advanced options
                with gr.Row():
                    adv_top_k_slider = gr.Slider(
                        minimum=1,
                        maximum=20,
                        value=10,
                        step=1,
                        label="Number of results"
                    )
                    
                    adv_show_sources = gr.Checkbox(
                        label="Show sources",
                        value=True
                    )
                
                # Filters section
                gr.Markdown("### 🎯 Filters")
                with gr.Row():
                    topic_filter = gr.Dropdown(
                        choices=["All"] + filter_options.get('topics', []),
                        value="All",
                        label="Topic",
                        info="Filter by document topic"
                    )
                    
                    department_filter = gr.Dropdown(
                        choices=["All"] + filter_options.get('departments', []),
                        value="All",
                        label="Department",
                        info="Filter by department"
                    )
                
                section_type_filter = gr.Dropdown(
                    choices=["All"] + filter_options.get('section_types', []),
                    value="All",
                    label="Section Type",
                    info="Filter by section type"
                )
                
                # Advanced search button
                adv_search_btn = gr.Button(
                    "🔍 Advanced Search",
                    variant="primary",
                    size="lg"
                )
            
            with gr.Column(scale=2):
                # Filter help
                gr.Markdown("### Filter Help")
                gr.Markdown(
                    """
                    **Topic**: Filter by document topic/category
                    
                    **Department**: Filter by organizational department
                    
                    **Section Type**: Filter by document section type
                    
                    Use filters to narrow down results to specific areas of your knowledge base.
                    """
                )
        
        # Results section
        with gr.Row():
            with gr.Column():
                gr.Markdown("### 💬 Answer")
                adv_answer_output = gr.Markdown(
                    value="Enter a question above to get started...",
                    elem_classes=["answer-container"]
                )
                
                # Sources section
                with gr.Accordion("📚 Sources", open=False):
                    adv_sources_output = gr.Markdown(
                        value="Sources will appear here after searching...",
                        elem_classes=["sources-container"]
                    )
                
                # Debug info
                with gr.Accordion("🔧 Debug Information", open=False):
                    adv_debug_output = gr.JSON(
                        value={},
                        label="Processing Details"
                    )
        
        # Store components for event handlers
        self.advanced_components = {
            'query_input': adv_query_input,
            'top_k_slider': adv_top_k_slider,
            'show_sources': adv_show_sources,
            'topic_filter': topic_filter,
            'department_filter': department_filter,
            'section_type_filter': section_type_filter,
            'search_btn': adv_search_btn,
            'answer_output': adv_answer_output,
            'sources_output': adv_sources_output,
            'debug_output': adv_debug_output
        }
    
    def _create_analytics_tab(self) -> None:
        """Create the analytics tab."""
        
        with gr.Row():
            with gr.Column():
                gr.Markdown("### 📊 Search Analytics")
                
                # Refresh analytics button
                refresh_analytics_btn = gr.Button(
                    "🔄 Refresh Analytics",
                    variant="secondary"
                )
                
                # Analytics display
                analytics_output = gr.Markdown(
                    value=self._get_analytics_summary(),
                    elem_classes=["analytics-container"]
                )
                
                # Recent searches
                gr.Markdown("### 🔍 Recent Searches")
                recent_searches_output = gr.Markdown(
                    value=self._get_recent_searches(),
                    elem_classes=["recent-searches-container"]
                )
        
        # Store components for event handlers
        self.analytics_components = {
            'refresh_btn': refresh_analytics_btn,
            'analytics_output': analytics_output,
            'recent_searches_output': recent_searches_output
        }
    
    def _create_test_case_generation_tab(self) -> None:
        """Create the test case generation tab."""
        
        with gr.Row():
            with gr.Column(scale=3):
                # API Name input
                api_name_input = gr.Textbox(
                    label="🔧 API Name",
                    placeholder="e.g., FinalizeSaleAPI, CancelSubscriptionAPI",
                    lines=1,
                    info="Name of the API being modified"
                )
                
                # Requirements input
                requirements_input = gr.Textbox(
                    label="📝 Requirements/Changes",
                    placeholder="""e.g., 
- Add validation for credit card expiration date
- Implement retry logic for failed payment processing
- Add support for subscription trial periods""",
                    lines=8,
                    max_lines=15,
                    info="Describe the new requirements or changes for the API"
                )
                
                # Context chunks slider
                context_chunks_slider = gr.Slider(
                    minimum=5,
                    maximum=50,
                    value=20,
                    step=5,
                    label="Context Chunks",
                    info="Number of API-related chunks to retrieve for context"
                )
                
                # Action buttons
                with gr.Row():
                    generate_btn = gr.Button(
                        "🧪 Generate Test Cases",
                        variant="primary",
                        size="lg"
                    )
                    
                    clear_btn = gr.Button(
                        "🗑️ Clear",
                        variant="secondary"
                    )
            
            with gr.Column(scale=2):
                # Help section
                gr.Markdown("### 💡 Help")
                gr.Markdown(
                    """
                    **API Name**: Enter the exact name of the API you're modifying
                    
                    **Requirements**: Describe the new features, changes, or requirements
                    
                    **Context Chunks**: How many API-related chunks to retrieve for context
                    
                    The system will:
                    1. Search for existing API documentation
                    2. Generate test cases in Gherkin format
                    3. Include positive, negative, and edge cases
                    """
                )
        
        # Results section
        with gr.Row():
            with gr.Column():
                gr.Markdown("### 🧪 Generated Test Cases")
                test_cases_output = gr.Markdown(
                    value="Enter API name and requirements above to generate test cases...",
                    elem_classes=["test-cases-container"]
                )
                
                # Action buttons for results
                with gr.Row():
                    copy_btn = gr.Button(
                        "📋 Copy Test Cases",
                        variant="secondary",
                        size="sm"
                    )
                    
                    export_btn = gr.Button(
                        "💾 Export to File",
                        variant="secondary",
                        size="sm"
                    )
                
                # API Context section
                with gr.Accordion("📚 API Context Used", open=False):
                    context_used_output = gr.Markdown(
                        value="API context will appear here after generation...",
                        elem_classes=["context-container"]
                    )
                
                # Generation metadata
                with gr.Accordion("🔧 Generation Metadata", open=False):
                    metadata_output = gr.JSON(
                        value={},
                        label="Processing Details"
                    )
        
        # Store components for event handlers
        self.test_case_components = {
            'api_name_input': api_name_input,
            'requirements_input': requirements_input,
            'context_chunks_slider': context_chunks_slider,
            'generate_btn': generate_btn,
            'clear_btn': clear_btn,
            'test_cases_output': test_cases_output,
            'context_used_output': context_used_output,
            'metadata_output': metadata_output,
            'copy_btn': copy_btn,
            'export_btn': export_btn
        }
    
    def _setup_event_handlers(self) -> None:
        """Set up event handlers for all components."""
        
        # Basic search handlers
        if hasattr(self, 'basic_components'):
            self.basic_components['search_btn'].click(
                fn=self.handle_search,
                inputs=[
                    self.basic_components['query_input'],
                    self.basic_components['top_k_slider'],
                    self.basic_components['show_sources']
                ],
                outputs=[
                    self.basic_components['answer_output'],
                    self.basic_components['sources_output'],
                    self.basic_components['debug_output']
                ]
            )
        
        # Advanced search handlers
        if hasattr(self, 'advanced_components'):
            self.advanced_components['search_btn'].click(
                fn=self.handle_advanced_search,
                inputs=[
                    self.advanced_components['query_input'],
                    self.advanced_components['top_k_slider'],
                    self.advanced_components['show_sources'],
                    self.advanced_components['topic_filter'],
                    self.advanced_components['department_filter'],
                    self.advanced_components['section_type_filter']
                ],
                outputs=[
                    self.advanced_components['answer_output'],
                    self.advanced_components['sources_output'],
                    self.advanced_components['debug_output']
                ]
            )
        
        # Analytics handlers
        if hasattr(self, 'analytics_components'):
            self.analytics_components['refresh_btn'].click(
                fn=self._refresh_analytics,
                inputs=[],
                outputs=[
                    self.analytics_components['analytics_output'],
                    self.analytics_components['recent_searches_output']
                ]
            )
        
        # Test case generation handlers
        if hasattr(self, 'test_case_components'):
            self.test_case_components['generate_btn'].click(
                fn=self.handle_test_case_generation,
                inputs=[
                    self.test_case_components['api_name_input'],
                    self.test_case_components['requirements_input'],
                    self.test_case_components['context_chunks_slider']
                ],
                outputs=[
                    self.test_case_components['test_cases_output'],
                    self.test_case_components['context_used_output'],
                    self.test_case_components['metadata_output']
                ]
            )
            
            self.test_case_components['clear_btn'].click(
                fn=self._clear_test_case_inputs,
                inputs=[],
                outputs=[
                    self.test_case_components['api_name_input'],
                    self.test_case_components['requirements_input'],
                    self.test_case_components['test_cases_output'],
                    self.test_case_components['context_used_output'],
                    self.test_case_components['metadata_output']
                ]
            )
    
    def handle_search(self, query: str, top_k: int, show_sources: bool) -> Tuple[str, str, Dict]:
        """
        Gradio callback for basic search.
        
        Args:
            query: User query
            top_k: Number of results to retrieve
            show_sources: Whether to show sources
            
        Returns:
            Tuple[str, str, Dict]: (answer_text, sources_text, debug_info)
        """
        try:
            logger.info(f"Handling basic search: {query[:100]}...")
            
            # Validate query
            is_valid, error_msg = self.rag_pipeline.validate_query(query)
            if not is_valid:
                return (
                    f"❌ **Invalid Query**: {error_msg}",
                    "",
                    {"error": error_msg, "query": query}
                )
            
            # Process query
            response = self.rag_pipeline.answer_query(
                query=query,
                user_id="gradio_user",
                top_k=top_k
            )
            
            # Format response
            answer_text = self.format_answer_for_display(response)
            sources_text = self.format_sources_for_display(response.get('sources', [])) if show_sources else ""
            debug_info = response.get('metadata', {})
            
            return answer_text, sources_text, debug_info
            
        except Exception as e:
            logger.error(f"Search failed: {e}")
            return (
                f"❌ **Error**: {str(e)}",
                "",
                {"error": str(e), "query": query}
            )
    
    def handle_advanced_search(self, query: str, top_k: int, show_sources: bool, 
                              topic_filter: str, department_filter: str, section_type_filter: str) -> Tuple[str, str, Dict]:
        """
        Gradio callback for advanced search with filters.
        
        Args:
            query: User query
            top_k: Number of results to retrieve
            show_sources: Whether to show sources
            topic_filter: Topic filter
            department_filter: Department filter
            section_type_filter: Section type filter
            
        Returns:
            Tuple[str, str, Dict]: (answer_text, sources_text, debug_info)
        """
        try:
            logger.info(f"Handling advanced search: {query[:100]}...")
            
            # Validate query
            is_valid, error_msg = self.rag_pipeline.validate_query(query)
            if not is_valid:
                return (
                    f"❌ **Invalid Query**: {error_msg}",
                    "",
                    {"error": error_msg, "query": query}
                )
            
            # Build filters
            filters = {}
            if topic_filter and topic_filter != "All":
                filters['topic'] = topic_filter
            if department_filter and department_filter != "All":
                filters['department'] = department_filter
            if section_type_filter and section_type_filter != "All":
                filters['section_type'] = section_type_filter
            
            # Process query with filters
            response = self.rag_pipeline.answer_query(
                query=query,
                user_id="gradio_user",
                top_k=top_k,
                filters=filters if filters else None
            )
            
            # Format response
            answer_text = self.format_answer_for_display(response)
            sources_text = self.format_sources_for_display(response.get('sources', [])) if show_sources else ""
            debug_info = response.get('metadata', {})
            debug_info['filters_applied'] = filters
            
            return answer_text, sources_text, debug_info
            
        except Exception as e:
            logger.error(f"Advanced search failed: {e}")
            return (
                f"❌ **Error**: {str(e)}",
                "",
                {"error": str(e), "query": query, "filters": {"topic": topic_filter, "department": department_filter, "section_type": section_type_filter}}
            )
    
    def handle_test_case_generation(self, api_name: str, requirements: str, context_chunks: int) -> Tuple[str, str, Dict]:
        """
        Gradio callback for test case generation.
        
        Args:
            api_name: Name of the API being modified
            requirements: New requirements for the API
            context_chunks: Number of context chunks to retrieve
            
        Returns:
            Tuple[str, str, Dict]: (test_cases_markdown, context_used_text, metadata)
        """
        try:
            logger.info(f"Handling test case generation for API: {api_name}")
            
            # Validate inputs
            if not api_name or not api_name.strip():
                return (
                    "❌ **Error**: API name cannot be empty",
                    "",
                    {"error": "API name is required"}
                )
            
            if not requirements or not requirements.strip():
                return (
                    "❌ **Error**: Requirements cannot be empty",
                    "",
                    {"error": "Requirements are required"}
                )
            
            # Generate test cases
            response = self.test_case_generator.generate_test_cases(
                api_name=api_name.strip(),
                requirements=requirements.strip(),
                user_id="gradio_user"
            )
            
            # Format response
            test_cases_text = self.format_test_cases_for_display(response)
            context_used_text = self.format_context_for_display(response.get('context_used', ''))
            metadata = response.get('metadata', {})
            
            return test_cases_text, context_used_text, metadata
            
        except Exception as e:
            logger.error(f"Test case generation failed: {e}")
            return (
                f"❌ **Error**: {str(e)}",
                "",
                {"error": str(e), "api_name": api_name}
            )
    
    def format_test_cases_for_display(self, response: Dict) -> str:
        """
        Format generated test cases for display.
        
        Args:
            response: Response from TestCaseGenerator
            
        Returns:
            str: Markdown formatted test cases
        """
        test_cases = response.get('test_cases', 'No test cases generated')
        metadata = response.get('metadata', {})
        
        # Add metadata if available
        if metadata:
            processing_time = metadata.get('processing_times', {}).get('total_time', 0)
            context_found = metadata.get('context_found', False)
            parsed_scenarios = metadata.get('parsed_scenarios', 0)
            
            metadata_text = f"""
            
            ---
            **Generation Details:**
            - ⏱️ Generation time: {processing_time:.2f}s
            - 📚 Context found: {'✅ Yes' if context_found else '❌ No'}
            - 🧪 Scenarios parsed: {parsed_scenarios}
            """
            
            if metadata.get('request_id'):
                metadata_text += f"\n- 🆔 Request ID: `{metadata['request_id']}`"
            
            test_cases += metadata_text
        
        return test_cases
    
    def format_context_for_display(self, context: str) -> str:
        """
        Format API context for display.
        
        Args:
            context: API context string
            
        Returns:
            str: Markdown formatted context
        """
        if not context or not context.strip():
            return "No API context was found or used for test case generation."
        
        # Truncate very long context for display
        if len(context) > 2000:
            truncated_context = context[:2000] + "\n\n... (context truncated for display)"
        else:
            truncated_context = context
        
        return f"""
**API Context Used:**

```text
{truncated_context}
```

**Context Statistics:**
- 📏 Total length: {len(context):,} characters
- 📄 Estimated tokens: {len(context) // 4:,}
"""
    
    def _clear_test_case_inputs(self) -> Tuple[str, str, str, str, Dict]:
        """
        Clear all test case generation inputs and outputs.
        
        Returns:
            Tuple: Empty values for all components
        """
        return "", "", "Enter API name and requirements above to generate test cases...", "API context will appear here after generation...", {}
    
    def format_answer_for_display(self, response: Dict) -> str:
        """
        Format answer for Gradio markdown display.
        
        Args:
            response: Response from RAG pipeline
            
        Returns:
            str: Markdown formatted answer
        """
        answer = response.get('answer', 'No answer generated')
        
        # Add metadata if available
        metadata = response.get('metadata', {})
        if metadata:
            processing_time = metadata.get('total_time', 0)
            chunks_used = metadata.get('chunks_used', 0)
            context_tokens = metadata.get('context_tokens', 0)
            
            metadata_text = f"""
            
            ---
            **Processing Details:**
            - ⏱️ Response time: {processing_time:.2f}s
            - 📄 Chunks used: {chunks_used}
            - 🧠 Context tokens: {context_tokens:,}
            """
            
            if metadata.get('request_id'):
                metadata_text += f"\n- 🆔 Request ID: `{metadata['request_id']}`"
            
            answer += metadata_text
        
        return answer
    
    def format_sources_for_display(self, sources: List[Dict]) -> str:
        """
        Format source citations for display.
        
        Args:
            sources: List of source dictionaries
            
        Returns:
            str: Markdown formatted sources
        """
        if not sources:
            return "No sources available."
        
        sources_text = ""
        for i, source in enumerate(sources, 1):
            # Extract source information
            document = source.get('document', 'Unknown document')
            section = source.get('section', 'Unknown section')
            score = source.get('score', 0)
            topic = source.get('topic', 'Unknown topic')
            
            # Format source entry
            sources_text += f"""
**{i}. {document}**
- 📍 Section: {section}
- 🎯 Topic: {topic}
- 📊 Relevance: {score:.3f}
- 🔗 Path: `{document}`

---
"""
        
        return sources_text
    
    def _get_filter_options(self) -> Dict[str, List[str]]:
        """
        Get available filter options from the pipeline.
        
        Returns:
            Dict[str, List[str]]: Available filter options
        """
        # This would typically come from the vector store or configuration
        # For now, return some example options
        return {
            'topics': ['API', 'Security', 'Authentication', 'Database', 'Frontend', 'Backend'],
            'departments': ['Engineering', 'Product', 'Security', 'DevOps', 'QA'],
            'section_types': ['Overview', 'Tutorial', 'Reference', 'FAQ', 'Troubleshooting']
        }
    
    def _format_stats_for_display(self) -> str:
        """Format pipeline statistics for display."""
        stats = self.pipeline_stats
        
        index_stats = stats.get('index_stats', {})
        pipeline_config = stats.get('pipeline_config', {})
        
        return f"""
**📊 Index Statistics:**
- **Name**: {index_stats.get('index_name', 'Unknown')}
- **Total Vectors**: {index_stats.get('total_vectors', 0):,}
- **Dimension**: {index_stats.get('dimension', 'Unknown')}

**⚙️ Pipeline Configuration:**
- **Max Context Tokens**: {pipeline_config.get('max_context_tokens', 0):,}
- **Default Top-K**: {pipeline_config.get('default_top_k', 0)}

**🔧 Component Status:**
- **Query Processor**: ✅ Initialized
- **Search Engine**: ✅ Initialized
- **Context Builder**: ✅ Initialized
- **Answer Generator**: ✅ Initialized
- **Search Logger**: ✅ Initialized
"""
    
    def _get_analytics_summary(self) -> str:
        """Get analytics summary for display."""
        try:
            analytics = self.rag_pipeline.search_logger.get_analytics_summary()
            
            if not analytics:
                return "No analytics data available yet."
            
            return f"""
**📈 Daily Analytics Summary**

- **Total Searches**: {analytics.get('total_searches', 0)}
- **Successful Responses**: {analytics.get('successful_responses', 0)}
- **Errors**: {analytics.get('errors', 0)}
- **Success Rate**: {analytics.get('success_rate', 0):.1f}%
- **Average Response Time**: {analytics.get('avg_response_time', 0):.2f}s
- **Error Rate**: {analytics.get('error_rate', 0):.1f}%

**🔍 Top Queries:**
{self._format_top_queries(analytics.get('top_queries', []))}
"""
        except Exception as e:
            logger.error(f"Failed to get analytics: {e}")
            return f"Error loading analytics: {str(e)}"
    
    def _format_top_queries(self, top_queries: List) -> str:
        """Format top queries for display."""
        if not top_queries:
            return "No queries recorded yet."
        
        formatted = ""
        for i, query_info in enumerate(top_queries[:5], 1):
            # Handle both tuple format (query, count) and dict format
            if isinstance(query_info, tuple):
                query, count = query_info
            else:
                query = query_info.get('query', 'Unknown')
                count = query_info.get('count', 0)
            formatted += f"{i}. **{query}** ({count} times)\n"
        
        return formatted
    
    def _get_recent_searches(self) -> str:
        """Get recent searches for display."""
        try:
            recent_searches = self.rag_pipeline.search_logger.get_search_history(limit=10)
            
            if not recent_searches:
                return "No recent searches found."
            
            formatted = ""
            for search in recent_searches:
                timestamp = search.get('timestamp', 'Unknown time')
                query = search.get('query', 'Unknown query')
                formatted += f"- **{timestamp}**: {query}\n"
            
            return formatted
        except Exception as e:
            logger.error(f"Failed to get recent searches: {e}")
            return f"Error loading recent searches: {str(e)}"
    
    def _refresh_analytics(self) -> Tuple[str, str]:
        """Refresh analytics data."""
        analytics_summary = self._get_analytics_summary()
        recent_searches = self._get_recent_searches()
        return analytics_summary, recent_searches
    
    def launch(self, share: bool = False, server_port: int = 7860, server_name: str = "0.0.0.0") -> None:
        """
        Start the Gradio server.
        
        Args:
            share: Whether to create a public link
            server_port: Port to run the server on
            server_name: Server hostname
        """
        logger.info(f"Launching Gradio interface on {server_name}:{server_port}")
        
        interface = self.create_interface()
        
        interface.launch(
            share=share,
            server_port=server_port,
            server_name=server_name,
            show_error=True
        )


# Example usage and testing
def main():
    """Launch the Gradio search interface."""
    print("=== Gradio Search Interface ===\n")
    
    try:
        # Initialize interface
        print("🔄 Initializing GradioSearchInterface...")
        interface = GradioSearchInterface()
        
        print("✅ GradioSearchInterface initialized successfully!")
        print("   🎨 Ready to create Gradio interface")
        print("   🔍 Supports basic and advanced search")
        print("   📊 Includes analytics dashboard")
        print("   🛡️  Includes error handling and validation")
        
        # Show pipeline stats
        stats = interface.pipeline_stats
        print(f"\n📊 Pipeline Statistics:")
        print(f"   📂 Index: {stats.get('index_stats', {}).get('index_name', 'Unknown')}")
        print(f"   📊 Total vectors: {stats.get('index_stats', {}).get('total_vectors', 0):,}")
        print(f"   ⚙️  Max context tokens: {stats.get('pipeline_config', {}).get('max_context_tokens', 0):,}")
        
        print(f"\n🚀 Launching Gradio interface...")
        print(f"   🌐 Will be available at http://localhost:7860")
        print(f"   📱 Press Ctrl+C to stop the server")
        
        # Launch the interface
        interface.launch(share=False, server_port=7860)
        
    except KeyboardInterrupt:
        print(f"\n👋 Gradio interface stopped by user")
    except Exception as e:
        print(f"❌ Launch failed: {e}")
        print("\nMake sure all RAG components are properly configured")
        print("Check that all required environment variables are set:")
        print("  - PINECONE_API_KEY")
        print("  - PINECONE_INDEX_NAME") 
        print("  - OPENAI_API_KEY")
        print("  - ANTHROPIC_API_KEY")


if __name__ == "__main__":
    main()
