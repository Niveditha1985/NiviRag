# Phase 1: Simple Semantic Search System Design

## Overview
A streamlined semantic search system that uses vector similarity search with Pinecone, integrated with a Gradio UI for user interaction and Claude for response generation. This is the foundation that will later evolve into a two-stage hybrid RAG system.

## System Architecture

### 1. Query Processing Layer
**Purpose**: Convert user queries into searchable format and manage search flow

#### `QueryProcessor` Class
**Responsibilities**: 
- Parse and preprocess user queries
- Coordinate semantic search
- Format results for UI display

**Methods**:
- `process_query(query_text: str, top_k: int = 10) -> SearchResult`
- `_preprocess_query(query_text: str) -> str`
- `_combine_search_results(semantic_results: List[Dict]) -> SearchResult`

### 2. Search Engine Layer
**Purpose**: Execute semantic similarity search using existing Pinecone infrastructure

#### `SemanticSearchEngine` Class
**Responsibilities**: 
- Orchestrate the entire semantic search process
- Handle query vectorization using existing infrastructure
- Execute Pinecone search and format results
- Manage search parameters and result ranking

**Methods**:
- `search(query_text: str, top_k: int = 10) -> SearchResult`
- `_vectorize_query(query_text: str) -> List[float]`
- `_search_pinecone(query_vector: List[float], top_k: int = 10) -> List[Dict]`
- `_format_results(raw_results: List[Dict]) -> List[Dict]`
- `_rank_results(results: List[Dict]) -> List[Dict]`
- `_extract_chunk_metadata(result: Dict) -> Dict[str, Any]`

### 3. Response Generation Layer
**Purpose**: Generate contextual responses using Claude with retrieved chunks

#### `ResponseGenerator` Class
**Responsibilities**: 
- Integrate with Claude API
- Format context and generate responses
- Handle conversation flow

**Methods**:
- `generate_response(query: str, context_chunks: List[Dict], conversation_history: List[Dict] = None) -> str`
- `_format_context_for_claude(chunks: List[Dict]) -> str`
- `_create_claude_prompt(query: str, context: str, history: List[Dict] = None) -> str`
- `_call_claude_api(prompt: str) -> str`
- `_post_process_response(response: str) -> str`

#### `ContextFormatter` Class
**Responsibilities**: 
- Format retrieved chunks into coherent context
- Manage context length and relevance

**Methods**:
- `format_chunks_as_context(chunks: List[Dict], max_length: int = 4000) -> str`
- `_prioritize_chunks_by_relevance(chunks: List[Dict]) -> List[Dict]`
- `_truncate_context_if_needed(context: str, max_length: int) -> str`
- `_add_source_citations(chunks: List[Dict]) -> str`

### 4. User Interface Layer
**Purpose**: Provide interactive Gradio interface for search and conversation

#### `SearchInterface` Class
**Responsibilities**: 
- Create and manage Gradio UI components
- Handle user interactions and state management
- Display search results and responses

**Methods**:
- `create_interface() -> gr.Blocks`
- `_create_search_tab() -> gr.Tab`
- `_create_conversation_tab() -> gr.Tab`
- `_handle_search(query: str, top_k: int) -> Tuple[str, str, str]`
- `_handle_conversation(query: str, history: List[Tuple[str, str]]) -> Tuple[str, List[Tuple[str, str]]]`
- `_display_search_results(results: SearchResult) -> str`
- `_display_conversation_history(history: List[Tuple[str, str]]) -> str`

#### `UIStateManager` Class
**Responsibilities**: 
- Manage application state across UI interactions
- Handle conversation history and context

**Methods**:
- `initialize_state() -> Dict[str, Any]`
- `update_conversation_history(query: str, response: str) -> None`
- `get_conversation_context() -> List[Dict]`
- `clear_conversation() -> None`
- `save_search_session(session_data: Dict) -> None`

### 5. Data Models
**Purpose**: Define data structures for search results and system state

#### `SearchResult` Class
**Responsibilities**: 
- Structure search results with metadata
- Provide result analysis and statistics

**Attributes**:
- `query: str`
- `chunks: List[ChunkResult]`
- `total_chunks_found: int`
- `search_time_ms: float`
- `query_vector: List[float]`

**Methods**:
- `get_top_chunks(n: int = 5) -> List[ChunkResult]`
- `get_search_summary() -> Dict[str, Any]`

#### `ChunkResult` Class
**Responsibilities**: 
- Represent individual chunk results with metadata

**Attributes**:
- `content: str`
- `metadata: Dict[str, Any]`
- `similarity_score: float`
- `source_document: str`
- `chunk_index: int`

**Methods**:
- `get_formatted_content() -> str`
- `get_source_info() -> str`
- `get_relevance_explanation() -> str`

### 6. Configuration and Integration
**Purpose**: Manage system configuration and external service integration

#### `SearchSystemConfig` Class
**Responsibilities**: 
- Manage configuration for all search components
- Handle environment variables and API keys

**Methods**:
- `load_config() -> Dict[str, Any]`
- `get_pinecone_config() -> Dict[str, str]`
- `get_claude_config() -> Dict[str, str]`
- `get_embedding_config() -> Dict[str, str]`
- `validate_config() -> bool`

#### `ServiceIntegrator` Class
**Responsibilities**: 
- Integrate with existing document processor
- Manage Pinecone and Claude connections
- Handle service initialization

**Methods**:
- `initialize_services() -> Dict[str, Any]`
- `get_document_processor() -> HybridRAGDocumentProcessor`
- `get_pinecone_manager() -> PineconeVectorStoreManager`
- `get_claude_client() -> ClaudeClient`
- `health_check() -> Dict[str, bool]`

## Integration Points with Existing Code

### Leveraging Existing Infrastructure

1. **Document Processor Integration**:
   - Reuse `DocumentChunkingAndVectorization` for query vectorization
   - Leverage `OpenAIEmbeddingClient` for consistent embeddings
   - Use existing vectorization pipeline

2. **Pinecone Integration**:
   - Use `PineconeVectorStoreManager.search_vectors()` for semantic search
   - Leverage `PineconeHTTPIndex.query()` for low-level operations
   - Reuse existing metadata handling

## Search Flow Design

### Simple Semantic Search Process

1. **Query Processing**
   - Preprocess user query
   - Pass query to SemanticSearchEngine

2. **Semantic Search Engine Processing**
   - Vectorize query using existing infrastructure (DocumentChunkingAndVectorization or OpenAIEmbeddingClient)
   - Search Pinecone with query vector using existing PineconeVectorStoreManager
   - Format and rank results
   - Return SearchResult with ChunkResult objects

3. **Response Generation**
   - Format retrieved chunks as context
   - Send to Claude with query
   - Generate contextual response
   - Return formatted answer

## UI Design Considerations

### Gradio Interface Components

1. **Search Tab**:
   - Query input field
   - Search parameters (top_k)
   - Results display area
   - Source citations

2. **Conversation Tab**:
   - Chat interface
   - Context-aware responses
   - Conversation history
   - Export/import functionality

3. **Settings Tab**:
   - Search parameters configuration
   - System status and health checks

## Benefits of This Design

1. **Reuses Existing Infrastructure**: Leverages document processor, Pinecone manager
2. **Simple Architecture**: Single-stage search with clear class responsibilities
3. **Fast Implementation**: Can be built quickly and tested
4. **User-Friendly Interface**: Gradio provides intuitive interaction
5. **Context-Aware Responses**: Claude integration for intelligent answers
6. **Foundation for Evolution**: Easy to extend to two-stage system later
7. **Clear Separation of Concerns**: Each class has distinct responsibilities
8. **Easy to Test**: Simple architecture makes testing straightforward

## Implementation Priority

1. **Core Search Engine** (`SemanticSearchEngine`)
2. **Gradio Interface** (`SearchInterface`, `UIStateManager`)
3. **Claude Integration** (`ResponseGenerator`, `ContextFormatter`)
4. **Configuration Management** (`SearchSystemConfig`, `ServiceIntegrator`)
5. **Testing and Refinement**

## Next Steps

1. Implement `SemanticSearchEngine` (single class handling all search logic)
2. Create basic Gradio interface
3. Integrate Claude API
4. Add conversation management
5. Test and refine the system
6. Prepare for Phase 2 evolution to two-stage system
