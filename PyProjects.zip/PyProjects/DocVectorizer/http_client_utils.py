#!/usr/bin/env python3
"""
HTTP Client Utilities

This module provides utility functions to create HTTP clients with different SSL contexts
for use with various API integrations.
"""

import os
import httpx
import ssl
from typing import Optional


def get_environment_http_client() -> httpx.Client:
    """
    Create an HTTP client based on environment configuration.
    
    This function reads the SSL_VERIFY environment variable and creates the appropriate
    HTTP client. If SSL_VERIFY is not set, it defaults to standard SSL verification.
    
    Returns:
        httpx.Client: Configured HTTP client based on environment settings
    """
    ssl_verify = os.getenv("SSL_VERIFY", "DEFAULT").upper()
    
    if ssl_verify == "NONE":
        return create_http_client_with_ssl_disabled()
    elif ssl_verify == "CUSTOM":
        return create_http_client_with_ca_bundle()
    else:  # DEFAULT or any other value
        return httpx.Client()


def create_http_client_with_ssl_disabled() -> httpx.Client:
    """
    Create an HTTP client with SSL certificate verification disabled.
    
    ⚠️  Security Warning: This disables SSL certificate verification and should only be used as a last resort.
    
    Returns:
        httpx.Client: HTTP client with SSL verification disabled
    """
    # Create a custom SSL context that doesn't verify certificates
    ssl_context = ssl.create_default_context()
    ssl_context.check_hostname = False
    ssl_context.verify_mode = ssl.CERT_NONE
    
    # Create custom transport with SSL context
    transport = httpx.HTTPTransport(verify=ssl_context)
    client = httpx.Client(transport=transport)
    
    return client


def create_http_client_with_ca_bundle() -> httpx.Client:
    """
    Create an HTTP client with custom CA bundle for corporate certificates.
    
    The CA bundle path is automatically read from the ANTHROPIC_CA_BUNDLE_PATH environment variable.
    
    Returns:
        httpx.Client: HTTP client with custom CA bundle
        
    Raises:
        ValueError: If CA bundle file is not found or ANTHROPIC_CA_BUNDLE_PATH environment variable not set
    """
    # Get CA bundle path from environment variable
    ca_bundle_path = os.getenv("ANTHROPIC_CA_BUNDLE_PATH")
    if not ca_bundle_path:
        raise ValueError("ANTHROPIC_CA_BUNDLE_PATH environment variable not set")
    
    if not os.path.exists(ca_bundle_path):
        raise ValueError(f"CA bundle file not found: {ca_bundle_path}")
    
    # Create SSL context with custom CA bundle
    ssl_context = ssl.create_default_context()
    ssl_context.load_verify_locations(cafile=ca_bundle_path)
    
    # Create custom transport with SSL context
    transport = httpx.HTTPTransport(verify=ssl_context)
    client = httpx.Client(transport=transport)
    
    return client 