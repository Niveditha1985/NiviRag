# RAG Pipeline Implementation

This implementation provides a complete RAG (Retrieval-Augmented Generation) system based on the design document `rag_search_system_design.md`. The system enables semantic search over document collections with AI-powered answer generation.

## 🏗️ Architecture Overview

The RAG Pipeline consists of the following components:

```
User Query → QueryProcessor → SemanticSearchEngine → ContextBuilder → ClaudeAnswerGenerator → Response
     ↓              ↓              ↓                    ↓                    ↓
SearchLogger ← Analytics ← Logging ← Logging ← Logging ← Logging
```

### Components

1. **QueryProcessor** (`query_processor.py`) - Handles query preprocessing and vectorization
2. **SemanticSearchEngine** (`semantic_search_engine.py`) - Executes vector similarity search
3. **ContextBuilder** (`context_builder.py`) - Assembles retrieved chunks into LLM-ready context
4. **ClaudeClient** (`claude_client.py`) - HTTP communication with Claude API
5. **ClaudeAnswerGenerator** (`claude_answer_generator.py`) - Business logic for answer generation
6. **SearchLogger** (`search_logger.py`) - Logging and analytics
7. **RAGPipeline** (`rag_pipeline.py`) - Main orchestrator

## 🚀 Quick Start

### 1. Environment Setup

Create a `.env` file with the required API keys:

```bash
# Existing (already configured)
PINECONE_API_KEY=your_pinecone_api_key
PINECONE_ENVIRONMENT=your_pinecone_environment
PINECONE_INDEX_NAME=engineering-rag-index
OPENAI_API_KEY=your_openai_api_key
OPENAI_BASE_URL=https://api.openai.com/v1
OPENAI_EMBEDDING_MODEL=text-embedding-3-small

# New (for RAG system)
ANTHROPIC_API_KEY=your_anthropic_api_key
ANTHROPIC_MODEL=claude-3-5-sonnet-20241022
ANTHROPIC_BASE_URL=https://api.anthropic.com

# Optional Configuration
MAX_CONTEXT_TOKENS=8000
DEFAULT_TOP_K=10
SSL_VERIFY=DEFAULT  # or CUSTOM or NONE
```

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

### 3. Test the Pipeline

```bash
python test_rag_pipeline.py
```

## 📖 Usage Examples

### Basic Usage

```python
from rag_pipeline import RAGPipeline

# Initialize the pipeline
pipeline = RAGPipeline()

# Answer a query
response = pipeline.answer_query(
    query="What are the API security requirements?",
    user_id="user@example.com",
    top_k=10
)

print(f"Answer: {response['answer']}")
print(f"Sources: {len(response['sources'])}")
print(f"Processing time: {response['metadata']['total_time']:.2f}s")
```

### Search Results Only

```python
# Get search results without LLM generation
search_results = pipeline.get_search_results_only(
    query="API security",
    top_k=5
)

for result in search_results:
    print(f"Score: {result['score']:.3f}")
    print(f"Content: {result['content'][:100]}...")
    print(f"Topic: {result['topic']}")
```

### Advanced Search with Filters

```python
# Search with metadata filters
response = pipeline.answer_query(
    query="How do I configure authentication?",
    filters={
        "topic": "APISecurity",
        "section_type": "security"
    },
    top_k=5
)
```

### Query Validation

```python
# Validate queries before processing
is_valid, error = pipeline.validate_query("What is API security?")
if is_valid:
    response = pipeline.answer_query("What is API security?")
else:
    print(f"Invalid query: {error}")
```

## 🔧 Configuration Options

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `MAX_CONTEXT_TOKENS` | Maximum context window size | 8000 |
| `DEFAULT_TOP_K` | Default number of search results | 10 |
| `SSL_VERIFY` | SSL verification mode | DEFAULT |

### Component Configuration

Each component can be configured independently:

```python
from query_processor import QueryProcessor
from semantic_search_engine import SemanticSearchEngine
from context_builder import ContextBuilder
from claude_answer_generator import ClaudeAnswerGenerator

# Custom configuration
query_processor = QueryProcessor()
search_engine = SemanticSearchEngine()
context_builder = ContextBuilder(max_context_tokens=6000)
answer_generator = ClaudeAnswerGenerator()

# Use in pipeline
pipeline = RAGPipeline()
```

## 📊 Analytics and Logging

### Search Analytics

```python
# Get analytics summary
analytics = pipeline.search_logger.get_analytics_summary()
print(f"Total searches: {analytics['total_searches']}")
print(f"Success rate: {analytics['success_rate']:.1f}%")
print(f"Average response time: {analytics['avg_response_time']:.2f}s")
```

### Search History

```python
# Get search history
history = pipeline.search_logger.get_search_history(
    user_id="user@example.com",
    limit=50
)

for entry in history:
    print(f"Query: {entry['query']}")
    print(f"Timestamp: {entry['timestamp']}")
```

### Export Logs

```python
from datetime import datetime

# Export logs for analysis
export_path = pipeline.search_logger.export_logs(
    start_date=datetime(2025, 1, 1),
    end_date=datetime(2025, 1, 31),
    format="jsonl"
)
print(f"Logs exported to: {export_path}")
```

## 🛠️ Component Details

### QueryProcessor

- Preprocesses and cleans user queries
- Vectorizes queries using the same embedding model as documents
- Ensures vector space compatibility

### SemanticSearchEngine

- Executes vector similarity search using Pinecone
- Supports metadata filtering
- Formats results for downstream consumption

### ContextBuilder

- Deduplicates overlapping chunks
- Orders results by relevance score
- Manages token limits and truncation
- Includes source citations

### ClaudeAnswerGenerator

- Creates optimized prompts for Claude
- Handles response parsing and formatting
- Extracts citations from generated answers
- Manages context length validation

### SearchLogger

- Logs all search requests and responses
- Captures timing and performance metrics
- Provides analytics and reporting
- Supports log export in multiple formats

## 🔍 Error Handling

The pipeline includes comprehensive error handling:

```python
try:
    response = pipeline.answer_query("Your query here")
    if response['metadata'].get('error'):
        print(f"Error: {response['metadata']['error_message']}")
    else:
        print(f"Answer: {response['answer']}")
except Exception as e:
    print(f"Pipeline error: {e}")
```

## 📈 Performance Monitoring

### Timing Metrics

Each response includes detailed timing information:

```python
metadata = response['metadata']
print(f"Total time: {metadata['total_time']:.2f}s")
print(f"Query processing: {metadata['query_processing_time']:.2f}s")
print(f"Search time: {metadata['search_time']:.2f}s")
print(f"Context building: {metadata['context_building_time']:.2f}s")
print(f"LLM generation: {metadata['llm_generation_time']:.2f}s")
```

### Resource Usage

```python
print(f"Chunks retrieved: {metadata['chunks_retrieved']}")
print(f"Chunks used: {metadata['chunks_used']}")
print(f"Context tokens: {metadata['context_tokens']}")
```

## 🧪 Testing

### Unit Tests

Each component includes comprehensive tests:

```bash
python query_processor.py
python semantic_search_engine.py
python context_builder.py
python claude_client.py
python claude_answer_generator.py
python search_logger.py
python rag_pipeline.py
```

### Integration Test

```bash
python test_rag_pipeline.py
```

## 🔒 Security Considerations

- All API keys are loaded from environment variables
- SSL configuration supports corporate environments
- Query validation prevents injection attacks
- Logging includes privacy controls

## 📝 Log Files

The system creates structured log files:

```
logs/
├── search_queries.jsonl      # All search requests and responses
├── search_errors.jsonl       # Error logs with stack traces
├── search_analytics.json     # Daily analytics summaries
└── exports/                  # User-requested log exports
```

## 🚀 Future Enhancements

The design supports future enhancements:

1. **Query Expansion** - Add related terms to improve recall
2. **Query Reformulation** - Rewrite queries in different ways
3. **Hybrid Search** - Combine semantic and keyword search
4. **Result Reranking** - Use cross-encoder models for better ranking
5. **A/B Testing** - Framework for testing search improvements

## 📞 Support

For issues or questions:

1. Check the log files for detailed error information
2. Verify all environment variables are set correctly
3. Test individual components using their demo functions
4. Review the analytics for performance insights

## 🎯 Key Features

✅ **Complete RAG Implementation** - Full end-to-end pipeline  
✅ **Modular Architecture** - Easy to test and extend  
✅ **Comprehensive Logging** - Analytics and debugging support  
✅ **Error Handling** - Robust error management  
✅ **Performance Monitoring** - Detailed timing metrics  
✅ **SSL Support** - Corporate environment compatibility  
✅ **Source Attribution** - Always cite sources  
✅ **Token Management** - Prevents context overflow  
✅ **Query Validation** - Input sanitization and validation  
✅ **Flexible Configuration** - Environment-based settings
