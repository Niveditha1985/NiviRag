# RAG Search System Design Document

## Overview
Design for a semantic search system with Gradio UI that leverages existing document processing infrastructure.

---

## Architecture Components

### 1. Query Processing Layer
**File:** `query_processor.py`

#### Class: `QueryProcessor`
Handles user query preparation and vectorization.

**Methods:**
- `__init__(self, embedding_client)`
  - Initialize with existing OpenAIEmbeddingClient from document_chunking_vectorizer
  
- `vectorize_query(self, query_text: str) -> List[float]`
  - Reuse existing embedding client to vectorize user query
  - Returns: 1536-dimensional vector
  
- `preprocess_query(self, query: str) -> str`
  - Clean and normalize query text
  - Remove extra whitespace, handle special characters
  - Returns: Cleaned query string
  
- `process(self, query: str) -> Dict[str, Any]`
  - Main method: preprocesses then vectorizes query
  - Returns: Dict with original_query, cleaned_query, query_vector

---

### 2. Search/Retrieval Layer
**File:** `semantic_search_engine.py`

#### Class: `SemanticSearchEngine`
Executes vector similarity search using existing Pinecone infrastructure.

**Methods:**
- `__init__(self, pinecone_manager: PineconeVectorStoreManager)`
  - Initialize with existing PineconeVectorStoreManager
  - No query processing - receives pre-computed vectors
  
- `search(self, query_vector: List[float], top_k: int = 10) -> List[Dict[str, Any]]`
  - Main search method
  - Receives pre-computed query vector from RAGPipeline
  - Uses pinecone_manager.search_vectors() to retrieve results
  - Returns: List of search results with content, metadata, and scores
  
- `search_with_filters(self, query_vector: List[float], metadata_filters: Dict = None, top_k: int = 10) -> List[Dict[str, Any]]`
  - Search with optional metadata filtering
  - Filters by topic, department, section_type, etc.
  - Returns: Filtered search results
  
- `format_results(self, raw_results: List[Dict]) -> List[Dict[str, Any]]`
  - Format Pinecone results for downstream consumption
  - Extract relevant fields (content, metadata, score)
  - Standardize result format
  - Returns: Cleaned and formatted results

#### Alternative Design Options (Future Enhancements)

**Option 2: Abstract Interface Pattern**
```python
from abc import ABC, abstractmethod

class VectorStoreInterface(ABC):
    @abstractmethod
    def search_vectors(self, query_vector: List[float], 
                      filter_metadata: Optional[Dict] = None,
                      top_k: int = 10) -> List[Dict[str, Any]]:
        pass
    
    @abstractmethod
    def get_index_stats(self) -> Dict[str, Any]:
        pass

class SemanticSearchEngine:
    def __init__(self, vector_store: VectorStoreInterface):
        """Initialize with any vector store implementation."""
        self.vector_store = vector_store
```

**Benefits:**
- Follows dependency inversion principle
- Easy to test with mocks
- Can swap implementations (Pinecone, Weaviate, Chroma, etc.)
- Caller only needs to know about the interface
- Better separation of concerns

**Option 3: Factory Pattern**
```python
class SemanticSearchEngine:
    def __init__(self, vector_store_factory=None):
        """Initialize with optional factory for vector store."""
        if vector_store_factory is None:
            vector_store_factory = lambda: PineconeVectorStoreManager()
        
        self.pinecone_manager = vector_store_factory()
```

**Benefits:**
- Flexible dependency creation
- Easy to inject test doubles
- Configurable at runtime
- Maintains encapsulation

**Current Implementation Choice:**
The current implementation uses internal initialization (`__init__(self)`) for simplicity and encapsulation, but Options 2 and 3 provide better testability and flexibility for future enhancements.

---

### 3. Context Building Layer
**File:** `context_builder.py`

#### Class: `ContextBuilder`
Assembles retrieved chunks into LLM-ready context.

**Methods:**
- `__init__(self, max_context_tokens: int = 8000)`
  - Set maximum context window size
  
- `build_context(self, search_results: List[Dict], query: str) -> str`
  - Main method: combines chunks into coherent context
  - Deduplicates chunks from same document
  - Orders by relevance score
  - Truncates to token limit
  - Returns: Formatted context string
  
- `deduplicate_results(self, results: List[Dict]) -> List[Dict]`
  - Remove duplicate or overlapping chunks
  - Keep highest scoring version
  - Returns: Deduplicated results
  
- `format_context_with_sources(self, results: List[Dict]) -> str`
  - Format chunks with source citations
  - Include document path, section, topic
  - Returns: Context with citation markers
  
- `estimate_tokens(self, text: str) -> int`
  - Rough token count estimation
  - Returns: Approximate token count

---

### 4. LLM Integration Layer

#### 4.1 HTTP Client Layer
**File:** `claude_client.py`

#### Class: `ClaudeClient`
Handles HTTP communication with Claude API using existing SSL infrastructure.

**Methods:**
- `__init__(self)`
  - Initialize with configuration from environment variables
  - Load ANTHROPIC_API_KEY, ANTHROPIC_MODEL from .env
  - No HTTP client creation until first request
  
- `_make_api_request(self, messages: List[Dict], model: str, max_tokens: int = 4000) -> Dict[str, Any]`
  - Make HTTP request to Claude API
  - Uses get_environment_http_client() for SSL handling
  - Handles authentication headers
  - Returns: Raw API response
  
- `generate_completion(self, messages: List[Dict], model: str = None, max_tokens: int = 4000) -> Dict[str, Any]`
  - Main method for Claude API calls
  - Uses default model if not specified
  - Handles HTTP errors and timeouts
  - Returns: Parsed API response
  
- `get_available_models(self) -> List[str]`
  - Retrieve list of available Claude models
  - Returns: List of model names

#### 4.2 Business Logic Layer
**File:** `claude_answer_generator.py`

#### Class: `ClaudeAnswerGenerator`
Generates answers using Claude with retrieved context and handles prompt engineering.

**Methods:**
- `__init__(self)`
  - Initialize with internal ClaudeClient instance
  - Create ClaudeClient automatically for API communication
  - Store model configuration and prompt templates
  
- `generate_answer(self, query: str, context: str) -> Dict[str, Any]`
  - Main method: sends query + context to Claude
  - Uses ClaudeClient for API communication
  - Returns: Dict with answer, sources, metadata
  
- `create_prompt(self, query: str, context: str) -> str`
  - Build prompt with instructions and context
  - Include system prompt, user query, and retrieved context
  - Returns: Complete prompt string
  
- `extract_citations(self, answer: str) -> List[str]`
  - Parse answer for source citations
  - Look for citation patterns like [1], [source], etc.
  - Returns: List of cited sources
  
- `format_response(self, raw_response: str, sources: List[Dict]) -> Dict[str, Any]`
  - Structure final response
  - Include answer, citations, source metadata
  - Add timing and model information
  - Returns: Complete response object
  
- `_validate_context_length(self, context: str, max_tokens: int = 8000) -> str`
  - Check if context exceeds token limits
  - Truncate if necessary while preserving structure
  - Returns: Validated context string

---

### 5. RAG Pipeline Orchestrator
**File:** `rag_pipeline.py`

#### Class: `RAGPipeline`
Main orchestrator that connects all components and controls the search flow.

**Methods:**
- `__init__(self)`
  - Initialize all components:
    - QueryProcessor (for vectorization)
    - SemanticSearchEngine (for search - receives vectors)
    - ContextBuilder (for context assembly)
    - ClaudeAnswerGenerator (for answer generation - creates ClaudeClient internally)
    - SearchLogger (for logging)
  - Load configuration from environment
  
- `answer_query(self, query: str, user_id: str = None, top_k: int = 10, filters: Dict = None) -> Dict[str, Any]`
  - Main end-to-end method
  - **Flow:**
    1. Vectorize query using QueryProcessor
    2. Pass vector to SemanticSearchEngine for search
    3. Pass results to ContextBuilder
    4. Pass context to ClaudeAnswerGenerator
    5. Log request/response via SearchLogger
  - Returns: Complete response with answer, sources, and metadata
  
- `get_search_results_only(self, query: str, top_k: int = 10) -> List[Dict]`
  - Return search results without LLM generation
  - Vectorizes query, searches, formats results
  - Useful for debugging or UI previews
  - Returns: Raw search results with scores and metadata
  
- `validate_query(self, query: str) -> Tuple[bool, str]`
  - Check if query is valid
  - Minimum length, not empty, no prohibited patterns
  - Returns: (is_valid, error_message)
  
- `_merge_and_deduplicate_results(self, results: List[Dict]) -> List[Dict]`
  - Helper method for combining search results
  - Remove duplicates by chunk_id
  - Keep highest scoring version
  - Returns: Deduplicated results
  
**Note:** RAGPipeline owns query vectorization, enabling future enhancements like query expansion and reformulation without modifying SearchEngine.

---

### 6. Gradio UI Layer
**File:** `gradio_search_interface.py`

#### Class: `GradioSearchInterface`
Web UI for interacting with the RAG system.

**Methods:**
- `__init__(self, rag_pipeline: RAGPipeline)`
  - Initialize with RAGPipeline instance
  
- `create_interface(self) -> gr.Blocks`
  - Build Gradio interface
  - Define input/output components
  - Connect to pipeline methods
  - Returns: Gradio Blocks object
  
- `handle_search(self, query: str, top_k: int, show_sources: bool) -> Tuple[str, str]`
  - Gradio callback for search button
  - Calls rag_pipeline.answer_query()
  - Returns: (answer_text, sources_text)
  
- `handle_advanced_search(self, query: str, top_k: int, topic_filter: str, department_filter: str) -> Tuple[str, str]`
  - Advanced search with filters
  - Returns: (answer_text, sources_text)
  
- `format_answer_for_display(self, response: Dict) -> str`
  - Format answer for Gradio markdown display
  - Returns: Markdown formatted answer
  
- `format_sources_for_display(self, sources: List[Dict]) -> str`
  - Format source citations for display
  - Returns: Markdown formatted sources
  
- `launch(self, share: bool = False)`
  - Start Gradio server
  - Configure sharing, port, etc.

---

## Data Flow

```
User Query (Gradio UI)
    ↓
RAGPipeline.answer_query()
    ↓
QueryProcessor.process() → query_vector
    ↓
SemanticSearchEngine.search(query_vector) → search_results
    ↓
PineconeVectorStoreManager.search_vectors() [existing]
    ↓
ContextBuilder.build_context(results, query) → context_string
    ↓
ClaudeAnswerGenerator.generate_answer(query, context)
    ↓
ClaudeAnswerGenerator → ClaudeClient.generate_completion() → raw_response
    ↓
ClaudeAnswerGenerator.format_response() → answer
    ↓
SearchLogger.log_search_response() [logs everything]
    ↓
GradioSearchInterface.format_answer_for_display()
    ↓
Display to User
```

**Key Point:** RAGPipeline controls query vectorization and passes vectors to SearchEngine. This design enables future query expansion/reformulation features.

---

## Reused Existing Components

### From `document_chunking_vectorizer.py`:
- `OpenAIEmbeddingClient` - for query vectorization
- Same embedding model ensures vector space compatibility

### From `pinecone_vector_store_manager.py`:
- `PineconeVectorStoreManager` - for search operations
- `search_vectors()` method - retrieves similar chunks
- `get_index_stats()` - for UI statistics display

### From `http_client_utils.py`:
- SSL handling for corporate environment
- Used by ClaudeClient for API calls
- SSL_VERIFY environment variable controls SSL behavior
- Consistent SSL configuration across all HTTP clients

---

## Configuration

### Environment Variables Needed:
```
# Existing (already configured)
PINECONE_API_KEY
PINECONE_INDEX_NAME
OPENAI_API_KEY

# New (for search system)
ANTHROPIC_API_KEY
ANTHROPIC_MODEL=claude-3-5-sonnet-20241022
MAX_CONTEXT_TOKENS=8000
DEFAULT_TOP_K=10
SSL_VERIFY=DEFAULT  # or CUSTOM or NONE
```

---

## Gradio UI Components

### Main Interface Layout:

**Input Section:**
- Text area: Query input
- Slider: Number of results (top_k)
- Checkboxes: Show sources, Show debug info

**Advanced Filters (Collapsible):**
- Dropdown: Topic filter
- Dropdown: Department filter
- Dropdown: Section type filter

**Output Section:**
- Markdown: Generated answer
- Accordion: Source citations with metadata
- JSON: Debug info (search results, context)

**Statistics Panel:**
- Index stats from Pinecone
- Total vectors, last updated, etc.

---

## Key Design Decisions

1. **Reuse Existing Infrastructure**
   - No duplicate embedding clients
   - Same vectorization ensures compatibility
   - Leverage existing Pinecone setup

2. **Modular Architecture**
   - Each layer has single responsibility
   - Easy to test components independently
   - Can swap Claude for other LLMs

3. **Gradio for UI**
   - Fast prototyping
   - Built-in sharing capabilities
   - Professional-looking interface

4. **Context Management**
   - Token-aware context building
   - Prevents context overflow
   - Intelligent deduplication

5. **Source Attribution**
   - Always cite sources
   - Include metadata for traceability
   - Support debugging workflow

---

### 7. Logging and Analytics Layer
**File:** `search_logger.py`

#### Class: `SearchLogger`
Captures all search interactions for debugging, monitoring, and analytics.

**Methods:**
- `__init__(self, log_dir: str = "./logs")`
  - Set up log file paths and directory structure
  - Create daily rotating log files
  - Initialize file handlers with proper permissions
  
- `log_search_request(self, user_id: str, query: str, timestamp: datetime, session_info: Dict) -> str`
  - Log incoming search query with user context
  - Capture IP, user agent, Gradio session ID
  - Generate and return unique request_id for tracking
  
- `log_search_response(self, request_id: str, response: Dict, metadata: Dict) -> None`
  - Log complete response with answer, sources, and metadata
  - Include all timing metrics (query processing, search, context building, LLM)
  - Store chunks retrieved vs chunks used in context
  - Record context token count and model used
  
- `log_error(self, request_id: str, error: Exception, context: Dict) -> None`
  - Log errors with full stack trace
  - Include query, user_id, and processing stage where error occurred
  - Store error type and message for analysis
  
- `get_search_history(self, user_id: str = None, start_date: datetime = None, end_date: datetime = None, limit: int = 100) -> List[Dict]`
  - Retrieve search history for debugging or analysis
  - Filter by user, date range, or both
  - Returns: List of search log entries
  
- `get_analytics_summary(self, date: datetime = None) -> Dict[str, Any]`
  - Generate daily analytics summary
  - Returns: Total searches, avg response time, top queries, error rate
  
- `export_logs(self, start_date: datetime, end_date: datetime, format: str = "jsonl") -> str`
  - Export logs for specified date range
  - Supports formats: jsonl, csv, json
  - Returns: Path to exported file

---

### 8. Analytics Dashboard (Future Enhancement)
**File:** `analytics_dashboard.py`

#### Class: `AnalyticsDashboard`
Admin interface for monitoring search system performance and usage.

**Methods:**
- `__init__(self, search_logger: SearchLogger)`
  - Initialize with SearchLogger instance
  - Load historical data for trends
  
- `create_dashboard(self) -> gr.Blocks`
  - Build Gradio analytics interface
  - Create tabs for different analytics views
  - Returns: Gradio Blocks object
  
- `get_daily_stats(self, date: datetime = None) -> Dict[str, Any]`
  - Total searches, unique users, avg response time
  - Error rate, peak usage hours
  - Returns: Statistics dictionary
  
- `get_top_queries(self, period: str = "today", limit: int = 20) -> List[Dict]`
  - Most frequent queries in specified period
  - Include query count and avg satisfaction score
  - Returns: List of query statistics
  
- `get_slow_queries(self, threshold_seconds: float = 3.0, limit: int = 20) -> List[Dict]`
  - Queries that took longer than threshold
  - Include timing breakdown for optimization
  - Returns: List of slow query details
  
- `get_failed_searches(self, period: str = "today", limit: int = 50) -> List[Dict]`
  - Searches that returned errors or zero results
  - Useful for identifying gaps in knowledge base
  - Returns: List of failed searches
  
- `get_user_activity(self, user_id: str = None) -> Dict[str, Any]`
  - Search frequency, common topics, usage patterns
  - Returns: User activity summary
  
- `generate_performance_report(self, start_date: datetime, end_date: datetime) -> str`
  - Comprehensive performance report for date range
  - Include graphs, trends, recommendations
  - Returns: HTML report path
  
- `visualize_response_times(self, period: str = "week") -> gr.Plot`
  - Time series graph of response times
  - Breakdown by component (search, context, LLM)
  - Returns: Gradio plot component
  
- `visualize_topic_distribution(self, period: str = "week") -> gr.Plot`
  - Pie chart or bar chart of topics searched
  - Based on retrieved chunks' topics
  - Returns: Gradio plot component

---

## Integration with Existing Components

### RAGPipeline Updates:
```
Modified methods:
- __init__(): Add SearchLogger initialization
- answer_query(): Add logging before/after processing
  - Log request with request_id
  - Log response with metadata
  - Log errors if any occur
```

### GradioSearchInterface Updates:
```
Modified methods:
- __init__(): Store user authentication info
- handle_search(): Pass user_id and session_info to pipeline
- create_interface(): Add optional admin tab with analytics
```

---

## Log File Structure

```
logs/
├── search_queries_2025-01-15.jsonl      # All successful searches
├── search_queries_2025-01-16.jsonl
├── search_errors_2025-01-15.jsonl       # Errors and failures
├── search_analytics_2025-01-15.json     # Daily summaries
└── exports/                              # User-requested exports
    └── search_history_2025-01-01_to_2025-01-31.csv
```

### Log Entry Format (JSONL):
```json
{
  "request_id": "req_20250115_143022_abc123",
  "timestamp": "2025-01-15T14:30:22.123Z",
  "user_id": "john.doe@company.com",
  "query": "how do I cancel subscriptions",
  "response": {
    "answer": "To cancel a subscription...",
    "sources": [
      {"document": "apis/cancel_subscription.md", "section": "Overview", "score": 0.87}
    ]
  },
  "metadata": {
    "total_time": 1.63,
    "query_processing_time": 0.15,
    "search_time": 0.23,
    "context_building_time": 0.05,
    "llm_generation_time": 1.20,
    "chunks_retrieved": 10,
    "chunks_used": 5,
    "context_tokens": 3200,
    "top_k": 10
  },
  "session_info": {
    "ip_address": "10.0.1.45",
    "user_agent": "Mozilla/5.0...",
    "gradio_session_id": "sess_xyz789"
  }
}
```

---

## Privacy and Compliance Considerations

**Data Retention:**
- Default: 90 days for detailed logs
- Daily summaries: 1 year
- Configurable via environment variable

**Access Controls:**
- Log files restricted to admin users only
- Analytics dashboard requires admin authentication
- Audit trail for log access

**Data Sanitization:**
- Option to redact sensitive patterns (emails, tokens, etc.)
- PII detection and masking
- Compliance with company data policies

---

## Future Enhancements (Not in Initial Design)

**Phase 1 (Post-Launch):**
- User feedback collection (thumbs up/down on answers)
- Conversation history per user session
- Query suggestion/autocomplete

**Phase 2 (Query Enhancement):**
- **Query Expansion**: Add related terms to improve recall
  - Example: "cancel subscription" → "cancel subscription OR terminate membership OR end recurring billing"
  - Use topic hierarchy to find related terms
  - Can be implemented in RAGPipeline by:
    1. Generating expanded queries
    2. Vectorizing each variant
    3. Searching with multiple vectors
    4. Merging and deduplicating results

- **Query Reformulation**: Rewrite query in different ways
  - Example: "how do I cancel subscriptions?" → ["subscription cancellation process", "steps to terminate subscription", "end subscription guide"]
  - Use LLM to generate reformulations
  - Can be implemented in RAGPipeline by:
    1. Generating query variations
    2. Vectorizing each
    3. Combining search results
    4. Weighted merging by relevance

**Implementation Pattern for Query Expansion/Reformulation:**
```python
# New component: query_expander.py
class QueryExpander:
    def expand_with_hierarchy(query: str) -> List[str]
    def reformulate_with_llm(query: str) -> List[str]

# In RAGPipeline.answer_query():
if self.enable_query_expansion:  # Config flag
    expanded_queries = self.query_expander.expand(query)
    all_vectors = [self.query_processor.vectorize_query(q) for q in expanded_queries]
    all_results = [self.search_engine.search(vec, top_k) for vec in all_vectors]
    merged_results = self._merge_and_deduplicate_results(all_results)
```

**Phase 3 (Advanced Search):**
- Hybrid search (semantic + keyword BM25)
- Result reranking with cross-encoder models
- A/B testing framework for search improvements

**Phase 4 (Analytics - Already Designed):**
- Analytics Dashboard implementation
- Real-time monitoring alerts
- Automated quality reports
- Search quality scoring based on user feedback

---

## Implementation Order

1. **QueryProcessor** - Simple, uses existing embedding client
2. **ContextBuilder** - No external dependencies
3. **SemanticSearchEngine** - Integrates existing Pinecone
4. **ClaudeClient** - HTTP communication layer using http_client_utils
5. **ClaudeAnswerGenerator** - Business logic layer using ClaudeClient
6. **RAGPipeline** - Orchestrates all components
7. **GradioSearchInterface** - UI layer on top of pipeline

---

## Testing Strategy

Each class should have:
- Unit tests with mock dependencies
- Integration tests with real components
- End-to-end test through RAGPipeline

UI testing:
- Manual testing through Gradio interface
- Test edge cases (empty query, no results, etc.)