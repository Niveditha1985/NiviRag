#!/usr/bin/env python3
"""
Re-populate Pinecone Index with Content

This script clears the existing Pinecone index and re-populates it with content included in metadata.
"""

import os
import json
from dotenv import load_dotenv
from document_chunking_vectorizer import DocumentChunkingAndVectorization
from pinecone_vector_store_manager import PineconeVectorStoreManager

# Load environment variables
load_dotenv()


def repopulate_index():
    """Clear and re-populate Pinecone index with content in metadata."""
    print("=== Re-populating Pinecone Index with Content ===\n")
    
    try:
        # Sample document content (same as before)
        sample_documents = [
            {
                "path": "api_security_guide.md",
                "content": """# API Security Guide

## Overview
API security is critical for protecting your applications and data. This guide covers essential security practices.

## Authentication
<!-- topic: Authentication -->
All API endpoints must implement proper authentication mechanisms. Use JWT tokens or API keys for authentication.

### JWT Implementation
- Generate tokens with appropriate expiration times
- Validate tokens on every request
- Use secure signing algorithms

## Authorization
<!-- topic: Authorization -->
Authorization determines what authenticated users can access.

### Role-Based Access Control
- Define user roles (admin, user, guest)
- Implement permission checks
- Use middleware for authorization

## Data Protection
<!-- topic: DataProtection -->
Protect sensitive data in transit and at rest.

### Encryption
- Use HTTPS for all API communications
- Encrypt sensitive data before storage
- Implement proper key management

## Rate Limiting
<!-- topic: RateLimiting -->
Implement rate limiting to prevent abuse.

### Implementation
- Set appropriate limits per user/IP
- Use sliding window algorithms
- Return proper HTTP status codes"""
            },
            {
                "path": "database_setup.md", 
                "content": """# Database Setup Guide

## Overview
This guide covers database configuration and best practices for production environments.

## Connection Pooling
<!-- topic: ConnectionPooling -->
Use connection pooling for better performance and resource management.

### Configuration
- Set appropriate pool sizes
- Configure timeout values
- Monitor connection usage

## Indexing Strategy
<!-- topic: Indexing -->
Proper indexing is crucial for query performance.

### Best Practices
- Create indexes on frequently queried columns
- Avoid over-indexing
- Monitor index usage

## Backup and Recovery
<!-- topic: BackupRecovery -->
Implement robust backup and recovery procedures.

### Backup Strategy
- Schedule regular backups
- Test restore procedures
- Store backups securely"""
            },
            {
                "path": "deployment_guide.md",
                "content": """# Deployment Guide

## Overview
This guide covers deployment strategies and best practices for production applications.

## Container Deployment
<!-- topic: ContainerDeployment -->
Use containers for consistent deployments across environments.

### Docker Configuration
- Create optimized Dockerfiles
- Use multi-stage builds
- Implement health checks

## CI/CD Pipeline
<!-- topic: CICD -->
Implement continuous integration and deployment.

### Pipeline Stages
- Code quality checks
- Automated testing
- Deployment automation

## Monitoring
<!-- topic: Monitoring -->
Set up comprehensive monitoring for deployed applications.

### Metrics Collection
- Application performance metrics
- Infrastructure monitoring
- Log aggregation"""
            }
        ]
        
        # Initialize components
        print("🔄 Initializing components...")
        chunker = DocumentChunkingAndVectorization(
            chunk_size=300,
            chunk_overlap=50,
            min_chunk_size=100
        )
        
        pinecone_manager = PineconeVectorStoreManager()
        
        # Get current index stats
        print("\n📊 Current Index Stats:")
        stats = pinecone_manager.get_index_stats()
        print(f"   Total vectors: {stats.get('total_vectors', 0)}")
        
        # Note: We can't easily delete all vectors via HTTP API
        # So we'll just add new vectors with different IDs
        print("\n⚠️  Note: Existing vectors will remain in the index.")
        print("   New vectors will be added with content in metadata.")
        
        # Process each document
        total_chunks = 0
        for i, doc in enumerate(sample_documents):
            print(f"\n📄 Processing document {i+1}: {doc['path']}")
            
            # Chunk and vectorize document
            vectorization_result = chunker.chunk_and_vectorize_document(
                content=doc['content'],
                document_path=doc['path']
            )
            
            print(f"   Created {len(vectorization_result.chunks)} chunks")
            
            # Store in Pinecone (now with content in metadata)
            storage_result = pinecone_manager.store_document_vectors(vectorization_result)
            
            if storage_result.get('success'):
                chunks_stored = storage_result.get('chunks_stored', 0)
                total_chunks += chunks_stored
                print(f"   ✅ Stored {chunks_stored} chunks in Pinecone")
            else:
                print(f"   ❌ Failed to store: {storage_result.get('error', 'Unknown error')}")
        
        print(f"\n📊 Summary:")
        print(f"   Documents processed: {len(sample_documents)}")
        print(f"   Total chunks stored: {total_chunks}")
        
        # Verify storage
        print(f"\n🔍 Verifying storage...")
        stats = pinecone_manager.get_index_stats()
        print(f"   Index vectors: {stats.get('total_vectors', 0)}")
        
        if stats.get('total_vectors', 0) > 0:
            print(f"   ✅ Data successfully added to index!")
            
            # Test a simple query to verify content is available
            print(f"\n🧪 Testing query functionality...")
            test_vector = [0.0] * 1536  # Simple test vector
            results = pinecone_manager.search_vectors(test_vector, top_k=3)
            print(f"   Query returned {len(results)} results")
            
            if results:
                print(f"   Sample result:")
                sample = results[0]
                print(f"     ID: {sample.get('id', 'unknown')}")
                print(f"     Score: {sample.get('score', 0):.3f}")
                print(f"     Document: {sample.get('metadata', {}).get('document_path', 'unknown')}")
                
                # Check if content is now available
                content = sample.get('metadata', {}).get('content', '')
                if content:
                    print(f"     Content: {content[:100]}...")
                    print(f"   ✅ Content is now available in metadata!")
                else:
                    print(f"   ❌ Content still missing from metadata")
            
            return True
        else:
            print(f"   ❌ No vectors found in index")
            return False
        
    except Exception as e:
        print(f"❌ Failed to re-populate index: {e}")
        return False


def main():
    """Main function."""
    print("Starting index re-population...")
    print("=" * 50)
    
    success = repopulate_index()
    
    print("=" * 50)
    if success:
        print("🎉 Index re-populated successfully!")
        print("   Content is now included in metadata.")
        print("   You can now test the RAG Pipeline:")
        print("   python test_rag_pipeline.py")
    else:
        print("❌ Failed to re-populate index.")
        print("   Check the error messages above for details.")


if __name__ == "__main__":
    main()
