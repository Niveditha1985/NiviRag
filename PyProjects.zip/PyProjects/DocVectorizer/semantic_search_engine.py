#!/usr/bin/env python3
"""
Semantic Search Engine

This module executes vector similarity search using existing Pinecone infrastructure.
"""

import logging
from typing import Dict, List, Optional, Any
from pinecone_vector_store_manager import PineconeVectorStoreManager

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class SemanticSearchEngine:
    """
    Executes vector similarity search using existing Pinecone infrastructure.
    
    This class receives pre-computed query vectors and uses the PineconeVectorStoreManager
    to retrieve similar document chunks. It focuses purely on search operations
    without handling query processing.
    """
    
    def __init__(self, pinecone_manager: PineconeVectorStoreManager = None):
        """
        Initialize the semantic search engine.
        
        Args:
            pinecone_manager: PineconeVectorStoreManager instance for search operations.
                            If None, creates a new instance.
        """
        if pinecone_manager is None:
            self.pinecone_manager = PineconeVectorStoreManager()
        else:
            self.pinecone_manager = pinecone_manager
            
        logger.info("SemanticSearchEngine initialized with PineconeVectorStoreManager")
    
    def search(self, query_vector: List[float], top_k: int = 10) -> List[Dict[str, Any]]:
        """
        Main search method using pre-computed query vector.
        
        Args:
            query_vector: Pre-computed query vector from QueryProcessor
            top_k: Number of results to return
            
        Returns:
            List[Dict[str, Any]]: List of search results with content, metadata, and scores
        """
        try:
            logger.info(f"Searching with vector of {len(query_vector)} dimensions, top_k={top_k}")
            
            # Use PineconeVectorStoreManager for search
            raw_results = self.pinecone_manager.search_vectors(
                query_vector=query_vector,
                top_k=top_k
            )
            
            # Format results for downstream consumption
            formatted_results = self.format_results(raw_results)
            
            logger.info(f"Found {len(formatted_results)} search results")
            return formatted_results
            
        except Exception as e:
            logger.error(f"Search failed: {e}")
            return []
    
    def search_with_filters(self, query_vector: List[float], 
                           metadata_filters: Dict = None, 
                           top_k: int = 10) -> List[Dict[str, Any]]:
        """
        Search with optional metadata filtering.
        
        Args:
            query_vector: Pre-computed query vector
            metadata_filters: Optional filters for topic, department, section_type, etc.
            top_k: Number of results to return
            
        Returns:
            List[Dict[str, Any]]: Filtered search results
        """
        try:
            logger.info(f"Searching with filters: {metadata_filters}, top_k={top_k}")
            
            # Use PineconeVectorStoreManager with filters
            raw_results = self.pinecone_manager.search_vectors(
                query_vector=query_vector,
                filter_metadata=metadata_filters,
                top_k=top_k
            )
            
            # Format results
            formatted_results = self.format_results(raw_results)
            
            logger.info(f"Found {len(formatted_results)} filtered results")
            return formatted_results
            
        except Exception as e:
            logger.error(f"Filtered search failed: {e}")
            return []
    
    def format_results(self, raw_results: List[Dict]) -> List[Dict[str, Any]]:
        """
        Format Pinecone results for downstream consumption.
        
        Args:
            raw_results: Raw results from PineconeVectorStoreManager
            
        Returns:
            List[Dict[str, Any]]: Cleaned and formatted results
        """
        formatted_results = []
        
        for result in raw_results:
            try:
                # Extract basic fields
                chunk_id = result.get('id', 'unknown')
                score = result.get('score', 0.0)
                metadata = result.get('metadata', {})
                
                # Extract content from metadata (stored as page_content in LangChain format)
                content = metadata.get('page_content', '')
                if not content:
                    # Fallback: try to get content from other metadata fields
                    content = metadata.get('content', '')
                
                # Create formatted result
                formatted_result = {
                    'chunk_id': chunk_id,
                    'content': content,
                    'score': score,
                    'metadata': metadata,
                    # Extract commonly used metadata fields for easy access
                    'topic': metadata.get('topic'),
                    'section_title': metadata.get('section_title'),
                    'section_type': metadata.get('section_type'),
                    'document_path': metadata.get('document_path'),
                    'chunk_index': metadata.get('chunk_index'),
                    'char_count': metadata.get('char_count'),
                    'word_count': metadata.get('word_count')
                }
                
                formatted_results.append(formatted_result)
                
            except Exception as e:
                logger.warning(f"Failed to format result {result.get('id', 'unknown')}: {e}")
                continue
        
        # Sort by score (highest first)
        formatted_results.sort(key=lambda x: x['score'], reverse=True)
        
        logger.debug(f"Formatted {len(formatted_results)} results")
        return formatted_results
    
    def get_index_stats(self) -> Dict[str, Any]:
        """
        Get statistics about the Pinecone index.
        
        Returns:
            Dict[str, Any]: Index statistics
        """
        try:
            return self.pinecone_manager.get_index_stats()
        except Exception as e:
            logger.error(f"Failed to get index stats: {e}")
            return {"error": str(e)}


# Example usage and testing
def main():
    """Demonstrate semantic search engine functionality."""
    print("=== Semantic Search Engine Demo ===\n")
    
    try:
        # Initialize search engine
        print("🔄 Initializing SemanticSearchEngine...")
        search_engine = SemanticSearchEngine()
        
        # Get index statistics
        stats = search_engine.get_index_stats()
        print(f"\n📊 Index Statistics:")
        print(f"   📂 Index: {stats.get('index_name', 'unknown')}")
        print(f"   📊 Total vectors: {stats.get('total_vectors', 0)}")
        print(f"   📈 Index fullness: {stats.get('index_fullness', 0):.2%}")
        
        # Note: For full demo, you would need a query vector from QueryProcessor
        print(f"\n✅ SemanticSearchEngine ready!")
        print(f"   🔍 Ready to search with pre-computed vectors")
        print(f"   🏷️  Supports metadata filtering")
        print(f"   📊 Provides index statistics")
        
        # Example of how it would be used with QueryProcessor
        print(f"\n💡 Usage example:")
        print(f"   query_processor = QueryProcessor()")
        print(f"   query_result = query_processor.process('user query')")
        print(f"   search_results = search_engine.search(query_result['query_vector'])")
        
    except Exception as e:
        print(f"❌ Demo failed: {e}")
        print("\nMake sure PineconeVectorStoreManager is properly configured")


if __name__ == "__main__":
    main()