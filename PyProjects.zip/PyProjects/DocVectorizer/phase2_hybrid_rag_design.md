# Phase 2: Two-Stage Hybrid RAG Search System Design

## Overview
An advanced two-stage hybrid RAG search system that combines topic-based filtering with semantic similarity search, integrated with a Gradio UI for user interaction and Claude for response generation. This builds upon the Phase 1 semantic search system.

## System Architecture

### 1. Query Processing Layer
**Purpose**: Convert user queries into searchable format and manage two-stage search flow

#### `QueryProcessor` Class
**Responsibilities**: 
- Parse and preprocess user queries
- Coordinate two-stage retrieval
- Format results for UI display

**Methods**:
- `process_query(query_text: str, topics: List[str] = None, top_k: int = 10) -> SearchResult`
- `_preprocess_query(query_text: str) -> str`
- `_extract_topic_hints(query_text: str) -> List[str]`
- `_combine_search_results(topic_results: List[Dict], semantic_results: List[Dict]) -> SearchResult`

#### `QueryVectorizer` Class
**Responsibilities**: 
- Convert text queries to vectors using existing infrastructure
- Reuse document processor's vectorization capabilities

**Methods**:
- `vectorize_query(query_text: str) -> List[float]`
- `_get_embedding_client() -> OpenAIEmbeddingClient`
- `_normalize_query_for_vectorization(query_text: str) -> str`

### 2. Search Engine Layer
**Purpose**: Execute two-stage retrieval using existing Pinecone infrastructure

#### `HybridSearchEngine` Class
**Responsibilities**: 
- Orchestrate Stage 1 (topic filtering) and Stage 2 (semantic search)
- Manage search parameters and result ranking

**Methods**:
- `search(query_text: str, topics: List[str] = None, top_k: int = 10) -> SearchResult`
- `_stage1_topic_filtering(topics: List[str]) -> List[str]`
- `_stage2_semantic_search(query_vector: List[float], topic_filters: Dict = None, top_k: int = 10) -> List[Dict]`
- `_rank_and_combine_results(topic_results: List[Dict], semantic_results: List[Dict]) -> List[Dict]`

#### `TopicFilterManager` Class
**Responsibilities**: 
- Manage topic-based filtering logic
- Handle topic hierarchy relationships

**Methods**:
- `filter_by_topics(topics: List[str]) -> Dict[str, Any]`
- `_expand_topic_hierarchy(topics: List[str]) -> List[str]`
- `_create_pinecone_filter(topics: List[str]) -> Dict[str, Any]`
- `_validate_topics(topics: List[str]) -> List[str]`

#### `SemanticSearchManager` Class
**Responsibilities**: 
- Execute semantic similarity search using existing Pinecone methods
- Handle vector-based retrieval

**Methods**:
- `search_by_vector(query_vector: List[float], filters: Dict = None, top_k: int = 10) -> List[Dict]`
- `_format_search_results(raw_results: List[Dict]) -> List[Dict]`
- `_extract_chunk_metadata(result: Dict) -> Dict[str, Any]`

### 3. Response Generation Layer
**Purpose**: Generate contextual responses using Claude with retrieved chunks

#### `ResponseGenerator` Class
**Responsibilities**: 
- Integrate with Claude API
- Format context and generate responses
- Handle conversation flow

**Methods**:
- `generate_response(query: str, context_chunks: List[Dict], conversation_history: List[Dict] = None) -> str`
- `_format_context_for_claude(chunks: List[Dict]) -> str`
- `_create_claude_prompt(query: str, context: str, history: List[Dict] = None) -> str`
- `_call_claude_api(prompt: str) -> str`
- `_post_process_response(response: str) -> str`

#### `ContextFormatter` Class
**Responsibilities**: 
- Format retrieved chunks into coherent context
- Manage context length and relevance

**Methods**:
- `format_chunks_as_context(chunks: List[Dict], max_length: int = 4000) -> str`
- `_prioritize_chunks_by_relevance(chunks: List[Dict]) -> List[Dict]`
- `_truncate_context_if_needed(context: str, max_length: int) -> str`
- `_add_source_citations(chunks: List[Dict]) -> str`

### 4. User Interface Layer
**Purpose**: Provide interactive Gradio interface for search and conversation

#### `SearchInterface` Class
**Responsibilities**: 
- Create and manage Gradio UI components
- Handle user interactions and state management
- Display search results and responses

**Methods**:
- `create_interface() -> gr.Blocks`
- `_create_search_tab() -> gr.Tab`
- `_create_conversation_tab() -> gr.Tab`
- `_handle_search(query: str, topics: str, top_k: int) -> Tuple[str, str, str]`
- `_handle_conversation(query: str, history: List[Tuple[str, str]]) -> Tuple[str, List[Tuple[str, str]]]`
- `_display_search_results(results: SearchResult) -> str`
- `_display_conversation_history(history: List[Tuple[str, str]]) -> str`

#### `UIStateManager` Class
**Responsibilities**: 
- Manage application state across UI interactions
- Handle conversation history and context

**Methods**:
- `initialize_state() -> Dict[str, Any]`
- `update_conversation_history(query: str, response: str) -> None`
- `get_conversation_context() -> List[Dict]`
- `clear_conversation() -> None`
- `save_search_session(session_data: Dict) -> None`

### 5. Data Models
**Purpose**: Define data structures for search results and system state

#### `SearchResult` Class
**Responsibilities**: 
- Structure search results with metadata
- Provide result analysis and statistics

**Attributes**:
- `query: str`
- `topic_filters: List[str]`
- `chunks: List[Dict]`
- `total_chunks_found: int`
- `search_time_ms: float`
- `stage1_results: List[Dict]`
- `stage2_results: List[Dict]`

**Methods**:
- `get_top_chunks(n: int = 5) -> List[Dict]`
- `get_chunks_by_topic(topic: str) -> List[Dict]`
- `get_search_summary() -> Dict[str, Any]`

#### `ChunkResult` Class
**Responsibilities**: 
- Represent individual chunk results with metadata

**Attributes**:
- `content: str`
- `metadata: Dict[str, Any]`
- `similarity_score: float`
- `source_document: str`
- `chunk_index: int`
- `topics: List[str]`

**Methods**:
- `get_formatted_content() -> str`
- `get_source_info() -> str`
- `get_relevance_explanation() -> str`

### 6. Configuration and Integration
**Purpose**: Manage system configuration and external service integration

#### `SearchSystemConfig` Class
**Responsibilities**: 
- Manage configuration for all search components
- Handle environment variables and API keys

**Methods**:
- `load_config() -> Dict[str, Any]`
- `get_pinecone_config() -> Dict[str, str]`
- `get_claude_config() -> Dict[str, str]`
- `get_embedding_config() -> Dict[str, str]`
- `validate_config() -> bool`

#### `ServiceIntegrator` Class
**Responsibilities**: 
- Integrate with existing document processor
- Manage Pinecone and Claude connections
- Handle service initialization

**Methods**:
- `initialize_services() -> Dict[str, Any]`
- `get_document_processor() -> HybridRAGDocumentProcessor`
- `get_pinecone_manager() -> PineconeVectorStoreManager`
- `get_claude_client() -> ClaudeClient`
- `health_check() -> Dict[str, bool]`

## Integration Points with Existing Code

### Leveraging Existing Infrastructure

1. **Document Processor Integration**:
   - Reuse `DocumentChunkingAndVectorization` for query vectorization
   - Leverage `OpenAIEmbeddingClient` for consistent embeddings
   - Use existing topic hierarchy management

2. **Pinecone Integration**:
   - Use `PineconeVectorStoreManager.search_vectors()` for semantic search
   - Leverage `PineconeHTTPIndex.query()` for low-level operations
   - Reuse existing metadata cleaning and filtering

3. **Topic Hierarchy Integration**:
   - Use `get_topic_hierarchy_manager()` for topic expansion
   - Leverage `get_topic_metadata_all_hierarchies()` for filtering
   - Reuse topic relationship data

## Search Flow Design

### Two-Stage Retrieval Process

1. **Stage 1: Topic-Based Filtering**
   - Extract topic hints from query
   - Expand topics using hierarchy
   - Create Pinecone metadata filters
   - Fast filtering by topic tags

2. **Stage 2: Semantic Similarity Search**
   - Vectorize query using existing infrastructure
   - Search Pinecone with topic filters
   - Rank results by similarity score
   - Return top-k most relevant chunks

3. **Response Generation**
   - Format retrieved chunks as context
   - Send to Claude with query
   - Generate contextual response
   - Return formatted answer

## `_extract_topic_hints` Algorithm Design

### Algorithm Overview
The `_extract_topic_hints` method analyzes user queries to identify potential topics that can be used for Stage 1 filtering. It uses multiple strategies to extract topic hints from natural language queries.

### Algorithm Steps

#### 1. **Text Preprocessing**
```python
def _extract_topic_hints(self, query_text: str) -> List[str]:
    """
    Extract topic hints from user query using multiple strategies.
    
    Algorithm:
    1. Preprocess query text
    2. Extract explicit topic mentions
    3. Extract implicit topics via keyword matching
    4. Expand topics using hierarchy relationships
    5. Rank and filter topic hints
    6. Return top-k most relevant topics
    """
    
    # Step 1: Preprocess query
    cleaned_query = self._preprocess_query(query_text)
    topic_hints = set()
    
    # Step 2: Extract explicit topic mentions
    explicit_topics = self._extract_explicit_topics(cleaned_query)
    topic_hints.update(explicit_topics)
    
    # Step 3: Extract implicit topics via keyword matching
    implicit_topics = self._extract_implicit_topics(cleaned_query)
    topic_hints.update(implicit_topics)
    
    # Step 4: Expand topics using hierarchy
    expanded_topics = self._expand_topics_hierarchically(topic_hints)
    topic_hints.update(expanded_topics)
    
    # Step 5: Rank and filter
    ranked_topics = self._rank_topic_hints(topic_hints, cleaned_query)
    
    return ranked_topics[:5]  # Return top 5 most relevant
```

#### 2. **Explicit Topic Extraction**
```python
def _extract_explicit_topics(self, query: str) -> List[str]:
    """
    Extract topics that are explicitly mentioned in the query.
    
    Strategies:
    - Direct topic name matches
    - Topic aliases and synonyms
    - Quoted topic names
    - Topic patterns (e.g., "about X", "related to Y")
    """
    
    # Get all available topics from hierarchy manager
    all_topics = list(self.hierarchy_manager.topic_to_hierarchy_map.keys())
    
    explicit_topics = []
    query_lower = query.lower()
    
    # Strategy 1: Direct topic name matches
    for topic in all_topics:
        topic_lower = topic.lower()
        
        # Exact match
        if topic_lower in query_lower:
            explicit_topics.append(topic)
            continue
            
        # Word boundary matches
        if re.search(r'\b' + re.escape(topic_lower) + r'\b', query_lower):
            explicit_topics.append(topic)
    
    # Strategy 2: Pattern-based extraction
    patterns = [
        r'about\s+([a-zA-Z\s]+)',
        r'related\s+to\s+([a-zA-Z\s]+)',
        r'topic\s+([a-zA-Z\s]+)',
        r'regarding\s+([a-zA-Z\s]+)',
        r'concerning\s+([a-zA-Z\s]+)'
    ]
    
    for pattern in patterns:
        matches = re.findall(pattern, query_lower)
        for match in matches:
            match_clean = match.strip()
            if match_clean in [t.lower() for t in all_topics]:
                explicit_topics.append(match_clean.title())
    
    return list(set(explicit_topics))
```

#### 3. **Implicit Topic Extraction**
```python
def _extract_implicit_topics(self, query: str) -> List[str]:
    """
    Extract topics implicitly through keyword matching and semantic analysis.
    
    Strategies:
    - Keyword-to-topic mapping
    - Semantic similarity to topic names
    - Context-based topic inference
    """
    
    implicit_topics = []
    query_words = query.lower().split()
    
    # Strategy 1: Keyword-to-topic mapping
    keyword_mappings = {
        'api': ['api', 'apis', 'rest', 'graphql', 'endpoints'],
        'database': ['database', 'db', 'sql', 'nosql', 'storage'],
        'security': ['security', 'auth', 'authentication', 'authorization'],
        'performance': ['performance', 'optimization', 'speed', 'latency'],
        'testing': ['testing', 'test', 'qa', 'quality', 'validation'],
        'deployment': ['deployment', 'deploy', 'ci', 'cd', 'pipeline'],
        'monitoring': ['monitoring', 'logging', 'metrics', 'observability'],
        'architecture': ['architecture', 'design', 'pattern', 'structure']
    }
    
    for topic, keywords in keyword_mappings.items():
        if any(keyword in query_words for keyword in keywords):
            implicit_topics.append(topic)
    
    # Strategy 2: Semantic similarity to existing topics
    all_topics = list(self.hierarchy_manager.topic_to_hierarchy_map.keys())
    
    for topic in all_topics:
        topic_words = topic.lower().split()
        
        # Check for word overlap
        overlap = set(query_words) & set(topic_words)
        if len(overlap) > 0:
            implicit_topics.append(topic)
        
        # Check for partial matches
        for query_word in query_words:
            for topic_word in topic_words:
                if (len(query_word) > 3 and len(topic_word) > 3 and 
                    (query_word in topic_word or topic_word in query_word)):
                    implicit_topics.append(topic)
    
    return list(set(implicit_topics))
```

#### 4. **Hierarchical Topic Expansion**
```python
def _expand_topics_hierarchically(self, topics: List[str]) -> List[str]:
    """
    Expand topics using hierarchy relationships.
    
    For each identified topic:
    - Add parent topics (broader context)
    - Add child topics (more specific context)
    - Add related topics (sibling topics)
    """
    
    expanded_topics = set(topics)
    
    for topic in topics:
        try:
            # Get topic metadata from all hierarchies
            topic_metadata = get_topic_metadata_all_hierarchies(topic)
            
            if topic_metadata['exists']:
                # Add parent topics (broader context)
                expanded_topics.update(topic_metadata['all_parents_combined'])
                
                # Add child topics (more specific context)
                expanded_topics.update(topic_metadata['all_children_combined'])
                
                # Add related topics (sibling topics)
                expanded_topics.update(topic_metadata['all_related_topics_combined'])
                
        except Exception as e:
            logger.warning(f"Failed to expand topic '{topic}': {e}")
    
    return list(expanded_topics)
```

#### 5. **Topic Ranking and Filtering**
```python
def _rank_topic_hints(self, topics: List[str], query: str) -> List[str]:
    """
    Rank topic hints by relevance to the query.
    
    Ranking factors:
    - Exact match score
    - Word overlap score
    - Hierarchy depth (prefer specific topics)
    - Topic frequency in documents
    """
    
    query_words = set(query.lower().split())
    topic_scores = {}
    
    for topic in topics:
        score = 0
        topic_words = set(topic.lower().split())
        
        # Factor 1: Exact match bonus
        if topic.lower() in query.lower():
            score += 10
        
        # Factor 2: Word overlap score
        overlap = len(query_words & topic_words)
        score += overlap * 3
        
        # Factor 3: Hierarchy depth bonus (prefer specific topics)
        try:
            topic_metadata = get_topic_metadata_all_hierarchies(topic)
            if topic_metadata['exists']:
                # Deeper topics (more specific) get higher scores
                depth = len(topic_metadata['all_parents_combined'])
                score += depth * 0.5
        except:
            pass
        
        # Factor 4: Topic length penalty (prefer concise topics)
        if len(topic.split()) > 3:
            score -= 1
        
        topic_scores[topic] = score
    
    # Sort by score and return top topics
    ranked_topics = sorted(topic_scores.items(), key=lambda x: x[1], reverse=True)
    return [topic for topic, score in ranked_topics if score > 0]
```

#### 6. **Query Preprocessing**
```python
def _preprocess_query(self, query_text: str) -> str:
    """
    Clean and normalize query text for better topic extraction.
    """
    
    # Remove extra whitespace
    cleaned = re.sub(r'\s+', ' ', query_text.strip())
    
    # Remove common stop words that don't help with topic extraction
    stop_words = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by'}
    words = cleaned.split()
    filtered_words = [word for word in words if word.lower() not in stop_words]
    
    return ' '.join(filtered_words)
```

### Algorithm Benefits

1. **Multi-Strategy Approach**: Combines explicit mentions, implicit keywords, and semantic analysis
2. **Hierarchy-Aware**: Leverages your existing topic hierarchy for expansion
3. **Ranked Results**: Prioritizes most relevant topics for filtering
4. **Robust Error Handling**: Gracefully handles missing topics or hierarchy issues
5. **Configurable**: Easy to adjust ranking factors and thresholds

### Integration with Existing Code

- Uses `get_topic_metadata_all_hierarchies()` from your topic hierarchy parser
- Leverages `topic_to_hierarchy_map` for topic discovery
- Integrates with your existing `HybridRAGDocumentProcessor` infrastructure
- Returns topics compatible with your `topic_filter_tags` system

## UI Design Considerations

### Gradio Interface Components

1. **Search Tab**:
   - Query input field
   - Topic selection dropdown
   - Search parameters (top_k, filters)
   - Results display area
   - Source citations

2. **Conversation Tab**:
   - Chat interface
   - Context-aware responses
   - Conversation history
   - Export/import functionality

3. **Settings Tab**:
   - Search parameters configuration
   - Topic hierarchy visualization
   - System status and health checks

## Benefits of This Design

1. **Reuses Existing Infrastructure**: Leverages document processor, Pinecone manager, and topic hierarchy
2. **Modular Architecture**: Each component has clear responsibilities
3. **Scalable Design**: Easy to extend with additional search features
4. **User-Friendly Interface**: Gradio provides intuitive interaction
5. **Context-Aware Responses**: Claude integration for intelligent answers
6. **Two-Stage Efficiency**: Fast topic filtering + precise semantic search

## Evolution from Phase 1

### Key Differences from Phase 1:
1. **Added Topic Filtering**: Stage 1 topic-based filtering before semantic search
2. **Enhanced Query Processing**: Topic hint extraction and hierarchy expansion
3. **Advanced Search Engine**: Two-stage retrieval with result combination
4. **Topic-Aware UI**: Topic selection and filtering options
5. **Enhanced Data Models**: Support for topic-based results

### Migration Path:
1. Start with Phase 1 semantic search system
2. Add topic hint extraction capabilities
3. Implement Stage 1 topic filtering
4. Integrate two-stage search engine
5. Enhance UI with topic selection
6. Add advanced result ranking and combination

## Next Steps

1. Complete Phase 1 implementation
2. Add topic hint extraction to Phase 1
3. Implement Stage 1 topic filtering
4. Create two-stage search engine
5. Enhance UI with topic selection
6. Add advanced result ranking
7. Comprehensive testing and optimization
