#!/usr/bin/env python3
"""
Claude Client HTTP Layer

This module handles HTTP communication with Claude API using existing SSL infrastructure.
"""

import os
import json
import logging
from typing import Dict, List, Any, Optional
from dotenv import load_dotenv
from http_client_utils import get_environment_http_client

# Load environment variables
load_dotenv()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ClaudeClient:
    """
    Handles HTTP communication with Claude API using existing SSL infrastructure.
    
    This class manages all HTTP communication with the Claude API, including
    authentication, request formatting, and response parsing. It uses the
    existing SSL infrastructure from http_client_utils.
    """
    
    def __init__(self):
        """
        Initialize the Claude client.
        
        Loads configuration from environment variables:
        - ANTHROPIC_API_KEY: Your Anthropic API key
        - ANTHROPIC_MODEL: Claude model to use (default: claude-3-5-sonnet-20241022)
        - ANTHROPIC_BASE_URL: API base URL (default: https://api.anthropic.com)
        """
        # Load API key
        self.api_key = os.getenv("ANTHROPIC_API_KEY")
        if not self.api_key:
            raise ValueError("ANTHROPIC_API_KEY not found in environment variables")
        
        # Load model configuration
        self.default_model = os.getenv("ANTHROPIC_MODEL", "claude-3-5-sonnet-20241022")
        
        # Load base URL
        self.base_url = os.getenv("ANTHROPIC_BASE_URL", "https://api.anthropic.com")
        
        logger.info(f"ClaudeClient initialized with model: {self.default_model}")
    
    def _make_api_request(self, messages: List[Dict], model: str, max_tokens: int = 4000) -> Dict[str, Any]:
        """
        Make HTTP request to Claude API.
        
        Args:
            messages: List of message objects for the conversation
            model: Claude model to use
            max_tokens: Maximum tokens to generate
            
        Returns:
            Dict[str, Any]: Raw API response
            
        Raises:
            Exception: If API request fails
        """
        # Prepare request payload
        payload = {
            "model": model,
            "max_tokens": max_tokens,
            "messages": messages
        }
        
        # Prepare headers
        headers = {
            "x-api-key": self.api_key,
            "Content-Type": "application/json",
            "anthropic-version": "2023-06-01"
        }
        
        # Create HTTP client with SSL configuration
        client = get_environment_http_client()
        
        try:
            logger.debug(f"Making Claude API request to {self.base_url}/v1/messages")
            
            response = client.post(
                f"{self.base_url}/v1/messages",
                headers=headers,
                json=payload,
                timeout=60  # Claude can take longer to respond
            )
            
            # Check for HTTP errors
            response.raise_for_status()
            
            # Parse response
            response_data = response.json()
            
            logger.debug("Claude API request successful")
            return response_data
            
        except Exception as e:
            logger.error(f"Claude API request failed: {e}")
            raise Exception(f"Claude API request failed: {str(e)}")
        finally:
            client.close()
    
    def generate_completion(self, messages: List[Dict], model: str = None, max_tokens: int = 4000) -> Dict[str, Any]:
        """
        Main method for Claude API calls.
        
        Args:
            messages: List of message objects for the conversation
            model: Claude model to use (uses default if None)
            max_tokens: Maximum tokens to generate
            
        Returns:
            Dict[str, Any]: Parsed API response with content and metadata
            
        Raises:
            Exception: If API call fails
        """
        if model is None:
            model = self.default_model
        
        try:
            logger.info(f"Generating completion with model: {model}")
            
            # Make API request
            raw_response = self._make_api_request(messages, model, max_tokens)
            
            # Parse response
            parsed_response = self._parse_response(raw_response)
            
            logger.info("Completion generated successfully")
            return parsed_response
            
        except Exception as e:
            logger.error(f"Completion generation failed: {e}")
            raise Exception(f"Completion generation failed: {str(e)}")
    
    def _parse_response(self, raw_response: Dict[str, Any]) -> Dict[str, Any]:
        """
        Parse Claude API response into standardized format.
        
        Args:
            raw_response: Raw response from Claude API
            
        Returns:
            Dict[str, Any]: Parsed response with content and metadata
        """
        try:
            # Extract content from response
            content = ""
            if "content" in raw_response and raw_response["content"]:
                # Claude returns content as a list of text blocks
                content_blocks = raw_response["content"]
                if isinstance(content_blocks, list):
                    content = "".join([block.get("text", "") for block in content_blocks if block.get("type") == "text"])
                else:
                    content = str(content_blocks)
            
            # Extract metadata
            metadata = {
                "model": raw_response.get("model", "unknown"),
                "stop_reason": raw_response.get("stop_reason", "unknown"),
                "usage": raw_response.get("usage", {}),
                "id": raw_response.get("id", ""),
                "type": raw_response.get("type", "message")
            }
            
            parsed_response = {
                "content": content,
                "metadata": metadata,
                "raw_response": raw_response
            }
            
            return parsed_response
            
        except Exception as e:
            logger.error(f"Failed to parse Claude response: {e}")
            # Return raw response if parsing fails
            return {
                "content": str(raw_response),
                "metadata": {"error": "parsing_failed"},
                "raw_response": raw_response
            }
    
    def get_available_models(self) -> List[str]:
        """
        Retrieve list of available Claude models.
        
        Returns:
            List[str]: List of available model names
        """
        # Claude models are typically fixed, but this could be extended
        # to make an API call to get available models
        available_models = [
            "claude-3-5-sonnet-20241022",
            "claude-3-5-sonnet-20240620", 
            "claude-3-opus-20240229",
            "claude-3-sonnet-20240229",
            "claude-3-haiku-20240307"
        ]
        
        logger.debug(f"Available models: {available_models}")
        return available_models
    
    def test_connection(self) -> bool:
        """
        Test connection to Claude API.
        
        Returns:
            bool: True if connection successful, False otherwise
        """
        try:
            # Simple test message
            test_messages = [
                {
                    "role": "user",
                    "content": "Hello, this is a connection test. Please respond with 'Connection successful'."
                }
            ]
            
            response = self.generate_completion(test_messages, max_tokens=50)
            
            if response.get("content"):
                logger.info("Claude API connection test successful")
                return True
            else:
                logger.warning("Claude API connection test failed: no content in response")
                return False
                
        except Exception as e:
            logger.error(f"Claude API connection test failed: {e}")
            return False


# Example usage and testing
def main():
    """Demonstrate Claude client functionality."""
    print("=== Claude Client Demo ===\n")
    
    try:
        # Initialize Claude client
        print("🔄 Initializing ClaudeClient...")
        client = ClaudeClient()
        
        # Test connection
        print("🔗 Testing connection...")
        if client.test_connection():
            print("✅ Connection test successful!")
        else:
            print("❌ Connection test failed!")
            return
        
        # Get available models
        models = client.get_available_models()
        print(f"\n📋 Available models: {models}")
        
        # Test completion generation
        print("\n💬 Testing completion generation...")
        test_messages = [
            {
                "role": "user", 
                "content": "What is the capital of France? Please keep your answer brief."
            }
        ]
        
        response = client.generate_completion(test_messages, max_tokens=100)
        
        print(f"\n📄 Response:")
        print(f"   Content: {response['content']}")
        print(f"   Model: {response['metadata']['model']}")
        print(f"   Stop reason: {response['metadata']['stop_reason']}")
        
        if 'usage' in response['metadata']:
            usage = response['metadata']['usage']
            print(f"   Tokens used: {usage.get('input_tokens', 0)} input, {usage.get('output_tokens', 0)} output")
        
        print(f"\n✅ ClaudeClient demo completed!")
        print(f"   🔑 API key configured")
        print(f"   🌐 SSL integration enabled")
        print(f"   🤖 Ready for answer generation")
        
    except ValueError as e:
        print(f"❌ Configuration error: {e}")
        print("\n💡 Make sure to set the required environment variables:")
        print("   ANTHROPIC_API_KEY=your_api_key_here")
        print("   Optional:")
        print("   ANTHROPIC_MODEL=claude-3-5-sonnet-20241022")
        print("   ANTHROPIC_BASE_URL=https://api.anthropic.com")
    except Exception as e:
        print(f"❌ Demo failed: {e}")


if __name__ == "__main__":
    main()