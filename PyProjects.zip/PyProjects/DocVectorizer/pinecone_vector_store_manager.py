# Import SSL workaround from core HTTP client
from pinecone_http_client import PineconeHTTPClient, PineconeHTTPIndex

import os
import logging
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import asdict
import json
from datetime import datetime

# LangChain imports
try:
    from langchain_pinecone import PineconeVectorStore
    from langchain.schema import Document
    LANGCHAIN_AVAILABLE = True
except ImportError:
    LANGCHAIN_AVAILABLE = False

# Pinecone imports
try:
    from pinecone import Pinecone, ServerlessSpec
    PINECONE_AVAILABLE = True
except ImportError:
    PINECONE_AVAILABLE = False

# Import document chunking vectorizer
from document_chunking_vectorizer import VectorizedChunk, DocumentVectorization

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class PineconeVectorStoreManager:
    """
    Manages Pinecone vector storage for hybrid RAG system.
    
    Features:
    - Uses company SSL certificates via get_environment_http_client()
    - Stores complete enriched metadata with vectors
    - Supports batch operations for efficiency
    - Uses LangChain for simplified operations
    - Handles index creation and management
    """
    
    def __init__(self):
        """
        Initialize Pinecone vector store manager.
        
        Required environment variables:
        - PINECONE_API_KEY: Your Pinecone API key
        - PINECONE_ENVIRONMENT: Pinecone environment (e.g., 'us-east-1-aws')
        - PINECONE_INDEX_NAME: Name of the index to use (default: 'company-rag-index')
        - PINECONE_DIMENSION: Vector dimension (default: 1536 for text-embedding-3-small)
        - PINECONE_METRIC: Distance metric (default: 'cosine')
        - PINECONE_CLOUD: Cloud provider (default: 'aws')
        - PINECONE_REGION: Cloud region (default: 'us-east-1')
        """
        if not PINECONE_AVAILABLE:
            raise ImportError("Pinecone package not installed. Run: pip install pinecone-client")
        
        if not LANGCHAIN_AVAILABLE:
            raise ImportError("LangChain Pinecone package not installed. Run: pip install langchain-pinecone")
        
        # Load configuration from environment
        self.api_key = self._get_env_var("PINECONE_API_KEY")
        self.environment = self._get_env_var("PINECONE_ENVIRONMENT") 
        self.index_name = os.getenv("PINECONE_INDEX_NAME", "engineering-rag-index")
        self.dimension = int(os.getenv("PINECONE_DIMENSION", "1536"))  # text-embedding-3-small
        self.metric = os.getenv("PINECONE_METRIC", "cosine")
        self.cloud = os.getenv("PINECONE_CLOUD", "aws")
        self.region = os.getenv("PINECONE_REGION", "us-east-1")
        
        # Batch configuration
        self.batch_size = int(os.getenv("PINECONE_BATCH_SIZE", "100"))
        
        # Initialize HTTP client
        self.http_client = PineconeHTTPClient(self.api_key)
        self.vector_store = None
        
        # Ensure index exists
        self._ensure_index_exists()
        
        logger.info(f"PineconeVectorStoreManager initialized: "
                   f"index='{self.index_name}', dimension={self.dimension}, "
                   f"environment='{self.environment}'")
    
    

    def _get_env_var(self, var_name: str) -> str:
        """Get required environment variable."""
        value = os.getenv(var_name)
        if not value:
            raise ValueError(f"Required environment variable {var_name} is not set")
        return value
    
    def _create_serverless_spec(self):
        """Create ServerlessSpec-like object for HTTP client."""
        class ServerlessSpec:
            def __init__(self, cloud, region):
                self.cloud = cloud
                self.region = region
        
        return ServerlessSpec(cloud=self.cloud, region=self.region)
    
    
    
    def _ensure_index_exists(self):
        """Ensure the Pinecone index exists, create if it doesn't."""
        try:
            # Check if index exists
            existing_indexes = [index.name for index in self.http_client.list_indexes()]
            
            if self.index_name not in existing_indexes:
                logger.info(f"Creating Pinecone index: {self.index_name}")
                
                # Create ServerlessSpec-like object for HTTP client
                spec = self._create_serverless_spec()
                
                # Create index with serverless configuration using HTTP client
                self.http_client.create_index(
                    name=self.index_name,
                    dimension=self.dimension,
                    metric=self.metric,
                    spec=spec
                )
                
                logger.info(f"✅ Index '{self.index_name}' created successfully")
            else:
                logger.info(f"✅ Index '{self.index_name}' already exists")
                
        except Exception as e:
            logger.error(f"Failed to ensure index exists: {e}")
            raise
    
    def get_index_stats(self) -> Dict[str, Any]:
        """Get statistics about the Pinecone index."""
        try:
            index = self.http_client.get_index(self.index_name)
            stats = index.describe_index_stats()
            
            # Calculate total vectors from namespaces
            total_vectors = 0
            namespaces = stats.get('namespaces', {})
            for namespace_data in namespaces.values():
                if isinstance(namespace_data, dict):
                    total_vectors += namespace_data.get('vectorCount', 0)
                else:
                    total_vectors += namespace_data
            
            return {
                "index_name": self.index_name,
                "total_vectors": total_vectors,
                "index_fullness": stats.get('indexFullness', 0),
                "namespaces": namespaces
            }
            
        except Exception as e:
            logger.error(f"Failed to get index stats: {e}")
            return {"error": str(e)}
    



    
    
    def store_document_vectors(self, vectorization_result: DocumentVectorization) -> Dict[str, Any]:
        """
        Store all vectors from a document vectorization result in Pinecone.
        
        Args:
            vectorization_result: Complete vectorization result from DocumentChunkingAndVectorization
            
        Returns:
            Dictionary with storage statistics and results
        """
        if not vectorization_result.chunks:
            logger.warning("No chunks to store in vectorization result")
            return {"success": False, "reason": "No chunks to store"}
        
        logger.info(f"Storing {len(vectorization_result.chunks)} chunks in Pinecone for document: "
                   f"{vectorization_result.document_path}")
        
        try:
            # Convert chunks to LangChain documents
            documents = []
            vectors = []
            metadatas = []
            ids = []
            
            for vectorized_chunk in vectorization_result.chunks:
                # Create rich metadata from chunk and document info
                metadata = self._create_chunk_metadata(vectorized_chunk, vectorization_result)
                
                # Create LangChain document
                doc = Document(
                    page_content=vectorized_chunk.chunk.content,
                    metadata=metadata
                )
                
                documents.append(doc)
                vectors.append(vectorized_chunk.embedding)
                metadatas.append(metadata)
                ids.append(vectorized_chunk.chunk.chunk_id)
            
            # Store in batches for efficiency
            storage_results = self._store_in_batches(documents, vectors, metadatas, ids)
            
            # Store document metadata embedding if available
            if vectorization_result.metadata_embedding:
                self._store_document_metadata_vector(vectorization_result)
            
            logger.info(f"Successfully stored {storage_results['chunks_stored']} chunks in Pinecone")
            
            return {
                "success": True,
                "document_path": vectorization_result.document_path,
                "chunks_stored": storage_results['chunks_stored'],
                "batches_processed": storage_results['batches_processed'],
                "metadata_stored": vectorization_result.metadata_embedding is not None,
                "storage_stats": storage_results
            }
            
        except Exception as e:
            logger.error(f"Failed to store document vectors: {e}")
            return {
                "success": False,
                "document_path": vectorization_result.document_path,
                "error": str(e)
            }
    
    def _create_chunk_metadata(self, vectorized_chunk: VectorizedChunk, 
                              vectorization_result: DocumentVectorization) -> Dict[str, Any]:
        """
        Create comprehensive metadata for a chunk to store in Pinecone.
        Includes all enriched metadata from the document processor.
        """
        chunk = vectorized_chunk.chunk
        
        # Start with chunk-specific metadata
        metadata = {
            # === Chunk Content ===
            "content": chunk.content,
            "page_content": chunk.content,  # LangChain compatibility
            
            # === Chunk-Specific Metadata ===
            "chunk_id": chunk.chunk_id,
            "topic": chunk.topic,
            "section_title": chunk.section_title,
            "section_type": chunk.section_type,
            "chunk_index": chunk.chunk_index,
            "start_position": chunk.start_position,
            "end_position": chunk.end_position,
            "char_count": chunk.char_count,
            "word_count": chunk.word_count,
            
            # === Document Metadata ===
            "document_path": vectorization_result.document_path,
            
            # === Processing Metadata ===
            "embedding_model": vectorized_chunk.embedding_model,
            "embedding_dimension": vectorized_chunk.dimension,
            "storage_timestamp": datetime.now().isoformat(),
        }
        
        # Add vectorization stats if available
        if vectorization_result.vectorization_stats:
            metadata["vectorization_stats"] = {
                "total_chunks": vectorization_result.vectorization_stats.get("total_chunks"),
                "avg_chunk_size": vectorization_result.vectorization_stats.get("avg_chunk_size"),
                "chunks_by_topic": vectorization_result.vectorization_stats.get("chunks_by_topic", {})
            }
        
        # Note: Document enriched metadata (title, primary_topic, parent_topics, etc.) 
        # will be added by the caller from HybridRAGDocument.metadata
        
        return metadata
    
    def _store_in_batches(self, documents: List[Document], vectors: List[List[float]], 
                         metadatas: List[Dict], ids: List[str]) -> Dict[str, Any]:
        """Store vectors in Pinecone using direct HTTP calls."""
        total_chunks = len(documents)
        logger.info(f"Storing {total_chunks} chunks in batches of {self.batch_size}")
        
        # Use direct HTTP calls since we have pre-computed vectors
        logger.info("Using direct HTTP calls for vector storage with pre-computed vectors")
        return self._store_via_http(vectors, metadatas, ids)
    
    def _store_via_http(self, vectors: List[List[float]], metadatas: List[Dict], ids: List[str]) -> Dict[str, Any]:
        """Store vectors using direct HTTP calls to Pinecone."""
        total_chunks = len(vectors)
        chunks_stored = 0
        batches_processed = 0
        failed_batches = 0
        
        try:
            # Get the index object for direct HTTP operations
            index = self.http_client.get_index(self.index_name)
            
            # Process in batches
            for i in range(0, total_chunks, self.batch_size):
                batch_end = min(i + self.batch_size, total_chunks)
                
                batch_vectors = vectors[i:batch_end]
                batch_metadata = metadatas[i:batch_end]
                batch_ids = ids[i:batch_end]
                
                try:
                    # Prepare vectors for upsert
                    upsert_data = []
                    for j, (vector, metadata, vector_id) in enumerate(zip(batch_vectors, batch_metadata, batch_ids)):
                        # Clean metadata - remove null values and ensure proper types
                        clean_metadata = self._clean_metadata_for_pinecone(metadata)
                        
                        upsert_data.append({
                            "id": vector_id,
                            "values": vector,
                            "metadata": clean_metadata
                        })
                    
                    # Upsert the batch
                    index.upsert(vectors=upsert_data)
                    
                    chunks_stored += len(batch_vectors)
                    batches_processed += 1
                    
                    logger.info(f"✅ Stored batch {batches_processed} via HTTP: {len(batch_vectors)} chunks")
                    
                except Exception as e:
                    failed_batches += 1
                    logger.error(f"❌ Failed to store HTTP batch {batches_processed + 1}: {e}")
                    continue
            
            success_rate = (batches_processed / ((total_chunks - 1) // self.batch_size + 1)) * 100 if total_chunks > 0 else 0
            
            logger.info(f"HTTP batch storage complete: {chunks_stored}/{total_chunks} chunks stored "
                       f"({batches_processed} successful, {failed_batches} failed batches)")
            
            return {
                "chunks_stored": chunks_stored,
                "batches_processed": batches_processed,
                "failed_batches": failed_batches,
                "batch_size": self.batch_size,
                "total_chunks": total_chunks,
                "success_rate": success_rate
            }
            
        except Exception as e:
            logger.error(f"Failed to store vectors via HTTP: {e}")
            return {
                "chunks_stored": 0,
                "batches_processed": 0,
                "failed_batches": 1,
                "batch_size": self.batch_size,
                "total_chunks": total_chunks,
                "success_rate": 0.0,
                "error": str(e)
            }
    
    def _clean_metadata_for_pinecone(self, metadata: Dict[str, Any]) -> Dict[str, Any]:
        """
        Clean metadata for Pinecone compatibility.
        
        Pinecone requires metadata values to be:
        - string, number, boolean, or list of strings
        - No null/None values
        
        Args:
            metadata: Original metadata dictionary
            
        Returns:
            Cleaned metadata dictionary
        """
        clean_metadata = {}
        
        for key, value in metadata.items():
            if value is None:
                # Skip null values
                continue
            elif isinstance(value, (str, int, float, bool)):
                # Direct supported types
                clean_metadata[key] = value
            elif isinstance(value, list):
                # Clean list - only keep strings and convert others
                clean_list = []
                for item in value:
                    if item is not None:
                        clean_list.append(str(item))
                if clean_list:  # Only add non-empty lists
                    clean_metadata[key] = clean_list
            elif isinstance(value, dict):
                # Convert dict to string representation
                clean_metadata[key] = str(value)
            else:
                # Convert other types to string
                clean_metadata[key] = str(value)
        
        return clean_metadata
    
    def _store_document_metadata_vector(self, vectorization_result: DocumentVectorization):
        """Store document-level metadata vector separately."""
        try:
            # Skip metadata vector storage for now since we're using direct HTTP calls
            # This would require implementing a separate upsert call for the metadata vector
            logger.debug("Skipping document metadata vector storage (not implemented for HTTP-only mode)")
            
        except Exception as e:
            logger.warning(f"Failed to store document metadata vector: {e}")
    
    def update_chunk_metadata(self, chunk_id: str, updated_metadata: Dict[str, Any]) -> bool:
        """
        Update metadata for a specific chunk in Pinecone.
        
        Args:
            chunk_id: ID of the chunk to update
            updated_metadata: New metadata to merge with existing
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Get HTTP index object for metadata updates
            index = self.http_client.get_index(self.index_name)
            
            # Note: HTTP-only index doesn't support metadata updates directly
            # This would require implementing update functionality in PineconeHTTPIndex
            logger.warning(f"Metadata update not supported in HTTP-only mode for chunk: {chunk_id}")
            return False
            
        except Exception as e:
            logger.error(f"Failed to update metadata for chunk {chunk_id}: {e}")
            return False
    
    def delete_document_vectors(self, document_path: str) -> Dict[str, Any]:
        """
        Delete all vectors associated with a document.
        
        Args:
            document_path: Path of the document to remove
            
        Returns:
            Dictionary with deletion results
        """
        try:
            # Get HTTP index for deletion operations
            index = self.http_client.get_index(self.index_name)
            
            # Note: HTTP-only index doesn't support delete by filter directly
            # This would require implementing delete functionality in PineconeHTTPIndex
            logger.warning(f"Document deletion not supported in HTTP-only mode for: {document_path}")
            
            return {
                "success": False,
                "document_path": document_path,
                "error": "Delete by filter not supported in HTTP-only mode"
            }
            
        except Exception as e:
            logger.error(f"Failed to delete vectors for document {document_path}: {e}")
            return {
                "success": False,
                "document_path": document_path,
                "error": str(e)
            }
    
    def search_vectors(self, query_vector: List[float], 
                      filter_metadata: Optional[Dict[str, Any]] = None,
                      top_k: int = 10) -> List[Dict[str, Any]]:
        """
        Search for similar vectors in Pinecone using direct HTTP calls.
        
        Args:
            query_vector: Query vector for similarity search
            filter_metadata: Optional metadata filters
            top_k: Number of results to return
            
        Returns:
            List of matching documents with scores and metadata
        """
        try:
            # Use direct HTTP calls
            index = self.http_client.get_index(self.index_name)
            
            # Use the HTTP client's query method
            results = index.query(
                vector=query_vector,
                top_k=top_k,
                include_metadata=True,
                include_values=False,
                filter=filter_metadata
            )
            
            # Format results
            formatted_results = []
            if 'matches' in results:
                for match in results['matches']:
                    formatted_results.append({
                        "id": match.get('id'),
                        "score": match.get('score', 0.0),
                        "metadata": match.get('metadata', {})
                    })
            
            logger.debug(f"Found {len(formatted_results)} similar vectors via HTTP")
            return formatted_results
            
        except Exception as e:
            logger.error(f"Failed to search vectors: {e}")
            return []
    
    def get_index_stats(self) -> Dict[str, Any]:
        """Get statistics about the Pinecone index."""
        try:
            index = self.http_client.get_index(self.index_name)
            stats = index.describe_index_stats()
            
            # Calculate total vectors from namespaces
            total_vectors = 0
            namespaces = stats.get('namespaces', {})
            for namespace_data in namespaces.values():
                if isinstance(namespace_data, dict):
                    total_vectors += namespace_data.get('vectorCount', 0)
                else:
                    total_vectors += namespace_data
            
            return {
                "index_name": self.index_name,
                "total_vectors": total_vectors,
                "index_fullness": stats.get('indexFullness', 0),
                "namespaces": namespaces
            }
            
        except Exception as e:
            logger.error(f"Failed to get index stats: {e}")
            return {"error": str(e)}


# Example usage and testing
def main():
    """Demonstrate Pinecone vector store integration."""
    print("=== Pinecone Vector Store Integration Demo ===\n")
    
    try:
        # Initialize Pinecone manager
        print("🔄 Initializing Pinecone vector store manager...")
        pinecone_manager = PineconeVectorStoreManager()
        
        # Get index statistics
        stats = pinecone_manager.get_index_stats()
        print("\n📊 Pinecone Index Statistics:")
        print(f"   📂 Index: {stats.get('index_name')}")
        print(f"   📐 Dimension: {stats.get('dimension')}")
        print(f"   📊 Total vectors: {stats.get('total_vectors', 0)}")
        print(f"   📈 Index fullness: {stats.get('index_fullness', 0):.2%}")
        
        # Note: For full demo, you would need a DocumentVectorization result
        print("\n✅ Pinecone integration ready!")
        print("   🔑 API key configured")
        print("   🏠 Index created/verified")
        print("   🔒 Company SSL integration enabled")
        print("   📦 LangChain integration active")
        
        print(f"\n🎯 Ready to store vectors from HybridRAGDocumentProcessor!")
        
    except Exception as e:
        print(f"❌ Demo failed: {e}")
        print("\nRequired environment variables:")
        print("   PINECONE_API_KEY=your_pinecone_api_key")
        print("   PINECONE_ENVIRONMENT=your_pinecone_environment")
        print("   Optional:")
        print("   PINECONE_INDEX_NAME=engineering-rag-index")
        print("   PINECONE_DIMENSION=1536")
        print("   PINECONE_METRIC=cosine")
        

if __name__ == "__main__":
    main()