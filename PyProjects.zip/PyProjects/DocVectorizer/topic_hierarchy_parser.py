import json
import os
from typing import Dict, List, Set, Optional, Union
from pathlib import Path
import threading
from functools import lru_cache

class SingletonMeta(type):
    """
    Thread-safe Singleton metaclass to ensure only one instance exists.
    """
    _instances = {}
    _lock: threading.Lock = threading.Lock()
    
    def __call__(cls, *args, **kwargs):
        with cls._lock:
            if cls not in cls._instances:
                instance = super().__call__(*args, **kwargs)
                cls._instances[cls] = instance
        return cls._instances[cls]


class TopicHierarchyManager(metaclass=SingletonMeta):
    """
    Singleton manager for topic hierarchies that loads once and persists throughout application lifecycle.
    Automatically loads all JSON files from directory specified in .env file.
    """
    
    def __init__(self):
        """Initialize the manager only once (Singleton pattern)."""
        if hasattr(self, '_initialized'):
            return
        
        self._initialized = True
        self.hierarchies = {}
        self.child_to_parent_mappings = {}
        self.topic_to_hierarchy_map = {}  # topic -> list of hierarchies
        self._load_lock = threading.Lock()
        
        # Load hierarchies from .env configuration
        self._load_hierarchies_from_env()
    
    def _load_hierarchies_from_env(self):
        """Load all hierarchies from directory specified in .env file."""
        try:
            from dotenv import load_dotenv
            load_dotenv()
            
            # Get hierarchy directory from .env file
            hierarchy_dir = os.getenv('TOPIC_HIERARCHY_DIRECTORY')
            if not hierarchy_dir:
                print("Warning: TOPIC_HIERARCHY_DIRECTORY not found in .env file")
                return
            
            directory = Path(hierarchy_dir)
            if not directory.exists():
                print(f"Warning: Hierarchy directory not found: {hierarchy_dir}")
                return
            
            print(f"Loading topic hierarchies from: {hierarchy_dir}")
            
            # Load all JSON files from the directory
            json_files = list(directory.glob("*.json"))
            if not json_files:
                print(f"Warning: No JSON files found in {hierarchy_dir}")
                return
            
            for json_file in json_files:
                hierarchy_name = json_file.stem  # filename without extension
                try:
                    with open(json_file, 'r', encoding='utf-8') as f:
                        hierarchy_data = json.load(f)
                    
                    self._add_hierarchy(hierarchy_name, hierarchy_data)
                    print(f"✓ Loaded hierarchy: {hierarchy_name}")
                    
                except (json.JSONDecodeError, FileNotFoundError) as e:
                    print(f"✗ Failed to load {json_file}: {e}")
            
            print(f"Successfully loaded {len(self.hierarchies)} hierarchies")
            
        except ImportError:
            print("Warning: python-dotenv not installed. Install with: pip install python-dotenv")
        except Exception as e:
            print(f"Error loading hierarchies: {e}")
    
    def _add_hierarchy(self, hierarchy_name: str, hierarchy_data: Dict):
        """Add a hierarchy and build its mappings."""
        self.hierarchies[hierarchy_name] = hierarchy_data
        self._build_mappings_for_hierarchy(hierarchy_name, hierarchy_data)
    
    def _build_mappings_for_hierarchy(self, hierarchy_name: str, hierarchy_data: Dict):
        """Build reverse mapping for a specific hierarchy."""
        child_to_parent = {}
        
        for parent, children in hierarchy_data.items():
            # Map topic to hierarchy (support multiple hierarchies per topic)
            if parent not in self.topic_to_hierarchy_map:
                self.topic_to_hierarchy_map[parent] = []
            if hierarchy_name not in self.topic_to_hierarchy_map[parent]:
                self.topic_to_hierarchy_map[parent].append(hierarchy_name)
            
            if isinstance(children, list):
                for child in children:
                    child_to_parent[child] = parent
                    
                    # Map child to hierarchy (support multiple hierarchies per topic)
                    if child not in self.topic_to_hierarchy_map:
                        self.topic_to_hierarchy_map[child] = []
                    if hierarchy_name not in self.topic_to_hierarchy_map[child]:
                        self.topic_to_hierarchy_map[child].append(hierarchy_name)
        
        self.child_to_parent_mappings[hierarchy_name] = child_to_parent
    
    def reload_hierarchies(self):
        """
        Reload all hierarchies from the directory.
        Useful if hierarchy files are updated during runtime.
        """
        with self._load_lock:
            print("Reloading topic hierarchies...")
            self.hierarchies.clear()
            self.child_to_parent_mappings.clear()
            self.topic_to_hierarchy_map.clear()
            self._load_hierarchies_from_env()
    
    def add_hierarchy_runtime(self, hierarchy_name: str, hierarchy_data: Dict, overwrite: bool = False):
        """
        Add a hierarchy at runtime (useful for testing or dynamic hierarchies).
        """
        with self._load_lock:
            if hierarchy_name in self.hierarchies and not overwrite:
                raise ValueError(f"Hierarchy '{hierarchy_name}' already exists. Use overwrite=True to replace.")
            
            self._add_hierarchy(hierarchy_name, hierarchy_data)
            print(f"Added hierarchy at runtime: {hierarchy_name}")
    
    def find_topic_hierarchy(self, topic: str) -> Optional[List[str]]:
        """Find which hierarchies contain the given topic. Returns list of hierarchy names."""
        return self.topic_to_hierarchy_map.get(topic, [])
    
    def get_all_parents(self, topic: str, hierarchy_name: Optional[str] = None) -> List[str]:
        """Get all parents of a topic."""
        if hierarchy_name is None:
            # If topic exists in multiple hierarchies, get parents from all
            hierarchies = self.find_topic_hierarchy(topic)
            if not hierarchies:
                return []
            
            # If multiple hierarchies, return parents from the first one by default
            # or you might want to return from all - see get_all_parents_multi_hierarchy
            hierarchy_name = hierarchies[0]
        
        if hierarchy_name not in self.child_to_parent_mappings:
            return []
        
        parents = []
        current_topic = topic
        child_to_parent = self.child_to_parent_mappings[hierarchy_name]
        
        while current_topic in child_to_parent:
            parent = child_to_parent[current_topic]
            parents.append(parent)
            current_topic = parent
        
        return parents
    
    def get_all_parents_multi_hierarchy(self, topic: str) -> Dict[str, List[str]]:
        """
        Get all parents from ALL hierarchies that contain this topic.
        Returns dict mapping hierarchy_name -> list of parents.
        """
        hierarchies = self.find_topic_hierarchy(topic)
        result = {}
        
        for hierarchy_name in hierarchies:
            parents = self.get_all_parents(topic, hierarchy_name)
            if parents:  # Only include if there are parents
                result[hierarchy_name] = parents
        
        return result
    
    def get_direct_children_multi_hierarchy(self, topic: str) -> Dict[str, List[str]]:
        """
        Get direct children from ALL hierarchies that contain this topic.
        Returns dict mapping hierarchy_name -> list of children.
        """
        hierarchies = self.find_topic_hierarchy(topic)
        result = {}
        
        for hierarchy_name in hierarchies:
            children = self.get_direct_children(topic, hierarchy_name)
            if children:  # Only include if there are children
                result[hierarchy_name] = children
        
        return result
    
    def get_topic_metadata_multi_hierarchy(self, topic: str) -> Dict:
        """
        Get comprehensive metadata for a topic across ALL hierarchies it belongs to.
        This is the recommended method for topics that exist in multiple hierarchies.
        """
        hierarchies = self.find_topic_hierarchy(topic)
        
        if not hierarchies:
            return {
                'topic': topic,
                'hierarchies': [],
                'exists': False,
                'hierarchy_data': {},
                'all_parents_combined': [],
                'all_children_combined': [],
                'all_related_topics_combined': [],
                'appears_in_multiple_hierarchies': False
            }
        
        hierarchy_data = {}
        all_parents = set()
        all_children = set()
        
        for hierarchy_name in hierarchies:
            parents = self.get_all_parents(topic, hierarchy_name)
            children = self.get_direct_children(topic, hierarchy_name)
            
            hierarchy_data[hierarchy_name] = {
                'parents': parents,
                'children': children,
                'hierarchy_path': parents[::-1] + [topic],
                'depth_level': len(parents)
            }
            
            all_parents.update(parents)
            all_children.update(children)
        
        return {
            'topic': topic,
            'hierarchies': hierarchies,
            'hierarchy_data': hierarchy_data,
            'all_parents_combined': list(all_parents),
            'all_children_combined': list(all_children),
            'all_related_topics_combined': list(all_parents | all_children),
            'exists': True,
            'appears_in_multiple_hierarchies': len(hierarchies) > 1
        }
    
    def get_direct_children(self, topic: str, hierarchy_name: Optional[str] = None) -> List[str]:
        """Get direct children of a topic."""
        if hierarchy_name is None:
            hierarchies = self.find_topic_hierarchy(topic)
            if not hierarchies:
                return []
            hierarchy_name = hierarchies[0]
        
        if hierarchy_name not in self.hierarchies:
            return []
        
        return self.hierarchies[hierarchy_name].get(topic, [])
    
    def get_topic_metadata(self, topic: str, hierarchy_name: Optional[str] = None) -> Dict:
        """
        Get comprehensive metadata for a topic from a specific hierarchy.
        For topics in multiple hierarchies, use get_topic_metadata_multi_hierarchy instead.
        """
        if hierarchy_name is None:
            hierarchies = self.find_topic_hierarchy(topic)
            if not hierarchies:
                return {
                    'topic': topic,
                    'hierarchy': None,
                    'parents': [],
                    'children': [],
                    'all_related_topics': [],
                    'hierarchy_path': [topic],
                    'depth_level': 0,
                    'exists': False
                }
            
            # If multiple hierarchies, use the first one and warn
            hierarchy_name = hierarchies[0]
            if len(hierarchies) > 1:
                print(f"Warning: Topic '{topic}' exists in multiple hierarchies {hierarchies}. Using '{hierarchy_name}'. Consider using get_topic_metadata_multi_hierarchy().")
        
        parents = self.get_all_parents(topic, hierarchy_name)
        children = self.get_direct_children(topic, hierarchy_name)
        
        return {
            'topic': topic,
            'hierarchy': hierarchy_name,
            'parents': parents,
            'children': children,
            'all_related_topics': list(set(parents + children)),
            'hierarchy_path': parents[::-1] + [topic],
            'depth_level': len(parents),
            'exists': True
        }
    
    @lru_cache(maxsize=1000)
    def get_topic_metadata_cached(self, topic: str, hierarchy_name: Optional[str] = None) -> tuple:
        """
        Cached version of get_topic_metadata for frequently accessed topics.
        Returns tuple instead of dict for hashability (LRU cache requirement).
        """
        metadata = self.get_topic_metadata(topic, hierarchy_name)
        return (
            metadata['topic'],
            metadata['hierarchy'],
            tuple(metadata['parents']),
            tuple(metadata['children']),
            tuple(metadata['all_related_topics']),
            tuple(metadata['hierarchy_path']),
            metadata['depth_level'],
            metadata['exists']
        )
    
    def get_cross_hierarchy_topics(self, topics: List[str]) -> Dict[str, any]:
        """Get metadata for multiple topics that may span different hierarchies."""
        results = {}
        hierarchy_groups = {}
        
        for topic in topics:
            metadata = self.get_topic_metadata(topic)
            results[topic] = metadata
            
            # Group by hierarchy for analysis
            hierarchy = metadata['hierarchy']
            if hierarchy:
                if hierarchy not in hierarchy_groups:
                    hierarchy_groups[hierarchy] = []
                hierarchy_groups[hierarchy].append(topic)
        
        # Collect all related topics across hierarchies
        all_related_topics = set()
        for metadata in results.values():
            all_related_topics.update(metadata['all_related_topics'])
            all_related_topics.add(metadata['topic'])
        
        return {
            'individual_topics': results,
            'hierarchy_groups': hierarchy_groups,
            'all_related_topics': list(all_related_topics),
            'hierarchies_involved': list(hierarchy_groups.keys())
        }
    
    def list_hierarchies(self) -> List[str]:
        """List all available hierarchy names."""
        return list(self.hierarchies.keys())
    
    def get_hierarchy_stats(self) -> Dict:
        """Get statistics about all hierarchies."""
        stats = {}
        
        for hierarchy_name, hierarchy_data in self.hierarchies.items():
            all_topics = set(hierarchy_data.keys())
            for children in hierarchy_data.values():
                if isinstance(children, list):
                    all_topics.update(children)
            
            child_to_parent = self.child_to_parent_mappings.get(hierarchy_name, {})
            root_topics = set(hierarchy_data.keys()) - set(child_to_parent.keys())
            leaf_topics = all_topics - set(hierarchy_data.keys())
            
            stats[hierarchy_name] = {
                'total_topics': len(all_topics),
                'parent_topics': len(hierarchy_data.keys()),
                'root_topics': list(root_topics),
                'leaf_topics': list(leaf_topics),
                'max_depth': self._calculate_max_depth(hierarchy_name)
            }
        
        return stats
    
    def _calculate_max_depth(self, hierarchy_name: str) -> int:
        """Calculate the maximum depth of a hierarchy."""
        if hierarchy_name not in self.child_to_parent_mappings:
            return 0
        
        child_to_parent = self.child_to_parent_mappings[hierarchy_name]
        max_depth = 0
        
        for topic in self.topic_to_hierarchy_map:
            if hierarchy_name in self.topic_to_hierarchy_map[topic]:
                depth = len(self.get_all_parents(topic, hierarchy_name))
                max_depth = max(max_depth, depth)
        
        return max_depth
    
    def clear_cache(self):
        """Clear the LRU cache for metadata lookups."""
        self.get_topic_metadata_cached.cache_clear()
    
    def get_cache_stats(self) -> Dict:
        """Get statistics about the metadata cache."""
        cache_info = self.get_topic_metadata_cached.cache_info()
        return {
            'hits': cache_info.hits,
            'misses': cache_info.misses,
            'maxsize': cache_info.maxsize,
            'currsize': cache_info.currsize,
            'hit_rate': cache_info.hits / (cache_info.hits + cache_info.misses) if (cache_info.hits + cache_info.misses) > 0 else 0
        }


# Convenience functions for easy access (recommended usage pattern)
def get_topic_hierarchy_manager() -> TopicHierarchyManager:
    """
    Get the singleton instance of TopicHierarchyManager.
    This is the recommended way to access the hierarchy manager.
    """
    return TopicHierarchyManager()


def get_topic_metadata(topic: str) -> Dict:
    """Convenience function to get topic metadata. Uses single hierarchy by default."""
    manager = get_topic_hierarchy_manager()
    return manager.get_topic_metadata(topic)


def get_topic_metadata_all_hierarchies(topic: str) -> Dict:
    """Convenience function to get topic metadata from ALL hierarchies it belongs to."""
    manager = get_topic_hierarchy_manager()
    return manager.get_topic_metadata_multi_hierarchy(topic)


def get_enriched_topics(topics: List[str], include_multi_hierarchy: bool = True) -> List[str]:
    """
    Convenience function to get all related topics for RAG enrichment.
    
    Args:
        topics: List of original topics
        include_multi_hierarchy: If True, gets related topics from all hierarchies
                               If False, uses only first hierarchy for multi-hierarchy topics
    """
    manager = get_topic_hierarchy_manager()
    
    if include_multi_hierarchy:
        # Get all related topics from all hierarchies
        all_related = set(topics)
        
        for topic in topics:
            metadata = manager.get_topic_metadata_multi_hierarchy(topic)
            if metadata['exists']:
                all_related.update(metadata['all_related_topics_combined'])
        
        return list(all_related)
    else:
        # Use the original cross-hierarchy method
        cross_analysis = manager.get_cross_hierarchy_topics(topics)
        return cross_analysis['all_related_topics']


def check_topic_conflicts() -> Dict[str, List[str]]:
    """
    Utility function to identify topics that exist in multiple hierarchies.
    Useful for debugging and data quality checks.
    """
    manager = get_topic_hierarchy_manager()
    conflicts = {}
    
    for topic, hierarchies in manager.topic_to_hierarchy_map.items():
        if len(hierarchies) > 1:
            conflicts[topic] = hierarchies
    
    return conflicts


# Backward compatibility wrapper
class TopicHierarchyParser:
    """
    Backward compatibility wrapper that uses the singleton manager.
    This maintains the original interface while using the optimized singleton approach.
    """
    
    def __init__(self, hierarchy_file_path: Optional[str] = None, hierarchy_dict: Optional[Dict] = None):
        """
        Initialize parser. Note: For production use, hierarchies should be loaded via .env configuration.
        This constructor is mainly for testing and backward compatibility.
        """
        self.manager = get_topic_hierarchy_manager()
        
        # For testing: add hierarchy at runtime if provided
        if hierarchy_file_path or hierarchy_dict:
            if hierarchy_file_path:
                with open(hierarchy_file_path, 'r', encoding='utf-8') as f:
                    hierarchy_dict = json.load(f)
            
            # Add as runtime hierarchy for testing
            self.manager.add_hierarchy_runtime("test_hierarchy", hierarchy_dict, overwrite=True)
    
    def get_all_parents(self, topic: str) -> List[str]:
        return self.manager.get_all_parents(topic)
    
    def get_direct_children(self, topic: str) -> List[str]:
        return self.manager.get_direct_children(topic)
    
    def get_topic_metadata(self, topic: str) -> Dict:
        return self.manager.get_topic_metadata(topic)
    
    def topic_exists(self, topic: str) -> bool:
        return len(self.manager.find_topic_hierarchy(topic)) > 0


# Example usage and configuration
def main():
    """
    Example usage showing multi-hierarchy support and conflict detection.
    """
    print("=== Multi-Hierarchy Topic Manager Demo ===")
    
    # Create test hierarchies with overlapping topics
    brand_hierarchy = {
        "Brands": ["LEX", "CRCOM"],
        "LEX": ["API", "SignUP"],  # "API" appears in both hierarchies
        "SignUP": ["CreateCustomerAPI"]
    }
    
    technical_hierarchy = {
        "Systems": ["API", "Database"],  # "API" appears here too
        "API": ["REST", "GraphQL"],
        "Database": ["MySQL", "MongoDB"]
    }
    
    # Add hierarchies to manager for testing
    manager = get_topic_hierarchy_manager()
    manager.add_hierarchy_runtime("brand", brand_hierarchy, overwrite=True)
    manager.add_hierarchy_runtime("technical", technical_hierarchy, overwrite=True)
    
    print(f"Loaded hierarchies: {manager.list_hierarchies()}")
    
    # Test topic that exists in multiple hierarchies
    topic = "API"
    print(f"\n=== Analysis for '{topic}' (exists in multiple hierarchies) ===")
    
    # Find which hierarchies contain the topic
    hierarchies = manager.find_topic_hierarchy(topic)
    print(f"'{topic}' exists in hierarchies: {hierarchies}")
    
    # Get metadata from single hierarchy (with warning)
    single_metadata = manager.get_topic_metadata(topic)
    print(f"\nSingle hierarchy metadata: {single_metadata['hierarchy']}")
    print(f"Parents: {single_metadata['parents']}")
    print(f"Children: {single_metadata['children']}")
    
    # Get metadata from ALL hierarchies
    multi_metadata = manager.get_topic_metadata_multi_hierarchy(topic)
    print(f"\n=== Multi-hierarchy metadata ===")
    print(f"Appears in multiple hierarchies: {multi_metadata['appears_in_multiple_hierarchies']}")
    print(f"Combined parents: {multi_metadata['all_parents_combined']}")
    print(f"Combined children: {multi_metadata['all_children_combined']}")
    print(f"All related topics: {multi_metadata['all_related_topics_combined']}")
    
    for hierarchy, data in multi_metadata['hierarchy_data'].items():
        print(f"\nIn '{hierarchy}' hierarchy:")
        print(f"  Path: {' -> '.join(data['hierarchy_path'])}")
        print(f"  Parents: {data['parents']}")
        print(f"  Children: {data['children']}")
    
    # Check for conflicts across all topics
    print(f"\n=== Topic Conflicts Check ===")
    conflicts = check_topic_conflicts()
    if conflicts:
        print("Topics existing in multiple hierarchies:")
        for topic, hierarchies in conflicts.items():
            print(f"  '{topic}': {hierarchies}")
    else:
        print("No topic conflicts found.")
    
    # Test enriched topics with multi-hierarchy support
    print(f"\n=== RAG Enrichment Comparison ===")
    document_topics = ["API", "SignUP"]
    
    # Method 1: Include all hierarchies
    enriched_multi = get_enriched_topics(document_topics, include_multi_hierarchy=True)
    print(f"Original topics: {document_topics}")
    print(f"Multi-hierarchy enriched: {enriched_multi}")
    
    # Method 2: Single hierarchy only
    enriched_single = get_enriched_topics(document_topics, include_multi_hierarchy=False)
    print(f"Single-hierarchy enriched: {enriched_single}")
    
    # Show the difference
    additional_topics = set(enriched_multi) - set(enriched_single)
    print(f"Additional topics from multi-hierarchy: {list(additional_topics)}")


if __name__ == "__main__":
    main()


if __name__ == "__main__":
    main()


# =====================================================
# Configuration Instructions
# =====================================================

# Add this to your .env file:
# TOPIC_HIERARCHY_DIRECTORY=./config/hierarchies

# Directory structure example:
# project/
# ├── .env
# ├── config/
# │   └── hierarchies/
# │       ├── brand_hierarchy.json
# │       ├── product_hierarchy.json
# │       └── technical_hierarchy.json
# └── main.py

# Usage in your RAG application:
# from topic_hierarchy_manager import get_topic_metadata, get_enriched_topics
# 
# # Get metadata for a single topic
# metadata = get_topic_metadata("APIscope")
# 
# # Get enriched topics for document
# document_topics = ["APIscope", "SignUP"]
# all_topics = get_enriched_topics(document_topics)import json
import os
from typing import Dict, List, Set, Optional, Union
from pathlib import Path
import threading
from functools import lru_cache

class SingletonMeta(type):
    """
    Thread-safe Singleton metaclass to ensure only one instance exists.
    """
    _instances = {}
    _lock: threading.Lock = threading.Lock()
    
    def __call__(cls, *args, **kwargs):
        with cls._lock:
            if cls not in cls._instances:
                instance = super().__call__(*args, **kwargs)
                cls._instances[cls] = instance
        return cls._instances[cls]


class TopicHierarchyManager(metaclass=SingletonMeta):
    """
    Singleton manager for topic hierarchies that loads once and persists throughout application lifecycle.
    Automatically loads all JSON files from directory specified in .env file.
    """
    
    def __init__(self):
        """Initialize the manager only once (Singleton pattern)."""
        if hasattr(self, '_initialized'):
            return
        
        self._initialized = True
        self.hierarchies = {}
        self.child_to_parent_mappings = {}
        self.topic_to_hierarchy_map = {}  # topic -> list of hierarchies
        self._load_lock = threading.Lock()
        
        # Load hierarchies from .env configuration
        self._load_hierarchies_from_env()
    
    def _load_hierarchies_from_env(self):
        """Load all hierarchies from directory specified in .env file."""
        try:
            from dotenv import load_dotenv
            load_dotenv()
            
            # Get hierarchy directory from .env file
            hierarchy_dir = os.getenv('TOPIC_HIERARCHY_DIRECTORY')
            if not hierarchy_dir:
                print("Warning: TOPIC_HIERARCHY_DIRECTORY not found in .env file")
                return
            
            directory = Path(hierarchy_dir)
            if not directory.exists():
                print(f"Warning: Hierarchy directory not found: {hierarchy_dir}")
                return
            
            print(f"Loading topic hierarchies from: {hierarchy_dir}")
            
            # Load all JSON files from the directory
            json_files = list(directory.glob("*.json"))
            if not json_files:
                print(f"Warning: No JSON files found in {hierarchy_dir}")
                return
            
            for json_file in json_files:
                hierarchy_name = json_file.stem  # filename without extension
                try:
                    with open(json_file, 'r', encoding='utf-8') as f:
                        hierarchy_data = json.load(f)
                    
                    self._add_hierarchy(hierarchy_name, hierarchy_data)
                    print(f"✓ Loaded hierarchy: {hierarchy_name}")
                    
                except (json.JSONDecodeError, FileNotFoundError) as e:
                    print(f"✗ Failed to load {json_file}: {e}")
            
            print(f"Successfully loaded {len(self.hierarchies)} hierarchies")
            
        except ImportError:
            print("Warning: python-dotenv not installed. Install with: pip install python-dotenv")
        except Exception as e:
            print(f"Error loading hierarchies: {e}")
    
    def _add_hierarchy(self, hierarchy_name: str, hierarchy_data: Dict):
        """Add a hierarchy and build its mappings."""
        self.hierarchies[hierarchy_name] = hierarchy_data
        self._build_mappings_for_hierarchy(hierarchy_name, hierarchy_data)
    
    def _build_mappings_for_hierarchy(self, hierarchy_name: str, hierarchy_data: Dict):
        """Build reverse mapping for a specific hierarchy."""
        child_to_parent = {}
        
        for parent, children in hierarchy_data.items():
            # Map topic to hierarchy (support multiple hierarchies per topic)
            if parent not in self.topic_to_hierarchy_map:
                self.topic_to_hierarchy_map[parent] = []
            if hierarchy_name not in self.topic_to_hierarchy_map[parent]:
                self.topic_to_hierarchy_map[parent].append(hierarchy_name)
            
            if isinstance(children, list):
                for child in children:
                    child_to_parent[child] = parent
                    
                    # Map child to hierarchy (support multiple hierarchies per topic)
                    if child not in self.topic_to_hierarchy_map:
                        self.topic_to_hierarchy_map[child] = []
                    if hierarchy_name not in self.topic_to_hierarchy_map[child]:
                        self.topic_to_hierarchy_map[child].append(hierarchy_name)
        
        self.child_to_parent_mappings[hierarchy_name] = child_to_parent
    
    def reload_hierarchies(self):
        """
        Reload all hierarchies from the directory.
        Useful if hierarchy files are updated during runtime.
        """
        with self._load_lock:
            print("Reloading topic hierarchies...")
            self.hierarchies.clear()
            self.child_to_parent_mappings.clear()
            self.topic_to_hierarchy_map.clear()
            self._load_hierarchies_from_env()
    
    def add_hierarchy_runtime(self, hierarchy_name: str, hierarchy_data: Dict, overwrite: bool = False):
        """
        Add a hierarchy at runtime (useful for testing or dynamic hierarchies).
        """
        with self._load_lock:
            if hierarchy_name in self.hierarchies and not overwrite:
                raise ValueError(f"Hierarchy '{hierarchy_name}' already exists. Use overwrite=True to replace.")
            
            self._add_hierarchy(hierarchy_name, hierarchy_data)
            print(f"Added hierarchy at runtime: {hierarchy_name}")
    
    def find_topic_hierarchy(self, topic: str) -> Optional[List[str]]:
        """Find which hierarchies contain the given topic. Returns list of hierarchy names."""
        return self.topic_to_hierarchy_map.get(topic, [])
    
    def get_all_parents(self, topic: str, hierarchy_name: Optional[str] = None) -> List[str]:
        """Get all parents of a topic."""
        if hierarchy_name is None:
            # If topic exists in multiple hierarchies, get parents from all
            hierarchies = self.find_topic_hierarchy(topic)
            if not hierarchies:
                return []
            
            # If multiple hierarchies, return parents from the first one by default
            # or you might want to return from all - see get_all_parents_multi_hierarchy
            hierarchy_name = hierarchies[0]
        
        if hierarchy_name not in self.child_to_parent_mappings:
            return []
        
        parents = []
        current_topic = topic
        child_to_parent = self.child_to_parent_mappings[hierarchy_name]
        
        while current_topic in child_to_parent:
            parent = child_to_parent[current_topic]
            parents.append(parent)
            current_topic = parent
        
        return parents
    
    def get_all_parents_multi_hierarchy(self, topic: str) -> Dict[str, List[str]]:
        """
        Get all parents from ALL hierarchies that contain this topic.
        Returns dict mapping hierarchy_name -> list of parents.
        """
        hierarchies = self.find_topic_hierarchy(topic)
        result = {}
        
        for hierarchy_name in hierarchies:
            parents = self.get_all_parents(topic, hierarchy_name)
            if parents:  # Only include if there are parents
                result[hierarchy_name] = parents
        
        return result
    
    def get_direct_children_multi_hierarchy(self, topic: str) -> Dict[str, List[str]]:
        """
        Get direct children from ALL hierarchies that contain this topic.
        Returns dict mapping hierarchy_name -> list of children.
        """
        hierarchies = self.find_topic_hierarchy(topic)
        result = {}
        
        for hierarchy_name in hierarchies:
            children = self.get_direct_children(topic, hierarchy_name)
            if children:  # Only include if there are children
                result[hierarchy_name] = children
        
        return result
    
    def get_topic_metadata_multi_hierarchy(self, topic: str) -> Dict:
        """
        Get comprehensive metadata for a topic across ALL hierarchies it belongs to.
        This is the recommended method for topics that exist in multiple hierarchies.
        """
        hierarchies = self.find_topic_hierarchy(topic)
        
        if not hierarchies:
            return {
                'topic': topic,
                'hierarchies': [],
                'exists': False,
                'hierarchy_data': {},
                'all_parents_combined': [],
                'all_children_combined': [],
                'all_related_topics_combined': [],
                'appears_in_multiple_hierarchies': False
            }
        
        hierarchy_data = {}
        all_parents = set()
        all_children = set()
        
        for hierarchy_name in hierarchies:
            parents = self.get_all_parents(topic, hierarchy_name)
            children = self.get_direct_children(topic, hierarchy_name)
            
            hierarchy_data[hierarchy_name] = {
                'parents': parents,
                'children': children,
                'hierarchy_path': parents[::-1] + [topic],
                'depth_level': len(parents)
            }
            
            all_parents.update(parents)
            all_children.update(children)
        
        return {
            'topic': topic,
            'hierarchies': hierarchies,
            'hierarchy_data': hierarchy_data,
            'all_parents_combined': list(all_parents),
            'all_children_combined': list(all_children),
            'all_related_topics_combined': list(all_parents | all_children),
            'exists': True,
            'appears_in_multiple_hierarchies': len(hierarchies) > 1
        }
    
    def get_direct_children(self, topic: str, hierarchy_name: Optional[str] = None) -> List[str]:
        """Get direct children of a topic."""
        if hierarchy_name is None:
            hierarchies = self.find_topic_hierarchy(topic)
            if not hierarchies:
                return []
            hierarchy_name = hierarchies[0]
        
        if hierarchy_name not in self.hierarchies:
            return []
        
        return self.hierarchies[hierarchy_name].get(topic, [])
    
    def get_topic_metadata(self, topic: str, hierarchy_name: Optional[str] = None) -> Dict:
        """
        Get comprehensive metadata for a topic from a specific hierarchy.
        For topics in multiple hierarchies, use get_topic_metadata_multi_hierarchy instead.
        """
        if hierarchy_name is None:
            hierarchies = self.find_topic_hierarchy(topic)
            if not hierarchies:
                return {
                    'topic': topic,
                    'hierarchy': None,
                    'parents': [],
                    'children': [],
                    'all_related_topics': [],
                    'hierarchy_path': [topic],
                    'depth_level': 0,
                    'exists': False
                }
            
            # If multiple hierarchies, use the first one and warn
            hierarchy_name = hierarchies[0]
            if len(hierarchies) > 1:
                print(f"Warning: Topic '{topic}' exists in multiple hierarchies {hierarchies}. Using '{hierarchy_name}'. Consider using get_topic_metadata_multi_hierarchy().")
        
        parents = self.get_all_parents(topic, hierarchy_name)
        children = self.get_direct_children(topic, hierarchy_name)
        
        return {
            'topic': topic,
            'hierarchy': hierarchy_name,
            'parents': parents,
            'children': children,
            'all_related_topics': list(set(parents + children)),
            'hierarchy_path': parents[::-1] + [topic],
            'depth_level': len(parents),
            'exists': True
        }
    
    @lru_cache(maxsize=1000)
    def get_topic_metadata_cached(self, topic: str, hierarchy_name: Optional[str] = None) -> tuple:
        """
        Cached version of get_topic_metadata for frequently accessed topics.
        Returns tuple instead of dict for hashability (LRU cache requirement).
        """
        metadata = self.get_topic_metadata(topic, hierarchy_name)
        return (
            metadata['topic'],
            metadata['hierarchy'],
            tuple(metadata['parents']),
            tuple(metadata['children']),
            tuple(metadata['all_related_topics']),
            tuple(metadata['hierarchy_path']),
            metadata['depth_level'],
            metadata['exists']
        )
    
    def get_cross_hierarchy_topics(self, topics: List[str]) -> Dict[str, any]:
        """Get metadata for multiple topics that may span different hierarchies."""
        results = {}
        hierarchy_groups = {}
        
        for topic in topics:
            metadata = self.get_topic_metadata(topic)
            results[topic] = metadata
            
            # Group by hierarchy for analysis
            hierarchy = metadata['hierarchy']
            if hierarchy:
                if hierarchy not in hierarchy_groups:
                    hierarchy_groups[hierarchy] = []
                hierarchy_groups[hierarchy].append(topic)
        
        # Collect all related topics across hierarchies
        all_related_topics = set()
        for metadata in results.values():
            all_related_topics.update(metadata['all_related_topics'])
            all_related_topics.add(metadata['topic'])
        
        return {
            'individual_topics': results,
            'hierarchy_groups': hierarchy_groups,
            'all_related_topics': list(all_related_topics),
            'hierarchies_involved': list(hierarchy_groups.keys())
        }
    
    def list_hierarchies(self) -> List[str]:
        """List all available hierarchy names."""
        return list(self.hierarchies.keys())
    
    def get_hierarchy_stats(self) -> Dict:
        """Get statistics about all hierarchies."""
        stats = {}
        
        for hierarchy_name, hierarchy_data in self.hierarchies.items():
            all_topics = set(hierarchy_data.keys())
            for children in hierarchy_data.values():
                if isinstance(children, list):
                    all_topics.update(children)
            
            child_to_parent = self.child_to_parent_mappings.get(hierarchy_name, {})
            root_topics = set(hierarchy_data.keys()) - set(child_to_parent.keys())
            leaf_topics = all_topics - set(hierarchy_data.keys())
            
            stats[hierarchy_name] = {
                'total_topics': len(all_topics),
                'parent_topics': len(hierarchy_data.keys()),
                'root_topics': list(root_topics),
                'leaf_topics': list(leaf_topics),
                'max_depth': self._calculate_max_depth(hierarchy_name)
            }
        
        return stats
    
    def _calculate_max_depth(self, hierarchy_name: str) -> int:
        """Calculate the maximum depth of a hierarchy."""
        if hierarchy_name not in self.child_to_parent_mappings:
            return 0
        
        child_to_parent = self.child_to_parent_mappings[hierarchy_name]
        max_depth = 0
        
        for topic in self.topic_to_hierarchy_map:
            if hierarchy_name in self.topic_to_hierarchy_map[topic]:
                depth = len(self.get_all_parents(topic, hierarchy_name))
                max_depth = max(max_depth, depth)
        
        return max_depth
    
    def clear_cache(self):
        """Clear the LRU cache for metadata lookups."""
        self.get_topic_metadata_cached.cache_clear()
    
    def get_cache_stats(self) -> Dict:
        """Get statistics about the metadata cache."""
        cache_info = self.get_topic_metadata_cached.cache_info()
        return {
            'hits': cache_info.hits,
            'misses': cache_info.misses,
            'maxsize': cache_info.maxsize,
            'currsize': cache_info.currsize,
            'hit_rate': cache_info.hits / (cache_info.hits + cache_info.misses) if (cache_info.hits + cache_info.misses) > 0 else 0
        }


# Convenience functions for easy access (recommended usage pattern)
def get_topic_hierarchy_manager() -> TopicHierarchyManager:
    """
    Get the singleton instance of TopicHierarchyManager.
    This is the recommended way to access the hierarchy manager.
    """
    return TopicHierarchyManager()


def get_topic_metadata(topic: str) -> Dict:
    """Convenience function to get topic metadata. Uses single hierarchy by default."""
    manager = get_topic_hierarchy_manager()
    return manager.get_topic_metadata(topic)


def get_topic_metadata_all_hierarchies(topic: str) -> Dict:
    """Convenience function to get topic metadata from ALL hierarchies it belongs to."""
    manager = get_topic_hierarchy_manager()
    return manager.get_topic_metadata_multi_hierarchy(topic)


def get_enriched_topics(topics: List[str], include_multi_hierarchy: bool = True) -> List[str]:
    """
    Convenience function to get all related topics for RAG enrichment.
    
    Args:
        topics: List of original topics
        include_multi_hierarchy: If True, gets related topics from all hierarchies
                               If False, uses only first hierarchy for multi-hierarchy topics
    """
    manager = get_topic_hierarchy_manager()
    
    if include_multi_hierarchy:
        # Get all related topics from all hierarchies
        all_related = set(topics)
        
        for topic in topics:
            metadata = manager.get_topic_metadata_multi_hierarchy(topic)
            if metadata['exists']:
                all_related.update(metadata['all_related_topics_combined'])
        
        return list(all_related)
    else:
        # Use the original cross-hierarchy method
        cross_analysis = manager.get_cross_hierarchy_topics(topics)
        return cross_analysis['all_related_topics']


def check_topic_conflicts() -> Dict[str, List[str]]:
    """
    Utility function to identify topics that exist in multiple hierarchies.
    Useful for debugging and data quality checks.
    """
    manager = get_topic_hierarchy_manager()
    conflicts = {}
    
    for topic, hierarchies in manager.topic_to_hierarchy_map.items():
        if len(hierarchies) > 1:
            conflicts[topic] = hierarchies
    
    return conflicts


# Backward compatibility wrapper
class TopicHierarchyParser:
    """
    Backward compatibility wrapper that uses the singleton manager.
    This maintains the original interface while using the optimized singleton approach.
    """
    
    def __init__(self, hierarchy_file_path: Optional[str] = None, hierarchy_dict: Optional[Dict] = None):
        """
        Initialize parser. Note: For production use, hierarchies should be loaded via .env configuration.
        This constructor is mainly for testing and backward compatibility.
        """
        self.manager = get_topic_hierarchy_manager()
        
        # For testing: add hierarchy at runtime if provided
        if hierarchy_file_path or hierarchy_dict:
            if hierarchy_file_path:
                with open(hierarchy_file_path, 'r', encoding='utf-8') as f:
                    hierarchy_dict = json.load(f)
            
            # Add as runtime hierarchy for testing
            self.manager.add_hierarchy_runtime("test_hierarchy", hierarchy_dict, overwrite=True)
    
    def get_all_parents(self, topic: str) -> List[str]:
        return self.manager.get_all_parents(topic)
    
    def get_direct_children(self, topic: str) -> List[str]:
        return self.manager.get_direct_children(topic)
    
    def get_topic_metadata(self, topic: str) -> Dict:
        return self.manager.get_topic_metadata(topic)
    
    def topic_exists(self, topic: str) -> bool:
        return len(self.manager.find_topic_hierarchy(topic)) > 0


# Example usage and configuration
def main():
    """
    Example usage showing multi-hierarchy support and conflict detection.
    """
    print("=== Multi-Hierarchy Topic Manager Demo ===")
    
    # Create test hierarchies with overlapping topics
    # brand_hierarchy = {
    #     "Brands": ["LEX", "CRCOM"],
    #     "LEX": ["API", "SignUP"],  # "API" appears in both hierarchies
    #     "SignUP": ["CreateCustomerAPI"]
    # }
    
    # technical_hierarchy = {
    #     "Systems": ["API", "Database"],  # "API" appears here too
    #     "API": ["REST", "GraphQL"],
    #     "Database": ["MySQL", "MongoDB"]
    # }
    
    # Add hierarchies to manager for testing
    manager = get_topic_hierarchy_manager()

    print(f"hierarchies: {manager.hierarchies}")
    print(f"\nchild_to_parent_mappings: {manager.child_to_parent_mappings}")
    print(f"\ntopic_to_hierarchy_map: {manager.topic_to_hierarchy_map}")    

    #manager.add_hierarchy_runtime("brand", brand_hierarchy, overwrite=True)
    #manager.add_hierarchy_runtime("technical", technical_hierarchy, overwrite=True)
    

    print(f"\nLoaded hierarchies: {manager.list_hierarchies()}")
    
    # Test topic that exists in multiple hierarchies
    topic = "API"
    print(f"\n=== Analysis for '{topic}' (exists in multiple hierarchies) ===")
    
    # Find which hierarchies contain the topic
    hierarchies = manager.find_topic_hierarchy(topic)
    print(f"'{topic}' exists in hierarchies: {hierarchies}")
    
    # Get metadata from single hierarchy (with warning)
    single_metadata = manager.get_topic_metadata(topic)
    print(f"\nSingle hierarchy metadata: {single_metadata['hierarchy']}")
    print(f"Parents: {single_metadata['parents']}")
    print(f"Children: {single_metadata['children']}")
    
    # Get metadata from ALL hierarchies
    multi_metadata = manager.get_topic_metadata_multi_hierarchy(topic)
    print(f"\n=== Multi-hierarchy metadata ===")
    print(f"Appears in multiple hierarchies: {multi_metadata['appears_in_multiple_hierarchies']}")
    print(f"Combined parents: {multi_metadata['all_parents_combined']}")
    print(f"Combined children: {multi_metadata['all_children_combined']}")
    print(f"All related topics: {multi_metadata['all_related_topics_combined']}")
    
    for hierarchy, data in multi_metadata['hierarchy_data'].items():
        print(f"\nIn '{hierarchy}' hierarchy:")
        print(f"  Path: {' -> '.join(data['hierarchy_path'])}")
        print(f"  Parents: {data['parents']}")
        print(f"  Children: {data['children']}")
    
    # Check for conflicts across all topics
    print(f"\n=== Topic Conflicts Check ===")
    conflicts = check_topic_conflicts()
    if conflicts:
        print("Topics existing in multiple hierarchies:")
        for topic, hierarchies in conflicts.items():
            print(f"  '{topic}': {hierarchies}")
    else:
        print("No topic conflicts found.")
    
    # Test enriched topics with multi-hierarchy support
    print(f"\n=== RAG Enrichment Comparison ===")
    document_topics = ["API", "SignUP"]
    
    # Method 1: Include all hierarchies
    enriched_multi = get_enriched_topics(document_topics, include_multi_hierarchy=True)
    print(f"Original topics: {document_topics}")
    print(f"Multi-hierarchy enriched: {enriched_multi}")
    
    # Method 2: Single hierarchy only
    enriched_single = get_enriched_topics(document_topics, include_multi_hierarchy=False)
    print(f"Single-hierarchy enriched: {enriched_single}")
    
    # Show the difference
    additional_topics = set(enriched_multi) - set(enriched_single)
    print(f"Additional topics from multi-hierarchy: {list(additional_topics)}")


if __name__ == "__main__":
    main()


# =====================================================
# Configuration Instructions
# =====================================================

# Add this to your .env file:
# TOPIC_HIERARCHY_DIRECTORY=./config/hierarchies

# Directory structure example:
# project/
# ├── .env
# ├── config/
# │   └── hierarchies/
# │       ├── brand_hierarchy.json
# │       ├── product_hierarchy.json
# │       └── technical_hierarchy.json
# └── main.py

# Usage in your RAG application:
# from topic_hierarchy_manager import get_topic_metadata, get_enriched_topics
# 
# # Get metadata for a single topic
# metadata = get_topic_metadata("APIscope")
# 
# # Get enriched topics for document
# document_topics = ["APIscope", "SignUP"]
# all_topics = get_enriched_topics(document_topics)