#!/usr/bin/env python3
"""
Simple launcher script for the Gradio Search Interface.

This script provides a simple way to launch the RAG search interface.
"""

import os
import sys
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def check_environment():
    """Check if required environment variables are set."""
    required_vars = [
        'PINECONE_API_KEY',
        'PINECONE_INDEX_NAME',
        'OPENAI_API_KEY',
        'ANTHROPIC_API_KEY'
    ]
    
    missing_vars = []
    for var in required_vars:
        if not os.getenv(var):
            missing_vars.append(var)
    
    if missing_vars:
        print("❌ Missing required environment variables:")
        for var in missing_vars:
            print(f"   - {var}")
        print("\nPlease set these variables in your .env file or environment.")
        return False
    
    return True

def main():
    """Launch the Gradio search interface."""
    print("🚀 RAG Search Interface Launcher")
    print("=" * 40)
    
    # Check environment
    if not check_environment():
        sys.exit(1)
    
    print("✅ Environment variables configured")
    
    try:
        # Import and launch the interface
        from gradio_search_interface import GradioSearchInterface
        
        print("🔄 Initializing RAG pipeline...")
        interface = GradioSearchInterface()
        
        print("✅ Interface ready!")
        print("\n🌐 Starting Gradio server...")
        print("   📱 Open your browser to: http://localhost:7860")
        print("   🛑 Press Ctrl+C to stop the server")
        print("=" * 40)
        
        # Launch the interface
        interface.launch(share=False, server_port=7860)
        
    except KeyboardInterrupt:
        print("\n👋 Server stopped by user")
    except ImportError as e:
        print(f"❌ Import error: {e}")
        print("Make sure all required packages are installed:")
        print("   pip install -r requirements.txt")
    except Exception as e:
        print(f"❌ Launch failed: {e}")
        print("\nTroubleshooting:")
        print("1. Check that all environment variables are set")
        print("2. Verify Pinecone index exists and is accessible")
        print("3. Ensure OpenAI and Anthropic API keys are valid")
        print("4. Check that all RAG components are properly configured")

if __name__ == "__main__":
    main()
