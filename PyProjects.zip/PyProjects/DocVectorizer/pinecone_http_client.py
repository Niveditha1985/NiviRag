# Apply SSL workaround FIRST, before any other imports
import os
import ssl
import urllib3
import warnings

# Disable all SSL warnings
urllib3.disable_warnings()
warnings.filterwarnings('ignore')

# Suppress LangChain pydantic deprecation warnings
warnings.filterwarnings('ignore', category=DeprecationWarning, module='langchain_pinecone')
warnings.filterwarnings('ignore', message='.*pydantic.*', category=DeprecationWarning)

# Set environment variables to disable SSL verification
os.environ['PYTHONHTTPSVERIFY'] = '0'
os.environ['CURL_CA_BUNDLE'] = ''
os.environ['REQUESTS_CA_BUNDLE'] = ''

# Create a custom SSL context that accepts everything
def create_permissive_ssl_context():
    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    # Lower security level to accept weak certificates
    context.set_ciphers('DEFAULT@SECLEVEL=1')
    return context

# Monkey patch the default SSL context globally
ssl._create_default_https_context = create_permissive_ssl_context

# Also patch urllib3 specifically
try:
    import urllib3.util.ssl_
    urllib3.util.ssl_.DEFAULT_CIPHERS = 'ALL:@SECLEVEL=0'
except:
    pass

# Patch HTTP libraries that Pinecone might use
try:
    import requests
    # Patch requests to disable SSL verification by default
    original_requests_get = requests.get
    original_requests_post = requests.post
    original_requests_session = requests.Session
    
    def patched_requests_get(*args, **kwargs):
        kwargs.setdefault('verify', False)
        return original_requests_get(*args, **kwargs)
    
    def patched_requests_post(*args, **kwargs):
        kwargs.setdefault('verify', False)
        return original_requests_post(*args, **kwargs)
    
    def patched_requests_session(*args, **kwargs):
        session = original_requests_session(*args, **kwargs)
        session.verify = False
        return session
    
    requests.get = patched_requests_get
    requests.post = patched_requests_post
    requests.Session = patched_requests_session
    print("🔧 requests library patched for SSL bypass")
except ImportError:
    pass

try:
    import httpx
    # Patch httpx to disable SSL verification by default
    original_httpx_client = httpx.Client
    
    def patched_httpx_client(*args, **kwargs):
        kwargs.setdefault('verify', False)
        return original_httpx_client(*args, **kwargs)
    
    httpx.Client = patched_httpx_client
    print("🔧 httpx library patched for SSL bypass")
except ImportError:
    pass

print("🔧 SSL configuration patched for corporate environment")

import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


@dataclass
class IndexInfo:
    """Information about a Pinecone index."""
    name: str
    dimension: int
    metric: str
    status: str


class PineconeHTTPClient:
    """
    Core HTTP-only Pinecone client for corporate environments.
    
    This class handles all direct HTTP communication with Pinecone's API,
    bypassing SSL certificate issues common in corporate environments.
    
    Features:
    - SSL verification disabled for corporate environments
    - Direct HTTP calls to Pinecone REST API
    - Mimics official Pinecone client interface
    - Handles index management operations
    """
    
    def __init__(self, api_key: str, base_url: str = "https://api.pinecone.io"):
        """
        Initialize HTTP-only Pinecone client.
        
        Args:
            api_key: Pinecone API key
            base_url: Pinecone API base URL (default: https://api.pinecone.io)
        """
        self.api_key = api_key
        self.base_url = base_url
        self.headers = {
            'Api-Key': api_key,
            'Content-Type': 'application/json'
        }
        
        logger.info(f"PineconeHTTPClient initialized for {base_url}")
    
    def test_connection(self) -> bool:
        """
        Test basic connectivity to Pinecone API.
        
        Returns:
            True if connection successful, False otherwise
        """
        try:
            import requests
            
            response = requests.get(
                f"{self.base_url}/indexes",
                headers=self.headers,
                verify=False,  # Disable SSL verification
                timeout=30
            )
            
            if response.status_code == 200:
                data = response.json()
                indexes = data.get('indexes', [])
                logger.info(f"Direct HTTP connection successful! Found {len(indexes)} indexes")
                return True
            else:
                logger.error(f"Direct HTTP connection failed with status: {response.status_code}")
                return False
                
        except Exception as e:
            logger.error(f"Direct HTTP connection test failed: {e}")
            raise
    
    def list_indexes(self) -> List[IndexInfo]:
        """
        List all indexes using direct HTTP calls.
        
        Returns:
            List of IndexInfo objects
        """
        try:
            import requests
            
            response = requests.get(
                f"{self.base_url}/indexes",
                headers=self.headers,
                verify=False,
                timeout=30
            )
            response.raise_for_status()
            data = response.json()
            
            # Convert to IndexInfo objects
            indexes = []
            for idx_data in data.get('indexes', []):
                index_info = IndexInfo(
                    name=idx_data.get('name'),
                    dimension=idx_data.get('dimension'),
                    metric=idx_data.get('metric'),
                    status=idx_data.get('status')
                )
                indexes.append(index_info)
            
            logger.debug(f"Listed {len(indexes)} indexes")
            return indexes
            
        except Exception as e:
            logger.error(f"Failed to list indexes: {e}")
            raise
    
    def create_index(self, name: str, dimension: int, metric: str, spec) -> Dict[str, Any]:
        """
        Create an index using direct HTTP calls.
        
        Args:
            name: Index name
            dimension: Vector dimension
            metric: Distance metric
            spec: ServerlessSpec-like object with cloud and region
            
        Returns:
            Dictionary with creation response
        """
        try:
            import requests
            
            payload = {
                'name': name,
                'dimension': dimension,
                'metric': metric,
                'spec': {
                    'serverless': {
                        'cloud': spec.cloud,
                        'region': spec.region
                    }
                }
            }
            
            response = requests.post(
                f"{self.base_url}/indexes",
                headers=self.headers,
                json=payload,
                verify=False,
                timeout=30
            )
            response.raise_for_status()
            
            logger.info(f"Successfully created index: {name}")
            return response.json()
            
        except Exception as e:
            logger.error(f"Failed to create index: {e}")
            raise
    
    def delete_index(self, name: str) -> Dict[str, Any]:
        """
        Delete an index using direct HTTP calls.
        
        Args:
            name: Index name to delete
            
        Returns:
            Dictionary with deletion response
        """
        try:
            import requests
            
            response = requests.delete(
                f"{self.base_url}/indexes/{name}",
                headers=self.headers,
                verify=False,
                timeout=30
            )
            response.raise_for_status()
            
            logger.info(f"Successfully deleted index: {name}")
            
            # Handle empty response body (common for DELETE operations)
            try:
                return response.json()
            except ValueError:
                # Empty response body - return success message
                return {"success": True, "message": f"Index '{name}' deleted successfully"}
            
        except Exception as e:
            logger.error(f"Failed to delete index: {e}")
            raise
    
    def get_index(self, index_name: str) -> 'PineconeHTTPIndex':
        """
        Get an index object for vector operations.
        
        Args:
            index_name: Name of the index
            
        Returns:
            PineconeHTTPIndex instance for vector operations
        """
        return PineconeHTTPIndex(self.api_key, index_name, self.base_url)


class PineconeHTTPIndex:
    """
    HTTP-only Index implementation for vector operations.
    
    This class handles vector operations (upsert, query, stats) for a specific index
    using direct HTTP calls to Pinecone's API.
    """
    
    def __init__(self, api_key: str, index_name: str, base_url: str = "https://api.pinecone.io"):
        """
        Initialize HTTP-only index.
        
        Args:
            api_key: Pinecone API key
            index_name: Name of the index
            base_url: Pinecone API base URL
        """
        self.api_key = api_key
        self.index_name = index_name
        self.base_url = base_url
        self.headers = {
            'Api-Key': api_key,
            'Content-Type': 'application/json'
        }
        
        logger.debug(f"PineconeHTTPIndex initialized for index: {index_name}")
    
    def upsert(self, vectors: List[Dict]) -> Dict[str, Any]:
        """
        Upsert vectors using the correct Pinecone API approach.
        
        The upsert endpoint requires the index's data plane URL, not the control plane.
        We need to first get the index description to get the host URL.
        
        Args:
            vectors: List of vector dictionaries with id, values, and metadata
            
        Returns:
            Dictionary with upsert response
        """
        try:
            import requests
            
            # First, get the index description to get the host URL
            index_desc_response = requests.get(
                f"{self.base_url}/indexes/{self.index_name}",
                headers=self.headers,
                verify=False,
                timeout=30
            )
            index_desc_response.raise_for_status()
            index_desc = index_desc_response.json()
            
            # Extract the host URL from the index description
            if 'host' not in index_desc:
                logger.error(f"No host URL found in index description for {self.index_name}")
                raise ValueError(f"No host URL found in index description for {self.index_name}")
            
            host_url = index_desc['host']
            if not host_url.startswith('https://'):
                host_url = f"https://{host_url}"
            
            # Prepare the payload
            payload = {
                'vectors': vectors
            }
            
            logger.debug(f"Upserting to URL: {host_url}/vectors/upsert")
            logger.debug(f"Payload sample: {payload['vectors'][0] if vectors else 'No vectors'}")
            
            # Now upsert to the data plane
            response = requests.post(
                f"{host_url}/vectors/upsert",
                headers=self.headers,
                json=payload,
                verify=False,
                timeout=30
            )
            
            # Log response details for debugging
            logger.debug(f"Response status: {response.status_code}")
            if response.status_code != 200:
                logger.error(f"Response content: {response.text}")
            
            response.raise_for_status()
            
            logger.info(f"Successfully upserted {len(vectors)} vectors to {self.index_name}")
            return response.json()
            
        except Exception as e:
            logger.error(f"Failed to upsert vectors to {self.index_name}: {e}")
            raise
    
    def query(self, vector: List[float], top_k: int = 10, 
              include_metadata: bool = True, include_values: bool = False,
              filter: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Query vectors using direct HTTP calls.
        
        Args:
            vector: Query vector
            top_k: Number of results to return
            include_metadata: Whether to include metadata in results
            include_values: Whether to include vector values in results
            filter: Optional metadata filter for query
            
        Returns:
            Dictionary with query results
        """
        try:
            import requests
            
            # First, get the index description to get the host URL
            index_desc_response = requests.get(
                f"{self.base_url}/indexes/{self.index_name}",
                headers=self.headers,
                verify=False,
                timeout=30
            )
            index_desc_response.raise_for_status()
            index_desc = index_desc_response.json()
            
            # Extract the host URL from the index description
            if 'host' not in index_desc:
                logger.error(f"No host URL found in index description for {self.index_name}")
                raise Exception(f"No host URL found in index description for {self.index_name}")
            
            host_url = index_desc['host']
            if not host_url.startswith('https://'):
                host_url = f"https://{host_url}"
            
            payload = {
                'vector': vector,
                'topK': top_k,
                'includeMetadata': include_metadata,
                'includeValues': include_values
            }
            
            # Add filter if provided
            if filter is not None:
                payload['filter'] = filter
            
            # Use the data plane URL for querying
            response = requests.post(
                f"{host_url}/query",
                headers=self.headers,
                json=payload,
                verify=False,
                timeout=30
            )
            response.raise_for_status()
            
            logger.debug(f"Successfully queried {self.index_name} with top_k={top_k}")
            return response.json()
            
        except Exception as e:
            logger.error(f"Failed to query vectors from {self.index_name}: {e}")
            raise
    
    def describe_index_stats(self) -> Dict[str, Any]:
        """
        Get index statistics using the correct Pinecone API approach.
        
        The stats endpoint requires the index's data plane URL, not the control plane.
        We need to first get the index description to get the host URL.
        
        Returns:
            Dictionary with index statistics
        """
        try:
            import requests
            
            # First, get the index description to get the host URL
            index_desc_response = requests.get(
                f"{self.base_url}/indexes/{self.index_name}",
                headers=self.headers,
                verify=False,
                timeout=30
            )
            index_desc_response.raise_for_status()
            index_desc = index_desc_response.json()
            
            # Extract the host URL from the index description
            if 'host' not in index_desc:
                logger.error(f"No host URL found in index description for {self.index_name}")
                return {
                    "total_vector_count": 0,
                    "index_fullness": 0.0,
                    "namespaces": {},
                    "error": "No host URL found in index description"
                }
            
            host_url = index_desc['host']
            if not host_url.startswith('https://'):
                host_url = f"https://{host_url}"
            
            # Now get the stats from the data plane
            stats_response = requests.post(
                f"{host_url}/describe_index_stats",
                headers=self.headers,
                json={},  # Empty body for describe_index_stats
                verify=False,
                timeout=30
            )
            stats_response.raise_for_status()
            
            stats_data = stats_response.json()
            logger.info(f"Successfully retrieved stats for {self.index_name}: {stats_data}")
            return stats_data
            
        except Exception as e:
            logger.error(f"Failed to get index stats for {self.index_name}: {e}")
            # Return a fallback response instead of raising
            return {
                "total_vector_count": 0,
                "index_fullness": 0.0,
                "namespaces": {},
                "error": str(e)
            }


# Example usage and testing
def main():
    """Demonstrate Pinecone HTTP client functionality."""
    print("=== Pinecone HTTP Client Demo ===\n")
    
    try:
        # Get API key from environment
        api_key = os.getenv("PINECONE_API_KEY")
        if not api_key:
            print("❌ PINECONE_API_KEY environment variable not set")
            return
        
        # Initialize HTTP client
        print("🔄 Initializing Pinecone HTTP client...")
        client = PineconeHTTPClient(api_key)
        
        # Test connection
        print("🔍 Testing connection...")
        if client.test_connection():
            print("✅ Connection successful!")
        else:
            print("❌ Connection failed!")
            return
        
        # List indexes
        print("\n📋 Listing indexes...")
        indexes = client.list_indexes()
        print(f"Found {len(indexes)} indexes:")
        for index in indexes:
            print(f"  📂 {index.name}: {index.dimension}D, {index.metric}, {index.status}")
        
        print("\n✅ HTTP client demo completed successfully!")
        
    except Exception as e:
        print(f"❌ Demo failed: {e}")


if __name__ == "__main__":
    main()
