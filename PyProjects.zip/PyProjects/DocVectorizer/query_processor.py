#!/usr/bin/env python3
"""
Query Processing Layer

This module handles user query preparation and vectorization for the RAG search system.
"""

import re
import logging
from typing import Dict, List, Any
from openai_embedding_client import OpenAIEmbeddingClient

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class QueryProcessor:
    """
    Handles user query preparation and vectorization.
    
    This class processes user queries by cleaning and normalizing them,
    then vectorizing them using the same embedding client used for documents.
    """
    
    def __init__(self, embedding_client: OpenAIEmbeddingClient = None):
        """
        Initialize the query processor.
        
        Args:
            embedding_client: OpenAIEmbeddingClient instance for vectorization.
                            If None, creates a new instance.
        """
        if embedding_client is None:
            self.embedding_client = OpenAIEmbeddingClient()
        else:
            self.embedding_client = embedding_client
            
        logger.info("QueryProcessor initialized with OpenAIEmbeddingClient")
    
    def vectorize_query(self, query_text: str) -> List[float]:
        """
        Vectorize user query using the same embedding model as documents.
        
        Args:
            query_text: The query text to vectorize
            
        Returns:
            List[float]: 1536-dimensional vector
            
        Raises:
            Exception: If vectorization fails
        """
        try:
            logger.debug(f"Vectorizing query: {query_text[:100]}...")
            embedding = self.embedding_client.get_single_embedding(query_text)
            logger.debug(f"Query vectorized successfully: {len(embedding)} dimensions")
            return embedding
        except Exception as e:
            logger.error(f"Failed to vectorize query: {e}")
            raise Exception(f"Query vectorization failed: {str(e)}")
    
    def preprocess_query(self, query: str) -> str:
        """
        Clean and normalize query text.
        
        Args:
            query: Raw query string
            
        Returns:
            str: Cleaned query string
        """
        if not query:
            return ""
        
        # Remove extra whitespace
        cleaned = re.sub(r'\s+', ' ', query.strip())
        
        # Remove special characters that might interfere with search
        # Keep alphanumeric, spaces, and common punctuation
        cleaned = re.sub(r'[^\w\s\-.,!?]', '', cleaned)
        
        # Ensure minimum length
        if len(cleaned) < 2:
            logger.warning(f"Query too short after cleaning: '{cleaned}'")
            return query.strip()  # Return original if cleaning made it too short
        
        logger.debug(f"Query preprocessed: '{query}' -> '{cleaned}'")
        return cleaned
    
    def process(self, query: str) -> Dict[str, Any]:
        """
        Main method: preprocesses then vectorizes query.
        
        Args:
            query: Raw user query
            
        Returns:
            Dict[str, Any]: Dictionary containing:
                - original_query: The original query string
                - cleaned_query: The preprocessed query
                - query_vector: The vectorized query
                
        Raises:
            Exception: If processing fails
        """
        if not query or not query.strip():
            raise ValueError("Query cannot be empty")
        
        logger.info(f"Processing query: {query[:100]}...")
        
        # Step 1: Preprocess query
        cleaned_query = self.preprocess_query(query)
        
        # Step 2: Vectorize query
        query_vector = self.vectorize_query(cleaned_query)
        
        result = {
            "original_query": query,
            "cleaned_query": cleaned_query,
            "query_vector": query_vector
        }
        
        logger.info(f"Query processed successfully: {len(query_vector)} dimensions")
        return result


# Example usage and testing
def main():
    """Demonstrate query processing functionality."""
    print("=== Query Processor Demo ===\n")
    
    try:
        # Initialize query processor
        print("🔄 Initializing QueryProcessor...")
        processor = QueryProcessor()
        
        # Test queries
        test_queries = [
            "How do I cancel my subscription?",
            "  API   security   requirements  ",  # Extra whitespace
            "What are the database requirements?", 
            "Show me external API integrations",
            ""  # Empty query for error testing
        ]
        
        print("\n📝 Processing test queries:")
        for i, query in enumerate(test_queries):
            print(f"\n--- Query {i+1} ---")
            print(f"Original: '{query}'")
            
            try:
                result = processor.process(query)
                print(f"Cleaned: '{result['cleaned_query']}'")
                print(f"Vector dimensions: {len(result['query_vector'])}")
                print(f"First 5 values: {result['query_vector'][:5]}")
                
            except ValueError as e:
                print(f"❌ Validation error: {e}")
            except Exception as e:
                print(f"❌ Processing error: {e}")
        
        print(f"\n✅ QueryProcessor demo completed!")
        print(f"   🔑 Uses same embedding model as documents")
        print(f"   🧹 Cleans and normalizes queries")
        print(f"   📐 Generates 1536-dimensional vectors")
        
    except Exception as e:
        print(f"❌ Demo failed: {e}")
        print("\nMake sure OpenAIEmbeddingClient is properly configured")


if __name__ == "__main__":
    main()