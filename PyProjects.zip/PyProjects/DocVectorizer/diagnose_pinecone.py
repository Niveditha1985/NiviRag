#!/usr/bin/env python3
"""
Pinecone Index Diagnostic Script

This script helps diagnose and fix Pinecone index issues.
"""

import os
import json
from dotenv import load_dotenv
from pinecone_vector_store_manager import PineconeVectorStoreManager

# Load environment variables
load_dotenv()


def diagnose_pinecone_index():
    """Diagnose Pinecone index configuration and connectivity."""
    print("=== Pinecone Index Diagnostic ===\n")
    
    try:
        # Initialize Pinecone manager
        print("🔄 Initializing PineconeVectorStoreManager...")
        manager = PineconeVectorStoreManager()
        
        # Get index stats
        print("\n📊 Index Statistics:")
        stats = manager.get_index_stats()
        print(f"   Index Name: {stats.get('index_name', 'Unknown')}")
        print(f"   Total Vectors: {stats.get('total_vectors', 0)}")
        print(f"   Index Fullness: {stats.get('index_fullness', 0):.2%}")
        print(f"   Namespaces: {stats.get('namespaces', {})}")
        
        # Check if index has vectors
        if stats.get('total_vectors', 0) == 0:
            print("\n⚠️  WARNING: Index is empty!")
            print("   You need to add vectors to the index before querying.")
            print("   Use the document processing pipeline to add documents.")
            return False
        
        # Test a simple query
        print("\n🔍 Testing Query Functionality:")
        
        # Create a simple test vector (1536 dimensions of zeros)
        test_vector = [0.0] * 1536
        
        try:
            results = manager.search_vectors(
                query_vector=test_vector,
                top_k=5
            )
            
            print(f"   ✅ Query successful! Found {len(results)} results")
            
            if results:
                print("   Sample result:")
                sample = results[0]
                print(f"     ID: {sample.get('id', 'unknown')}")
                print(f"     Score: {sample.get('score', 0):.3f}")
                print(f"     Metadata keys: {list(sample.get('metadata', {}).keys())}")
            
            return True
            
        except Exception as e:
            print(f"   ❌ Query failed: {e}")
            
            # Check if it's a URL issue
            if "404" in str(e) and "query" in str(e):
                print("\n🔧 DIAGNOSIS: 404 Query Error")
                print("   This usually means:")
                print("   1. The index doesn't exist")
                print("   2. Wrong API endpoint URL")
                print("   3. Index is not ready for querying")
                
                # Check index existence
                print("\n🔍 Checking index existence...")
                try:
                    # Try to get index info
                    index_info = manager.http_client.get_index(manager.index_name)
                    print(f"   ✅ Index exists: {index_info}")
                    
                    # Check if it's a serverless index
                    if hasattr(index_info, 'spec') and hasattr(index_info.spec, 'serverless'):
                        print("   📋 This is a serverless index")
                        print("   💡 Serverless indexes may have different query URLs")
                    
                except Exception as info_error:
                    print(f"   ❌ Index info check failed: {info_error}")
            
            return False
        
    except Exception as e:
        print(f"❌ Diagnostic failed: {e}")
        return False


def suggest_fixes():
    """Suggest fixes for common Pinecone issues."""
    print("\n=== Suggested Fixes ===\n")
    
    print("1. 📚 Add Documents to Index:")
    print("   Run the document processing pipeline to add vectors:")
    print("   python document_processor.py")
    print()
    
    print("2. 🔧 Check Environment Variables:")
    print("   Ensure these are set correctly:")
    print("   - PINECONE_API_KEY")
    print("   - PINECONE_ENVIRONMENT")
    print("   - PINECONE_INDEX_NAME")
    print()
    
    print("3. 🌐 Check API Endpoints:")
    print("   Pinecone uses different URLs for:")
    print("   - Control plane: https://api.pinecone.io")
    print("   - Data plane: https://<index-name>-<project-id>.svc.<environment>.pinecone.io")
    print()
    
    print("4. ⏰ Wait for Index Readiness:")
    print("   New indexes may take a few minutes to be ready for querying")
    print()
    
    print("5. 🔄 Recreate Index:")
    print("   If the index is corrupted, delete and recreate it:")
    print("   - Delete via Pinecone console")
    print("   - Or use PineconeVectorStoreManager to recreate")


def main():
    """Main diagnostic function."""
    print("Starting Pinecone Index Diagnostic...")
    print("=" * 50)
    
    success = diagnose_pinecone_index()
    
    if not success:
        suggest_fixes()
    
    print("=" * 50)
    if success:
        print("🎉 Index is working correctly!")
        print("   You can now use the RAG Pipeline.")
    else:
        print("❌ Index has issues that need to be resolved.")
        print("   Follow the suggested fixes above.")


if __name__ == "__main__":
    main()
