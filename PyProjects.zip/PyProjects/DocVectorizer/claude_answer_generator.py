#!/usr/bin/env python3
"""
Claude Answer Generator Business Logic Layer

This module generates answers using Claude with retrieved context and handles prompt engineering.
"""

import logging
import re
from typing import Dict, List, Any, Optional
from datetime import datetime
from claude_client import ClaudeClient

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ClaudeAnswerGenerator:
    """
    Generates answers using Claude with retrieved context and handles prompt engineering.
    
    This class manages the business logic for answer generation, including
    prompt creation, response formatting, and citation extraction.
    """
    
    def __init__(self, claude_client: ClaudeClient = None):
        """
        Initialize the Claude answer generator.
        
        Args:
            claude_client: ClaudeClient instance for API communication.
                         If None, creates a new instance.
        """
        if claude_client is None:
            self.claude_client = ClaudeClient()
        else:
            self.claude_client = claude_client
        
        # Store model configuration and prompt templates
        self.default_model = self.claude_client.default_model
        self.max_tokens = 4000
        
        logger.info(f"ClaudeAnswerGenerator initialized with model: {self.default_model}")
    
    def generate_answer(self, query: str, context: str) -> Dict[str, Any]:
        """
        Main method: sends query + context to Claude.
        
        Args:
            query: User query
            context: Retrieved context from ContextBuilder
            
        Returns:
            Dict[str, Any]: Complete response with answer, sources, and metadata
        """
        try:
            logger.info(f"Generating answer for query: {query[:100]}...")
            
            # Step 1: Validate context length
            validated_context = self._validate_context_length(context)
            
            # Step 2: Create prompt
            prompt = self.create_prompt(query, validated_context)
            
            # Step 3: Generate completion
            messages = [
                {
                    "role": "user",
                    "content": prompt
                }
            ]
            
            raw_response = self.claude_client.generate_completion(
                messages=messages,
                model=self.default_model,
                max_tokens=self.max_tokens
            )
            
            # Step 4: Extract answer and citations
            answer = raw_response.get("content", "")
            citations = self.extract_citations(answer)
            
            # Step 5: Format final response
            response = self.format_response(raw_response, citations)
            
            logger.info("Answer generated successfully")
            return response
            
        except Exception as e:
            logger.error(f"Answer generation failed: {e}")
            return {
                "answer": f"Sorry, I encountered an error while generating an answer: {str(e)}",
                "sources": [],
                "metadata": {
                    "error": str(e),
                    "timestamp": datetime.now().isoformat(),
                    "model": self.default_model
                }
            }
    
    def create_prompt(self, query: str, context: str) -> str:
        """
        Build prompt with instructions and context.
        
        Args:
            query: User query
            context: Retrieved context
            
        Returns:
            str: Complete prompt string
        """
        system_prompt = """You are a helpful AI assistant that answers questions based on the provided context. 

Instructions:
1. Answer the user's question using only the information provided in the context
2. If the context doesn't contain enough information to answer the question, say so clearly
3. Cite sources using the format [1], [2], etc. when referencing specific information
4. Be concise but comprehensive in your answer
5. If you're unsure about something, express that uncertainty
6. Focus on being helpful and accurate

Context:
{context}

Question: {query}

Answer:"""

        prompt = system_prompt.format(context=context, query=query)
        
        logger.debug(f"Created prompt with {len(prompt)} characters")
        return prompt
    
    def extract_citations(self, answer: str) -> List[str]:
        """
        Parse answer for source citations.
        
        Args:
            answer: Generated answer text
            
        Returns:
            List[str]: List of cited source numbers
        """
        # Look for citation patterns like [1], [2], etc.
        citation_pattern = r'\[(\d+)\]'
        citations = re.findall(citation_pattern, answer)
        
        # Remove duplicates and sort
        unique_citations = sorted(list(set(citations)))
        
        logger.debug(f"Extracted citations: {unique_citations}")
        return unique_citations
    
    def format_response(self, raw_response: Dict[str, Any], sources: List[str]) -> Dict[str, Any]:
        """
        Structure final response.
        
        Args:
            raw_response: Raw response from ClaudeClient
            sources: List of cited sources
            
        Returns:
            Dict[str, Any]: Complete response object
        """
        answer = raw_response.get("content", "")
        metadata = raw_response.get("metadata", {})
        
        # Create source objects with metadata
        source_objects = []
        for source_num in sources:
            source_objects.append({
                "citation_number": source_num,
                "description": f"Source {source_num}",
                "metadata": {}
            })
        
        response = {
            "answer": answer,
            "sources": source_objects,
            "metadata": {
                "timestamp": datetime.now().isoformat(),
                "model": metadata.get("model", self.default_model),
                "stop_reason": metadata.get("stop_reason", "unknown"),
                "usage": metadata.get("usage", {}),
                "citations_found": len(sources),
                "answer_length": len(answer)
            }
        }
        
        logger.debug(f"Formatted response with {len(sources)} citations")
        return response
    
    def _validate_context_length(self, context: str, max_tokens: int = 8000) -> str:
        """
        Check if context exceeds token limits.
        
        Args:
            context: Context string to validate
            max_tokens: Maximum token limit
            
        Returns:
            str: Validated context string
        """
        # Rough estimation: ~4 characters per token
        estimated_tokens = len(context) // 4
        
        if estimated_tokens <= max_tokens:
            logger.debug(f"Context within token limit: {estimated_tokens}/{max_tokens}")
            return context
        
        logger.warning(f"Context exceeds token limit: {estimated_tokens}/{max_tokens}")
        
        # Truncate context while preserving structure
        # Find a good breaking point (end of a citation block)
        truncated_context = context
        while len(truncated_context) // 4 > max_tokens and truncated_context:
            # Find the last complete citation block
            last_citation = truncated_context.rfind('\n[')
            if last_citation > 0:
                truncated_context = truncated_context[:last_citation]
            else:
                # If no citation boundary found, truncate by character count
                max_chars = max_tokens * 4
                truncated_context = truncated_context[:max_chars]
                break
        
        final_tokens = len(truncated_context) // 4
        logger.info(f"Truncated context: {estimated_tokens} -> {final_tokens} tokens")
        
        return truncated_context
    
    def generate_with_custom_prompt(self, user_message: str, context: str, system_prompt: str) -> Dict[str, Any]:
        """
        Generate response with custom system prompt.
        
        Args:
            user_message: User's input (e.g., requirements for test cases)
            context: Retrieved documentation/code context
            system_prompt: Custom system template for specific task
            
        Returns:
            Dict[str, Any]: Generated content with metadata
        """
        try:
            logger.info(f"Generating response with custom prompt for message: {user_message[:100]}...")
            
            # Step 1: Validate context length
            validated_context = self._validate_context_length(context)
            
            # Step 2: Create custom prompt
            prompt = self.create_custom_prompt(user_message, validated_context, system_prompt)
            
            # Step 3: Generate completion
            messages = [
                {
                    "role": "user",
                    "content": prompt
                }
            ]
            
            raw_response = self.claude_client.generate_completion(
                messages=messages,
                model=self.default_model,
                max_tokens=self.max_tokens
            )
            
            # Step 4: Format response
            response = {
                "content": raw_response.get("content", ""),
                "metadata": {
                    "timestamp": datetime.now().isoformat(),
                    "model": raw_response.get("metadata", {}).get("model", self.default_model),
                    "stop_reason": raw_response.get("metadata", {}).get("stop_reason", "unknown"),
                    "usage": raw_response.get("metadata", {}).get("usage", {}),
                    "content_length": len(raw_response.get("content", "")),
                    "context_length": len(validated_context),
                    "system_prompt_length": len(system_prompt)
                }
            }
            
            logger.info("Custom prompt response generated successfully")
            return response
            
        except Exception as e:
            logger.error(f"Custom prompt generation failed: {e}")
            return {
                "content": f"Sorry, I encountered an error while generating a response: {str(e)}",
                "metadata": {
                    "error": str(e),
                    "timestamp": datetime.now().isoformat(),
                    "model": self.default_model
                }
            }
    
    def create_custom_prompt(self, user_message: str, context: str, system_prompt: str) -> str:
        """
        Build prompt with custom system template.
        
        Args:
            user_message: User's input message
            context: Retrieved context
            system_prompt: Custom system template
            
        Returns:
            str: Complete prompt string
        """
        if context and context.strip():
            prompt = f"""System: {system_prompt}

Context:
{context}

User Message: {user_message}

Response:"""
        else:
            prompt = f"""System: {system_prompt}

User Message: {user_message}

Response:"""
        
        logger.debug(f"Created custom prompt with {len(prompt)} characters")
        return prompt
    
    def test_answer_generation(self, test_query: str = "What is artificial intelligence?") -> Dict[str, Any]:
        """
        Test answer generation with a simple query.
        
        Args:
            test_query: Test query to use
            
        Returns:
            Dict[str, Any]: Test response
        """
        # Simple test context
        test_context = """[1] Artificial Intelligence (AI) is a branch of computer science that aims to create machines capable of intelligent behavior.
Source: AI Basics Guide - Introduction (Topic: AI Fundamentals) (Relevance: 0.95)

[2] AI systems can perform tasks that typically require human intelligence, such as visual perception, speech recognition, and decision-making.
Source: AI Applications Handbook - Overview (Topic: AI Applications) (Relevance: 0.87)"""
        
        return self.generate_answer(test_query, test_context)


# Example usage and testing
def main():
    """Demonstrate Claude answer generator functionality."""
    print("=== Claude Answer Generator Demo ===\n")
    
    try:
        # Initialize answer generator
        print("🔄 Initializing ClaudeAnswerGenerator...")
        answer_generator = ClaudeAnswerGenerator()
        
        # Test answer generation
        print("💬 Testing answer generation...")
        test_query = "What are the main components of API security?"
        
        test_context = """[1] API security requires authentication tokens and proper authorization checks.
Source: api_docs.md - Authentication (Topic: APISecurity) (Relevance: 0.95)

[2] All endpoints must validate user permissions before processing requests.
Source: api_docs.md - Authorization (Topic: APISecurity) (Relevance: 0.87)

[3] Database connections should use connection pooling for better performance.
Source: database_guide.md - Performance (Topic: Database) (Relevance: 0.82)"""
        
        response = answer_generator.generate_answer(test_query, test_context)
        
        print(f"\n📄 Generated Response:")
        print("=" * 50)
        print(f"Answer: {response['answer']}")
        print("=" * 50)
        
        print(f"\n📊 Response Metadata:")
        metadata = response['metadata']
        print(f"   🤖 Model: {metadata.get('model', 'unknown')}")
        print(f"   📏 Answer length: {metadata.get('answer_length', 0)} characters")
        print(f"   📚 Citations found: {metadata.get('citations_found', 0)}")
        print(f"   ⏰ Timestamp: {metadata.get('timestamp', 'unknown')}")
        
        if 'usage' in metadata and metadata['usage']:
            usage = metadata['usage']
            print(f"   🎯 Tokens used: {usage.get('input_tokens', 0)} input, {usage.get('output_tokens', 0)} output")
        
        print(f"\n📚 Sources:")
        for source in response['sources']:
            print(f"   [{source['citation_number']}] {source['description']}")
        
        # Test citation extraction
        print(f"\n🔍 Citation Extraction Test:")
        test_answer = "API security requires authentication [1] and authorization [2]. Performance is also important [3]."
        citations = answer_generator.extract_citations(test_answer)
        print(f"   Answer: {test_answer}")
        print(f"   Citations found: {citations}")
        
        print(f"\n✅ ClaudeAnswerGenerator demo completed!")
        print(f"   🤖 Generates answers using Claude")
        print(f"   📝 Handles prompt engineering")
        print(f"   📚 Extracts citations")
        print(f"   📊 Provides response metadata")
        
    except Exception as e:
        print(f"❌ Demo failed: {e}")
        print("\nMake sure ClaudeClient is properly configured")


if __name__ == "__main__":
    main()