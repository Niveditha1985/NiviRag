#!/usr/bin/env python3
"""
RAG Pipeline Orchestrator

This module is the main orchestrator that connects all components and controls the search flow.
"""

import os
import re
import logging
import time
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
from dotenv import load_dotenv

# Import all RAG components
from query_processor import QueryProcessor
from semantic_search_engine import SemanticSearchEngine
from context_builder import ContextBuilder
from claude_answer_generator import ClaudeAnswerGenerator
from search_logger import SearchLogger

# Load environment variables
load_dotenv()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class RAGPipeline:
    """
    Main orchestrator that connects all components and controls the search flow.
    
    This class coordinates the entire RAG process:
    1. Query processing and vectorization
    2. Semantic search
    3. Context building
    4. Answer generation
    5. Logging and analytics
    """
    
    def __init__(self):
        """
        Initialize the RAG pipeline with all components.
        
        Loads configuration from environment variables and initializes:
        - QueryProcessor (for vectorization)
        - SemanticSearchEngine (for search)
        - ContextBuilder (for context assembly)
        - ClaudeAnswerGenerator (for answer generation)
        - SearchLogger (for logging)
        """
        logger.info("Initializing RAGPipeline...")
        
        # Load configuration from environment
        self.max_context_tokens = int(os.getenv("MAX_CONTEXT_TOKENS", "8000"))
        self.default_top_k = int(os.getenv("DEFAULT_TOP_K", "10"))
        
        # Initialize all components
        logger.info("Initializing QueryProcessor...")
        self.query_processor = QueryProcessor()
        
        logger.info("Initializing SemanticSearchEngine...")
        self.search_engine = SemanticSearchEngine()
        
        logger.info("Initializing ContextBuilder...")
        self.context_builder = ContextBuilder(max_context_tokens=self.max_context_tokens)
        
        logger.info("Initializing ClaudeAnswerGenerator...")
        self.answer_generator = ClaudeAnswerGenerator()
        
        logger.info("Initializing SearchLogger...")
        self.search_logger = SearchLogger()
        
        logger.info("RAGPipeline initialization complete")
    
    def answer_query(self, query: str, user_id: str = None, top_k: int = None, filters: Dict = None) -> Dict[str, Any]:
        """
        Main end-to-end method for answering queries.
        
        Args:
            query: User query
            user_id: User identifier for logging
            top_k: Number of search results to retrieve
            filters: Optional metadata filters for search
            
        Returns:
            Dict[str, Any]: Complete response with answer, sources, and metadata
        """
        start_time = time.time()
        request_id = None
        
        try:
            logger.info(f"Processing query: {query[:100]}...")
            
            # Set default values
            if top_k is None:
                top_k = self.default_top_k
            if user_id is None:
                user_id = "anonymous"
            
            # Step 1: Log search request
            session_info = {
                "timestamp": datetime.now().isoformat(),
                "user_id": user_id,
                "query_length": len(query)
            }
            request_id = self.search_logger.log_search_request(
                user_id=user_id,
                query=query,
                timestamp=datetime.now(),
                session_info=session_info
            )
            
            # Step 2: Process and vectorize query
            query_start = time.time()
            query_result = self.query_processor.process(query)
            query_time = time.time() - query_start
            
            # Step 3: Search for similar chunks
            search_start = time.time()
            if filters:
                search_results = self.search_engine.search_with_filters(
                    query_vector=query_result["query_vector"],
                    metadata_filters=filters,
                    top_k=top_k
                )
            else:
                search_results = self.search_engine.search(
                    query_vector=query_result["query_vector"],
                    top_k=top_k
                )
            search_time = time.time() - search_start
            
            if not search_results:
                logger.warning("No search results found")
                return self._create_no_results_response(query, request_id)
            
            # Step 4: Build context
            context_start = time.time()
            context = self.context_builder.build_context(search_results, query)
            context_time = time.time() - context_start
            
            if not context:
                logger.warning("No context built from search results")
                return self._create_no_context_response(query, request_id)
            
            # Step 5: Generate answer
            answer_start = time.time()
            response = self.answer_generator.generate_answer(query, context)
            answer_time = time.time() - answer_start
            
            # Step 6: Add processing metadata
            total_time = time.time() - start_time
            processing_metadata = {
                "total_time": total_time,
                "query_processing_time": query_time,
                "search_time": search_time,
                "context_building_time": context_time,
                "llm_generation_time": answer_time,
                "chunks_retrieved": len(search_results),
                "chunks_used": len(self.context_builder.deduplicate_results(search_results)),
                "context_tokens": self.context_builder.estimate_tokens(context),
                "top_k": top_k,
                "filters_applied": filters is not None,
                "request_id": request_id
            }
            
            response["metadata"].update(processing_metadata)
            
            # Step 7: Log search response
            self.search_logger.log_search_response(request_id, response, processing_metadata)
            
            logger.info(f"Query processed successfully in {total_time:.2f}s")
            return response
            
        except Exception as e:
            logger.error(f"Query processing failed: {e}")
            
            # Log error
            if request_id:
                error_context = {
                    "query": query,
                    "user_id": user_id,
                    "stage": "pipeline_processing"
                }
                self.search_logger.log_error(request_id, e, error_context)
            
            return self._create_error_response(query, str(e), request_id)
    
    def get_search_results_only(self, query: str, top_k: int = None) -> List[Dict]:
        """
        Return search results without LLM generation.
        
        Args:
            query: User query
            top_k: Number of results to return
            
        Returns:
            List[Dict]: Raw search results with scores and metadata
        """
        try:
            logger.info(f"Getting search results for: {query[:100]}...")
            
            if top_k is None:
                top_k = self.default_top_k
            
            # Process and vectorize query
            query_result = self.query_processor.process(query)
            
            # Search for similar chunks
            search_results = self.search_engine.search(
                query_vector=query_result["query_vector"],
                top_k=top_k
            )
            
            logger.info(f"Found {len(search_results)} search results")
            return search_results
            
        except Exception as e:
            logger.error(f"Search failed: {e}")
            return []
    
    def validate_query(self, query: str) -> Tuple[bool, str]:
        """
        Check if query is valid.
        
        Args:
            query: Query to validate
            
        Returns:
            Tuple[bool, str]: (is_valid, error_message)
        """
        if not query or not query.strip():
            return False, "Query cannot be empty"
        
        if len(query.strip()) < 2:
            return False, "Query too short (minimum 2 characters)"
        
        if len(query) > 1000:
            return False, "Query too long (maximum 1000 characters)"
        
        # Check for prohibited patterns (basic validation)
        prohibited_patterns = [
            r'<script.*?>',
            r'javascript:',
            r'data:',
        ]
        
        for pattern in prohibited_patterns:
            if re.search(pattern, query, re.IGNORECASE):
                return False, f"Query contains prohibited pattern: {pattern}"
        
        return True, ""
    
    def _merge_and_deduplicate_results(self, results: List[Dict]) -> List[Dict]:
        """
        Helper method for combining search results.
        
        Args:
            results: List of search results
            
        Returns:
            List[Dict]: Deduplicated results
        """
        return self.context_builder.deduplicate_results(results)
    
    def _create_no_results_response(self, query: str, request_id: str) -> Dict[str, Any]:
        """Create response when no search results are found."""
        return {
            "answer": "I couldn't find any relevant information to answer your question. Please try rephrasing your query or check if the information exists in the knowledge base.",
            "sources": [],
            "metadata": {
                "timestamp": datetime.now().isoformat(),
                "request_id": request_id,
                "no_results": True,
                "query": query
            }
        }
    
    def _create_no_context_response(self, query: str, request_id: str) -> Dict[str, Any]:
        """Create response when no context can be built."""
        return {
            "answer": "I found some information but couldn't build a coherent context to answer your question. The search results may be too fragmented or irrelevant.",
            "sources": [],
            "metadata": {
                "timestamp": datetime.now().isoformat(),
                "request_id": request_id,
                "no_context": True,
                "query": query
            }
        }
    
    def _create_error_response(self, query: str, error_message: str, request_id: str) -> Dict[str, Any]:
        """Create response when an error occurs."""
        return {
            "answer": f"Sorry, I encountered an error while processing your query: {error_message}",
            "sources": [],
            "metadata": {
                "timestamp": datetime.now().isoformat(),
                "request_id": request_id,
                "error": True,
                "error_message": error_message,
                "query": query
            }
        }
    
    def get_pipeline_stats(self) -> Dict[str, Any]:
        """
        Get statistics about the pipeline and its components.
        
        Returns:
            Dict[str, Any]: Pipeline statistics
        """
        try:
            # Get index stats from search engine
            index_stats = self.search_engine.get_index_stats()
            
            # Get recent analytics
            analytics = self.search_logger.get_analytics_summary()
            
            return {
                "pipeline_config": {
                    "max_context_tokens": self.max_context_tokens,
                    "default_top_k": self.default_top_k
                },
                "index_stats": index_stats,
                "analytics": analytics,
                "components": {
                    "query_processor": "initialized",
                    "search_engine": "initialized", 
                    "context_builder": "initialized",
                    "answer_generator": "initialized",
                    "search_logger": "initialized"
                }
            }
            
        except Exception as e:
            logger.error(f"Failed to get pipeline stats: {e}")
            return {"error": str(e)}


# Example usage and testing
def main():
    """Demonstrate RAG pipeline functionality."""
    print("=== RAG Pipeline Demo ===\n")
    
    try:
        # Initialize RAG pipeline
        print("🔄 Initializing RAGPipeline...")
        pipeline = RAGPipeline()
        
        # Get pipeline statistics
        print("📊 Getting pipeline statistics...")
        stats = pipeline.get_pipeline_stats()
        print(f"   📂 Index: {stats.get('index_stats', {}).get('index_name', 'unknown')}")
        print(f"   📊 Total vectors: {stats.get('index_stats', {}).get('total_vectors', 0)}")
        print(f"   ⚙️  Max context tokens: {stats.get('pipeline_config', {}).get('max_context_tokens', 0)}")
        
        # Test query validation
        print("\n✅ Testing query validation...")
        test_queries = [
            "What are the API security requirements?",
            "",  # Empty query
            "a",  # Too short
            "x" * 1001,  # Too long
        ]
        
        for query in test_queries:
            is_valid, error = pipeline.validate_query(query)
            print(f"   '{query[:50]}...': {'✅ Valid' if is_valid else '❌ Invalid - ' + error}")
        
        # Test search results only
        print("\n🔍 Testing search results only...")
        search_results = pipeline.get_search_results_only("API security", top_k=5)
        print(f"   Found {len(search_results)} search results")
        
        if search_results:
            print("   Sample result:")
            sample = search_results[0]
            print(f"     Chunk ID: {sample.get('chunk_id', 'unknown')}")
            print(f"     Score: {sample.get('score', 0):.3f}")
            print(f"     Content preview: {sample.get('content', '')[:100]}...")
        
        # Test full query processing (if we have data)
        if search_results:
            print("\n💬 Testing full query processing...")
            response = pipeline.answer_query(
                query="What are the API security requirements?",
                user_id="demo_user",
                top_k=5
            )
            
            print(f"   Answer: {response.get('answer', 'No answer')[:200]}...")
            print(f"   Sources: {len(response.get('sources', []))}")
            
            metadata = response.get('metadata', {})
            print(f"   Processing time: {metadata.get('total_time', 0):.2f}s")
            print(f"   Chunks retrieved: {metadata.get('chunks_retrieved', 0)}")
            print(f"   Context tokens: {metadata.get('context_tokens', 0)}")
        
        print(f"\n✅ RAGPipeline demo completed!")
        print(f"   🔄 Orchestrates all RAG components")
        print(f"   📊 Provides comprehensive logging")
        print(f"   ⚡ Handles end-to-end query processing")
        print(f"   🛡️  Includes error handling and validation")
        
    except Exception as e:
        print(f"❌ Demo failed: {e}")
        print("\nMake sure all components are properly configured")


if __name__ == "__main__":
    main()
