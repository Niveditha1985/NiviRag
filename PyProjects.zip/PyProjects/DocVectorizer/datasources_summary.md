# Data Sources Summary

This table lists all data sources configured in the sampleStandalone.xml file with their connection details.

| Data Source Name | Database Type | Connection URL | Username | Password |
|---|---|---|---|---|
| ExampleDS | H2 | jdbc:h2:mem:test;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE | sa | sa |
| SpringSecurityDataSource | SQL Server | jdbc:sqlserver://vwsl-cdb-t01.pgx.local:1433;DatabaseName=SpringSecurity | customer_master | LS9Y2KgQT7hD |
| CommonDatabaseDataSource | SQL Server | jdbc:sqlserver://vwsl-cdb-t01.pgx.local:1433;DatabaseName=Common | customer_master | LS9Y2KgQT7hD |
| paymentProcessorDataSource | SQL Server | jdbc:sqlserver://vwsl-findb-t01:1433;DatabaseName=PaymentProcessor;SendStringParametersAsUnicode=false | PaymentProcessor | jp4uh3XuCGIvAtKpfjvGWo1Xb |
| ValidationDatasource | SQL Server | jdbc:sqlserver://vwsl-cdb-t01.pgx.local:1433;DatabaseName=ValidationModule;sendStringParametersAsUnicode=false;prepareSQL=0 | validation | MyFVP2rpjjIH4bofWkKfdeR4s |
| batchdistributorLEXds | SQL Server | jdbc:sqlserver://vwsl-gpdb-t01.pgx.local:1433;DatabaseName=LEX;SendStringParametersAsUnicode=false | spp_batch_distributor | lN5t9KK7JWC3Q6Kjh2Gvk8Ahm |
| batchdistributorCRCOMds | SQL Server | jdbc:sqlserver://vwsl-gpdb-t01.pgx.local:1433;DatabaseName=CRCOM;SendStringParametersAsUnicode=false | spp_batch_distributor | lN5t9KK7JWC3Q6Kjh2Gvk8Ahm |
| batchdistributorSPPds | SQL Server | jdbc:sqlserver://vwsl-findb-t01:1433;DatabaseName=PaymentProcessor;SendStringParametersAsUnicode=false | spp_batch_distributor | 9OyM0lIpekNpqfJFOMulQNuK6 |
| batchprocessorLEXds | SQL Server | jdbc:sqlserver://vwsl-gpdb-t01.pgx.local:1433;DatabaseName=LEX;SendStringParametersAsUnicode=false | spp_batch_processor | pIqaLEt5PPqhnfWs66ZUDXBvF |
| batchprocessorCRCOMds | SQL Server | jdbc:sqlserver://vwsl-gpdb-t01.pgx.local:1433;DatabaseName=CRCOM;SendStringParametersAsUnicode=false | spp_batch_processor | pIqaLEt5PPqhnfWs66ZUDXBvF |
| batchprocessorCTSds | SQL Server | jdbc:sqlserver://med-test.pgx.local:1433;DatabaseName=CTS;SendStringParametersAsUnicode=false | spp_batch_processor | pIqaLEt5PPqhnfWs66ZUDXBvF |
| batchprocessorSPPds | SQL Server | jdbc:sqlserver://vwsl-findb-t01:1433;DatabaseName=PaymentProcessor;SendStringParametersAsUnicode=false | spp_batch_processor | x7p0oWTIw1vZwiVH3tdhAFlFM |
| batchprocessorlistenerCTSds | SQL Server | jdbc:sqlserver://med-test.pgx.local:1433;DatabaseName=CTS;SendStringParametersAsUnicode=false | spp_batch_processor_message_listener | TdMQmckTobP81Vg6c2WPFGOQu |
| AccountMigrationCRCOMds | SQL Server | jdbc:sqlserver://med-test.pgx.local:1433;DatabaseName=CRCOM;SendStringParametersAsUnicode=false | accounting_services | NoZdrhQXT646XoxMsgiG87IHf |
| BillingProductsDataSource | SQL Server | jdbc:sqlserver://VWSL-FINDB-t01.pgx.local:1433;DatabaseName=BillingProducts | billing_products | AJdyeeG8Rteilz43PlptPtXiF |
| reportingDataSource | SQL Server | jdbc:sqlserver://med-test.pgx.local;DatabaseName=reporting;SendStringParametersAsUnicode=false | spp_notification_services | Lyjsk3fJrUeCwx4Gs9ISs1x4f |
| LASWebDataSource | SQL Server | jdbc:sqlserver://vwsl-cdb-t01.pgx.local:1433;DatabaseName=legalagreementservices | legalagreementservicesweb | nujLQ0whhxjlHIc7 |
| LASWebLEXContentDataSource | MySQL | jdbc:mysql://austria-dev:3306/lams_lexingtonlaw_com | lasweb | PvDEngd1yUq6BASx |
| LASWebCRCOMContentDataSource | MySQL | jdbc:mysql://peru-dev:3306/lams_creditrepair_com | lasweb | PvDEngd1yUq6BASx |
| LASJobsDataSource | SQL Server | jdbc:sqlserver://vwsl-cdb-t01.pgx.local:1433;DatabaseName=legalagreementservices | legalagreementservicesjob | fmnwLdeR8WJoakq2 |
| LASListenersDataSource | SQL Server | jdbc:sqlserver://vwsl-cdb-t01.pgx.local:1433;DatabaseName=legalagreementservices | legalagreementserviceslistener | laFey4hTbT6sSUok |
| ChargebackAlerts | SQL Server | jdbc:sqlserver://VWSL-FINDB-T01.pgx.local:1433;DatabaseName=ChargebackAlerts | Chargebackalertprocessor | 7>455Z:|;*62{3s |
| capReportingDataSource | SQL Server | jdbc:sqlserver://med-test.pgx.local;DatabaseName=reporting | cts | test |
| LegalAgreementsDataSource | SQL Server | jdbc:sqlserver://vwsl-cdb-t01.pgx.local:1433;DatabaseName=LegalAgreementsModule | legalAgreement | mtS9IQICQJhrP4pHxDAIaXClZ |
| offerWarehouseApiDs | MySQL | jdbc:mysql://ccom-coredb-t01.vwsl.pgx.local:3306/offer_warehouse | b2b-batch | QZ98QeNfTmdDhzNV |
| COSWebDataSource | SQL Server | jdbc:sqlserver://vwsl-cdb-t01.pgx.local:1433;DatabaseName=CentralizedOfferServices | CentralizedOfferServicesWeb | cyJ2HYB1vphqkr5DC614 |
| SalesforceIntegrationsDataSource | SQL Server | jdbc:sqlserver://vwsl-cdb-t01.pgx.local:1433;DatabaseName=SalesforceIntegrations | SalesforceIntegrationDBUser | iVaFstWPM8QIycAS |

## Summary

- **Total Data Sources**: 27
- **Database Types**: 
  - SQL Server (Microsoft): 24 sources
  - MySQL: 4 sources
  - H2 (In-memory): 1 source
- **Environment Servers**: 
  - vwsl-cdb-t01.pgx.local
  - vwsl-findb-t01
  - vwsl-gpdb-t01.pgx.local
  - med-test.pgx.local
  - austria-dev
  - peru-dev
  - ccom-coredb-t01.vwsl.pgx.local

## Database Servers Used

| Server | Database Types | Purpose |
|---|---|---|
| vwsl-cdb-t01.pgx.local | SQL Server | Core database services (SpringSecurity, Common, ValidationModule, etc.) |
| vwsl-findb-t01 | SQL Server | Financial/payment processing databases |
| vwsl-gpdb-t01.pgx.local | SQL Server | General purpose databases (LEX, CRCOM) |
| med-test.pgx.local | SQL Server | Integration/testing databases |
| austria-dev | MySQL | Lexington Law content |
| peru-dev | MySQL | Credit repair content |
| ccom-coredb-t01.vwsl.pgx.local | MySQL | Offer warehouse |