#!/usr/bin/env python3
"""
Test Case Generation Layer

This module generates test cases using API context retrieved from Pinecone and new requirements.
"""

import os
import logging
import re
from typing import Dict, List, Any, Optional
from datetime import datetime
from dotenv import load_dotenv

from rag_pipeline import RAGPipeline
from claude_answer_generator import ClaudeAnswerGenerator
from search_logger import SearchLogger

# Load environment variables
load_dotenv()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class TestCaseGenerator:
    """
    Generates test cases using API context retrieved from Pinecone and new requirements.
    
    This class leverages the existing RAG infrastructure to:
    1. Retrieve API-specific context using metadata filtering
    2. Combine context with new requirements
    3. Generate test cases using Claude with a specialized system prompt
    4. Log generation requests and responses
    """
    
    # System template for test case generation
    SYSTEM_TEMPLATE = """You are an expert QA engineer and test automation specialist. Your task is to generate test cases in Gherkin format based on the provided requirements and the existing context about the API.

Guidelines for test case generation:
1. Create test cases that cover all functional requirements
2. Include positive, negative, and edge case scenarios
3. Consider boundary value analysis
4. Ensure test cases are clear, specific, and executable
5. Use the existing API context to understand current behavior
6. Consider the existing API context when generating test scenarios

Format your response as a structured list of test cases in Gherkin format only.
Do not include any other text or comments.

Example format:
Feature: [Feature Name]
  
  Scenario: [Scenario Name]
    Given [precondition]
    When [action]
    Then [expected result]"""
    
    def __init__(self, rag_pipeline: RAGPipeline, claude_client: ClaudeAnswerGenerator = None, search_logger: SearchLogger = None):
        """
        Initialize the test case generator.
        
        Args:
            rag_pipeline: RAGPipeline instance for context retrieval
            claude_client: ClaudeAnswerGenerator instance. If None, creates a new one.
            search_logger: SearchLogger instance. If None, creates a new one.
        """
        self.rag_pipeline = rag_pipeline
        
        # Initialize Claude client if not provided
        if claude_client is None:
            self.claude_client = ClaudeAnswerGenerator()
        else:
            self.claude_client = claude_client
        
        # Initialize search logger if not provided
        if search_logger is None:
            self.search_logger = SearchLogger()
        else:
            self.search_logger = search_logger
        
        # Configuration
        self.default_context_chunks = int(os.getenv("TEST_CASE_CONTEXT_CHUNKS", "20"))
        self.min_requirements_length = 10  # Minimum characters for requirements
        
        logger.info(f"TestCaseGenerator initialized with default_context_chunks={self.default_context_chunks}")
    
    def generate_test_cases(self, api_name: str, requirements: str, user_id: str = None) -> Dict[str, Any]:
        """
        Main method for test case generation.
        
        Args:
            api_name: Name of the API being modified (e.g., "FinalizeSaleAPI")
            requirements: New requirements or changes for the API
            user_id: User identifier for logging
            
        Returns:
            Dict[str, Any]: Complete response with test_cases, context_used, metadata
        """
        start_time = datetime.now()
        request_id = None
        
        try:
            logger.info(f"Generating test cases for API: {api_name}")
            
            # Set default user_id
            if user_id is None:
                user_id = "anonymous"
            
            # Validate inputs
            validation_result = self._validate_inputs(api_name, requirements)
            if not validation_result["valid"]:
                return self._create_error_response(
                    api_name, requirements, validation_result["error"], request_id
                )
            
            # Step 1: Log test case generation request
            session_info = {
                "timestamp": start_time.isoformat(),
                "user_id": user_id,
                "api_name": api_name,
                "requirements_length": len(requirements)
            }
            request_id = self.search_logger.log_test_case_request(
                user_id=user_id,
                api_name=api_name,
                requirements=requirements,
                timestamp=start_time,
                session_info=session_info
            )
            
            # Step 2: Retrieve API context
            context_start = datetime.now()
            api_context = self.retrieve_api_context(api_name)
            context_time = (datetime.now() - context_start).total_seconds()
            
            # Step 3: Build test case prompt
            prompt_start = datetime.now()
            if api_context:
                logger.info(f"Found API context: {len(api_context)} characters")
                prompt = self.build_test_case_prompt(api_context, requirements, use_context=True)
            else:
                logger.info("No API context found, generating test cases from requirements only")
                prompt = self.build_test_case_prompt("", requirements, use_context=False)
            prompt_time = (datetime.now() - prompt_start).total_seconds()
            
            # Step 4: Generate test cases using Claude
            generation_start = datetime.now()
            response = self.claude_client.generate_with_custom_prompt(
                user_message=requirements,
                context=api_context or "",
                system_prompt=self.SYSTEM_TEMPLATE
            )
            generation_time = (datetime.now() - generation_start).total_seconds()
            
            # Debug: Log the response structure
            logger.info(f"Claude response keys: {list(response.keys())}")
            logger.info(f"Claude response content length: {len(response.get('content', ''))}")
            if response.get('content'):
                logger.info(f"Claude response preview: {response.get('content', '')[:200]}...")
            else:
                logger.warning("Claude returned empty content")
            
            # Step 5: Parse and validate test cases
            parsing_start = datetime.now()
            parsed_test_cases = self.parse_and_validate_test_cases(response.get("content", ""))
            parsing_time = (datetime.now() - parsing_start).total_seconds()
            
            # Step 6: Build final response
            total_time = (datetime.now() - start_time).total_seconds()
            final_response = {
                "test_cases": response.get("content", ""),
                "parsed_test_cases": parsed_test_cases,
                "context_used": api_context,
                "metadata": {
                    "api_name": api_name,
                    "requirements": requirements,
                    "context_found": bool(api_context),
                    "context_length": len(api_context) if api_context else 0,
                    "test_cases_length": len(response.get("content", "")),
                    "parsed_scenarios": len(parsed_test_cases),
                    "processing_times": {
                        "total_time": total_time,
                        "context_retrieval_time": context_time,
                        "prompt_building_time": prompt_time,
                        "generation_time": generation_time,
                        "parsing_time": parsing_time
                    },
                    "timestamp": datetime.now().isoformat(),
                    "request_id": request_id,
                    "model": response.get("metadata", {}).get("model", "unknown")
                }
            }
            
            # Step 7: Log test case generation response
            self.search_logger.log_test_case_response(request_id, final_response, final_response["metadata"])
            
            logger.info(f"Test case generation completed in {total_time:.2f}s")
            return final_response
            
        except Exception as e:
            logger.error(f"Test case generation failed: {e}")
            
            # Log error
            if request_id:
                error_context = {
                    "api_name": api_name,
                    "requirements": requirements,
                    "user_id": user_id,
                    "stage": "test_case_generation"
                }
                self.search_logger.log_test_case_error(request_id, e, error_context)
            
            return self._create_error_response(api_name, requirements, str(e), request_id)
    
    def retrieve_api_context(self, api_name: str, context_chunks: int = None) -> str:
        """
        Use RAGPipeline to search for API-related chunks.
        
        Args:
            api_name: Name of the API to search for
            context_chunks: Number of chunks to retrieve (default from config)
            
        Returns:
            str: Context string with all API information, or empty string if none found
        """
        try:
            if context_chunks is None:
                context_chunks = self.default_context_chunks
            
            logger.info(f"Retrieving context for API: {api_name} (max {context_chunks} chunks)")
            
            # Strategy 1: Try metadata filtering first (most efficient)
            try:
                # Use semantic search with API name as query
                search_results = self.rag_pipeline.get_search_results_only(
                    query=api_name,
                    top_k=context_chunks * 2  # Get more to account for filtering
                )
                
                # Filter by primary_topic if available
                api_results = []
                for result in search_results:
                    # Check both primary_topic and topic fields
                    primary_topic = result.get('primary_topic') or result.get('topic', '')
                    if primary_topic and api_name.lower() in primary_topic.lower():
                        api_results.append(result)
                
                # If we found results with metadata filtering, use them
                if api_results:
                    logger.info(f"Found {len(api_results)} API-specific chunks using metadata filtering")
                    # Limit to requested number of chunks
                    api_results = api_results[:context_chunks]
                    return self.rag_pipeline.context_builder.build_context(api_results, api_name)
                
            except Exception as e:
                logger.warning(f"Metadata filtering failed: {e}, falling back to semantic search")
            
            # Strategy 2: Fallback to semantic search only
            search_results = self.rag_pipeline.get_search_results_only(
                query=api_name,
                top_k=context_chunks
            )
            
            if not search_results:
                logger.info(f"No search results found for API: {api_name}")
                return ""
            
            # Build context from all search results
            context = self.rag_pipeline.context_builder.build_context(search_results, api_name)
            logger.info(f"Built context from {len(search_results)} semantic search results")
            
            return context
            
        except Exception as e:
            logger.error(f"Failed to retrieve API context: {e}")
            return ""
    
    def build_test_case_prompt(self, api_context: str, requirements: str, use_context: bool = True) -> str:
        """
        Combine system template, API context, and requirements.
        
        Args:
            api_context: Retrieved API context (can be empty)
            requirements: New requirements for the API
            use_context: Whether to include context in the prompt
            
        Returns:
            str: Complete prompt string
        """
        if use_context and api_context:
            prompt = f"""System: {self.SYSTEM_TEMPLATE}

Existing API Context:
{api_context}

New Requirements:
{requirements}

Please generate test cases in Gherkin format that cover both the existing API behavior and the new requirements."""
        else:
            prompt = f"""System: {self.SYSTEM_TEMPLATE}

New Requirements:
{requirements}

Please generate test cases in Gherkin format based on the provided requirements."""
        
        logger.debug(f"Built prompt with {len(prompt)} characters")
        return prompt
    
    def parse_and_validate_test_cases(self, raw_response: str) -> List[Dict]:
        """
        Parse generated test cases (Gherkin format).
        
        Args:
            raw_response: Raw response from Claude
            
        Returns:
            List[Dict]: Structured list of test cases
        """
        try:
            if not raw_response or not raw_response.strip():
                return []
            
            # Basic Gherkin parsing
            scenarios = []
            current_scenario = None
            current_feature = None
            
            lines = raw_response.split('\n')
            
            for line in lines:
                line = line.strip()
                
                # Skip empty lines
                if not line:
                    continue
                
                # Feature line
                if line.startswith('Feature:'):
                    current_feature = line.replace('Feature:', '').strip()
                    continue
                
                # Scenario line
                if line.startswith('Scenario:'):
                    # Save previous scenario if exists
                    if current_scenario:
                        scenarios.append(current_scenario)
                    
                    # Start new scenario
                    scenario_name = line.replace('Scenario:', '').strip()
                    current_scenario = {
                        'feature': current_feature or 'Unknown Feature',
                        'scenario': scenario_name,
                        'steps': []
                    }
                    continue
                
                # Steps (Given, When, Then, And, But)
                if line.startswith(('Given ', 'When ', 'Then ', 'And ', 'But ')):
                    if current_scenario:
                        step_type = line.split()[0]
                        step_text = ' '.join(line.split()[1:])
                        current_scenario['steps'].append({
                            'type': step_type,
                            'text': step_text
                        })
            
            # Add the last scenario
            if current_scenario:
                scenarios.append(current_scenario)
            
            logger.info(f"Parsed {len(scenarios)} test scenarios")
            return scenarios
            
        except Exception as e:
            logger.error(f"Failed to parse test cases: {e}")
            return []
    
    def get_system_template(self) -> str:
        """
        Return the test case generation system prompt.
        
        Returns:
            str: System template for test case generation
        """
        return self.SYSTEM_TEMPLATE
    
    def _validate_inputs(self, api_name: str, requirements: str) -> Dict[str, Any]:
        """
        Validate input parameters.
        
        Args:
            api_name: API name to validate
            requirements: Requirements to validate
            
        Returns:
            Dict[str, Any]: Validation result with 'valid' boolean and optional 'error' message
        """
        if not api_name or not api_name.strip():
            return {"valid": False, "error": "API name cannot be empty"}
        
        if len(api_name.strip()) < 2:
            return {"valid": False, "error": "API name too short (minimum 2 characters)"}
        
        if not requirements or not requirements.strip():
            return {"valid": False, "error": "Requirements cannot be empty"}
        
        if len(requirements.strip()) < self.min_requirements_length:
            return {"valid": False, "error": f"Requirements too short (minimum {self.min_requirements_length} characters)"}
        
        if len(api_name) > 100:
            return {"valid": False, "error": "API name too long (maximum 100 characters)"}
        
        if len(requirements) > 5000:
            return {"valid": False, "error": "Requirements too long (maximum 5000 characters)"}
        
        return {"valid": True}
    
    def _create_error_response(self, api_name: str, requirements: str, error_message: str, request_id: str) -> Dict[str, Any]:
        """
        Create error response for test case generation.
        
        Args:
            api_name: API name
            requirements: Requirements
            error_message: Error message
            request_id: Request ID (can be None)
            
        Returns:
            Dict[str, Any]: Error response
        """
        return {
            "test_cases": f"Sorry, I encountered an error while generating test cases: {error_message}",
            "parsed_test_cases": [],
            "context_used": "",
            "metadata": {
                "api_name": api_name,
                "requirements": requirements,
                "context_found": False,
                "context_length": 0,
                "test_cases_length": 0,
                "parsed_scenarios": 0,
                "error": True,
                "error_message": error_message,
                "timestamp": datetime.now().isoformat(),
                "request_id": request_id
            }
        }


# Example usage and testing
def main():
    """Demonstrate test case generator functionality."""
    print("=== Test Case Generator Demo ===\n")
    
    try:
        # Initialize RAG pipeline
        print("🔄 Initializing RAGPipeline...")
        from rag_pipeline import RAGPipeline
        rag_pipeline = RAGPipeline()
        
        # Initialize test case generator
        print("🔄 Initializing TestCaseGenerator...")
        test_case_generator = TestCaseGenerator(rag_pipeline)
        
        # Test API context retrieval
        print("\n🔍 Testing API context retrieval...")
        api_name = "FinalizeSaleAPI"
        context = test_case_generator.retrieve_api_context(api_name, context_chunks=5)
        
        if context:
            print(f"   ✅ Found API context: {len(context)} characters")
            print(f"   📄 Context preview: {context[:200]}...")
        else:
            print(f"   ⚠️  No context found for API: {api_name}")
        
        # Test test case generation
        print(f"\n🧪 Testing test case generation...")
        requirements = """
        - Add validation for credit card expiration date
        - Implement retry logic for failed payment processing
        - Add support for subscription trial periods
        - Include fraud detection checks
        """
        
        response = test_case_generator.generate_test_cases(
            api_name=api_name,
            requirements=requirements,
            user_id="demo_user"
        )
        
        print(f"\n📄 Generated Test Cases:")
        print("=" * 60)
        print(response['test_cases'])
        print("=" * 60)
        
        # Show metadata
        metadata = response['metadata']
        print(f"\n📊 Generation Metadata:")
        print(f"   🎯 API: {metadata['api_name']}")
        print(f"   📝 Context found: {metadata['context_found']}")
        print(f"   📏 Context length: {metadata['context_length']} characters")
        print(f"   🧪 Test cases length: {metadata['test_cases_length']} characters")
        print(f"   📋 Parsed scenarios: {metadata['parsed_scenarios']}")
        print(f"   ⏱️  Total time: {metadata['processing_times']['total_time']:.2f}s")
        
        # Show parsed test cases
        if response['parsed_test_cases']:
            print(f"\n🔍 Parsed Test Scenarios:")
            for i, scenario in enumerate(response['parsed_test_cases'], 1):
                print(f"   {i}. {scenario['scenario']} ({len(scenario['steps'])} steps)")
        
        print(f"\n✅ TestCaseGenerator demo completed!")
        print(f"   🧪 Generates test cases in Gherkin format")
        print(f"   🔍 Retrieves API context using metadata filtering")
        print(f"   📝 Handles requirements-only generation")
        print(f"   📊 Provides comprehensive logging")
        
    except Exception as e:
        print(f"❌ Demo failed: {e}")
        print("\nMake sure all RAG components are properly configured")


if __name__ == "__main__":
    main()
