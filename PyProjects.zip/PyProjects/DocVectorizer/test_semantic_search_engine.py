"""
Test script for SemanticSearchEngine

This script tests the SemanticSearchEngine with a mock query vector to ensure
the search functionality works correctly with the existing Pinecone infrastructure.
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from semantic_search_engine import SemanticSearchEngine
from pinecone_vector_store_manager import PineconeVectorStoreManager
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def test_semantic_search():
    """Test the SemanticSearchEngine with a mock query vector."""
    print("=== Testing SemanticSearchEngine ===\n")
    
    try:
        # Initialize components
        print("🔄 Initializing components...")
        search_engine = SemanticSearchEngine()
        
        # Create a mock query vector (1536 dimensions for text-embedding-3-small)
        print("🔄 Creating mock query vector...")
        mock_query_vector = [0.1] * 1536
        
        # Test validation
        print("🧪 Testing query vector validation...")
        is_valid = search_engine.validate_query_vector(mock_query_vector)
        print(f"   Query vector validation: {'✅ PASS' if is_valid else '❌ FAIL'}")
        
        # Test search (will return empty results if no vectors in index)
        print("🔍 Testing search functionality...")
        results = search_engine.search(mock_query_vector, top_k=5)
        print(f"   Search results: {len(results)} found")
        
        # Test filtered search
        print("🔍 Testing filtered search...")
        filters = {"topic": "test"}
        filtered_results = search_engine.search_with_filters(
            mock_query_vector, 
            metadata_filters=filters, 
            top_k=5
        )
        print(f"   Filtered search results: {len(filtered_results)} found")
        
        # Test search stats
        print("📊 Testing search stats...")
        stats = search_engine.get_search_stats()
        print(f"   Search stats retrieved: {'✅ PASS' if 'search_engine' in stats else '❌ FAIL'}")
        print(f"   Index name: {stats.get('index_name', 'N/A')}")
        print(f"   Total vectors: {stats.get('total_vectors', 0)}")
        print(f"   Index fullness: {stats.get('index_fullness', 0):.2%}")
        print(f"   Dimension: {stats.get('dimension', 'N/A')}")
        print(f"   Metric: {stats.get('metric', 'N/A')}")
        
        print("\n✅ All tests completed successfully!")
        print("   🔍 Search methods working")
        print("   📊 Statistics accessible")
        print("   🧪 Validation working")
        print("   🎯 Ready for RAGPipeline integration")
        
        return True
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        logger.error(f"Test error: {e}")
        return False


if __name__ == "__main__":
    success = test_semantic_search()
    sys.exit(0 if success else 1)
