#!/usr/bin/env python3
"""
RAG Pipeline Test Script

This script demonstrates the complete RAG pipeline functionality.
"""

import os
import sys
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Add current directory to path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from rag_pipeline import RAGPipeline


def test_rag_pipeline():
    """Test the complete RAG pipeline."""
    print("=== RAG Pipeline Test ===\n")
    
    try:
        # Initialize pipeline
        print("🔄 Initializing RAG Pipeline...")
        pipeline = RAGPipeline()
        print("✅ Pipeline initialized successfully!")
        
        # Test pipeline stats
        print("\n📊 Pipeline Statistics:")
        stats = pipeline.get_pipeline_stats()
        
        index_stats = stats.get('index_stats', {})
        print(f"   📂 Index Name: {index_stats.get('index_name', 'Unknown')}")
        print(f"   📊 Total Vectors: {index_stats.get('total_vectors', 0)}")
        print(f"   📈 Index Fullness: {index_stats.get('index_fullness', 0):.2%}")
        
        pipeline_config = stats.get('pipeline_config', {})
        print(f"   ⚙️  Max Context Tokens: {pipeline_config.get('max_context_tokens', 0)}")
        print(f"   🔍 Default Top-K: {pipeline_config.get('default_top_k', 0)}")
        
        # Test query validation
        print("\n✅ Testing Query Validation:")
        test_queries = [
            ("What are the API security requirements?", True),
            ("", False),
            ("a", False),
            ("How do I configure authentication?", True)
        ]
        
        for query, expected_valid in test_queries:
            is_valid, error = pipeline.validate_query(query)
            status = "✅" if is_valid == expected_valid else "❌"
            print(f"   {status} '{query[:30]}...': {'Valid' if is_valid else 'Invalid - ' + error}")
        
        # Test search results only
        print("\n🔍 Testing Search Results:")
        search_results = pipeline.get_search_results_only("API security", top_k=3)
        print(f"   Found {len(search_results)} search results")
        
        if search_results:
            print("   Sample results:")
            for i, result in enumerate(search_results[:2]):
                print(f"     [{i+1}] Score: {result.get('score', 0):.3f}")
                print(f"         Topic: {result.get('topic', 'Unknown')}")
                print(f"         Content: {result.get('content', '')[:80]}...")
                print()
        
        # Test full query processing
        if search_results:
            print("💬 Testing Full Query Processing:")
            test_query = "What are the main API security requirements?"
            
            response = pipeline.answer_query(
                query=test_query,
                user_id="test_user",
                top_k=5
            )
            
            print(f"   Query: {test_query}")
            print(f"   Answer: {response.get('answer', 'No answer')[:200]}...")
            print(f"   Sources: {len(response.get('sources', []))}")
            
            metadata = response.get('metadata', {})
            print(f"   Processing Time: {metadata.get('total_time', 0):.2f}s")
            print(f"   Chunks Retrieved: {metadata.get('chunks_retrieved', 0)}")
            print(f"   Context Tokens: {metadata.get('context_tokens', 0)}")
            
            if metadata.get('error'):
                print(f"   ⚠️  Error: {metadata.get('error_message', 'Unknown error')}")
        
        print(f"\n🎉 RAG Pipeline Test Completed Successfully!")
        print(f"   ✅ All components initialized")
        print(f"   ✅ Query validation working")
        print(f"   ✅ Search functionality operational")
        print(f"   ✅ End-to-end processing functional")
        
        return True
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        print(f"\n💡 Make sure all required environment variables are set:")
        print(f"   - PINECONE_API_KEY")
        print(f"   - PINECONE_ENVIRONMENT") 
        print(f"   - OPENAI_API_KEY")
        print(f"   - ANTHROPIC_API_KEY")
        return False


def main():
    """Main test function."""
    print("Starting RAG Pipeline Test...")
    print("=" * 50)
    
    success = test_rag_pipeline()
    
    print("=" * 50)
    if success:
        print("🎉 All tests passed! RAG Pipeline is ready to use.")
    else:
        print("❌ Tests failed. Please check configuration and try again.")
    
    return success


if __name__ == "__main__":
    main()
