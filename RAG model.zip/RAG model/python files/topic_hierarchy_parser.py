import json
import os
from typing import Dict, List, Set, Optional
from pathlib import Path

class TopicHierarchyParser:
    """
    A class to parse topic hierarchies and extract parent-child relationships
    for enriching RAG model metadata.
    """
    
    def __init__(self, hierarchy_file_path: Optional[str] = None, hierarchy_dict: Optional[Dict] = None):
        """
        Initialize the parser with topic hierarchy data.
        
        Args:
            hierarchy_file_path: Path to JSON file containing topic hierarchy
            hierarchy_dict: Direct dictionary containing topic hierarchy
        """
        if hierarchy_file_path:
            self.hierarchy = self._load_hierarchy_from_file(hierarchy_file_path)
        elif hierarchy_dict:
            self.hierarchy = hierarchy_dict
        else:
            raise ValueError("Either hierarchy_file_path or hierarchy_dict must be provided")
        
        # Build reverse mapping for efficient parent lookup
        self.child_to_parent = self._build_child_to_parent_mapping()
    
    def _load_hierarchy_from_file(self, file_path: str) -> Dict:
        """Load topic hierarchy from JSON file."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            raise FileNotFoundError(f"Hierarchy file not found: {file_path}")
        except json.JSONDecodeError:
            raise ValueError(f"Invalid JSON format in file: {file_path}")
    
    def _build_child_to_parent_mapping(self) -> Dict[str, str]:
        """Build a reverse mapping from child to parent for efficient lookups."""
        child_to_parent = {}
        
        for parent, children in self.hierarchy.items():
            if isinstance(children, list):
                for child in children:
                    child_to_parent[child] = parent
        
        return child_to_parent
    
    def get_all_parents(self, topic: str) -> List[str]:
        """
        Get all parents of a topic, from immediate parent to root.
        
        Args:
            topic: The topic to find parents for
            
        Returns:
            List of parent topics ordered from immediate parent to root
        """
        parents = []
        current_topic = topic
        
        while current_topic in self.child_to_parent:
            parent = self.child_to_parent[current_topic]
            parents.append(parent)
            current_topic = parent
        
        return parents
    
    def get_direct_children(self, topic: str) -> List[str]:
        """
        Get direct children (one level down) of a topic.
        
        Args:
            topic: The topic to find children for
            
        Returns:
            List of direct child topics
        """
        return self.hierarchy.get(topic, [])
    
    def get_topic_metadata(self, topic: str) -> Dict[str, List[str]]:
        """
        Get comprehensive metadata for a topic including all parents and direct children.
        
        Args:
            topic: The topic to analyze
            
        Returns:
            Dictionary containing parents, children, and all related topics
        """
        parents = self.get_all_parents(topic)
        children = self.get_direct_children(topic)
        
        # Combine all related topics (excluding the topic itself)
        all_related = list(set(parents + children))
        
        metadata = {
            'topic': topic,
            'parents': parents,
            'children': children,
            'all_related_topics': all_related,
            'hierarchy_path': parents[::-1] + [topic],  # Root to current topic
            'depth_level': len(parents)
        }
        
        return metadata
    
    def topic_exists(self, topic: str) -> bool:
        """Check if a topic exists in the hierarchy."""
        return (topic in self.hierarchy or 
                topic in self.child_to_parent)
    
    def get_root_topics(self) -> List[str]:
        """Get all root topics (topics that are not children of any other topic)."""
        all_children = set(self.child_to_parent.keys())
        all_parents = set(self.hierarchy.keys())
        return list(all_parents - all_children)
    
    def get_leaf_topics(self) -> List[str]:
        """Get all leaf topics (topics that have no children)."""
        topics_with_children = set(self.hierarchy.keys())
        all_topics = set(list(self.hierarchy.keys()) + list(self.child_to_parent.keys()))
        return list(all_topics - topics_with_children)


def load_hierarchy_from_env() -> Dict:
    """
    Load topic hierarchy from environment variable or file path specified in .env
    """
    from dotenv import load_dotenv
    
    # Load .env file
    load_dotenv()
    
    # Try to get hierarchy file path from environment
    hierarchy_file = os.getenv('TOPIC_HIERARCHY_FILE')
    
    if hierarchy_file and Path(hierarchy_file).exists():
        with open(hierarchy_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    else:
        # Fallback to direct JSON string in environment (not recommended for large hierarchies)
        hierarchy_json = os.getenv('TOPIC_HIERARCHY_JSON')
        if hierarchy_json:
            return json.loads(hierarchy_json)
        else:
            raise ValueError("No topic hierarchy found in environment variables")


# Example usage and testing
def main():
    # Sample topic hierarchy (as provided)
    sample_hierarchy = {
        "Brands": [
            "LEX",
            "CRCOM", 
            "CCOM"
        ],
        "LEX": [
            "BrandScope",
            "SignUP",
            "CreditReportPullProcess",
            "SubscriptionManagement",
            "WalletManagement",
            "CreditRepairProcess"
        ],
        "SignUP": [
            "CreateCustomerAPI",
            "CreateSubscriptionAPI",
            "CreateWalletAPI",
            "FinalizeSaleAPI"
        ],
        "FinalizeSaleAPI": [
            "APIscope",
            "ExternalAPICalls",
            "DBInteraction",
            "APISecurity"
        ]
    }
    
    # Initialize parser with sample data
    parser = TopicHierarchyParser(hierarchy_dict=sample_hierarchy)
    
    # Test with different topics
    test_topics = ["APIscope", "FinalizeSaleAPI", "SignUP", "LEX", "Brands"]
    
    for topic in test_topics:
        if parser.topic_exists(topic):
            metadata = parser.get_topic_metadata(topic)
            print(f"\n=== Metadata for '{topic}' ===")
            print(f"Parents (immediate to root): {metadata['parents']}")
            print(f"Direct Children: {metadata['children']}")
            print(f"All Related Topics: {metadata['all_related_topics']}")
            print(f"Hierarchy Path: {' -> '.join(metadata['hierarchy_path'])}")
            print(f"Depth Level: {metadata['depth_level']}")
        else:
            print(f"Topic '{topic}' not found in hierarchy")
    
    # Display hierarchy statistics
    print(f"\n=== Hierarchy Statistics ===")
    print(f"Root topics: {parser.get_root_topics()}")
    print(f"Leaf topics: {parser.get_leaf_topics()}")


if __name__ == "__main__":
    main()
