import json
import os
from typing import Dict, List, Set, Optional, Union
from pathlib import Path
import threading
from functools import lru_cache

class SingletonMeta(type):
    """
    Thread-safe Singleton metaclass to ensure only one instance exists.
    """
    _instances = {}
    _lock: threading.Lock = threading.Lock()
    
    def __call__(cls, *args, **kwargs):
        with cls._lock:
            if cls not in cls._instances:
                instance = super().__call__(*args, **kwargs)
                cls._instances[cls] = instance
        return cls._instances[cls]


class TopicHierarchyManager(metaclass=SingletonMeta):
    """
    Singleton manager for topic hierarchies that loads once and persists throughout application lifecycle.
    Automatically loads all JSON files from directory specified in .env file.
    """
    
    def __init__(self):
        """Initialize the manager only once (Singleton pattern)."""
        if hasattr(self, '_initialized'):
            return
        
        self._initialized = True
        self.hierarchies = {}
        self.child_to_parent_mappings = {}
        self.topic_to_hierarchy_map = {}
        self._load_lock = threading.Lock()
        
        # Load hierarchies from .env configuration
        self._load_hierarchies_from_env()
    
    def _load_hierarchies_from_env(self):
        """Load all hierarchies from directory specified in .env file."""
        try:
            from dotenv import load_dotenv
            load_dotenv()
            
            # Get hierarchy directory from .env file
            hierarchy_dir = os.getenv('TOPIC_HIERARCHY_DIRECTORY')
            if not hierarchy_dir:
                print("Warning: TOPIC_HIERARCHY_DIRECTORY not found in .env file")
                return
            
            directory = Path(hierarchy_dir)
            if not directory.exists():
                print(f"Warning: Hierarchy directory not found: {hierarchy_dir}")
                return
            
            print(f"Loading topic hierarchies from: {hierarchy_dir}")
            
            # Load all JSON files from the directory
            json_files = list(directory.glob("*.json"))
            if not json_files:
                print(f"Warning: No JSON files found in {hierarchy_dir}")
                return
            
            for json_file in json_files:
                hierarchy_name = json_file.stem  # filename without extension
                try:
                    with open(json_file, 'r', encoding='utf-8') as f:
                        hierarchy_data = json.load(f)
                    
                    self._add_hierarchy(hierarchy_name, hierarchy_data)
                    print(f"✓ Loaded hierarchy: {hierarchy_name}")
                    
                except (json.JSONDecodeError, FileNotFoundError) as e:
                    print(f"✗ Failed to load {json_file}: {e}")
            
            print(f"Successfully loaded {len(self.hierarchies)} hierarchies")
            
        except ImportError:
            print("Warning: python-dotenv not installed. Install with: pip install python-dotenv")
        except Exception as e:
            print(f"Error loading hierarchies: {e}")
    
    def _add_hierarchy(self, hierarchy_name: str, hierarchy_data: Dict):
        """Add a hierarchy and build its mappings."""
        self.hierarchies[hierarchy_name] = hierarchy_data
        self._build_mappings_for_hierarchy(hierarchy_name, hierarchy_data)
    
    def _build_mappings_for_hierarchy(self, hierarchy_name: str, hierarchy_data: Dict):
        """Build reverse mapping for a specific hierarchy."""
        child_to_parent = {}
        
        for parent, children in hierarchy_data.items():
            # Map topic to hierarchy
            self.topic_to_hierarchy_map[parent] = hierarchy_name
            
            if isinstance(children, list):
                for child in children:
                    child_to_parent[child] = parent
                    self.topic_to_hierarchy_map[child] = hierarchy_name
        
        self.child_to_parent_mappings[hierarchy_name] = child_to_parent
    
    def reload_hierarchies(self):
        """
        Reload all hierarchies from the directory.
        Useful if hierarchy files are updated during runtime.
        """
        with self._load_lock:
            print("Reloading topic hierarchies...")
            self.hierarchies.clear()
            self.child_to_parent_mappings.clear()
            self.topic_to_hierarchy_map.clear()
            self._load_hierarchies_from_env()
    
    def add_hierarchy_runtime(self, hierarchy_name: str, hierarchy_data: Dict, overwrite: bool = False):
        """
        Add a hierarchy at runtime (useful for testing or dynamic hierarchies).
        """
        with self._load_lock:
            if hierarchy_name in self.hierarchies and not overwrite:
                raise ValueError(f"Hierarchy '{hierarchy_name}' already exists. Use overwrite=True to replace.")
            
            self._add_hierarchy(hierarchy_name, hierarchy_data)
            print(f"Added hierarchy at runtime: {hierarchy_name}")
    
    def find_topic_hierarchy(self, topic: str) -> Optional[str]:
        """Find which hierarchy contains the given topic."""
        return self.topic_to_hierarchy_map.get(topic)
    
    def get_all_parents(self, topic: str, hierarchy_name: Optional[str] = None) -> List[str]:
        """Get all parents of a topic."""
        if hierarchy_name is None:
            hierarchy_name = self.find_topic_hierarchy(topic)
            if hierarchy_name is None:
                return []
        
        if hierarchy_name not in self.child_to_parent_mappings:
            return []
        
        parents = []
        current_topic = topic
        child_to_parent = self.child_to_parent_mappings[hierarchy_name]
        
        while current_topic in child_to_parent:
            parent = child_to_parent[current_topic]
            parents.append(parent)
            current_topic = parent
        
        return parents
    
    def get_direct_children(self, topic: str, hierarchy_name: Optional[str] = None) -> List[str]:
        """Get direct children of a topic."""
        if hierarchy_name is None:
            hierarchy_name = self.find_topic_hierarchy(topic)
            if hierarchy_name is None:
                return []
        
        if hierarchy_name not in self.hierarchies:
            return []
        
        return self.hierarchies[hierarchy_name].get(topic, [])
    
    def get_topic_metadata(self, topic: str, hierarchy_name: Optional[str] = None) -> Dict:
        """Get comprehensive metadata for a topic."""
        if hierarchy_name is None:
            hierarchy_name = self.find_topic_hierarchy(topic)
        
        if hierarchy_name is None:
            return {
                'topic': topic,
                'hierarchy': None,
                'parents': [],
                'children': [],
                'all_related_topics': [],
                'hierarchy_path': [topic],
                'depth_level': 0,
                'exists': False
            }
        
        parents = self.get_all_parents(topic, hierarchy_name)
        children = self.get_direct_children(topic, hierarchy_name)
        
        return {
            'topic': topic,
            'hierarchy': hierarchy_name,
            'parents': parents,
            'children': children,
            'all_related_topics': list(set(parents + children)),
            'hierarchy_path': parents[::-1] + [topic],
            'depth_level': len(parents),
            'exists': True
        }
    
    @lru_cache(maxsize=1000)
    def get_topic_metadata_cached(self, topic: str, hierarchy_name: Optional[str] = None) -> tuple:
        """
        Cached version of get_topic_metadata for frequently accessed topics.
        Returns tuple instead of dict for hashability (LRU cache requirement).
        """
        metadata = self.get_topic_metadata(topic, hierarchy_name)
        return (
            metadata['topic'],
            metadata['hierarchy'],
            tuple(metadata['parents']),
            tuple(metadata['children']),
            tuple(metadata['all_related_topics']),
            tuple(metadata['hierarchy_path']),
            metadata['depth_level'],
            metadata['exists']
        )
    
    def get_cross_hierarchy_topics(self, topics: List[str]) -> Dict[str, any]:
        """Get metadata for multiple topics that may span different hierarchies."""
        results = {}
        hierarchy_groups = {}
        
        for topic in topics:
            metadata = self.get_topic_metadata(topic)
            results[topic] = metadata
            
            # Group by hierarchy for analysis
            hierarchy = metadata['hierarchy']
            if hierarchy:
                if hierarchy not in hierarchy_groups:
                    hierarchy_groups[hierarchy] = []
                hierarchy_groups[hierarchy].append(topic)
        
        # Collect all related topics across hierarchies
        all_related_topics = set()
        for metadata in results.values():
            all_related_topics.update(metadata['all_related_topics'])
            all_related_topics.add(metadata['topic'])
        
        return {
            'individual_topics': results,
            'hierarchy_groups': hierarchy_groups,
            'all_related_topics': list(all_related_topics),
            'hierarchies_involved': list(hierarchy_groups.keys())
        }
    
    def list_hierarchies(self) -> List[str]:
        """List all available hierarchy names."""
        return list(self.hierarchies.keys())
    
    def get_hierarchy_stats(self) -> Dict:
        """Get statistics about all hierarchies."""
        stats = {}
        
        for hierarchy_name, hierarchy_data in self.hierarchies.items():
            all_topics = set(hierarchy_data.keys())
            for children in hierarchy_data.values():
                if isinstance(children, list):
                    all_topics.update(children)
            
            child_to_parent = self.child_to_parent_mappings.get(hierarchy_name, {})
            root_topics = set(hierarchy_data.keys()) - set(child_to_parent.keys())
            leaf_topics = all_topics - set(hierarchy_data.keys())
            
            stats[hierarchy_name] = {
                'total_topics': len(all_topics),
                'parent_topics': len(hierarchy_data.keys()),
                'root_topics': list(root_topics),
                'leaf_topics': list(leaf_topics),
                'max_depth': self._calculate_max_depth(hierarchy_name)
            }
        
        return stats
    
    def _calculate_max_depth(self, hierarchy_name: str) -> int:
        """Calculate the maximum depth of a hierarchy."""
        if hierarchy_name not in self.child_to_parent_mappings:
            return 0
        
        child_to_parent = self.child_to_parent_mappings[hierarchy_name]
        max_depth = 0
        
        for topic in self.topic_to_hierarchy_map:
            if self.topic_to_hierarchy_map[topic] == hierarchy_name:
                depth = len(self.get_all_parents(topic, hierarchy_name))
                max_depth = max(max_depth, depth)
        
        return max_depth
    
    def clear_cache(self):
        """Clear the LRU cache for metadata lookups."""
        self.get_topic_metadata_cached.cache_clear()
    
    def get_cache_stats(self) -> Dict:
        """Get statistics about the metadata cache."""
        cache_info = self.get_topic_metadata_cached.cache_info()
        return {
            'hits': cache_info.hits,
            'misses': cache_info.misses,
            'maxsize': cache_info.maxsize,
            'currsize': cache_info.currsize,
            'hit_rate': cache_info.hits / (cache_info.hits + cache_info.misses) if (cache_info.hits + cache_info.misses) > 0 else 0
        }


# Convenience functions for easy access (recommended usage pattern)
def get_topic_hierarchy_manager() -> TopicHierarchyManager:
    """
    Get the singleton instance of TopicHierarchyManager.
    This is the recommended way to access the hierarchy manager.
    """
    return TopicHierarchyManager()


def get_topic_metadata(topic: str) -> Dict:
    """Convenience function to get topic metadata."""
    manager = get_topic_hierarchy_manager()
    return manager.get_topic_metadata(topic)


def get_enriched_topics(topics: List[str]) -> List[str]:
    """
    Convenience function to get all related topics for RAG enrichment.
    Takes a list of original topics and returns expanded list with all related topics.
    """
    manager = get_topic_hierarchy_manager()
    cross_analysis = manager.get_cross_hierarchy_topics(topics)
    return cross_analysis['all_related_topics']


# Backward compatibility wrapper
class TopicHierarchyParser:
    """
    Backward compatibility wrapper that uses the singleton manager.
    This maintains the original interface while using the optimized singleton approach.
    """
    
    def __init__(self, hierarchy_file_path: Optional[str] = None, hierarchy_dict: Optional[Dict] = None):
        """
        Initialize parser. Note: For production use, hierarchies should be loaded via .env configuration.
        This constructor is mainly for testing and backward compatibility.
        """
        self.manager = get_topic_hierarchy_manager()
        
        # For testing: add hierarchy at runtime if provided
        if hierarchy_file_path or hierarchy_dict:
            if hierarchy_file_path:
                with open(hierarchy_file_path, 'r', encoding='utf-8') as f:
                    hierarchy_dict = json.load(f)
            
            # Add as runtime hierarchy for testing
            self.manager.add_hierarchy_runtime("test_hierarchy", hierarchy_dict, overwrite=True)
    
    def get_all_parents(self, topic: str) -> List[str]:
        return self.manager.get_all_parents(topic)
    
    def get_direct_children(self, topic: str) -> List[str]:
        return self.manager.get_direct_children(topic)
    
    def get_topic_metadata(self, topic: str) -> Dict:
        return self.manager.get_topic_metadata(topic)
    
    def topic_exists(self, topic: str) -> bool:
        return self.manager.find_topic_hierarchy(topic) is not None


# Example usage and configuration
def main():
    """
    Example usage showing the singleton pattern and .env configuration.
    """
    print("=== Topic Hierarchy Manager Demo ===")
    
    # Method 1: Get manager instance (recommended for production)
    manager = get_topic_hierarchy_manager()
    print(f"Loaded hierarchies: {manager.list_hierarchies()}")
    
    # Method 2: Use convenience functions
    metadata = get_topic_metadata("APIscope")
    print(f"\nMetadata for 'APIscope': {metadata}")
    
    # Method 3: Get enriched topics for RAG
    document_topics = ["APIscope", "SignUP"]
    enriched_topics = get_enriched_topics(document_topics)
    print(f"\nOriginal topics: {document_topics}")
    print(f"Enriched topics for RAG: {enriched_topics}")
    
    # Show cache statistics
    cache_stats = manager.get_cache_stats()
    print(f"\nCache statistics: {cache_stats}")
    
    # Show hierarchy statistics
    hierarchy_stats = manager.get_hierarchy_stats()
    print(f"\nHierarchy statistics:")
    for name, stats in hierarchy_stats.items():
        print(f"  {name}: {stats['total_topics']} topics, depth: {stats['max_depth']}")
    
    # Demonstrate singleton behavior
    manager2 = get_topic_hierarchy_manager()
    print(f"\nSingleton test - Same instance: {manager is manager2}")


if __name__ == "__main__":
    main()


# =====================================================
# Configuration Instructions
# =====================================================

# Add this to your .env file:
# TOPIC_HIERARCHY_DIRECTORY=./config/hierarchies

# Directory structure example:
# project/
# ├── .env
# ├── config/
# │   └── hierarchies/
# │       ├── brand_hierarchy.json
# │       ├── product_hierarchy.json
# │       └── technical_hierarchy.json
# └── main.py

# Usage in your RAG application:
# from topic_hierarchy_manager import get_topic_metadata, get_enriched_topics
# 
# # Get metadata for a single topic
# metadata = get_topic_metadata("APIscope")
# 
# # Get enriched topics for document
# document_topics = ["APIscope", "SignUP"]
# all_topics = get_enriched_topics(document_topics)
