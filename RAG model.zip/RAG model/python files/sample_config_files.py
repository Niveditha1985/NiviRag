# =====================================================
# .env file example
# =====================================================
# Place this content in your .env file

# Path to the topic hierarchy JSON file
TOPIC_HIERARCHY_FILE=./config/topic_hierarchy.json

# Alternative: Direct JSON string (not recommended for large hierarchies)
# TOPIC_HIERARCHY_JSON={"Brands": ["LEX", "CRCOM", "CCOM"], "LEX": ["BrandScope", "SignUP"]}

# =====================================================
# topic_hierarchy.json file example
# =====================================================
# Save this as ./config/topic_hierarchy.json

{
    "Brands": [
        "LEX",
        "CRCOM",
        "CCOM"
    ],
    "LEX": [
        "BrandScope",
        "SignUP",
        "CreditReportPullProcess",
        "SubscriptionManagement",
        "WalletManagement",
        "CreditRepairProcess"
    ],
    "SignUP": [
        "CreateCustomerAPI",
        "CreateSubscriptionAPI",
        "CreateWalletAPI",
        "FinalizeSaleAPI"
    ],
    "FinalizeSaleAPI": [
        "APIscope",
        "ExternalAPICalls",
        "DBInteraction",
        "APISecurity"
    ],
    "BrandScope": [
        "UserInterface",
        "DataAnalytics"
    ],
    "CreditReportPullProcess": [
        "CreditBureauAPI",
        "ReportProcessing"
    ]
}

# =====================================================
# Simple usage example
# =====================================================

from topic_hierarchy_parser import TopicHierarchyParser, load_hierarchy_from_env

# Method 1: Load from environment
try:
    hierarchy = load_hierarchy_from_env()
    parser = TopicHierarchyParser(hierarchy_dict=hierarchy)
except ValueError as e:
    print(f"Error loading from environment: {e}")
    # Fallback to direct file loading
    parser = TopicHierarchyParser(hierarchy_file_path="./config/topic_hierarchy.json")

# Method 2: Direct file loading
parser = TopicHierarchyParser(hierarchy_file_path="./config/topic_hierarchy.json")

# Method 3: Direct dictionary
sample_hierarchy = {
    "Brands": ["LEX", "CRCOM", "CCOM"],
    "LEX": ["SignUP", "BrandScope"]
}
parser = TopicHierarchyParser(hierarchy_dict=sample_hierarchy)

# Get metadata for RAG enrichment
topic = "APIscope"
metadata = parser.get_topic_metadata(topic)

# Use metadata to enrich your RAG documents
enriched_topics = [topic] + metadata['all_related_topics']
print(f"Original topic: {topic}")
print(f"Enriched topics for RAG: {enriched_topics}")
